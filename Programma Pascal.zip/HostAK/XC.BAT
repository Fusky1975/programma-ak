k:
copy \tp\prose\*.x T:\
dir c.bat
