pkzip   k:\tp\games3.zip K:\TP\83\GW83
REM Remember to include GW83 in the backup system!
pause
REM Remember to include 10 labels, game   83.00!
pause
pkzip   k:\tp\games3.zip K:\TP\83\GW83
final
