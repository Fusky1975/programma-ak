copy prose\*.x K:\
dir c.bat
