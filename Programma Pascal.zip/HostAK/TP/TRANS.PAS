program name;

uses crt,dos;

label 99;
{$I-}

type str255 = String[255];
     strptr = ^str255;
VAR oldf,newf,conf: file;
    succf: text;
    oldts,newts: Str255;
    b255: byte;
    bpos: integer;
    fp: longint;
    outf,tf: text;
    succname,oldname,tfname: string;
    carr: array[0..32000] of byte;
    time: longint;
    pass_start,fixed: boolean;
    ots,nts: Str255;


PROCEDURE Repl_String;
VAR tpos: integer;
    maybelen,oldlen: integer;
    actread: word;
    fp1,startfp,transfp: longint;
    samelen: boolean;
BEGIN
    samelen:= false;
    IF Pos('/',newts) = 1 THEN BEGIN
      Delete(newts,1,1);
      samelen:= true;
     END;
    tpos:= Length(newts);
    WHILE ((tpos > 0) and (newts[tpos] = '_')) DO BEGIN
      newts[tpos]:= ' ';
      Dec(tpos);
     END;
    tpos:= Length(oldts);
    WHILE ((tpos > 0) and (oldts[tpos] = '_')) DO BEGIN
      oldts[tpos]:= ' ';
      Dec(tpos);
     END;
    IF not samelen THEN
      WHILE Length(newts) < Length(oldts) DO newts:= Concat(newts,' ');
    startfp:= FilePos(oldf);
    oldlen:= Length(oldts);
    pass_start:= false;
    REPEAT
      fp1:= FilePos(oldf);
      BlockRead(oldf,carr[1],4096,actread);
      IF startfp = 0 THEN pass_start:= ((Eof(oldf)) or (actread < 4096))
        ELSE pass_start:= ((fp1 < startfp) and (FilePos(oldf)+1 >= startfp));
      carr[tpos-1]:= 0;
      tpos:= 1;
      REPEAT
        maybelen:= carr[tpos-1];
        carr[tpos-1]:= oldlen;
        IF oldts = Strptr(Addr(carr[tpos-1]))^ THEN BEGIN
          fixed:= true;
          Seek(oldf,fp1+tpos-1-ord((samelen) or (maybelen=oldlen)));
          transfp:= FilePos(oldf);
          IF ((samelen) or (maybelen = oldlen)) THEN BlockWrite(oldf,newts,Length(newts)+1)
            ELSE BlockWrite(oldf,newts[1],Length(newts));
          IF ParamCount < 2 THEN BEGIN
              WRITE(outf,'at file position ',fp1+tpos-2);
              IF ((samelen) or (maybelen = oldlen)) THEN WRITE(outf,' (including string-length byte) ');
              WRITELN(outf);
              WRITELN(outf);
             END
            ELSE WRITELN(fp1+tpos-2,': Replacement successful');
          IF ParamCount = 3 THEN BEGIN
            WRITELN(succf,ots);
            WRITELN(succf,nts);
            WRITELN(succf,'   ',transfp);
           END;
         END;
        Inc(tpos);
      UNTIL ((fixed) or (tpos > (actread-oldlen)));
      IF not ((fixed) or (pass_start)) THEN
        IF actread = 4096 THEN Seek(oldf,fp1 +4096-256)
          ELSE Seek(oldf,0);
    UNTIL ((fixed) or (pass_start));
    IF not fixed THEN BEGIN
      WRITELN(outf,'String not found!');
      WRITELN(outf);
     END;
 END;

PROCEDURE Error(s: str255);
BEGIN
  WRITELN(outf,'Error: ',s{, ' -> Press Return'}); delay(250);
{  readln;}
 END;

begin
  IF ParamCount = 0 THEN BEGIN
      WRITE('Which translation-instructions file to use?');
      READLN(tfname);
     END
    ELSE BEGIN
      tfname:= Paramstr(1);
      IF ParamCount >= 2 THEN Assign(outf,ParamStr(2))
        ELSE Assign(outf,'CON');
      REWRITE(outf);
      IF IOResult <> 0 THEN BEGIN
        WRITELN('Can''t open the output file!');
        GOTO 99;
       END;
     END;
  Assign(tf,tfname);
  RESET(tf);
  IF IOResult <> 0 THEN BEGIN
    WRITELN('Can''t open that file!');
    Close(outf);
    GOTO 99;
   END;
  READLN(tf,oldname);
  Assign(oldf,oldname);
  reset(oldf,1);
  IF IOResult <> 0 THEN BEGIN
    Close(tf);
    Close(outf);
    WRITELN('Can''t open ',oldname,'!');
    GOTO 99;
   END;
  IF ParamCount = 3 THEN BEGIN
    succname:= ParamStr(3);
    Assign(succf,succname);
    Append(succf);
    IF IOResult <> 0 THEN BEGIN
      REWRITE(succf);
      WRITELN(succf,oldname);
     END;
   END;
  GetFTime(oldf,time);
  REPEAT
    oldts:= '';
    Readln(tf,oldts);
    Readln(tf,newts);
    ots:= oldts; nts:= newts;
    Readln(tf);
    IF ParamCount < 2 THEN BEGIN
      WRITELN(outf);
      WRITELN(outf,'Replacing:');
      WRITELN(outf,ots);
      WRITELN(outf,nts);
      WRITELN(outf);
     END;
    fixed:= false;
    IF oldts = '' THEN Error('Old string is empty.')
      ELSE IF Length(oldts) < (Length(newts)-ord(Pos('/',newts) = 1)) THEN
        Error('Old string is shorter than replacement string.')
      ELSE Repl_String;
    IF not fixed THEN IF ParamCount >= 2 THEN BEGIN
      WRITELN(outf,'While replacing:');
      WRITELN(outf,ots);
      WRITELN(outf,nts);
      WRITELN(outf);
     END;
  UNTIL ((eof(tf)) or (IOResult <> 0));
  SetFTime(oldf,time);
  Close(oldf); Close(tf);
  Close(outf);
  IF ParamCount = 3 THEN Close(succf);
  WRITELN('Program done; press Return.');
  Readln;
99: end.

