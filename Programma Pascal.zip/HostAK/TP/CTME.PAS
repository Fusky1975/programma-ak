const interp_vers = 30;
      fuccup = 1;

    dname: dstrs = ('Land Ship','Scythed Chariots',
      'Pony Express','Macadam Roads',
      'Greek Fire','Sextant',
      'Composite Bow','Tungsten-Tipped Arrow',
      'Strength Elixir','Mithril Chainmail',

      'Meditation Incense','Classification of Life',
      'Magnetized Lock Picks','Trap Finding Dust',
      'Compass','Telescope',
      'Invisible Ink','2-Way Mirrors',
      'Hieroglyphic Translation','Scientific Method',

      'Osteopathic Germ Warfare','Hidden Tattoos',
      'Penicillin','Artificial Organs',

      'Flood Dams','Giant Fan',
      'Reinforced Concrete','Asbestos Clothing',

      'Analytical Psychology','Propaganda Megaphones',
      'Dry Ice Fog','Lead-Lined Helmet',

      'Ultraviolet Lenses','Observation Balloons',
      'Hand-Held Radar','Infrared Goggles',

      'Peanut Butter Sandwich','Aspirin Pill','Pepper Spice','Cotton Gin',
      'Ice Cream Cone','Black Lace Teddy','Screw','Reforging of Steel',
      'Magnet','Malpractice Suit','Gambling Casino','Pulley',
      'Ink Stamp','Postage Stamp','Game of Chess','Water Wheel',
      'Soap Bar','Pipe Organ','Reaper','Coal Mine',
      'Spectacles','Windmill','Guitar','Paper Mill',
      'Umbrella','Timepiece','Fireworks Display','Vulcanized Rubber');

type
    spabil = (Noab, Rare_Magic, Some_Magic, White_Magic, Nec_Magic,
      Ele_Magic, Psy_Magic, Ill_Magic, Charm_Magic, Cold_Magic,
      Hot_Magic, Behold, Constrict, Swallow, Drain,
      Poison, Regenerate, Multiply, Lycanthropy, Possess,
      Web, Sleeps, Familiar);

    Death = (Squeeze,Batter,Crush,Slash,Chop,
      Pierce,Gulp,Burn,Fizz,Mental,Holy,Control,Killy,
      Execute,Magical,Draining,Poisonous,Scream,
      Glare,Bogus);

    weapdeath = array[weapon] of death;
    mabarr = array[monster] of spabil;

const
    weapkill: weapdeath = (Slash,Slash,Slash,Gulp,Crush,
      Batter,Slash,Pierce,Batter,Batter,Slash,
      Crush,Batter,Chop,Draining,Squeeze,
      Batter,Batter,Pierce,Burn,Fizz,
      Poisonous,Scream,
      Gulp,Crush,Pierce,Batter,Glare,
      Slash);

    mtrweap: mweaps = (NoWeap,NoWeap,NoWeap,NoWeap,NoWeap,
      FlameBreath,SpitAcid,PoisBreath,FlameBreath,FlameBreath,
      NoWeap,NoWeap,Boulder,NoWeap,Bow,NoWeap,
      NoWeap,NoWeap,NoWeap,NoWeap,NoWeap,NoWeap,

      NoWeap,Bow,NoWeap,NoWeap,NoWeap,Gaze,Gaze,
      NoWeap,NoWeap,NoWeap,NoWeap,NoWeap,
      NoWeap,NoWeap,NoWeap,FlameBreath,NoWeap,NoWeap,
      NoWeap,NoWeap,NoWeap,NoWeap,NoWeap,NoWeap,

      NoWeap,NoWeap,NoWeap,NoWeap,NoWeap,
      NoWeap,BScream,NoWeap,NoWeap,NoWeap,NoWeap,
      NoWeap,NoWeap,NoWeap,NoWeap,
      NoWeap,NoWeap,NoWeap,NoWeap,NoWeap,NoWeap,NoWeap,NoWeap,NoWeap,NoWeap);

    mtweap1: mweaps = (Talons,Talons,Fangs,Talons,Jaws,
      Jaws,Jaws,Jaws,Jaws,Jaws,
      Maw,Sword,Club,Fists,Sword,Sword,
      Staff,Dagger,Staff,Dagger,Staff,Claws,
      Dagger,Hooves,Fists,Fists,Claws,Jaws,Dagger,
      Claws,Sword,Fangs,Fangs,Claws,
      Talons,Claws,Jaws,ChimHeads,Jaws,Fangs,
      Club,Axe,Fangs,Limb,EndoPod,Mandible,
      Stinger,Stinger,Fangs,UTouch,Fists,
      Fists,UTouch,UTouch,UTouch,Tentacles,Jaws,
      Jaws,Jaws,Dagger,

      NoWeap,
      NoWeap,NoWeap,NoWeap,NoWeap,NoWeap,NoWeap,NoWeap,NoWeap,NoWeap,NoWeap);


    talkdiff: mtconst = (1,1,0,1,0,
      0,0,0,0,0,
      3,0,0,1,0,0,
      0,0,0,0,0,0,

      0,0,0,4,2,2,0,
      0,0,0,0,0,
      0,0,0,4,4,2,
      0,1,1,0,4,3,

      3,3,3,0,0,
      0,0,0,0,2,2,
      2,2,0,0,
      0,0,0,0,0,0,0,0,0,0);

type reply = (RPuzzled,RCharge,RWarn,RRegain,RVisit,
       RRiddle,RFRevenge,RPain,RSlave,RMate,

       RTrade,RWish,RSell,RSoul,RSacH,
       RWFree,RJUndead,RPRevenge,RDrain,RCircNav,

       R2Poles,R1Terr,RExpAll,RMAdvance);

     repdesc = array[reply] of outlook;
     intno = array[reply] of intlevel;
     repboo = array[reply] of boolean;
     repno = array[reply] of byte;
     repstrs = array[reply] of str10;

const nreplies = 24;

{    repname: repstrs = ('RPuzzled','RCharge','RWarn','RRegain','RVisit',
       'RRiddle','RFRevenge','RPain','RSlave','RMate',

       'RTrade','RWish','RSell','RSoul','RSacH',
       'RWFree','RJUndead','RPRevenge','RDrain','RCircNav',

       'R2Poles','R1Terr','RExpAll','RMAdvance');
 }
      repfreq: repno = (5,10,7,5,10,
        7,8,3,5,3,
        7,10,10,8,5,
        4,10,9,8,4,
        4,4,4,10);

      char_inv: repboo =
        (false,false,false,false,false,
        false,true,false,false,false,

        false,false,false,false,false,
        false,false,true,false,false,

        false,false,false,false);

      repint: intno =
        (Semi,Medium,Medium,Medium,Medium,
         High,Medium,Semi,Medium,Low,

         High,Godlike,Medium,High,High,
         Low,Medium,Medium,Medium,Godlike,

         Godlike,Godlike,Godlike,Medium);

      rivar: repno = (0,2,3,1,1,
        1,1,0,1,2,
        2,1,1,1,1,
        1,2,1,2,2,
        2,2,2,3);

      repview: repdesc =
        (Special,Evil,Evil,Animal,Druidic,
         Worldly,Worldly,Worldly,Worldly,Worldly,

         Worldly,Heavenly,Worldly,Hellish,Hellish,
         Worldly,Undead,Worldly,Undead,Worldly,
         Worldly,Worldly,Worldly,Mechanical);

      rvvar: repno = (0,2,4,3,2,
        1,2,2,2,2,
        4,1,2,0,1,
        3,0,2,0,3,
        3,3,3,1);


    mtemper: mttemp = (Brave,Berserk,Brave,Brave,Berserk,
      Brave,Cautious,Cowardly,Cautious,Brave,
      Brave,Brave,Brave,Cautious,Brave,Berserk,
      Cautious,Cautious,Cautious,Cautious,Cautious,Cautious,

      Cautious,Brave,Brave,Berserk,Berserk,Brave,Cautious,
      Berserk,Brave,Cautious,Brave,Berserk,
      Brave,Cautious,Berserk,Brave,Brave,Cautious,
      Berserk,Berserk,Berserk,Cautious,Berserk,Brave,

      Berserk,Brave,Cautious,Cautious,Brave,
      Brave,Cautious,Cautious,Brave,Brave,Cautious,
      Brave,Brave,Cautious,Cowardly,
      Cowardly,Cowardly,Cowardly,Cowardly,Cowardly,Cowardly,Cowardly,Cowardly,Cowardly,Cowardly);

    mintel: mintarr =
      (Semi,Low,Godlike,Medium,High,
       High,Medium,High,High,Godlike,
       Semi,Godlike,Low,Low,Medium,Medium,
       High,High,High,High,High,High,

       High,Medium,Godlike,Mech,Low,Semi,Medium,
       Godlike,High,High,High,High,
       High,High,Medium,Semi,High,Semi,
       Low,Low,Semi,High,Mech,Semi,

       Semi,Semi,Semi,High,HIgh,
       High,High,Godlike,High,Semi,Semi,
       Semi,Low,Medium,Mech,
       Mech,Mech,Mech,Mech,Mech,Mech,Mech,Mech,Mech,Mech);
{
type monster = (Roc,Gryphon,Couatl,GiEagle,Sphinx,
       RDragon,BDragon,GrDragon,SDragon,GoDragon,
       GiWorm,Titan,Giant,Bigfoot,Archer,Swordsman,
       WhiteMage,NecMage,EleMage,PsyMage,IllMage,Witch,

       Dryad,Centaur,Genie,Golem,Gargoyle,Basilisk,Medusa,
       BalDemon,MarDemon,Succubus,Rakshasha,IceDevil,
       BoneDevil,Imp,Werewolf,Chimera,Hydra,Beholder,
       Troll,Minotaur,GiWolverine,Treant,GiAmoeba,GiPMantis,

       GiScorpion,GiWasp,GiSpider,Ghost,Vampire,
       Mummy,Banshee,Lich,Spectre,GiOctopus,GiClam,
       Elasmosaurus,GWWhale,Mermaid,Nomonster);
}
    mview: mtoutl = (Animal,Animal,Good,Worldly,Worldly,
      Evil,Evil,Animal,Druidic,Good,
      Animal,Good,Worldly,Animal,Worldly,Worldly,
      Worldly,Worldly,Worldly,Worldly,Worldly,Animal,

      Worldly,Worldly,Heavenly,Mechanical,Evil,Animal,Animal,
      Hellish,Hellish,Evil,Evil,Hellish,
      Hellish,Hellish,Animal,Evil,Animal,Animal,
      Evil,Animal,Animal,Druidic,Mechanical,Animal,

      Animal,Animal,Animal,Undead,Undead,
      Undead,Undead,Undead,Undead,Animal,Animal,
      Animal,Druidic,Druidic,Mechanical,
      Mechanical,Mechanical,Mechanical,Mechanical,Mechanical,Mechanical,Mechanical,Mechanical,Mechanical,Mechanical);

    mvvar: mtconst = (0,0,1,1,1,
      1,1,1,1,1,
      0,1,1,1,2,2,
      2,2,2,2,2,1,

      1,1,1,0,0,0,1,
      0,0,1,1,0,
      0,1,1,0,1,1,
      0,1,1,1,0,1,

      1,1,1,0,0,
      0,0,1,0,0,0,
      0,1,1,0,
      0,0,0,0,0,0,0,0,0,0);

    basegold: mtconst = (2,1,4,1,6,
      10,8,6,9,12,
      6,12,4,1,3,3,
      4,5,4,5,4,6,

      2,2,6,6,2,2,3,
      8,10,5,4,9,
      7,1,2,6,7,5,
      3,4,2,1,2,1,

      1,1,2,3,6,
      8,2,8,6,8,6,
      4,2,1,0,
      0,0,0,0,0,0,0,0,0,0);

    mtbasehp: mtconst = (30,25,20,15,25,
      35,30,25,30,40,
      35,40,25,18,10,10,
      10,10,10,10,10,10,

      10,12,20,25,15,20,10,
      30,25,20,25,30,
      20,12,12,25,20,25,
      25,20,20,25,15,15,

      10,10,10,15,20,
      20,15,25,20,25,20,
      25,30,10,0,
      0,0,0,0,0,0,0,0,0,0);

    mtmelee: mtconst = (1,1,3,2,2,
      3,2,2,2,3,
      0,4,1,0,1,3,
      1,1,1,1,1,1,

      0,1,2,2,1,1,0,
      3,4,1,2,3,
      2,1,1,2,2,1,
      1,1,2,1,0,2,

      1,1,1,1,2,
      1,1,1,1,1,0,
      2,3,1,0,
      0,0,0,0,0,0,0,0,0,0);

    mtmeldam: mtconst = (12,8,6,6,8,
      10,8,6,9,12,
      15,20,10,8,6,6,
      6,6,6,6,6,4,

      4,6,8,10,8,8,4,
      12,10,6,8,12,
      8,6,6,10,6,8,
      8,8,8,15,4,6,

      8,8,6,6,8,
      8,4,6,6,8,8,
      10,12,6,0,
      0,0,0,0,0,0,0,0,0,0);

    mtarch: mtconst = (0,0,0,0,0,
      2,2,2,2,2,
      0,0,1,0,3,0,
      0,0,0,0,0,0,

      0,2,0,0,0,2,2,
      0,0,0,0,0,
      0,0,0,2,0,0,
      0,0,0,0,0,0,

      0,0,0,0,0,
      0,2,0,0,0,0,
      0,0,0,0,
      0,0,0,0,0,0,0,0,0,0);


    mtmisdam: mtconst = (0,0,0,0,0,
      12,10,7,10,15,
      0,0,10,0,6,0,
      0,0,0,0,0,0,

      0,6,0,0,0,15,15,
      0,0,0,0,0,
      0,0,0,10,0,0,
      0,0,0,0,0,0,

      0,0,0,0,0,
      0,8,0,0,0,0,
      0,0,0,0,
      0,0,0,0,0,0,0,0,0,0);


    mtspeed: mtconst = (3,3,3,3,3,
      3,3,3,3,3,
      2,3,2,2,2,2,
      2,2,2,2,2,1,
      2,3,2,1,2,1,1,
      3,2,3,3,1,
      2,2,2,3,1,1,
      2,1,3,2,1,2,
      2,3,2,2,2,
      1,2,1,2,2,1,
      3,3,3,0,
      0,0,0,0,0,0,0,0,0,0);

const

    trvic: trbytes =
     (0,0,0,0,0,
      0,0,0,0,0,
      0,0,0,0,0,

      0,0,0,0,
      0,0,0,0,
      0,0,0,0,
      0,0,0,0,
      0,0,0,0,

      1,1,0,0,1,
      1,1,1,1,
      0,0,0,0,0,
      1,1,1,

      0,0,0,0,0,
      0,0,0,0,0,
      0,0,0,0,0,

      0,0,0,
      0,0,0,0,0,0,0,0,0,0,0,
      0,0,0,0,0,0,0,
      0,0,0,0,0,
      0,0,0,0,0,0,0,0,0,0,
      0,0,0,0,0,0,0,0,0,0);

    Batt = 1; Comm = 2; Prof = 3; Form = 4;

    squires: array[0..9] OF Str10 =
      ('Gridley','Tattoo','Gunga Din','Mortimer','Moosu',
       'Berthier','Frodo','Tonto','Montgomery','Watson');

    dspread: discbyte = (Batt,Batt,
      Comm,Comm,
      Form,Prof,
      Prof,Form,
      Form,Form,

      Form,Prof,
      Prof,Form,
      Prof,Prof,
      Form,Prof,
      Prof,Prof,

      Form,Prof,
      Form,Form,

      Comm,Batt,
      Comm,Form,

      Prof,Batt,
      Form,Form,

      Form,Batt,
      Form,Form,

      Comm,Prof,Prof,Comm,
      Comm,Prof,Comm,Prof,
      Prof,Comm,Comm,Comm,
      Comm,Comm,Comm,Comm,
      Comm,Comm,Comm,Comm,
      Comm,Comm,Comm,Comm,
      Comm,Comm,Prof,Prof);

      cons: array[0..18] of char =
        ('B','D','F','G','H','J','K','L','M','N',
         'P','R','S','T','V','W','X','Y','Z');
      vowels: array[0..4] of char =
        ('A','E','I','O','U');

{none, change character only if change isn't already made,
      legal range, kings only, only experienced
      need apply, payup, same align, similar align, same temper, same race,
      same sex, more war, more peace

}
TYPE power = (PNone, NewSex,NewTemp,NewRace,UpSkill,UpApt,
              DnSkill,DnApt,
              DampCollege,DampMagic,WarpSpace,
              CastSpell,AnsPrayer,
              MapFeat,MapProv,SageDisc,

              OracAlign,OracPower,OracOffice,
              OracGold,OracTreas,

              Recharge,
              GrantWish,Gamble,

              Chance);

TYPE magfeat = (MFNone, Pool,Fountain,Cup,MAlter,Idol,
                Pedestal,Throne,Incenser,Lamp,Pentagram,
                CrysBall,Hourglass,Bell,Painting,Machine,
                Book,Puzzle,Gastrap,Seal,Itself);

CONST mfpow1: ARRAY[magfeat] OF power =
               (PNone, NewSex,NewSex,NewSex,NewSex,NewSex,
                NewSex,NewSex,NewSex,OracAlign,NewSex,
                CastSpell,DampCollege,OracAlign,OracAlign,Gamble,
                CastSpell,SageDisc,CastSpell,OracAlign,DampCollege);

CONST mfpowf: ARRAY[magfeat] OF power =
               (PNone, DnSkill,DnSkill,DnSkill,Grantwish,Gamble,
                Recharge,Recharge,Recharge,Gamble,Chance,
                SageDisc,WarpSpace,Gamble,Gamble,Chance,
                SageDisc,OracTreas,CastSpell,Gamble,WarpSpace);


TYPE comfeat = (CFNone,Seaweed,Whirlpool,Trees,Cliff,LavaPool,
                Stalacs,Mine,Quicksand,Corner,Pit,
                CPool,Stairs,Table,Gametable,Hammock,
                Rug,Fireplace,Piano,Chandelier,CWindow,
                HiWindow,Passages,Coffin,Gong,Pillar,Well);

CONST cfs: ARRAY[feature] OF comfeat =
     (Coffin,Coffin,Coffin,Coffin,CFNone,
      Passages,Mine,Well,Passages,Passages,
      CFNone,Pillar,Pillar,Gong,Pillar,
      CFNone,CFNone,Pillar,Gong,Pillar,
      Passages,CFNone,Pillar,CFNone,Well,
      Mine,Mine,CFNone,CFNone,Stalacs,
      CFNone,CFNone,CFNone,CFNone,CFNone,CFNone,CFNone,CFNone,CFNone,CFNone,CFNone,CFNone);

CONST cf1: ARRAY[feature] OF comfeat =
     (Corner,Corner,Corner,Corner,Stalacs,
      LavaPool,LavaPool,Mine,Corner,Mine,
      Corner,Corner,Mine,Corner,Corner,
      Trees,Cliff,Quicksand,Quicksand,Quicksand,
      Mine,Quicksand,Quicksand,Pit,Quicksand,
      Trees,Cliff,Seaweed,Seaweed,Seaweed,
      Whirlpool,CFNone,
      CFNone,CFNone,CFNone,CFNone,CFNone,CFNone,CFNone,CFNone,CFNone,CFNone);

CONST cff: ARRAY[feature] OF comfeat =
     (Table,Rug,Stairs,CPool,CPool,
      Stairs,LavaPool,CWindow,Stairs,Table,
      HiWindow,HiWindow,CWindow,CWindow,CWindow,
      Trees,Cliff,Quicksand,Quicksand,Stairs,
      Stairs,Table,CWindow,HiWindow,Quicksand,
      Cliff,Cliff,Whirlpool,Seaweed,Whirlpool,
      Whirlpool,CFNone,
      CFNone,CFNone,CFNone,CFNone,CFNone,CFNone,CFNone,CFNone,CFNone,CFNone);

CONST mf1: ARRAY[feature] OF magfeat =
     (Cup,Cup,MAlter,Incenser,Incenser,
      Pool,Book,Pool,Painting,Pool,
      Fountain,Pool,Fountain,Pool,Pool,
      Pool,Cup,MAlter,Fountain,MAlter,
      MAlter,Pool,Fountain,Pentagram,Pool,
      Pool,MAlter,Pool,Fountain,Pool,
      MFNone,MFNone,
      MFNone,MFNone,MFNone,MFNone,MFNone,MFNone,MFNone,MFNone,MFNone,MFNone);

CONST mff: ARRAY[feature] OF magfeat =
     (Seal,Seal,Seal,Seal,Pentagram,
      Hourglass,Gastrap,Seal,Seal,Seal,
      Gastrap,Seal,Gastrap,Seal,Seal,
      Idol,Throne,Pentagram,Pedestal,Throne,
      Seal,Seal,Painting,Hourglass,Fountain,
      Fountain,Throne,Cup,Fountain,Throne,
      MFNone,MFNone,MFNone,MFNone,MFNone,MFNone,MFNone,MFNone,MFNone,MFNone,MFNone,MFNone);

TYPE intro = (INone,Monk,Valet,Call,
              Walkinto,DownStairs,UpStairs,Climbup,
              Walkupto,Wander,WalkMid,Wade,
              Swim,Sail,Dive);

CONST fintro1: ARRAY[feature] OF intro =
    (Walkinto,Call,Walkinto,Walkinto,Call,
      Walkinto,Walkinto,Valet,Wander,Wander,
      Valet,Valet,Monk,Monk,Monk,
      Wander,Climbup,Walkupto,Walkupto,WalkMid,
      WalkMid,Wander,UpStairs,Valet,WalkMid,
      Climbup,Climbup,Wade,Wade,Swim,
      Swim,INone,INone,INone,INone,INone,INone,INone,INone,INone,INone,INone);

CONST fintrof: ARRAY[feature] OF intro =
     (Climbup,Walkinto,Downstairs,Walkinto,Walkinto,
      Downstairs,Walkinto,Downstairs,Wander,Wander,
      Walkinto,Walkinto,Walkinto,Walkinto,Walkinto,
      WalkMid,Walkupto,Walkupto,Walkupto,Walkmid,
      Walkmid,WalkMid,Walkupto,Walkupto,WalkMid,
      Climbup,Climbup,Swim,Dive,Dive,
      Dive,INone,INone,INone,INone,INone,INone,INone,INone,INone,INone,INone);

TYPE powco = (PCNone,PayUp,SameAlign,Drain_Skill,NeedKing,GTurn,Drain_Courage);

CONST  modprog = true;

       apt_rise: array[0..10] OF byte = (0,10,25,50,100,80,60,40,20,0,0);

mfname: array[magfeat] OF Str40 =
               ('None/FNone','Pool/FStream','Fountain/FFount','Cup/FDecanter','Altar/FPrayer_Rug','Idol/FStatue',
                'Pedestal/FDais','Throne/FDirector''s_Chair','Incense_Burner/FEverlit_Candle',
                  'Lamp/FCrucible','Pentagram/FMagic_Circle',
                'Crystal_Ball/FMagic_Mirror','Hourglass/FCuckoo_Clock','Bell/FGong',
                  'Painting/FTapestry','Roulette_Wheel/FSlot_Machine',
                'Book/FTome','Puzzle/FEnigma','Gas_Trap/SElectric_Trap','Sealed_Entrance/FSealed_Room','&');

