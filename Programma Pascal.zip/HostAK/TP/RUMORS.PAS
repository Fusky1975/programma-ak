unit rumors;
{$I-}

interface

uses dos,crt,defines,yak,map,mboth;

{$I modflag.pas}
{$I pro.pas}
{$I noble.pas}
{$I Russian.pas}

FUNCTION Say_Code(code: integer): boolean;
PROCEDURE PNum(num: integer); {Write a number (num) to turn report}
PROCEDURE Enc_Say(kn: krange; paren: boolean); {List the player's names and addresses}
FUNCTION Rint: integer; {Read a code from the character's "story" file}
PROCEDURE FD(fn: str40; spl,dex: integer);
PROCEDURE Say(s: String; spytype: integer); {Write string "s" to the turn report.}
FUNCTION Nemo(ldr: integer; at,aopp: army): boolean;
FUNCTION Known_Loc(ln,kng,gtmod: integer; advrep: boolean): boolean;
FUNCTION Known_Merc(an,kng: integer): boolean;
FUNCTION Army_Str(an,ldr,kng,oppkng,bx,by: integer; relabil: ability;
                  aopp: army; defdr,actual,campres,ofc: boolean;
                  plusqual: shortint; see_ia: boolean): integer;
FUNCTION Adverse_Terrain(at: army; ter: terrain): boolean;
PROCEDURE PW(code: integer);
PROCEDURE PWP(X,Y: INTEGER);
PROCEDURE PW2(code1,code2: integer);

PROCEDURE Page_Print;
PROCEDURE Set_Intel(x,y: integer);
PROCEDURE Refresh_Moves;
PROCEDURE End_Effects;
PROCEDURE Re_Liege;
FUNCTION Plan_Intent(td: desigptr): maneuver;
FUNCTION ISpy_Cover(ldr: integer): real;
PROCEDURE Put_Cust;
PROCEDURE Clear_FD;
PROCEDURE Bonus_Intel(VAR n: integer);
PROCEDURE Write_Addr(kng: krange; VAR mf: text; inch: boolean);
FUNCTION Rep_Charges(k: krange; su: boolean): longint;
PROCEDURE Write_Stars; VAR i: integer;
PROCEDURE Write_MF(k: krange);
PROCEDURE Center_Write(k: krange; s: Str80);
PROCEDURE Append_Note;
PROCEDURE Add_Tr(tr: treasure; tow,tch: integer);
PROCEDURE Use_NewVal(donew,alive: boolean);
PROCEDURE Give_Notice(s1: str40; i1: integer;
                      s2: Str40; r1: real; s3: Str40);
FUNCTION Counter_Science(ldr: integer; spellno: spell): boolean;
PROCEDURE Inc_Tit(ldr: integer; tit: office; tval: integer);
FUNCTION Find_Record(ldr: integer; tit: office): integer;
FUNCTION Defeated(k: krange): boolean;
FUNCTION Sending_Int(k: integer): integer; {0 = no, 1 = via CIS, 2 = Via Genie}
PROCEDURE Get_AbDesc(ldr: integer; VAR s: Str80);
{Search speak.pas and say.pas for more program comments.  If I don't comment
a procedure, it is something you don't need to look at.}
PROCEDURE Space; {Print a blank character to turn report}
PROCEDURE WW(s: Str40); {write a word to turn report}
PROCEDURE Desig(_dex,spytype: integer); {Write an army name/designation}

const
     _LDies = 3000; _LSucc = 3001; _LExpAtt = 3002; _LExpImp = 3003;
     _LExpFail = 3004; _LExpMax = 3005; _LFind = 3006; _LMove = 3007;
     _LHFail = 3008; _LHire = 3009; _LFire = 3010; _LAlly = 3011;
     _LBreak = 3012; _LBurn = 3013; _LInher = 3014; _LGain = 3015;
     _ThFail = 3016; _LMisses = 3017; _LInfl = 3018; _LMortB = 3019;
     _LToBow = 3020; _LToMel = 3021; _LFArr = 3022; _LCast = 3023;
     _LRecov = 3024; _LStun = 3025; _LGetAw = 3026; _LSeen = 3027;
     _LSwing = 3028; _LFlee = 3029; _LCot = 3030; _LBung = 3031;
     _LSquee = 3032; _LChall = 3033; _LSearch = 3034; _LImpr = 3035;
     _LStudV = 3036; _LSteal = 3037; _LTakeG = 3038; _LRans = 3039;
     _LWandTo = 3040; _LExec = 3041; _LBinoc = 3042; _LSeeI = 3043;
     _LNBinIce = 3044; _LSpy = 3045; _LInfo = 3046; _LIgnore = 3047;
     _LRebuff = 3048; _LWandFr = 3049; _LDesert = 3050; _LStandby = 3051;
     _LEnc = 3052; _LExpCo = 3053; _LThAtt = 3054; _LRev = 3055;
     _LLCosts = 3056; _LACosts = 3057; _LFinance = 3058; _LCHoly = 3059;
     _LCHOD = 3060; _LCPsyBl = 3061; _LCInvis = 3062; _LTreas = 3063;

     _LSTax = 3064; _LSAT = 3065; _LSList = 3066; _LSHere = 3067;
     _LSLeads = 3068; _LSGarr = 3069; {_LSComm = 3070;} {_LSARep = 3071;}
     {_LSPer = 3072;} _LSNone = 3073; _LSCap = 3074; _LSEtc = 3075;
     _LSNoch = 3076; _LMarch = 3077; _LExpDiff = 3078; _LSpoilG = 3079;
     {_LIndet = 3080;} _ThNoMI = 3081; _LDisc = 3082; _LNoDisc = 3083;
     _LRNoCo = 3084; _LSacked = 3085; _LCounter = 3086; _LWill = 3087;
     _LRemain = 3088; _LDefend = 3089; _LHearInv = 3090; _LSplit = 3091;
     _LTrade = 3092; _LNDeal = 3093; _LCantPu = 3094; _LCPurs = 3095;
     _LNoPuI = 3096; _LNoPuA = 3097; _LAlrMax = 3098; _LAvoid = 3099;
     _LBenc = 3100; _ADishK = 3101; _ADishF = 3102; _LAssume = 3103;
     _LTeach = 3104; {_LHard = 3105; }_LCatch = 3106; _LRefA = 3107;
     _LHeavP = 3108; _LSNews = 3109; _LNoHeav = 3110; _LCMarch = 3111;
     _LCTalk = 3112; _MReply = 3113; _LCSpir = 3114; _LCContU = 3115;
     _LSpIneff = 3116; _LCIceS = 3117; _LBIce = 3118; _LFice = 3119;
     _LIceCr = 3120; _LIceGh = 3121; _LPIce = 3122; _LShIce = 3123;
     _LWMelt = 3124; _LConfu = 3125; _LAccept = 3126; _LUndWF = 3127;
     _LSFroz = 3128; _LCMI = 3129; _LMSwAtI = 3130; _LMDiss = 3131;
     _LRevive = 3132; _LSlit = 3133; _LTSColl = 3134; _LMDisb = 3135;
     _LExper = 3136; _LANoTr = 3137; _LTrSpy = 3138; _LChEst = 3139;
     _LHasT = 3140; {_LKLeads = 3141;} _LTaBase = 3142; _LOwns = 3143;
     _LSTBase = 3144; _LKEn = 3145; _LKAll = 3146; _LMerc = 3147;
     _LKick = 3148; _LBeg = 3149;

     _LSBinIce = 3150; _LCow = 3151; _LPOwns = 3152; _LNoNews = 3153;
     _LKillE = 3154; _LOProv = 3155; _LSuOwn = 3156; _LSuOwn2 = 3157;
     _LSay = 3158; _LSayend = 3159; _LDevast = 3160; _LKMeet = 3161;
     _LKNext1 = 3162; _LSick = 3163; _LMCharm = 3164; _LMDesc = 3165;
     _LFRaid = 3166; _LSpake = 3167; _MFulf = 3168; _LPacif = 3169;
     _LHaHa = 3170; _LStrand = 3171; _MNoBold = 3172; _MUnDt = 3173;
     _LChEsc = 3174; _LWGrr = 3175; _LWTake = 3176; _LWErrand = 3177;
     _LPrDie = 3178; _LFWrong = 3179; _LFNQual = 3180; _LFProgr = 3181;
     _LFTryAg = 3182; _LFNoAg = 3183; _LQDone = 3184; _LLose = 3185;
     _LFuVis = 3186; _LWoff = 3187; _LMSnow = 3188; _LFNoPri = 3189;
     _LFKOnly = 3190; _LFHero = 3191; _LThEnd = 3192; _LFRumor = 3193;
     _LSlow = 3194; _LUse = 3195; _LVuln = 3196; _LCast1 = 3197;
     _LWDie = 3198; _LTrack = 3199;

     _LBers = 3300; _LWield = 3301; _LStays = 3302; _LNLRet = 3303;
     _LInstead = 3304; _LREnc = 3305; _LSafe = 3306; _LWEnc = 3307;
     _LPatr = 3308; _LPEnc = 3309;_LPass = 3310; _LBefr = 3311;
     _LTricks = 3312; _LDense = 3313; _LDona = 3314; _LHear = 3315;
     _LNice = 3316; _LGreet = 3317; _DCConv = 3318; _LEncEnd = 3319;
     _LRepo = 3320; _LStake = 3321; _LRise = 3322; _LImpris = 3323;
     _LEQuit = 3324; _LPenta = 3325; _BFun = 3326; _LChUnd = 3327;
     _LM2Diss = 3328; _LValHal = 3329; _LVLeave = 3330; _LRiseV = 3331;
     _LRead = 3332; _LBThen = 3333; _LRidAns = 3334; _LBGen = 3335;
     _LTell = 3336;  _LPTell = 3337; _LDTell = 3338; _EIntro = 3339;
     _PowMsg = 3340; _EDesc = 3341; _ECond = 3342; _NoMeet = 3343;
     _LScout = 3344; _NeedI = 3345; _NoNews = 3346; _MFDesc = 3347;
     _SDub = 3348; _MAnti = 3349; _MCond = 3350; _EndQ = 3351;
     _SWarp = 3352; _LMFApp = 3353; _LPUse = 3354; _ArmSay = 3355;
     _AbSay = 3356; _MDead = 3357; _LPsych = 3358; _LPigeon = 3359;
     _ODesc = 3360; _LOUse = 3361; _LPWand = 3362; _ATFan = 3363;
     _OAlert = 3364; _ARFan = 3365; _TrRes = 3366; _AKill = 3367;
     _ASeek = 3368; _AFail = 3369; _FuEst = 3370; _LFOccu = 3371;
     _LEuro = 3372; _LNHave = 3373; _LGGive = 3374; _LFThun = 3375;
     _LKNex = 3376; _LNoRand = 3377; _LSeeTit = 3378; _LATreat = 3379;
     _LSIBers = 3380; _GDDisp = 3381; _LDFite = 3382; _LExSpy = 3383;
     _LCong = 3384; _LRApt = 3385; _LWWalk = 3386; _LFly = 3387;
     _BMNoPay = 3388; _LGDRef = 3389; _LSquit = 3390; _LEarth = 3391;
     _LOAss = 3392; _LHearPat = 3393; _LPatrol = 3394; _LIncid = 3395;

     T_Conf = 3200; T_LSteal = 3201; T_MSteal = 3202; T_LSpoils = 3203;
     T_MSpoils = 3204; {T_Inher = 3203;} T_ISpoils = 3207;
     G_Conf = 3210; G_LSteal = 3211; G_MSteal = 3212; G_LSpoils = 3213;
     G_MSpoils = 3214; G_Inher = 3215; _MGain = 3216; G_ISpoils = 3217;
     G_MCharm = 3218; {G_ECharm = 3219;}

     _FTr = 3500; _FNoTr = 3501; _NBatt = 3502; _NForm = 3503;
     _NComm = 3504; _NProf = 3505; _CBatt = 3506; _CForm = 3507;
     {_CComm = 3508; }_CProf = 3509; _DCSpy = 3510; _DCSUse = 3511;
     _DRvUse = 3512; _DAUse = 3513; _LDConf = 3514; _LDCFin = 3515;
     _DCBatt = 3516; _LFigI = 3517; _SANote = 3518; _LTFast  = 3519;

     _ARecr = 4000; _AHired = 4001; _ADisb = 4002; _ALeave = 4003;
     _APickup = 4004; _ARises = 4005; _ARedu = 4006; _ADesert = 4007;
     _AWandTo = 4008; _APDestr = 4009; _ATDestr = 4010; _AWandFr = 4011;
     _ADig = 4012; _AUnpaid = 4013; _ADecQ = 4014; _AIncQ = 4015;
     _AQuals = 4016; _Wand1 = 4017; _ATrain = 4018; _NoDestr = 4019;
     _AUseUp = 4020; _ADefend = 4021; _AHDisb = 4022; _ABFList = 4023;
     _ABFArmy = 4024; _ABFEnd = 4025; _AGFan = 4026; _AEFan = 4027;
     _AGFan2 = 4028; _AEFan2 = 4029; _AAResv = 4030; _ADResv =4031;
     _AFly = 4032; _AFlank = 4033; _AUWater = 4034; _AThirst = 4035;
     _APract = 4036; _AFly2 = 4037; _TrReg = 4038; _APSick = 4039;
     _ASlow = 4040; _ATTorn = 4041; _AEDestr = 4042; _NoEDest = 4043;
     _TWPass = 4044; _ANem = 4045; _BSpeech = 4046; _BHome = 4047;
     _BNoDru = 4048; _BRWeap = 4049; _BBluff = 4050; _BNoEx = 4051;
     _BSwitch = 4052; _ABDestr = 4053; _AAPay = 4054;

     _MInc = 4100; _MDec = 4101; _MSplut = 4102;

     _TrDesc = 5000; _TrDust = 5001;{_TrWith = 5002;}
     _TrShad = 5003; _TrImpl = 5004;

     _SFizz = 6000; _SDisr = 6001; _SPlague = 6002; _SFail = 6003;
     _SResur = 6004; _SPart = 6005; _SBless = 6006; _SNoSkel = 6007;
     _SKill = 6008; _SFlood = 6009; _STorn = 6010; _SQuake = 6011;
     _SCharm = 6012; _SOrat = 6013; _STerIl = 6014; _SIllAr = 6015;
     _SHideF = 6016; _SClairv = 6017; _SSick = 6018;
     _CSSkel = 6100; _CSOrat = 6101; _CSIA = 6102; _CSIT = 6103;
     _CSHF = 6104; _SAnti = 6105; _SCounter = 6106; _SComCtr = 6107;
     _SComRed = 6108; _SWave = 6109; _CSPA = 6110;

     _BInvas = 7000; _BCdrs = 7001; _BForces = 7002; _BAList = 7003;
     _BLeaders = 7004; _BLList = 7005; _BDefect = 7006; _BAid = 7007;
     _BLLen = 7008; _BRes = 7009; _BNoRet = 7010; _BWinner = 7011;
     _BDestr = 7012; _BDie = 7013; _BPurs = 7014; _BGoHome = 7015;
     _BLRetr = 7016; _BConq = 7017; _BInv = 7018; _BDef = 7019;
     _BDepl = 7020; _BIA = 7021; _BMagic = 7022; _BClash = 7023;
     _BPFail = 7024; _BLoyal = 7025; _PFiteAs = 7026; _BAWFlop = 7027;
     _BLuck = 7028; _CLuck = 7029; _BFace = 7030; _BPersp = 7031;
     _BStill = 7032; _BEleph = 7033; _BTac = 7034; _BSpite = 7035;
     _BRevolt = 7036; _BQuit = 7037; _BMercs = 7038; _CLuck2 = 7039;
     _BBite = 7040; _LRFlee = 7041; _BMonst = 7042; _STFite = 7043;
     _STZero = 7044;

     _EndPh = 8000; _AssPh = 8001; _EndBat = 8002; _Ass2 = 8003;
     _End2 = 8004;  _AssRand = 8005;               _IllEq = 8007;
     _SetPow = 8008;


     _PPlague = 9000; _SQuote = 9001;

     _ZEndEx = 11999;

implementation

PROCEDURE PW(code: integer);
BEGIN
  WRITE(intfile,code);
  WRITE(code:5);
  NIO_Check('PW Write',code);
  IF double_ldr <> noleader THEN BEGIN
    WRITE(dintfile,code);
    NIO_Check('Doub Write',double_ldr);
   END;
  IF pwarmy THEN CASE code OF
    1024..1279: PW(ord(atype[code-1024]));
    12000..12999: PW(ord(atype[code-12000]));
   END;
{  IF code = 1912 THEN WEK;}
 END;

PROCEDURE PW2(code1,code2: integer);
BEGIN
  PW(code1);
  PW(code2);
 END;

PROCEDURE PWP(X,Y: INTEGER); BEGIN  PW(13000+x*XMULT+y); END;

FUNCTION Known_Merc(an,kng: integer): boolean;
BEGIN
  Known_Merc:= ((astate[an] = Mercenary) and
    ((powner[ax[an],ay[an]] = kng) or (Ldr_Near(kng,ax[an],ay[an],1))));
 END;

FUNCTION Known_Loc(ln,kng,gtmod: integer; advrep: boolean): boolean;
VAR tkl: boolean;
    l2: integer;
BEGIN
  IF ((emp <> No_King) and (not advrep)) THEN tkl:= true ELSE
  tkl:= ((LKing(ln) <> kng) and ((powner[lx[ln],ly[ln]] <> ln) or (not advrep)) and
        (((lstate[ln] = Dead) or (Trunc(16*ISpy_Cover(ln)) > ((kng+ln+orig_turn+gtmod+begvalkng) and 15))) and
         ((powner[lx[ln],ly[ln]] = kng) or
          (((ln+orig_turn+gtmod) MOD 5 <= 1) and (Ldr_Near(kng,lx[ln],ly[ln],0))))));
  IF not advrep THEN IF not tkl THEN IF ln >= nkings THEN IF powner[lx[ln],ly[ln]] = ln THEN
    FOR l2:= 0 TO nleaders-1 DO IF LKing(l2) = kng THEN
      IF LDist(l2,lx[ln],ly[ln]) <= 1 THEN tkl:= true;
  Known_Loc:= tkl;
 END;

FUNCTION Adverse_Terrain(at: army; ter: terrain): boolean;
BEGIN
  CASE ter OF
    LAVA: ter:= mtns;
    SWAMP: ter:= Jungle;
   END;
  IF (((gametyp = Europe_V) or (gametyp = Earth_V)) and (at = LCav)) THEN
      Adverse_Terrain:= false
    ELSE BEGIN
      Adverse_Terrain:= ((ter >= atadv1[at]) and (ter <= atadvf[at]));
{$IFNDEF Noble}
      IF gamevers >= 2 THEN CASE at OF
        LCav: IF ter = Forest THEN Adverse_Terrain:= false;
        Phalanx,Camels: IF ter = Mtns THEN Adverse_Terrain:= false;
        Mermen:  IF ((ter = Forest) or (ter = Jungle)) THEN Adverse_Terrain:= false;
        Ents: IF ter = Sea THEN Adverse_Terrain:= true;
       END;
{$ENDIF}
     END;
  IF New_Rules THEN IF at = LCav THEN Adverse_Terrain:= false;
{  IF gamevers >= 3 THEN IF at = Chariots THEN
    IF ter = Desert THEN Adverse_Terrain:= true;}
 END;

FUNCTION Nemo(ldr: integer; at,aopp: army): boolean;
BEGIN
  Nemo:= false; glob_nem:= noarmy;
  IF aopp <> noarmy THEN BEGIN
    IF (((aopp >= atnem1[at]) and (aopp <= atnemf[at])) or
        ((at = Ents) and (aopp = Dragonwing)) or
        ((at = Eaglewing) and (aopp = Vampires)) or
        ((at >= Lcav) and (at <= Chariots) and (aopp >= Weres) and (aopp <> Marauders))) THEN BEGIN
      Nemo:= true;
      glob_nem:= aopp;
      IF ((at >= Lcav) and (at <= Chariots) and (aopp <> Chariots)) THEN
        IF Has_SA(ldr,Brave_Horses) THEN BEGIN
          Nemo:= false;
          glob_nem:= noarmy;
          bravehorse:= true;
         END;
     END;
   END;
 END;

FUNCTION Army_Str(an,ldr,kng,oppkng,bx,by: integer; relabil: ability;
                  aopp: army; defdr,actual,campres,ofc: boolean; plusqual: shortint; see_ia: boolean): integer;
VAR ast,modqual,expill,armykng: integer;
    at: army;
    tac_mod,expmod,amul,totmul: real;
    first_ter: terrain;

FUNCTION Str(pt: terrain): integer;
VAR x,y: integer;
BEGIN
  at:= Mod_AType(an);
  IF pt2^[bx,by] <> noterr THEN IF pt = Sea THEN IF pt = Trav_Ter(bx,by) THEN
    IF Adverse_Terrain(at,pt) THEN pt:= pt2^[bx,by];
  armykng:= LKing(aleader[an]);
  IF armykng = noleader THEN armykng:= kng;
  IF ofc THEN
    IF relabil = Naval THEN pt:= Sea
      ELSE IF Air_Unit(an,false) THEN pt:= Sea;
  totmul:= 1.0;
  ast:= atstren[at];
  IF ((gametyp = Europe_V) or (gametyp = Earth_V)) THEN IF at = LCav THEN Inc(ast);
  IF pt <> Sea THEN IF at = WhaleLeague THEN ast:= 0;
  IF at = Garrison THEN IF not defdr THEN ast:= 1;
  dielstr:= -1; bravehorse:= false;
  CASE at OF
    Elephants: IF actual THEN BEGIN ast:= D4+1+R01; dielstr:= ast; END
      ELSE ast:= 3;
    Dinosaurs: IF actual THEN BEGIN ast:= D6+4; dielstr:= ast-4; END
      ELSE ast:= 7;
   END;
  WRITE(' A1:',ast);
{$IFNDEF Noble}
  CASE arace[an] OF
    Elven: BEGIN
      IF pt = FOREST THEN Inc(ast);
      IF at = Bowmen THEN Inc(ast);
     END;
    Dwarven: BEGIN
      IF pt = MTNS THEN Inc(ast);
      IF at = Axemen THEN Inc(ast);
     END;
    Orcish: BEGIN
      IF pt = MTNS THEN Inc(ast);
      IF at = Phalanx THEN Inc(ast);
     END;
    Human: IF at = Legion THEN Inc(ast);
    Rohan: BEGIN
      CASE at OF LCav,HCav: Inc(ast); END;
      IF pt = Plains THEN Inc(ast);
     END;
   END;
  WRITE(' A2:',ast);
  modqual:= Max(0,ord(aqual[an]) + Qual_Modfr(an,ldr,kng,oppkng,((pt = Desert) and (not campres))) + plusqual);
  WRITE(' MQ:',modqual);
{$ENDIF}
  IF armykng < nkings THEN BEGIN
    IF not ofc THEN BEGIN
        modqual:= modqual+ord((bx = bornx[armykng]) and (by = borny[armykng]));
        IF lalign[armykng] = Undead THEN IF astate[an] = Zomboid THEN
          Inc(modqual);
       END
      ELSE IF astate[an] = Zomboid THEN
        IF lalign[empldr] = Undead THEN Inc(modqual) ELSE Dec(modqual);
    IF oppkng < nkings THEN IF dknow^[oppkng,bild10] THEN
      IF astate[an] = Zomboid THEN IF modqual > 0 THEN Dec(modqual);
   END;
  WRITE(' Q2:',modqual);
  ast:= ast*modqual;
{$IFNDEF Noble}
  IF (((pt >= athome1[at]) and (pt <= athomef[at])) or ((at = Chariots) and (pt = Desert)) or
      ((at = WargRiders) and (NR94) and (pt = Forest)) or
      ((at = Mermen) and (pt = Jungle))) THEN BEGIN
        ast:= ast+modqual;
        WRITE(' +M');
       END;
{$ENDIF}
  IF Adverse_Terrain(at,pt) THEN
    IF Has_SA(ldr,Halve_AT) THEN BEGIN
        totmul:= totmul*0.75;
        WRITE(' 3/4');
       END
      ELSE BEGIN
        totmul:= totmul*0.5;
        WRITE(' 1/2');
       END;

  IF Nemo(ldr,at,aopp) THEN BEGIN
    totmul:= totmul*0.66666667;
    WRITE(' Nem');
   END;
  IF defdr THEN totmul:= totmul*1.25;
{$IFNDEF Noble}
  IF kng >= nkings THEN expmod:= 1.25
    ELSE IF ofc THEN expmod:= 1.25
    ELSE BEGIN
      expmod:= 1.0+(kexp^[kng][ax[an],ay[an]]*0.0025);
      IF expmod < 1.25 THEN
        IF (((gamevers >= 4) or (gdyear >= 1992)) and (titchar[Admiral] = ldr) and
            (Trav_Ter(bx,by) = Sea)) THEN expmod:= 1.25
          ELSE IF ((NR_Or_G4) and (titchar[Druidking] = ldr) and
            (Trav_Ter(bx,by) <> Sea)) THEN expmod:= 1.25;
     END;
{$ELSE}
  expmod:= 1.0;
{$ENDIF}
  WRITE(' EM:',expmod:4:2);
  totmul:= totmul*expmod;
  IF ldr <> noleader THEN BEGIN
    tac_mod:= 0.20*Min(4,M_Skill(ldr,relabil)) + 0.01*SA_Mod(ldr,relabil);
    totmul:= totmul *(1.0 + tac_mod);
    WRITE(' TM:',tac_mod:4:2);
   END;
  IF not ofc THEN IF aleader[an] <> noleader THEN BEGIN
    IF ((oppkng < nkings) and (dknow^[oppkng,bild41])) THEN amul:= 0.05
      ELSE amul:= 0.15;
    IF see_ia THEN amul:= amul*0.5;
    WRITE(' IM:', amul*((lspec[aleader[an]] DIV L_IA) and 7):4:2);
    totmul:= totmul*(1.0 + amul*((lspec[aleader[an]] DIV L_IA) and 7));
   END;
  IF ofc THEN totmul:= totmul -
      0.05*Dist(ax[an],ay[an],bornx[kng],borny[kng])/(atspeed[at]+1);
  IF Air_Unit(an,false) THEN IF termod^[bx,by] and Fog_Eff <> 0 THEN BEGIN
    totmul:= totmul*0.5;
    WRITE('Fog');
   END;
  ast:= Round(ast*totmul);
  Str:= Max(ast,0);
  IF first_ter = noterr THEN WRITE(' =>AS:',ast)
    ELSE IF first_ter <> pt THEN WRITE('/I:',tername[pt]);
  first_ter:= pt;
 END;

BEGIN
  WRITELN;
  WRITE('  AS:',an,'-',atab[atype[an]],'=');
  first_ter:= noterr;
  expill:= ord(termod^[bx,by] and Illus_Exp <> 0);
  Army_Str:= (Str(App_Ter(bx,by)) Shl expill) + Str(Trav_Ter(bx,by)) DIV (2+expill);
 END;
{$V-}
PROCEDURE Space; {Print a blank character to turn report}
BEGIN  gs:= ' '; Spread(gs,0,false); END;

PROCEDURE WW(s: Str40); {write a word to turn report}
VAR s2: Str40;
BEGIN
  IF aoran THEN BEGIN
    CASE UpCase(s[1]) OF
      'A','E','I','O','U': s2:= 'an';
      ELSE s2:= 'a';
     END;
    Spread(s2,0,false);
    Space;
    aoran:= false;
   END;
  Spread(s,0,false);
  IF pro1words < 10 THEN Inc(pro1words);
  IF pro2words < 10 THEN Inc(pro2words);
 END;

PROCEDURE Desig(_dex,spytype: integer); {Write an army name/designation}
VAR s: Str20;
BEGIN
  WW('the'); Space;
  IF descqual THEN IF _qual <> Average THEN
    BEGIN WW(qname[_qual]); Space; END;
  Make_Des(_dex,s);
  WW(s); Space;
  IF astate[_dex] = Zomboid THEN
    IF Company = Roland THEN BEGIN WW('Squelette'); Space; END
      ELSE BEGIN WW('Skeletal'); Space; END;
  WW(atname[lastat[_dex]]);
  IF spytype = S_Batt THEN IF lastat[_dex] = Fleet THEN BEGIN
    Space;
    WW('Marines');
   END;
  IF expand_adesc THEN BEGIN
    Space;
    WW(Concat('(',qname[_qual]));
    Space;
    WW(Concat(rpname[_race],')'));
   END;
 END;

{$V+}
PROCEDURE Get_AbDesc(ldr: integer; VAR s: Str80);
{Get description for ldr's best ability and put it in "s", e.g. "famous for Necromancy"}
VAR ab: ability;
    lev: integer;
BEGIN
  Best_Ab(ldr,ab,lev);
  IF Company = Roland THEN CASE lev OF
    0: s:= 'remarqu� pour ';
    1: s:= 'bien connu pour ';
    2: s:= 'fameux pour ';
    3: s:= 'renomm� pour ';
    4: s:= 'mondialement fameux pour ';
    5: s:= 'r�v�r� pour ';
    6..9: s:= 'ador� pour ';
   END
  ELSE CASE lev OF
    0: s:= 'noted for ';
    1: s:= 'well known for ';
    2: s:= 'famous for ';
    3: s:= 'renowned for ';
    4: s:= 'world-famous for ';
    5: s:= 'revered for ';
    6..9: s:= 'worshipped for ';
   END;
  IF Company = Roland THEN s:= Concat('(un ',rname[lrace[ldr]],' ',s,anoun[ab],')')
    ELSE s:= Concat('(a ',rname[lrace[ldr]],' ',s,anoun[ab],')');
 END;

FUNCTION Sending_Int(k: integer): integer; {0 = no, 1 = via CIS, 2 = Via Genie}
VAR ss: Str60;
BEGIN
  IF sendint = 1 THEN Sending_Int:= 2
{         ELSE IF Pos('>NOTES',cis) = 1 THEN Sending_Int:= 1;}
    ELSE IF (((ksendmeth[k] < S_Disk) or (ksendmeth[k] = S_Both)) and ((player.cis = 'Internet') or
    (Pos('@',player.genie) > 0) or (Pos('@',player.cis) > 0))) THEN
      Sending_Int:= 2-ord(Pos('>',player.cis) > 0) {= >NOTES:, etc}
    ELSE Sending_Int:= 0;
 END;

PROCEDURE Page_Print;
BEGIN
  IF Company = PBM_Express THEN WRITE(playfile,'!R! DXPG 1; EXIT;')
    ELSE WRITE(playfile,chr(12));
 END;

FUNCTION Defeated(k: krange): boolean;
VAR an,na: integer;
BEGIN
  Defeated:= false; na:= 0;
  IF powner[bornx[k],borny[k]] <> k THEN BEGIN
    FOR an:= 0 TO narmies-1 DO IF A_Owner(an) = k THEN Inc(na);
    IF na < 6 THEN Defeated:= true;
   END;
 END;

FUNCTION Find_Record(ldr: integer; tit: office): integer;
label 99;
VAR tix: integer;
BEGIN
  Find_Record:= -1;
  tix:= 0;
  WHILE tix < ntrecs DO BEGIN
    IF ((tityp^[tix] = tit) and (tildr^[tix] = ldr)) THEN BEGIN
      Find_Record:= tix;
      GOTO 99;
     END;
    Inc(tix);
   END;
99: END;

PROCEDURE Inc_Tit(ldr: integer; tit: office; tval: integer);
label 10;
VAR tix: integer;
    tt: office;
    totpts,tldrs,qtrpts: longint;
BEGIN
  IF ldr < nleaders THEN BEGIN
10: tix:= Find_Record(ldr,tit);
    IF tix >= 0 THEN tipts^[tix]:= tipts^[tix]+tval
      ELSE IF ntrecs < 1000 THEN BEGIN
        tipts^[ntrecs]:= tval;
        tityp^[ntrecs]:= tit;
        tildr^[ntrecs]:= ldr;
        Inc(ntrecs);
       END
      ELSE BEGIN
        FOR tt:= HumanKing TO Bravest DO BEGIN
          WRITELN('Purging Titles...');
          tix:= 0; totpts:= 0; tldrs:= 1;
          WHILE tix < ntrecs DO BEGIN
            IF tityp^[tix] = tt THEN BEGIN
              totpts:= totpts + tipts^[tix];
              tldrs:= tldrs+1;
             END;
            Inc(tix);
           END;
          IF tldrs > 0 THEN BEGIN
            qtrpts:= totpts DIV (tldrs*2);
            FOR tix:= 0 TO ntrecs-1 DO IF tityp^[tix] = tt THEN
              IF tipts^[tix] <= qtrpts THEN tityp^[tix]:= notitle;
           END;
         END;
        tix:= 0;
        WHILE tix < ntrecs DO BEGIN
          IF tityp^[tix] = notitle THEN BEGIN
            Dec(ntrecs);
            tityp^[tix]:= tityp^[ntrecs];
            tipts^[tix]:= tipts^[ntrecs];
            tildr^[tix]:= tildr^[ntrecs];
           END;
          Inc(tix);
         END;
        GOTO 10;
       END;
   END;
 END;

FUNCTION Counter_Science(ldr: integer; spellno: spell): boolean;
BEGIN
  Counter_Science:= false;
  ldr:= LKing(ldr);
  IF ldr < nkings THEN IF spellno < Spiritwrack THEN IF spellno > Holy_Symbol THEN
    Counter_Science:= dknow^[ldr,discovery(ord(bild10)+ord(spellno)-ord(Skeletal_Army))];
 END;

PROCEDURE Give_Notice(s1: str40; i1: integer;
                      s2: Str40; r1: real; s3: Str40);
VAR i: integer;
BEGIN
  IF autorun THEN BEGIN
      WRITE(mailfile,s1);
      IF i1 <> -5000 THEN WRITELN(mailfile,i1) ELSE WRITELN(mailfile);
      WRITE(mailfile,s2);
      IF r1 <> -5000 THEN WRITELN(mailfile,r1:7:2) ELSE WRITELN(mailfile);
      WRITELN(mailfile,s3);
      FOR i:= 4 TO 6 DO WRITELN(mailfile);
     END
    ELSE BEGIN
      WRITE(batfile,'REM ',s1);
      IF i1 <> -5000 THEN WRITE(batfile,i1);
      WRITE(batfile,s2);
      IF r1 <> -5000 THEN WRITE(batfile,r1:7:2);
      WRITELN(batfile,s3,'');
      WRITELN(batfile,'pause');
     END;
 END;

PROCEDURE Use_NewVal(donew,alive: boolean);
VAR t: integer;
    tw: word;
BEGIN
  IF valhero <> noleader THEN IF donew <> newvalin THEN IF not catchup THEN BEGIN
    tmp:= lname^[valhero]; lname^[valhero]:= vname; vname:= tmp;
    tc:= sex[maxkings]; sex[maxkings]:= vsex; vsex:= tc;
    t:= lx[valhero]; lx[valhero]:= vx; vx:= t;
    t:= ly[valhero]; ly[valhero]:= vy; vy:= t;
    t:= liege0[valhero]; liege0[valhero]:= vl0; vl0:= t;
    t:= lliege[valhero]; lliege[valhero]:= vll; vll:= t;
    WRITE('!',valhero,'/',lspec[valhero],'/',vsp,'.');
    tw:= lspec[valhero]; lspec[valhero]:= vsp; vsp:= tw;
   END;
  IF alive THEN lstate[valhero]:= Hired ELSE lstate[valhero]:= Dead;
  newvalin:= not newvalin;
 END;

PROCEDURE Add_Tr(tr: treasure; tow,tch: integer);
VAR trd,trl: integer;
BEGIN
  trav:= Max(maxfeatures+1,ntreasures);
  IF ntreasures = maxfeatures+1 THEN trl:= maxfeatures ELSE trl:= ntreasures;
  FOR trd:= 0 TO trl-1 DO IF trowner[trd] = noleader THEN IF trd <> maxfeatures THEN
    trav:= trd;
  trowner[trav]:= tow;
  trcharges[trav]:= tch and 255;
  treaslist[trav]:= tr;
  trowner[maxfeatures]:= noleader; treaslist[maxfeatures]:= treasure(0);
  trcharges[maxfeatures]:= 0;
  IF trav >= ntreasures THEN ntreasures:= trav+1;
 END;

PROCEDURE Bonus_Intel(VAR n: integer);
VAR kng: integer;
BEGIN
  kng:= powner[_px2,_py2];
  IF kng < nkings THEN BEGIN
    IF intel_lev[kng]-n < S_Priv THEN n:= intel_lev[kng]-S_Priv;
    intel_lev[kng]:= Max(S_Priv,intel_lev[kng]-n);
   END;
 END;

PROCEDURE Set_Intel(x,y: integer);
VAR pit,clobj,ldr,tph,kng: integer;

FUNCTION LRand: integer;
BEGIN LRand:= _prov+gameturn+kng+lplan^[kng].lobjects[0]; END;

PROCEDURE Add_Spy(divit: integer);
BEGIN
  pit:= intel_lev[kng];
  intel_lev[kng]:= Min(5,intel_lev[kng] +1 +(M_Skill(ldr,Spy) DIV divit));
  IF intel_lev[kng] > pit*2 THEN BEGIN
    prov_spy[kng]:= ldr;
    WRITE(' AS:',kng,'/',ldr);
   END;
 END;

BEGIN
  WRITE('SI',_rphase,'/Pk',playking,'/Pr',_prov,'b2=',bat2^[7][4],'.');
  FOR kng:= 0 TO nkings-1 DO BEGIN
    intel_lev[kng]:= 0;
    prov_spy[kng]:= noleader;
   END;
  IF ((_rphase >= 0) and (_rphase <= 4)) THEN FOR ldr:= 0 TO nleaders-1 DO
    IF ((ldr < nkings) or (lstate[ldr] = Hired) or (liege0[ldr] < nkings)) THEN BEGIN
      IF ldr < nkings THEN kng:= ldr
        ELSE IF lliege[ldr] < nkings THEN kng:= LKing(ldr) ELSE kng:= V_LKing(ldr,liege0);
{      WRITE('.',kng);}
      IF kng < nkings THEN IF intel_lev[kng] < 200 THEN WITH lplan^[ldr] DO BEGIN
        IF lactions[_rphase] = Succ_Trail THEN BEGIN
            IF ((lobjects[_rphase] = _attl) or
                ((lobjects[_rphase] = _defl) and (not spy_rep))) THEN Add_Spy(1);
           END;
        IF ((bat2^[ldr][_rphase] = _prov+(1024*playking)) {and
                   (Allied_Ldrs(kng,playking,false,false))}) THEN BEGIN
            intel_lev[kng]:= Max(4,intel_lev[kng]);
            prov_spy[kng]:= ldr;
            WRITE(' BS:',kng,'/',ldr,'/',bat2^[ldr][_rphase] and 1023,'/',
              bat2^[ldr][_rphase] DIV 1024,'.');
           END
          ELSE IF lobjects[_rphase] = _prov THEN CASE lactions[_rphase] OF
            ASpy: Add_Spy(1);
            LMove,Explore: IF M_Skill(ldr,Spy) > 0 THEN Add_Spy(2);
           END;
        clobj:= ((longint(lspec[ldr]) and longint(longint(L_Clairv)*longint(255))) DIV longint(L_Clairv)) -1;
        IF kng < nkings THEN IF ((clobj = _attl) or (clobj = _defl)) THEN FOR tph:= 0 TO _rphase DO
          IF ((((lactions[tph] = Cast) and (lobjects[tph] = ord(Clairvoyance))) or
               ((lactions[tph] = Use_MI) and (treaslist[lobjects[tph]] = bnaw))) and
              (lextra[tph] = clobj)) THEN BEGIN
            IF Counter_Science(clobj,Clairvoyance) THEN intel_lev[kng]:= intel_lev[kng]+1
              ELSE intel_lev[kng]:= 200;
            prov_spy[kng]:= ldr;
            WRITE(' CS:',kng,'/',ldr);
            WRITE('/',clobj,'/',_defl,'/',_attl);
           END;
       END;
     END;
  kng:= powner[x,y];
  IF kng < nkings THEN intel_lev[kng]:= intel_lev[kng]+4;
  FOR kng:= 0 TO nkings-1 DO CASE intel_lev[kng] OF
    0: intel_lev[kng]:= S_IDipl;
    1: intel_lev[kng]:= S_AA + (LRand MOD 3);
    2: intel_lev[kng]:= S_Batt + (LRand MOD 3);
    3: intel_lev[kng]:= S_Adv + (LRand MOD 3);
    4: intel_lev[kng]:= S_PCom + (LRand MOD 3);
    5: intel_lev[kng]:= S_PCom + (LRand and 1);
    100..255: intel_lev[kng]:= S_Priv; {clairv}
    ELSE intel_lev[kng]:= S_PCom;
   END;
  IF _attl = 162 THEN BEGIN
    WRITE('(162):',intel_lev[17],'.');
   END;
{  IF repldr = 3 THEN IF _rphase >= 5 THEN BEGIN
    WRITE('xxil:',intel_lev[7],'.');
    bwek('Author3');
   END;}
 END;

{FUNCTION Spy_Prof(kng: integer): integer;
VAR spn: integer;

FUNCTION LRand: integer;
BEGIN LRand:= _prov+gameturn+kng+lplan^[kng].lobjects[0]; END;

BEGIN
  spn:= intel_lev[kng];
  CASE spn OF
    0: Spy_Prof:= S_IDipl;
    1: Spy_Prof:= S_AA + (LRand MOD 3);
    2: Spy_Prof:= S_Batt + (LRand MOD 3);
    3: Spy_Prof:= S_Adv + (LRand MOD 3);
    4: Spy_Prof:= S_PCom + (LRand MOD 3);
    5: Spy_Prof:= S_PCom + (LRand and 1);
    100.255: Spy_Prof:= S_Priv;
    ELSE Spy_Prof:= S_PCom;
   END;
 END;
}
PROCEDURE Refresh_Moves;
VAR x,y,i: integer;
    a: ability;
BEGIN
  FOR x:= left TO right DO FOR y:= top TO bottom DO
    termod^[x,y]:= termod^[x,y] and (not Part_Eff);
  aphase:= -1;
  FOR i:= 0 TO nleaders-1 DO BEGIN
    IF i < nkings THEN kprevgold[i]:= No_King;
    lspec[i]:= lspec[i] and (L_Dead*7);
    WITH lplan^[i] DO BEGIN
      planstart:= -1;
      planend:= -1;
     END;
{    Clear_LMove(i);}
   END;
  IF valhero < nleaders THEN lstate[valhero]:= Hired;
 END;

PROCEDURE Re_Liege;
VAR i: integer;
BEGIN
  FOR i:= 0 TO nleaders-1 DO BEGIN
    liege0[i]:= lliege[i];
    IF i >= nkings THEN IF liege0[i] = noleader THEN lplan^[i].septr:= Nil;
   END;
 END;

PROCEDURE End_Effects;
VAR x,y,n,i,j,ldr: integer;
    badpeff: integer;
BEGIN
  badpeff:= 0;
  FOR x:= left TO right DO FOR y:= top TO bottom DO BEGIN
    FOR n:= 0 TO 1 DO ahired^[x,y,n]:= 0;
    termod^[x,y]:= termod^[x,y] and
      (not (Bless_Eff or Flood_Eff or Quake_Eff));
    IF Plague_Val(x,y) = 12 THEN Assign_Peff(termod^[x,y],0)
      ELSE IF Plague_Val(x,y) > 0 THEN Inc(badpeff);
    IF termod^[x,y] and (Illus_Eff*15) > 0 THEN
      IF Random < 0.15 THEN termod^[x,y]:= termod^[x,y] and (not (Illus_Eff*15))
   END;
  IF badpeff > 4 THEN IF gdyear = 1991 THEN
    FOR x:= left TO right DO FOR y:= top TO bottom DO Assign_Peff(termod^[x,y],0);
  FOR n:= 0 TO narmies-1 DO IF n <> 255 THEN BEGIN
    AMP[N]:= Mod_Speed(Mod_AType(n));
    IF adie^[n] = 250 THEN BEGIN
      adie^[n]:= 0;
      atype[n]:= weres;
      arace[n]:= werefolk;
     END;
    IF astate[n] <> Dead THEN adie^[n]:= 0;
   END;
  FOR n:= 0 TO nfeatures-1 DO BEGIN
    IF Random < 0.10 THEN IF fmod[n] and F_Hid > 0 THEN
      fmod[n]:= (fmod[n] xor F_Hid);
    fmod[n]:= fmod[n] and (not F_Sacked);
   END;
  FOR ldr:= 0 TO nleaders-1 DO BEGIN
    lspec[ldr]:= lspec[ldr] and $FFE0;
    IF ldr < nkings THEN BEGIN
      brreq[ldr]:= 0;
      allreq[ldr]:= 0;
     END;
   END;
 END;

FUNCTION Plan_Intent(td: desigptr): maneuver;
VAR int: maneuver;
BEGIN
  int:= CNone;
  WHILE ((int = CNone) and (td <> Nil)) DO BEGIN
    CASE maneuver(td^.dn) OF
      CFlee: int:= CFlee;
      CFulfill,CTalk,CGive: int:= CTalk;
      CSteal: int:= CSteal;
      CScout: ;
      CSay: IF td^.nextbyte = Nil THEN int:= CTalk;
      CShoot,CMelee: int:= CMelee;
      CUse_MI: IF ord(treaslist[td^.dobj]) <> ord(wcp) + ord(Invisibility) THEN
        IF ord(treaslist[td^.dobj]) <> ord(wcp) + ord(Charm) THEN
          int:= CMelee;
      CCast: WITH td^ DO CASE spell(dobj) OF
        Invisibility, Charm, Augur_Combat: ;
        ELSE int:= CMelee;
       END;
     END;
    td:= td^.nextbyte;
   END;
  IF int = CNone THEN int:= CMelee;
  Plan_Intent:= int;
 END;

FUNCTION ISpy_Cover(ldr: integer): real;
VAR tfa,covskill: integer;
BEGIN
  IF ldr >= nleaders THEN covskill:= 0
    ELSE IF cover[ldr] = noabil THEN covskill:= 0
    ELSE covskill:= M_Skill(ldr,cover[ldr]);
  CASE covskill OF
    0: ISpy_Cover:= 1.0;
    1: ISpy_Cover:= 0.5;
    2: ISpy_Cover:= 0.25;
    3: ISpy_Cover:= 0.12;
    4..10: ISpy_Cover:= 0.05;
   END;
 END;

PROCEDURE Put_Cust;
VAR datf: file;
    woe: integer;
BEGIN
{  WRITE(' PC:');}
  Assign(datf,'C:\tp\cust.dat');
  Reset(datf,1);
  woe:= IOResult;
  IF woe <> 0 THEN BEGIN
      WRITELN('Can''t open cust.dat! (error ',woe,')');
      WEK;
     END
    ELSE BEGIN
      Seek(datf,playspot);
      Check_Neg(player);
      BlockWrite(datf,player,SizeOf(guyrec));
      IO_Check('Put Cust');
      Close(datf);
     END;
 END;

PROCEDURE Clear_FD;
VAR i: integer;
BEGIN
  FOR i:= 0 TO 10 DO BEGIN fdinc[i]:= 13; fdcode[i]:= 0; fdch[i]:= 0; END;
 END;

FUNCTION Rep_Charges(k: krange; su: boolean): longint;
VAR turncharge: longint;
BEGIN
  WITH player DO
    IF COmpany = Lucky THEN turncharge:= 0
      ELSE IF standby[k] = SB_Waiting THEN turncharge:= 0
      ELSE IF not su THEN
        turncharge:= integer((((longint(turn_cost
          - (50*ord((ksendmeth[k] = S_Forum) or (ksendmeth[k] = S_Genie)))
          + (50*ord((ksendmeth[k] = S_CServe) and (kteam[k] >= 200))))
           Shr ord((not catchup) and (not kfindo[k]))) *
           longint(kpayperc[k]))+250) DIV 500)*5
      ELSE IF gametyp = Trial_V THEN BEGIN
        IF balance+checkadd >= 950 THEN turncharge:= 950 ELSE turncharge:= 0;
       END
      ELSE IF usefree THEN turncharge:= setup_fee
      ELSE BEGIN
        usefree:= true;
        turncharge:= 0;
       END;
  Rep_Charges:= turncharge;
 END;

PROCEDURE Write_Addr(kng: krange; VAR mf: text; inch: boolean);
VAR s,bs: str40;
BEGIN
  IF inch THEN BEGIN
     IF company = Roland THEN bs:= '                                     '
       ELSE bs:= '          '
    END
   ELSE bs:= '';
  WITH player DO BEGIN
    WRITELN(mf,bs,name);
    WRITELN(mf,bs,street1);
    IF street2 <> '' THEN WRITELN(mf,bs,street2);
    IF Company <> Roland THEN WRITE(mf,bs,city,'  ',state,'  ')
      ELSE WRITE(mf,bs,zip,' ',city,'  ',state);
    IF country <> '' THEN BEGIN
        IF Company <> Roland THEN WRITELN(mf,zip) ELSE WRITELN(mf);
        WRITE(mf,bs);
        IF Mail_Send(kng) THEN WRITE(mf,'');
        WRITELN(mf,country);
       END
      ELSE BEGIN
        WRITELN(mf);
        IF Company <> Roland THEN WRITELN(mf,bs,'':20,zip)
          ELSE WRITELN(mf);
       END;
    FOR i:= 5 + ord(street2 <> '') TO 6 DO WRITELN(mf);
   END;
 END;

PROCEDURE Center_Write(k: krange; s: Str80);
BEGIN
  Center_Pad(s,39);
  IF not Mail_Send(k) THEN gs:= Concat('                ',s)
    ELSE gs:= Concat(chr(14),s);
  WRITELN(playfile,gs);
 END;

PROCEDURE Write_Stars; VAR i: integer;
BEGIN FOR i:= 1 TO 78 DO WRITE(playfile,'*'); WRITELN(playfile); END;

PROCEDURE Append_Note;
VAR ldr,woe: integer;
    afn: Str30;
BEGIN
  WRITE('Which King #? '); READLN(ldr);
  Get_MFN('se',gameturn-1,ldr,afn);
  Assign(playfile,afn);
  Append(playfile);
  woe:= IOResult;
  IF woe <> 0 THEN BEGIN WRITELN('Error ',woe); WEK; END
    ELSE BEGIN
      Center_Write(ldr,'GM NOTES');
      REPEAT
        WRITE('?'); Readln(tmp);
        Writeln(playfile,tmp);
      UNTIL Length(tmp) = 0;
      Write_Stars;
      AClose(playfile);
     END;
 END;

PROCEDURE Write_MF(k: krange);
label 5,7,10;
CONST doop: array[ArkRoyal..LastCo] OF Str10 =
      ('hpcon ','hpcon ','print ','hpcon ','print ','print ','hpcon ','hpcon ','hpcon ','hpcon ');

VAR ldr,k2: lrange;
    s2,s3,s4: str10;
    writnews,customer,fk: boolean;
    l2,bottline,tpay: byte;
    phases,kse,ks2,turncharge: integer;
    fn1,sufn: Str30;
    tf: Str40;

PROCEDURE New_Page;
BEGIN
  IF Mail_Send(k) THEN BEGIN
    Page_Print;
    WRITELN(playfile);
   END;
 END;

PROCEDURE WPF;
BEGIN  WRITELN(playfile); END;

PROCEDURE Write_SEP(sep: desigptr);
VAR ma: maneuver;
BEGIN
  IF sep <> Nil THEN BEGIN
    WRITE('Ws',sep^.dn,'/',sep^.dobj,'.');
    ma:= maneuver(sep^.dn);
    WRITE(playfile,manab[ma]);
    CASE ma OF
      CCast: WRITE(playfile,'-',spab[spell(sep^.dobj)]);
      CGive,CUse_MI: WRITE(playfile,'-',sep^.dobj);
      CSay: WRITE(playfile,'*');
     END;
    IF sep^.nextbyte <> Nil THEN WRITE(playfile,',') ELSE WRITE(playfile,' ');
    Write_SEP(sep^.nextbyte);
   END;
 END;

FUNCTION RCons: char; BEGIN  RCons:= cons[IRand MOD 19]; END;
FUNCTION RVowel: char; BEGIN  RVowel:= vowels[IRand MOD 5]; END;
{$V-}
PROCEDURE Check_UN(VAR uns: Str20);
BEGIN
  IF uns = '' THEN IF Company = ArkRoyal THEN BEGIN
    WRITELN;
    WRITE('User# for ',player.name,'? ');
    Readln(uns);
   END;
 END;
{$V+}

{$I send.pas}

PROCEDURE Check_LowLife;
BEGIN
  WITH player DO BEGIN
    IF country <> '' THEN IF ksendmeth[k] >= S_Disk THEN IF autorun THEN
      IF sendint = 0 THEN Inc(nfkings);
    IF credit+balance+turnadd[k]+checkadd < 0 THEN BEGIN
      Give_Notice(name,account,') has dropped to ',
        0.01*(credit+balance+turnadd[k]+checkadd-Rep_Charges(k,gameturn = 0)-guyfee),
        '. Please fix!');
      kbum[k]:= true;
     END;
   END;
 END;

PROCEDURE Write_Label(mode: integer);
VAR dfn,pfn,cfn: Str30;
    ks: Str40;
    i,k2,mi: integer;

PROCEDURE Check_First;
BEGIN  IF first_print THEN WRITE(batfile,'/q:32 '); first_print:= false; END;

PROCEDURE Check_Lab;
BEGIN
  IF first_print THEN BEGIN
      IF ((Company <> Standard) and (Company <> Roma)) THEN BEGIN
        IF not autorun THEN BEGIN
          WRITELN(batfile,'REM Feed mailing labels to printer');
          WRITELN(batfile,'pause');
         END;
        WRITE(batfile,doop[Company]);
        Check_First; WRITELN(batfile,'c:\',akroot,'mailjob.lab');
       END;
      IF not autorun THEN BEGIN
        WRITELN(batfile,'REM Feed 15# paper to printer');
        WRITELN(batfile,'pause');
       END;
      first_print:= false;
     END;
 END;

PROCEDURE Batch_Print;
BEGIN
  Check_Lab;
  WRITE(batfile,doop[Company],dfn,'\',pfn);
  IF Company = Standard THEN WRITE(batfile,' 1')
    ELSE WRITE(batfile,' ',aksides);
  WRITELN(batfile);
 END;

PROCEDURE Summ_Print;
VAR sfn: Str30;
BEGIN
  IF ((Company <> Standard) and (Company <> PBM_Express)) THEN
    IF diskminus[k] and 2 = 0 THEN BEGIN
      Check_Lab;
      Get_MFN('su',gameturn,k,sfn);
      WRITELN(batfile,doop[Company],dfn,'\',sfn,' ',aksides);
     END;
 END;

PROCEDURE Batch_Copy;
VAR dpref,mpref: Str10;
    xfn: Str30;
BEGIN
  IF kpmode[k] = 1 THEN dpref:= ' a:' ELSE dpref:= ' b:';
  IF kpmode[k] = 2 THEN mpref:= 'mcp m' ELSE mpref:= '';
  IF kpmode[k] = 99 {ex-8} THEN
      WRITELN(diskfile,'rem copy ',player.name,'''s Amiga disk (#',k,')')
    ELSE WRITELN(diskfile,'rem insert ',player.name,'''s disk (#',k,') in drive',dpref);
  WRITELN(diskfile,'pause');
  IF kpmode[k] <> 99 THEN BEGIN
    WRITELN(diskfile,mpref,'del',dpref,'xk*.k',k);
    WRITELN(diskfile,mpref,'del',dpref,'se*.k',k);
    IF gameturn <= 2 THEN IF kpmode[k] = 1 THEN BEGIN
      WRITELN(diskfile,'del',dpref,'rules.ak');
      WRITELN(diskfile,'del',dpref,'tips.ak');
      WRITELN(diskfile,'del',dpref,'policy.ak');
     END;
    IF ((kpmode[k] = 6) and (false)) THEN BEGIN
        WRITELN(diskfile,'copy c:\saga.prg b:');
        WRITELN(diskfile,'copy c:\saga.fed b:');
       END
      ELSE IF ((kpmode[k] = 1) or (kpmode[k] = 9)) THEN
        IF odinvers[k] < interp_vers THEN BEGIN
          WRITELN(diskfile,'copy c:\saga.exe',dpref);
          WRITELN(diskfile,'copy c:\??roman.fnt',dpref);
         END
        ELSE WITH player DO IF flysent and 32 = 0 THEN IF kpmode[k] = 9 THEN BEGIN
          WRITELN(diskfile,'del ',dpref,'rules.dos');
          WRITELN(diskfile,'copy c:\akstart.exe',dpref);
          WRITELN(diskfile,'copy c:\akgo.bat',dpref);
          WRITELN(diskfile,'copy c:\tp\rules.ak',dpref);
         END;
    Get_MFN('xk',gameturn+1,k,xfn);
    WRITELN(diskfile,mpref,'copy ',dfn,'\',xfn,dpref);
    WRITELN(diskfile,mpref,'copy ',dfn,'\',pfn,dpref);
    IF kpmode[k] <> 2 THEN BEGIN
      WRITELN(diskfile,'IF exist ',dpref,pfn,' GOTO NT',gameno,k);
      WRITELN(diskfile,'REM The file wasn''t copied!');
      WRITELN(diskfile,'pause');
      WRITELN(diskfile,':NT',gameno,k);
     END;
    WRITELN(diskfile,'REM Was the copy OK?  Press return to continue.');
   END;
  Get_MFN('se',gameturn,k,pfn);
  IF gameturn = 0 THEN BEGIN
      Batch_Print;
     END
    ELSE BEGIN
      Summ_Print;
     END;
 END;

BEGIN {write_label}
  WITH player DO BEGIN
    IF ((Company = Roma) or ((ksendmeth[k] = S_Disk) and (kpmode[k] = 1)) or
        (diskminus[k] and 2 <> 0) or
        ((gameturn = 0) and (kpayperc[k]+guyfee <> 0) and (player.dyear < 1992))) THEN
      Write_Addr(k,mailfile,false);
    GetDir(0,dfn);
    FOR mi:= 1 TO (1+ord(diskminus[k] and 8 = 8)) DO
     IF ((gameturn = 0) or (ksendmeth[k] > S_Disk) or
         ((ksendmeth[k] < S_Disk) and (diskminus[k] and 4 = 4)) or
         ((ksendmeth[k] = S_Disk) and (diskminus[k] and 1 = 0))) THEN BEGIN
      Get_MFN('xk',gameturn+1,k,cfn);
      WRITE(colorfile,'prak ',dfn,'\',cfn);
      IF kteam[k] >= 100 THEN FOR k2:= 0 TO nkings-1 DO IF k <> k2 THEN
        IF kteam[k2] = kteam[k] THEN BEGIN
          Get_MFN('xk',gameturn+1,k2,cfn);
          WRITE(colorfile,' ',dfn,'\',cfn);
         END;
      WRITELN(colorfile);
     END;
    Get_MFN('se',gameturn,k,pfn);
    CASE mode OF
      S_Forum,S_CServe,S_GEnie: IF ((gameturn = 0) or
        (diskminus[k] and 4 = 4)) THEN Batch_Print;
      S_Disk: BEGIN
        Batch_Copy;
        IF gameturn > 0 THEN IF diskminus[k] and 4 = 4 THEN Batch_Print;
       END;
      S_Both,S_Printout,S_Both: Batch_Print;
     END;
   END;
 END;

PROCEDURE Write_ALine(money: longint; desc: Str40; wrch: boolean; prefix: char);
BEGIN
  IF ((Company = PBM_Express) or (Company = Lucky)) THEN WRITE(playfile,'':35)
    ELSE IF money < -32499 THEN WRITE(playfile,'--------','':27)
    ELSE Write(playfile,prefix,money/100:7:2,'  ',desc,'':25-Length(desc));
  IF wrch THEN WITH player DO
    WRITELN(chargefile,money/100:7:2,'  ',money*15/11500:7:2,
            '   0.00   0.00 ',desc:12,' AK #',gameno:4,gameturn:3,
            '  Acct #',account:4,' ',name);
  WITH player DO IF bottline = 1 THEN
      WRITELN(playfile,'New address/phone? ____________________')
    ELSE IF bottline <= 4 THEN BEGIN
      IF ((bottline = 4) and (phone = '') and (gameturn <=2)) THEN
          WRITELN(playfile,   '(We don''t have your phone #: __________')
        ELSE WRITELN(playfile,'_______________________________________');
     END
    ELSE WPF;
  Inc(bottline);
 END;

PROCEDURE Check_News;
BEGIN
  IF not writnews THEN BEGIN
    IF emp = No_King THEN IF ksendmeth[k] > S_Genie THEN New_Page;
    WPF;
    Write_Stars;
    Center_Write(k,'GAME NEWS');
    WPF;
   END;
  writnews:= true;
 END;

PROCEDURE Fin_News;
TYPE daterec = record
     day,month,year,game: longint;
    END;
VAR p1,tsp,code: integer;
    news,search: daterec;

PROCEDURE Find_LNum;
BEGIN
  WHILE ((tsp+1 <= Length(tmp)) and
         (tmp[tsp+1] >= '0') and (tmp[tsp+1] <= '9')) DO Inc(tsp);
 END;

FUNCTION Find_Num: boolean;
BEGIN
  Find_Num:= true;
  Inc(tsp);
  WHILE ((tsp <= Length(tmp)) and ((tmp[tsp] = ' ') or (tmp[tsp] = '/'))) DO
    Inc(tsp);
  IF ((Length(tmp) < tsp) or (tmp[tsp] < '0') or (tmp[tsp] > '9')) THEN
      Find_Num:= false
    ELSE BEGIN
      p1:= tsp;
      Find_LNum;
      Find_Num:= true;
     END;
 END;

FUNCTION Get_Num(VAR n: longint): boolean;
BEGIN
  Get_Num:= false;
  IF Find_Num THEN BEGIN
    Val(Copy(tmp,p1,tsp-p1+1),n,code);
    Get_Num:= true;
   END;
 END;

PROCEDURE WT;
BEGIN
  Check_News;
  WRITELN(playfile,tmp);
  IF Pos('=*=',tmp) > 0 THEN kquest[k]:= true;
 END;

BEGIN
  IF customer THEN IF sendint = 0 THEN BEGIN
    Assign(miscfile,'C:\tp\news.txt');
    AReset(miscfile);
    IF IOResult = 0 THEN BEGIN
      WITH news DO BEGIN year:= 0; day:= 0; month:= 0; game:= 0; END;
      IF _areset THEN
        IF player.dmonth > 1 THEN Dec(player.dmonth) ELSE Dec(player.dyear);
      REPEAT
        READLN(miscfile,tmp);
        tsp:= 0;
        WITH search DO BEGIN
          day:= -1; month:= -1; year:= -1; game:= -1;
         END;
        WITH search DO IF Get_Num(month) THEN IF Get_Num(day) THEN
          IF Get_Num(year) THEN IF Get_Num(game) THEN BEGIN
  {          WRITE('',month:3,day:3,year:5,game:3); REadln;}
           END;
        IF search.game > -1 THEN BEGIN
          IF search.year < 85 THEN search.year:= search.year+2000
            ELSE IF search.year < 1900 THEN search.year:= search.year+1900;
          news:= search;
         END;
        WITH news DO BEGIN

          IF ((game > 0) or (Max(0,year-1989)*512+month*32+day >
            (Max(0,player.dyear-1989)*512)+(player.dmonth*32)+player.dday)) THEN
              IF ((game <= 0) or (gameno = game)) THEN WT;
         END;
      UNTIL ((IOResult <> 0) or (eof(miscfile)));
      AClose(miscfile);
     END;
    IF writnews THEN Write_Stars;
   END;
 END;

PROCEDURE Write_Standby;
BEGIN
  WPF;
  WRITELN(playfile,'   Occasionally, a player will drop out of a game.  We then try to substitute');
  WRITELN(playfile,'a standby player, charging a fraction of the turn cost proportional to the');
  WRITELN(playfile,'strength of the position until it is restored.  Are you interested in playing');
  WRITE(playfile,'a standby position, or do you know someone who is?');
  IF sbperc[Company] = 100 THEN WPF
    ELSE BEGIN
      WRITELN(playfile,'If so, please describe');
      WRITELN(playfile,'what type and strength/price of position you would like to stand by for');
      WRITELN(playfile,'(minimum turn fee is ',
        Max(40,sbperc[Company]),'% of regular fee) _____________________________________');
     END;
  WRITELN(playfile,'_____________________________________________________________________________');
 END;

PROCEDURE Write_Chars;
BEGIN
  WRITELN(playfile,' Name/Title: ______________________ Abilities: _____________ Temper: ________');
  WPF;
 END;

PROCEDURE CWP;
BEGIN
  IF customer THEN WITH player DO BEGIN
      Str(player.account,tmp);
      tmp:= Concat('Name: ',name,'  Acc: ',tmp);
     END
    ELSE tmp:= 'Name: ________  Acc: ____';
  WITH player DO Center_Write(k,tmp);
 END;

PROCEDURE Write_Entry;
BEGIN
  New_Page;
  WPF;
  Center_Write(k,'ADVENTURER-KINGS ENTRY FORM');
  CWP;
  WPF; WPF;
  Write_Chars;
  WRITELN(playfile,' Alignment: _____________ Race: ___________ (Standby positions may vary)');
  WPF;
  WRITELN(playfile,' Turnaround days: ______.  Diplomacy:   Full  Limited');
  WPF;
  WRITELN(playfile,' Which size game (circle one)?   8-11 players   25-40 players');
  WPF;
  WRITELN(playfile,' Which method (circle one)?   Postal   Disk-Mailer   E-Mail   Other');
  WPF;
  WRITELN(playfile,' Circle One:    New Game   Standby');
  Write_Standby;
 END;

PROCEDURE Check_PToo;
BEGIN
  IF kse = S_Both THEN Write_Label(S_Printout);
 END;

BEGIN {Write_MF}
  kquest[k]:= false;
  Check_Debug('p');
  New_Page;
  WPF;
  WRITELN(playfile,caddr[Company]);
  IF Company = Lucky THEN WRITELN(playfile,'                 Phone: (415)-712-0283  Fax: (415)-712-0284');
  WPF;
  Center_Write(k,'THE ADVENTURER-KINGS MOVES SHEET');
  Str(gameno,tmp);
  Str(Adj_Turn+1,s2);
  Str(gdday,s3); Str(gdyear,s4);
  IF emp = No_King THEN
    Center_Write(k,Concat('Game: ',tmp,'  Turn: ',s2,'  Due: ',
      Copy(monthname[month(gdmonth)],1,3),'. ',s3,', ',s4));
  writnews:= false;
  customer:= Get_Cust(k,player,true);
  CWP;
  Check_Debug('q');
  IF customer THEN WITH player DO BEGIN
    IF ((emp <> No_King) or (flysent and 16 = 0)) THEN
      IF standby[k] <= SB_Int THEN IF kacct[k] > 0 THEN BEGIN
        Center_Write(k,'Rating: ??????????????????');
{
        Get_MFN('se',gameturn,k,fn1);
        GetDir(0,tf);
        WRITELN(batfile,'putrat ',tf,'\',fn1,' ',kacct[k]);
}
       END;
    odinvers[k]:= Max(custodin,odinvers[k]);
    IF credit < 0 THEN credit:= 0;
    IF _areset THEN
      balance:= balance -turnadd[k] +Rep_Charges(k,false) +miscfee[k];
    Check_LowLife;
    WPF;
    bottline:= 1;
  Check_Debug('r');
    turncharge:= Rep_Charges(k,gameturn = 0);
    IF gameturn = 0 THEN IF kpayperc[k] = 0 THEN totfees:= totfees+miscfee[k]+guyfee;
    IF credit > 0 THEN Write_ALine(credit,'Beginning Credit',false,' ');
    Write_ALine(balance,'Beginning Balance',false,' ');
    IF gameturn = 0 THEN Write_ALine(turncharge,'Setup Fee',true,'-')
      ELSE Write_ALine(turncharge,'Turn Charge',true,'-');
    IF miscfee[k]+guyfee <> 0 THEN BEGIN
      IF miscfee[k]+guyfee > 0 THEN BEGIN
          Write_ALine(miscfee[k]+guyfee,miscdesc^[k],true,'-');
          turncharge:= turncharge + miscfee[k]+guyfee;
         END
        ELSE BEGIN
          Write_ALine(-(miscfee[k]+guyfee),'Promotional Credit',true,'+');
          credit:= credit-(miscfee[k]+guyfee);
         END;
     END;
  Check_Debug('s');
    IF turnadd[k]+checkadd > 0 THEN BEGIN
      Write_ALine(turnadd[k]+checkadd,'Funds Received',false,'+');
      balance:= balance+turnadd[k]+checkadd;
      Write_ALine(balance,'Adjusted Balance',false,' ');
     END;
    Write_ALine(-32500,'',false,' ');
    IF ((turncharge > 0) and (credit >= turncharge)) THEN BEGIN
        credit:= credit-turncharge;
        Write_ALine(credit,'Current Credit',false,' ');
        Write_ALine(balance,'Current Balance',false,' ');
       END
      ELSE BEGIN
        IF ((credit > 0) and (turncharge > 0)) THEN BEGIN
          turncharge:= turncharge-credit;
          credit:= 0;
          Write_ALine(0,'Current Credit',false,' ');
         END;
        balance:= balance-turncharge;
        Write_ALine(balance,'Current Balance',false,'=');
        IF balance+credit < turncharge THEN IF gametyp > Trial_V THEN BEGIN
          WPF;
          WRITELN(playfile,'_______ Enclosed? (Your account is low.  Please replenish it!)');
         END;
       END;
    IF prize[k] > 0 THEN BEGIN
      Write_ALine(prize[k],'Prize Credit',false,'+');
      credit:= credit+prize[k];
      Write_ALine(credit,'Adjusted Credit',false,' ');
     END;
   END;
  Check_Debug('t');
  IF customer THEN BEGIN
    WPF;
    kse:= ksendmeth[k];
    ks2:= kse; IF ks2 = S_Both THEN ks2:= S_CServe;
    IF ((Company = ArkRoyal) and (kse <> S_Printout)) THEN BEGIN
        Check_PToo;
        kse:= S_Forum; ks2:= kse;
        GOTO 5;
       END
      ELSE IF Sending_Int(k) = 2 THEN BEGIN
        kse:= -1;
        IF player.hasarc and 1 = 1 THEN
            Write_Send('pk','xk','Zip/UUE File',sendfile[S_GEnie],first_send[S_GEnie],S_GEnie)
          ELSE Write_Send('se','xk','Report',sendfile[ks2],first_send[ks2],ks2);
        Check_PToo;
       END
      ELSE IF Sending_Int(k) = 1 THEN BEGIN
        kse:= -1;
        Write_Send('pk','xk','Zip/UUE File',sendfile[S_CServe],first_send[S_CServe],S_CServe);
        Check_PToo;
       END
      ELSE {IF gameturn > 0 THEN}
5:    CASE kse OF
        S_CServe,S_GEnie,S_Both:
7:        BEGIN
          IF player.hasarc and 1 = 1 THEN BEGIN
              Write_Send('pk','xk','Archive File',sendfile[ks2],first_send[ks2],ks2);
              Check_PToo;
              GOTO 10;
             END
            ELSE IF kpmode[k] > Unk_Co THEN BEGIN
              Write_Send('se','xk','Report',sendfile[ks2],first_send[ks2],ks2);
              Write_Send('xk','xk','',sendfile[ks2],first_send[ks2],ks2);
              Check_PToo;
              GOTO 10;
             END
            ELSE BEGIN
              Write_Send('se','xk','Report',sendfile[ks2],first_send[ks2],ks2);
              Check_PToo;
             END;
         END;
        S_Forum: IF Company = ArkRoyal THEN GOTO 7
          ELSE BEGIN
            Write_Send('pk','xk','Crypted Archive',sendfile[S_Forum],first_send[S_Forum],S_Forum);
            GOTO 10;
           END;
        S_Disk: Write_Label(S_Disk);
        S_Printout: Write_Label(S_Printout);
       END
(*      ELSE BEGIN
{$IFDEF More_Entry}
        Write_Label(kse);
        IF kse = S_Forum THEN kse:= S_CServe;
        CASE kse OF
          S_Forum,S_CServe,S_GEnie,S_Both: IF kpmode[k] > Unk_Co THEN BEGIN
            Write_Send('xk','xk','',sendfile[ks2],first_send[ks2],kse);
            GOTO 10;
           END;
         END;
{$ENDIF}
       END;
*)
   END;
  Check_Debug('u');
  IF emp <> No_King THEN GOTO 10;
  WPF;
  WPF;
  WRITELN(playfile,' The Kingdom will Treat with (list King numbers): ____________________________');
  WPF;
  WRITELN(playfile,' The Kingdom will Break Treaty with (list Kings): ____________________________');
  WPF;
  IF req_vote = Vote_Turn THEN
      WRITELN(playfile,' An election for World Emperor is being held.  Who has your vote? ____________')
    ELSE BEGIN
      WRITELN(playfile,' Are you among those Kings who call for an election next turn? _______________');
     END;
  WPF;
  IF Total_USkill(k) < 7 THEN Write_Chars;
  WRITE(playfile,' Check here to start another game of');
  Check_Debug('v');
  IF ({(Company = ArkRoyal) or} (Company = Roma)) THEN WRITELN(playfile,':  "Darkness of Silverfall"-[]   "AK"-[]')
    ELSE WRITELN(playfile,' Adventurer-Kings: []');
  IF ((gdmonth = 1) or ((gdmonth = 2) and (gdday <= 14))) THEN IF gdyear = 1992 THEN
    WRITELN(playfile,' Check here to order "Flagship''s Guide to Adventurer-Kings" ($4.00): []');
  WPF;
  WRITELN(playfile,'               Moves:');
  WRITELN(playfile,'Character ID   Phase 1      Phase 2      Phase 3      Phase 4      Phase 5');
  Use_NewVal(true,true);
  FOR ldr:= 0 TO nleaders DO IF ((ldr >= nleaders) or (LKing(ldr) = k)) THEN BEGIN
    WRITE('wL:',ldr,'/',nleaders,'.');
  Check_Debug('w');
    IF ldr >= nleaders THEN tmp:= '' ELSE Str(ldr,tmp);
    tmp:= Concat(' _',tmp,'__________');
    IF ldr = valhero THEN phases:= Min(5,(Adj_Turn DIV 2) +1) ELSE phases:= 5;
    WRITE(playfile,Copy(tmp,1,12),' ');
    FOR i:= 1 TO phases DO WRITE(playfile,' (__)________');
    WRITELN(playfile);
    IF ldr >= nleaders THEN tmp:= '(___________'
      ELSE tmp:= Concat('(',lname^[ldr],'___________');
    kknows^[ldr]:= kknows^[ldr] or (longint(1) Shl k);
    WRITE(playfile,Copy(tmp,1,12),') ');
    FOR i:= 1 TO phases DO WRITE(playfile,'(___________)');
    WRITELN(playfile);
    WRITE(playfile,' Enctr Plans: ');
    FOR i:= 1 TO phases DO WRITE(playfile,' ___________ ');
    WRITELN(playfile);
    WRITE('SP:',ldr);
  Check_Debug('x');
    WRITE(playfile,' Special Plan: ');
    WRITE('??');
    IF ((ldr < nleaders) and (lplan^[ldr].septr <> Nil)) THEN
      Write_SEP(lplan^[ldr].septr);
    WRITE('!!');
    WRITE(playfile,'___________');
    WPF;
    WPF;
   END;
  Check_Debug('y');
  Use_NewVal(false,true);
  IF gameturn <= 3 THEN BEGIN
    WRITELN(playfile,'(If you hire more characters, enter their orders below or on back).');
    WPF;
   END;
{10:  IF not kfindo[k] THEN IF not catchup THEN IF gameturn > 0 THEN IF kacct[k] > 0 THEN BEGIN
    Check_News;
    WRITELN(playfile,'   We hope that your missed turn was an oversight.  But, if you are dropping');
    WRITELN(playfile,'out of the game, please notify us at once so that we can give the position');
    WRITELN(playfile,'to a standby player.');
    WPF;
   END; }
10: IF gameturn = 2 THEN BEGIN
    WPF;
    WRITELN(playfile,'   We''re always looking for ways to make the turn report more interesting');
    WRITELN(playfile,'and informative.  If you''ve any suggestions, please tell us about it:');
    WPF;
    WPF;
   END;
  IF gameturn = 0 THEN BEGIN
{$IFDEF More_Entry}
    WPF;
    WRITELN(playfile,'   If you want to rename your characters or home province, you may do so.');
    WRITELN(playfile,'Also, please review the "Beginner''s Tips"/"Example Moves" sheet');
    IF gametyp > Trial_V THEN Write_Standby;
    IF ksendmeth[k] <= S_GEnie THEN IF kpmode[k] > Unk_Co THEN BEGIN
      WPF;
      WRITELN(playfile,'   This is your setup report.  Your moves datafile will soon be sent');
      WRITELN(playfile,'to you by electronic mail.  In future turns, we will send you your turn');
      WRITELN(playfile,'report and moves datafile by electronic mail in a pkzipped binary file,');
      WRITELN(playfile,'no later than 7:00 PM PST, the day after the due date.  The file can be');
      WRITELN(playfile,'decompressed using PKUNZIP, available on CompuServe in the new user''s forum.');
      WPF;
     END;
{$ENDIF}
   END;
  IF ((standby[k] = SB_Start) or (standby[k] = SB_Waiting)) THEN BEGIN
    Check_News;
    WRITELN(playfile,'   Thank you for accepting this standby position.  We hope that you will enjoy');
    WRITELN(playfile,'playing the role of a new Adventurer-King, come into the realm to save it from');
    WRITELN(playfile,'thy negligent predecessor; a man who was interested only in his racehorses and');
    WRITELN(playfile,'and concubines, and who ignored the vital affairs of state.  If you wish, you');
    WRITELN(playfile,'may start your King character from scratch, choosing 4 new abilities for your');
    WRITELN(playfile,'King, and also his name, gender and temper.  You may choose an alignment that');
    WRITELN(playfile,'that is no further than two steps removed from any of your characters.');
    WRITELN(playfile,'   This game is a ',gturnlen,'-day, ',gds[gdipltype],' game.');
    WPF;
{   IF gdipltype = 1 THEN BEGIN
      fk:= true;
      FOR k2:= 0 TO nkings-1 DO IF k2 <> k THEN
        IF kkmet[Min(k,k2)] and (longint(1) Shl Max(k,k2)) > 0 THEN
          IF Get_Cust(k2,opponent,false) THEN WITH opponent DO BEGIN
            IF fk THEN WRITELN(playfile,'   The following is a list of all other Kings known to your Kingdom:');
            fk:= false;
            WRITE(playfile,'  ',lname^[k2],': ',name,', ',street1,', ',street2,' ',
              city,', ',state,' ',country,'  ',zip,'  ',phone);
            IF cis <> '' THEN WRITE(playfile,' (CompuServe ',cis,')');
            IF genie <> '' THEN WRITE(playfile,' (GEnie ',genie,')');
            WPF;
           END;
      IF not fk THEN WPF;
     END;}
   END;
  IF sbperc[Company] < 100 THEN IF standby[k] >= SB_Waiting THEN BEGIN
    IF ((standby[k] = SB_Waiting) or (standby[k] = SB_Start)) THEN tpay:= maxperc[k]
      ELSE tpay:= Max(maxperc[k],kpayperc[k]);
    IF tpay < 100 THEN BEGIN
        Check_News;
        WRITELN(playfile,'   The next turn will cost you ',tpay,'% of the normal turn cost, due to the sub-');
        WRITELN(playfile,'par condition of the Kingdom.  This figure will rise as your position improves.');
        IF standby[k] <> SB_Rising THEN BEGIN
          WRITELN(playfile,'It is indexed to your standing as World Emperor and your standing in the');
          WRITELN(playfile,'office race in which you are closest to ranking first.  When the average');
          WRITELN(playfile,'of your standings in these offices is at ',tpay,'% or below of the leader''s total,');
          WRITELN(playfile,'the percentage will be ',tpay,'%, and will rise to 100% when you are in first place.');
          WRITELN(playfile,'There is one exception: the percentage will never go down when you lose ground');
          WRITELN(playfile,'in a race for Imperial office, but will remain the same.');
         END;
        WPF;
       END
      ELSE IF not Defeated(k) THEN BEGIN
        Check_News;
        WRITELN(playfile,'   Congratulations!  You have done so well with this standby Kingdom, it has');
        WRITELN(playfile,'been restored to a full-paying position!');
        WPF;
       END;
   END;
  IF NR_Or_G4 THEN IF Defeated(k) THEN IF kpayperc[k] = 100 THEN IF Company = ArkRoyal THEN BEGIN
    Check_News;
    WRITELN(playfile,'   All future turns will be at half-price, due to the sub-par condition');
    WRITELN(playfile,'of your Kingdom and the unlikelihood of retaking your capital province.');
    WPF;
   END;
  Fin_News;
  WPF;
  IF not Mail_Send(k) THEN WRITELN(playfile,'*** ',modname[Company],' ***');
  IF ((standby[k] = SB_Int) or (emp <> No_King)) THEN BEGIN
    IF ksendmeth[k] = S_Disk THEN BEGIN
      AClose(playfile);
      Get_MFN('su',gameturn,k,sufn);
      Assign(playfile,sufn);
      Append(playfile);
      IO_Check('Sum App');
      Page_Print;
     END;
    Write_Entry;
    standby[k]:= SB_No;
   END;
 END;

PROCEDURE PNum(num: integer); {Write a number (num) to turn report}
VAR s: Str20;
BEGIN  Str(num,s); WW(s); END;

PROCEDURE Par_Str(num: integer; VAR s: Str10); {put a number in "s", e.g "(#33)"}
BEGIN  Str(num,s); s:= Concat('(#',s,')'); END;

PROCEDURE ParPNum(num: integer);{Write a number (num) to turn report, e.g. "(#33)"}
VAR s: Str10; BEGIN  Par_Str(num,s); WW(s); END;

FUNCTION Say_Code(code: integer): boolean;
{If function returns true, "code" is a number that causes writing to the turn report; if not, "code" just alters a variable.}
BEGIN Say_Code:= ((code >= 32500) or ((code >= 3000) and (code <= 9999))); END;

FUNCTION Rint: integer; {Read a code from the character's "story" file}
BEGIN
  IF say_trial THEN Rint:= R01+R01
    ELSE BEGIN  Rint:= story^[tdex]; WRITE('(',story^[tdex],') '); Inc(tdex); END;
 END;

PROCEDURE Say(s: String; spytype: integer); {Write string "s" to the turn report.}
label 1,10,20,30,70,80,99;
VAR person,sayq,sp,wp,kng: integer;
    tms: Str40;
    sub: Str80;
    qcs: str10;
    m: monster;
    kingsay,mlist: boolean;
    exchar,comchar,cc2,cc3: char;

const

    wname: mwstrs = ('talons','fangs','claws','maw','jaws',
      'fists','sword','dagger','staff','hooves','teeth',
      'jaws','club','axe','deathly touch','tentacles',
      'beak','boulder','arrow','flame breath','acid stream',
      'poisonous breath','horrid scream',
      'plasmic pseudopod','mandible','stinger','limb','stony gaze',
      'no weapon');

    whit: mwstrs = ('slashed/Rclawed at','lunged/Rstruck at','slashed/Rswang at','lunged_at/Rattacked','lunged/Rsnapped at',
      'punched/Rswung at','swang/Rthrust at','thrust/Rlunged at','swang/Rthrust at','kicked/Rthrust at','bit/Rsnapped at',
      'snapped/Rlunged at','swang/Rsmashed at','chopped/Rswang at','groped_for/Rlunged_at','assailed/Rlashed_at',
      'pecked/Rstruck at','threw/Rhurled','fired/Rshot','breathed/Rexhaled','spat/Rsprayed',
      'breathed/Rexhaled','voiced/Rsounded',
      'oozed/Rgroped at','snapped/Rlunged at','thrust/Rflipped at','swang/Rclubbed at','glared/Rglowered',
      'swang at');

FUNCTION Ctrl_Punct(c: char): boolean;
{tests for ctrl-b and ctrl-e, which are symbols that turn the exclusive-king mode on and off.}
BEGIN
  Ctrl_Punct:= ((c = '') or (c = ''));
 END;

PROCEDURE Check_Nem(lopp: integer);
{If a monster opponent is a random encounter with a patrol, set the description as "the Officer"}
BEGIN
  IF lopp < nleaders THEN alt_pro:= 'the Officer';
 END;

PROCEDURE MW(fdex,adcode: integer); {write monster name to turn report}
BEGIN
  IF adcode = ill_addex THEN Say('the {mirror }image/Rillusion of ',spytype);
  IF ((randlevel > 1) and (fdex = maxfeatures+256) and
      (_mtype >= Giant) and (_mtype <= Witch)) THEN BEGIN
      WW('the Officer');
     END
    ELSE BEGIN
      IF randlevel = 1 THEN BEGIN
          Say(' ',spytype);
          tmp:= '';
          Dec(randlevel);
         END
        ELSE tmp:= 'the ';
      IF ill_addex = 3 THEN WW(Concat(tmp,mtname[fmonst[fdex and 255]]))
        ELSE WW(Concat(tmp,mtname[_mtype]));
     END;
 END;

PROCEDURE FW(fdex: integer); {write the feature name to the turn report}
BEGIN
  Say(ftname[ftype[_feat1 and 255]],spytype);
 END;

PROCEDURE AC_Say; {Write the name for the garrison commander of the province to the turn report}
BEGIN
  IF Company = Roland THEN Say('le commandant par interim',spytype)
    ELSE Say('the acting commander',spytype);
 END;

PROCEDURE Pronoun(_ldr,adcode: integer); {write pronoun, instead of leader name}
BEGIN
  IF _ldr >= 256 THEN MW(_ldr,adcode)
    ELSE IF _ldr <> noleader THEN BEGIN
      tms:= lname^[_ldr];
      IF ill_addex = adcode THEN Say('the illusion of ',spytype); {in case the leader is a mirror-image illusion}
      IF _impcode = _LKMeet THEN WW(Concat('"',tms,'"'))
        ELSE BEGIN
          IF kingsay THEN IF _ldr < nkings THEN KStr(_ldr,tms);
          WW(tms);
         END;
     END
    ELSE IF chief_on THEN BEGIN
      IF willdie <> noleader THEN AC_Say
        ELSE CASE Mod_PRace(_px,_py) OF Dragons..Whales, Mermish..Saurian:
            Say(Concat('the provincial ',rname[Mod_PRace(_px,_py)],' chieftain'),spytype);
              {In case the garrison commander is non-human, write "the provincial (race-name) Chieftain"}
          ELSE IF spytype <= S_Batt THEN AC_Say
          ELSE Say('the provincial garrison commander',spytype);
         END; {Case}
     END
    ELSE IF Company = Roland THEN WW('personne')
    ELSE WW('no one');
 END;

PROCEDURE Posse(_ldr: integer); {write possesive pronoun}
BEGIN
  CASE Gender(_ldr) OF
   -1: WW('her');
    0: WW('its');
    1: WW('his');
   END;
 END;

PROCEDURE Set_Plural;
{If repeating last "Say" statement, remove the part before "" because it's already been written.
This routine helps to conver two sentences, such as "I recruited army 222.  I recruited army 223."
to "I recruited army 222 and 223."}
VAR stdex,ctrlpos: integer;
    diffact: boolean;
BEGIN
  IF _saylev = 1 THEN _nextsay:= '';
  sayq:= 1;
  mlist:= false;
  ctrlpos:= Pos('',s);
  IF not say_trial THEN IF ctrlpos > 0 THEN BEGIN
    stdex:= tdex;
    IF _prevact = _impcode THEN BEGIN
{      WRITE('(SD)');}
      mlist:= true;
      IF ctrlpos > 1 THEN Delete(s,1,ctrlpos-1);
     END;
    diffact:= false;
    WHILE ((stdex < rdex) and (not diffact)) DO BEGIN
      CASE story^[stdex] OF
        3000..9999,32000..32760: IF story^[stdex] <> _impcode THEN
            diffact:= true
          ELSE BEGIN
            Inc(sayq);
            mlist:= true;
           END;
       END;
      Inc(stdex);
     END;
   END;
  IF _saylev = 1 THEN IF sayq > 1 THEN _nextsay:= s;
 END;

PROCEDURE Say_Options;
{Check all "/" separators to determine which phrase to choose, e.g. if "ran/Rswam", choose randomly between "ran" and "swam".}
VAR lbracep,slashp,w1bp,w2ep: integer;
    tbool: boolean;

FUNCTION Stop_Punct(c: char): boolean; {If "c" is a character that ends a word, function is true}
BEGIN
  Stop_Punct:= ((c = ' ') or (c = '}') or (c = '{') or (c = ',') or
     (End_Punct(c)));
 END;

FUNCTION Left_Choice: boolean; {Decide between left and write sides of "/" phrase-separator.}
BEGIN
  Left_Choice:= false;
  CASE s[slashp+1] OF
    'R': IF option = '' THEN Left_Choice:= tpinc <> 1
      ELSE Left_Choice:= Random < 0.5;
    'P': Left_Choice:= not mlist;
    'F': Left_Choice:= boolean(_feat1 and 1);
    'S': IF option = '' THEN BEGIN
          Left_Choice:= tpinc = 1;
         END
        ELSE IF ((spytype = S_PCom) or (spytype = S_Adv)) THEN BEGIN
           Left_Choice:= ((_mtype < GiOctopus) or (_mtype = nomonster));
         END
        ELSE IF Trav_Ter(_px,_py) <> Sea THEN
          IF _prov2 = 999 THEN Left_Choice:= true
            ELSE IF _impcode = _LExpCo THEN Left_Choice:= true
            ELSE IF Trav_Ter(_px2,_py2) <> Sea THEN Left_Choice:= true;
     ELSE WW('ERROR1');
   END;
 END;

BEGIN {Say_Options}
  REPEAT
    slashp:= Pos('/',s);
    IF slashp > 0 THEN
      IF Left_Choice THEN BEGIN
          w2ep:= slashp+2;
          WHILE ((w2ep < Length(s)) and (not Stop_Punct(s[w2ep+1]) and
                 (not Ctrl_Punct(s[w2ep+1])))) Do Inc(w2ep);
          Delete(s,slashp,w2ep-slashp+1);
         END
        ELSE BEGIN
          w1bp:= slashp-1;
          WHILE ((w1bp > 1) and (not Stop_Punct(s[w1bp-1])) and (not Ctrl_Punct(s[w1bp-1]))) DO Dec(w1bp);
          Delete(s,w1bp,slashp-w1bp+2);
         END;
  UNTIL slashp = 0;
  REPEAT
    lbracep:= Pos('{',s);
    IF lbracep > 0 THEN BEGIN
      IF option = '' THEN tbool:= tpinc < 2 ELSE tbool:= Random < 0.5;
      IF tbool THEN Delete(s,lbracep,Pos('}',s)-lbracep+1)
        ELSE BEGIN
          Delete(s,lbracep,1);
          Delete(s,Pos('}',s),1);
         END;
     END;
  UNTIL lbracep = 0;
 END;

PROCEDURE Check_Sayq;
{check for repeat of last "say" statement. If statements are repeated except for different subjects, make list.}
BEGIN
  IF sayq > 1 THEN BEGIN
    sp:= 255;
    IF sayq = 2 THEN BEGIN
        Space;
        WW('and');
        Space;
       END
      ELSE BEGIN
        WW(',');
        Space;
       END;
   END;
 END;

PROCEDURE Conc_Sub; {Join string "sub" with character s[wp]}
BEGIN
  sub:= Concat(sub,s[wp]);
  Inc(wp);
 END;

PROCEDURE Get_Char2; {place the next character in the "Say" string in cc2}
BEGIN
  IF Length(s) > sp THEN cc2:= s[sp+1] ELSE cc2:= '|';
  CASE cc2 OF
    '1'..'9': IF Length(s) > sp+1 THEN cc3:= s[sp+2] ELSE cc3:= '|';
    ELSE cc3:= '|';
   END;
 END;

PROCEDURE Set_Person(lcheck: integer);
{What sense is the sentence using? set "person" variable to:
  1 = "I",
  2 = "me",
  3 = "she/it/he",
  4 = "her/it/him"}

BEGIN
  IF (((ill_addex = 1) and (comchar = '<')) or (lcheck >= unkldr) or (cc2 = '6') or
      ((ill_addex = 2) and (comchar = '[')) or (sub = 'of')) THEN person:= 5
    ELSE BEGIN
      IF cc2 = '2' THEN person:= 2
        ELSE IF ((Company = Roland) and ((sub = 'de') or (sub = 'par') or (sub = '�'))) THEN person:= 2
        ELSE IF ((sub = 'to') or (sub = 'by') or (sub = 'at')) THEN
          person:= 2
        ELSE IF cc2 = '1' THEN person:= 1
        ELSE IF rumstats[playking]._pspace > 0 THEN person:= 1
        ELSE IF comchar = '<' THEN person:= 1 ELSE person:= 2;
      IF ((author = noleader) or (lcheck <> author)) THEN
        IF ((sub = 'by') or (sub = 'par')) THEN person:= 5 ELSE person:= person + 2;
     END;
 END;

PROCEDURE Set_Alt(lcheck,lopp,lcdex: integer);
{set appropriate pronoun substitute for "<" or "[" and place in variable "alt_pro"}
BEGIN
  IF Company = Roland THEN CASE person OF {"person" means 1st person, 2nd person, etc.}
    1: alt_pro:= 'je';
    2: alt_pro:= 'moi';
    3: IF firstp = lcheck THEN CASE Gender(lcheck) OF
       -1: alt_pro:= 'elle';
        0: alt_pro:= 'il';
        1: alt_pro:= 'il';
       END
      ELSE IF randlevel = 2 THEN IF lcheck = maxfeatures+256 THEN Check_Nem(lopp);
    4: IF secondp = lcheck THEN CASE Gender(lcheck) OF
       -1: alt_pro:= 'sa';
        0: alt_pro:= 'son';
        1: alt_pro:= 'son';
       END
      ELSE IF randlevel = 2 THEN Check_Nem(lopp);
   END
  ELSE CASE person OF
    1: alt_pro:= 'I';
    2: alt_pro:= 'me';
    3: IF firstp = lcheck THEN BEGIN
      IF pro1words < 7 THEN CASE Gender(lcheck) OF
       -1: alt_pro:= 'she';
        0: alt_pro:= 'it';
        1: alt_pro:= 'he';
       END
       END
      ELSE IF randlevel = 2 THEN IF lcheck = maxfeatures+256 THEN Check_Nem(lopp);
    4: IF secondp = lcheck THEN BEGIN
      IF pro2words < 7 THEN CASE Gender(lcheck) OF
       -1: alt_pro:= 'her';
        0: alt_pro:= 'it';
        1: alt_pro:= 'him';
       END
       END
      ELSE IF randlevel = 2 THEN Check_Nem(lopp);
   END;
  IF person <= 4 THEN
    IF Odd(person) THEN firstp:= lcheck ELSE secondp:= lcheck;
  lastp:= lcheck;
 END;

PROCEDURE Say_King(herg: integer); {Say King's name, or "the King"}
BEGIN
  IF herg = noleader THEN Say('the King',spytype)
    ELSE IF ((liege0[herg] = lliege[herg]) and (liege0[herg] <> noleader)) THEN
      Say(lname^[liege0[herg]],spytype)
    ELSE IF herg < nkings THEN Say(lname^[herg],spytype)
    ELSE Say('the King',spytype);
 END;

BEGIN {Procedure Say}
  IF Length(s) > 1 THEN IF Upcase(s[1]) = 'F' THEN CASE s[2] OF
    '0'..'9': BEGIN
      FD(Concat('c:\tp\prose\',s),spytype,IRand and 7);
      GOTO 99;
     END;
   END;
  IF _saylev = 0 THEN BEGIN
    tpinc:= 0;
    IF say_Trial THEN BEGIN  TextColor(7); WRITELN('  ',s,'=>'); attrib:= s; TextColor(15); END
      ELSE BEGIN
        IF Length(s) > 0 THEN FOR i:= 1 TO Length(s) DO
          IF s[i] >= ' ' THEN WRITE(s[i]) ELSE WRITE('^',chr(ord(s[i])+64));
        justecho:= true;
       END;
   END;
{  WRITE('+');}
1:  Inc(_saylev);
  Set_Plural;
  IF not extext THEN Say_Options;
  IF spytype <> S_Prev THEN event_lev:= spytype;
  IF undercov THEN
    IF spytype > S_Adv THEN undercov:= false
      ELSE event_lev:= S_Priv;
  sp:= 1; sub:= ''; kingsay:= false;
{  WRITE('|');}
  WHILE sp <= Length(s) DO BEGIN
    comchar:= s[sp]; Get_Char2;
    IF extext THEN GOTO 30;
    CASE comchar OF
      'a'..'z','A'..'Z': GOTO 30;
      ' ','_': IF not aoran THEN Space;
      '<': BEGIN
        Set_Person(_attl);
        IF ((cc2 = '''') or (cc3 = '''')) THEN IF lastp <> _attl THEN GOTO 70
          ELSE IF person + 2*ord(lastp <> _attl) <= 4 THEN BEGIN  sp:= sp+2; GOTO 10; END
            ELSE GOTO 70;
        Set_Alt(_attl,_defl,1);
70:     CASE cc2 OF '1'..'9': Inc(sp); END;
        IF cc2 = '3' THEN kingsay:= true;
        IF _attl < unkldr THEN IF spytype <> S_PCom THEN BEGIN
          Par_Str(_attl,rum_num);
          rum_ldr:= _attl;
         END;
        Pronoun(_attl,1);
        rum_ldr:= noleader;
        alt_pro:= ''; kingsay:= false;
        pro1words:= 0;
       END;
      '[': BEGIN
        Set_Person(_defl);
        IF ((cc2 = '''') or (cc3 = '''')) THEN IF lastp <> _defl THEN GOTO 80
          ELSE IF person + 2*ord(lastp <> _defl) <= 4 THEN BEGIN  sp:= sp+2; GOTO 20; END
            ELSE GOTO 80;
        Set_Alt(_defl,_attl,2);
80:     CASE cc2 OF '1'..'9': Inc(sp); END;
        IF cc2 = '3' THEN kingsay:= true;
        IF _defl < unkldr THEN IF spytype > S_PCom THEN BEGIN
          Par_Str(_defl,rum_num);
          rum_ldr:= _defl;
         END;
        Pronoun(_defl,2);
        rum_ldr:= noleader;
        alt_pro:= ''; kingsay:= false;
        pro2words:= 0;
       END;
      '>': BEGIN
10:     IF author <> noleader THEN IF _attl = author THEN IF ill_addex <> 1 THEN alt_pro:= 'my';
        Posse(_attl);
        alt_pro:= '';
        lastp:= _attl;
        pro1words:= 0;
       END;
      ']': BEGIN
20:     IF author <> noleader THEN IF _defl = author THEN IF ill_addex <> 2 THEN alt_pro:= 'my';
        Posse(_defl);
        alt_pro:= '';
        lastp:= _defl;
        pro2words:= 0;
       END;
      '@': Say(pname^[_px,_py],spytype);
      '=': BEGIN
        Desig(_adex,spytype);
        Check_Sayq;
       END;
      '#': BEGIN
        IF say_trial THEN _next:= R01+R01 ELSE _next:= story^[tdex];
        Inc(tdex); PNum(_next);
        Check_Sayq;
       END;
      '\': BEGIN
        Say(Tr_Name(_treas),spytype);
        Check_Sayq;
       END;
      '': ParPNum(_px*100+_py +101{*ord(gameno >= 3)});
      '': Say(pname^[_qprov DIV XMULT,_qprov MOD XMULT],spytype);
      '': Say(Tr_Name(treaslist[_qtrdex]),spytype);
      '': FD('c:\tp\prose\visit.x2',S_PCom,1000+_qsubplot);
      '': FD('c:\tp\prose\riddle.x2',S_PCom,1000+_qsubplot);
      '': BEGIN person:= 5; Pronoun(_qchar,0); Space; Par_Str(_qchar,qcs);
WW(qcs); END;
      '': BEGIN
        IF _spell = Augur_Combat THEN BEGIN
            _excldr:= LKing(_attl);
            _spell:= nospell;
           END
          ELSE _excldr:= playking;
        Inc(excldiff);
       END;
      '': BEGIN _excldr:= -1; Dec(excldiff); END;
      '': Say(dname[_discov],spytype);
      '': Say(rpname[_race],spytype);
      '': Say(Concat(' ',outname[_align],', ',tempername[_temper],' nature/Rcharacter'),spytype);
      '': BEGIN
        Say(pname^[_px2,_py2],spytype);
        Check_Sayq;
       END;
      '': Say(qname[_qual],spytype);
      '': aoran:= true;
      '+': BEGIN
        MW(_feat1,0);
       END;
      '*': Say(dirname[_dir],spytype);
      '`': IF ((_terrain = Sea) and (pterr[_px,_py] = Sea) and (pt2^[_px,_py] <> noterr)) THEN
          Say(Concat(tername[pt2^[_px,_py]],' Island'),spytype)
        ELSE Say(tername[_terrain],spytype);
      '': Say(tername[_qterr],spytype);
      '': Say_King(_attl);
      '$': BEGIN
        IF Length(s) = sp THEN exchar:= ' ' ELSE exchar:= cc2;
        CASE exchar OF
          '+': BEGIN PR1; Inc(sp); END;
          'a': BEGIN Say(outname[lalign[_attl]],spytype); Inc(sp); END;
          'o': BEGIN Say(outname[_align],spytype); Inc(sp); END;
          'A': Inc(sp);
          'W': BEGIN
{            IF gamevers < 2 THEN Inc(sp)
              ELSE}
{$IFNDEF Noble}
              CASE ptax[_px,_py] OF
                0..2: CASE pterr[_px,_py] OF Sea, Lava, Swamp, Desert: Inc(sp); ELSE WW('poor'); END;
                3..6: CASE pterr[_px,_py] OF Sea, Lava, Swamp, Desert: WW('prosperous'); ELSE Inc(sp); END;
                7..10: WW('rich');
               END;
{$ELSE}
              CASE ptax[_px,_py] OF
                0..2: CASE pterr[_px,_py] OF Sea: Inc(sp); ELSE WW('poor'); END;
                3..6: CASE pterr[_px,_py] OF Sea: WW('prosperous'); ELSE Inc(sp); END;
                7..10: WW('rich');
               END;
{$ENDIF}
            Inc(sp);
           END;
          'T': BEGIN  WW(tempername[_temper]); Inc(sp); END;
          'R': BEGIN  WW(radj[_race]); Inc(sp); END;
          '\': BEGIN  Say(mfname[_magfeat],spytype); Inc(sp); END;
{$IFNDEF Noble}
          'O': BEGIN  WW(ofcname[_office]); Inc(sp); END;
{$ENDIF}
          'K': BEGIN  Say_King(_defl); Inc(sp); END;
          '#': BEGIN
              ParPNum(_px2*100+_py2 +101{*ord(gameno >= 3)});
              Inc(sp);
             END;
          'S': BEGIN
            IF _attl < 256 THEN BEGIN
                IF ((_prevact = _LFarr) or (_impcode = _LFarr)) THEN Say(whit[Bow],spytype)
                  ELSE Say(whit[Sword],spytype);
               END
              ELSE IF ((_prevact = _LFarr) or (_impcode = _LFarr)) THEN
                Say(whit[mtrweap[_mtype]],spytype)
              ELSE Say(whit[mtweap1[_mtype]],spytype);
            Inc(sp);
           END;
          ELSE IF _defl < 256 THEN BEGIN
            Get_AbDesc(_defl,sub);
            Say(sub,spytype);
           END;
         END;
       END;
      '~': Say(spname[_spell],spytype);
      '&': FW(_feat1 and 255);
      '': ParPNum(_feat1 and 255);
      '^': BEGIN
        Say(anoun[_abil],spytype);
        Check_Sayq;
       END;
      '|': BEGIN WW(atname[_atype]); Check_Sayq; END;
      '': BEGIN
        Str(Rint,tms);
        Say(Concat(tms,' ',atname[_atype]),spytype);
        Check_Sayq;
       END;
      '': IF _treas <> notreasure THEN BEGIN
         IF ((_prevact <> _LFarr) and (_impcode <> _LFarr)) THEN
             Say(Tr_Name(_treas),spytype)
           ELSE Say('arrow from > \',spytype);
         END
        ELSE IF _attl < 256 THEN BEGIN
         IF Company = Roland THEN BEGIN
             IF ((_prevact = _LFarr) or (_impcode = _LFarr)) THEN WW('fl�che')
               ELSE WW('�p�e');
            END
           ELSE IF ((_prevact = _LFarr) or (_impcode = _LFarr)) THEN WW('arrow')
           ELSE WW('sword');
         END
        ELSE IF ((_prevact = _LFarr) or (_impcode = _LFarr)) THEN
          WW(wname[mtrweap[_mtype]])
        ELSE WW(wname[mtweap1[_mtype]]);
      '': ;
      ELSE BEGIN
30:     sub:= ''; wp:= sp;
        WHILE (((wp <= Length(s)) and (sub <> ' ')) and
               ((wp = sp) or ((s[wp] >= 'a') and (s[wp] <= 'z') and (not End_Punct(s[wp-1]))) or
               ((s[wp] <> ' ') and (s[wp] <> '_') and
                (not Ctrl_Punct(s[wp]) and
                (not End_Punct(s[wp-1])))))) DO Conc_Sub;
        IF wp > 1 THEN IF wp <= Length(s) THEN IF End_Punct(s[wp-1]) THEN
          IF End2_Punct(s[wp]) THEN Conc_Sub;
        IF sub = ' ' THEN Space ELSE WW(sub);
        sp:= wp-1;
       END;
     END;
    Inc(sp);
   END;
  Dec(_saylev);
  IF _saylev = 0 THEN IF excldiff <> 0 THEN BEGIN
    WRITELN('Bad excl-say: ',excldiff);
    WRITELN(s); Readln;
    _excldr:= -1;
    excldiff:= 0;
   END;
{  WRITE('-');}
  IF say_trial THEN IF _saylev = 0 THEN BEGIN
    Inc(tpinc);
    PR1;
    CASE tpinc OF
      1: author:= _defl;
      2: BEGIN
        author:= _attl;
        IF event_lev = S_PCom THEN
          REPEAT  _defl:= 256 + IRand and 127; UNTIL fstate[_defl-256] <> Dead;
       END;
      3: author:= noleader;
     END;
    s:= attrib;
    IF tpinc < 3 THEN GOTO 1;
    WEK; PR2;
   END;
99: END;

PROCEDURE FD(fn: str40; spl,dex: integer);
{write text from a C:\tp\prose\*.x* file name given by "fn"}
VAR sf: text;
    fddex,i,choices,blockdepth,lineno,trt,tl: integer;
    ldesc: string;
    ofn: str20;
    offer_stop_raid: boolean;

FUNCTION Good_Inc(ch: integer): integer; {Handle some random-number stuff}
VAR tryinc,dexno,incs: integer;
    okinc: boolean;
BEGIN
{  WRITE('GI');}
  REPEAT
    REPEAT tryinc:= IRand MOD Max(ch,2) UNTIL tryinc > 0;
    okinc:= false;
    dexno:= 1; incs:= 0;
    REPEAT
      dexno:= dexno+tryinc; IF dexno > ch THEN dexno:= dexno-ch;
      Inc(incs);
    UNTIL dexno = 1;
    IF incs = ch THEN okinc:= true;
  UNTIL okinc;
  IF Random < 0.5 THEN Good_Inc:= tryinc ELSE Good_Inc:= -tryinc;
{  WRITE('e');}
 END;

PROCEDURE Check_Raid; {Check to see if monster offers to stop raiding if its quest if fulfilled.}
BEGIN
  IF dex > 1000 THEN IF not offer_stop_raid THEN IF fn = 'mtalk' THEN
    IF fstate[_feat1-256]=Bold THEN IF ((ldesc = '') or (ldesc[1] = '(')) THEN BEGIN
      offer_stop_raid:= true;
      Say('[ also offered to stop raiding/Rplundering @ if this quest be/Rwere accomplished/Rcompleted.',S_PCom);
     END;
 END;

BEGIN {Procedure FD}
  ofn:= fn; fddex:= Min(dex,10);
  IF _nextsay <> '' THEN Say(_nextsay,spl)
    ELSE BEGIN
{      WRITE('FD');}
      {$IFDEF Moderator}
      IF Pos('c:',fn) <> 1 THEN fn:= Concat(ramdrive[Company],fn,'.x');
      {$ELSE}
      fn:= Concat(fn,'.x');
      {$ENDIF}
      WRITE(fn,' ');
      Assign(sf,fn);
      AReset(sf);
      IO_Check('FDk');
      choices:= 0; offer_stop_raid:= false;
      READLN(sf,choices,blockdepth);
      IO_Check('ChBl');
      IF choices <> 0 THEN BEGIN
          IO_Check('FDk2');
{          WRITE(' cb:',choices,blockdepth,' ');}
          IF dex >= 2000 THEN fdch[fddex]:= dex-2000
            ELSE IF dex >= 1000 THEN BEGIN
              fdch[fddex]:= dex-1000;
              IF dex-1000 > choices THEN BEGIN
                IF not autorun THEN BEGIN
                  WRITELN('fn: need more choices!(',dex,')');
                  Readln;
                 END;
                fdch[fddex]:= IRand MOD choices +1;
               END;
             END
            ELSE IF dex >= 100 THEN fdch[fddex]:= (dex MOD choices) +1
            ELSE IF ((gameturn <= 5) and (_impcode = _LValhal)) THEN BEGIN
              fdcode[dex]:= _impcode;
              fdch[dex]:= choices;
             END
            ELSE IF _impcode <> fdcode[fddex] THEN BEGIN
              fdinc[dex]:= Good_Inc(choices);
              fdcode[dex]:= _impcode;
              fdch[dex]:= (IRand MOD choices) +1;
             END
            ELSE BEGIN
              fdch[dex]:= fdch[dex]+fdinc[dex];
              IF fdch[dex] < 1 THEN REPEAT fdch[dex]:= fdch[dex]+choices UNTIL fdch[dex] >= 1;
              IF fdch[dex] > choices THEN REPEAT fdch[dex]:= fdch[dex]-choices UNTIL fdch[dex] <= choices;
             END;
          lineno:= 1;
          vchoice:= fdch[fddex];
{          WRITE('ch/fch/dp:',choices,'/',fdch[fddex],'/',blockdepth,' ');}
          IF option <> '' THEN WHILE lineno < (fdch[fddex]*blockdepth - (blockdepth-1)) DO BEGIN
              READLN(sf,ldesc);
              NIO_Check('Pre-Choice',lineno);
              Inc(lineno);
             END
            ELSE blockdepth:= choices*blockdepth;
          IF say_trial THEN WRITELN ELSE WRITELN(' => Choice: ',lineno);
          IF dex >= 2000 THEN BEGIN
              Read_Ldr(valhero,sf);
              Readln(sf,sex[maxkings],trt);
              IF trt <> ord(notreasure) THEN BEGIN
                  Add_Tr(treasure(trt),valhero,ord((trt >= ord(wcp)) and (trt <= ord(pic))));
                  valtrn:= trav;
                 END
                ELSE valtrn:= maxfeatures;
              WRITE('VH:',valhero,'/',viskng,'/',lx[viskng],'/',ly[viskng],'.');
              lx[valhero]:= lx[viskng]; ly[valhero]:= ly[viskng];
              lliege[valhero]:= viskng; liege0[valhero]:= viskng;
              AClose(sf);
              IO_Check('Valhero');
             END
            ELSE BEGIN
              i:= 1;
              REPEAT
                Readln(sf,ldesc);
                IF i = blockdepth THEN AClose(sf);
                IO_Check('Choice');
                Check_Raid;
                WRITE('W:');
                IF ldesc <> '' THEN Say(ldesc,spl);
  {              WRITE('x',Length(ldesc));}
                IF Pos('quotes',fn) > 0 THEN PR1;
  {              WRITE('y');}
                Inc(i);
              UNTIL i > blockdepth;
             END;
          ldesc:= '';
{              WRITE('z');}
          Check_Raid;
          WRITE('K');
         END
        ELSE BEGIN
          AClose(sf);
          Say(ofn,spl);
         END;
      IO_Check('FDclo');
{      WRITE('FDe');}
     END;
{              WRITE('Z');}
 END;

PROCEDURE Enc_Say(kn: krange; paren: boolean); {List the player's names and addresses}

PROCEDURE Name_Say; {Write player name/address}
VAR ts: Str20;
    astr: Str40;
BEGIN
  WITH player DO BEGIN
    Str(kn,ts);
    Say(Concat('King #',ts,', ',name,', ',street1,', ',street2,' ',
        city,', ',state,' ',country,'  ',zip,'  ',phone),S_Red);

    astr:= Concat(', a ',radj[lrace[kn]],' ruler,');
    IF ((lalign[kn] = Heavenly) or (lalign[kn] = Undead)) THEN
      Insert(Concat(', ',outname[lalign[kn]],' '),astr,Length(astr)-5);
    Say(astr,S_Red);

    IF Pos('@',Concat(cis,genie)) = 0 THEN BEGIN
        IF cis <> '' THEN Say(Concat(' (CompuServe ',cis,')'),S_Red);
        IF genie <> '' THEN Say(Concat(' (GEnie ',genie,')'),S_Red);
       END
      ELSE IF Pos('>',cis) = 1 THEN Say(Concat(' (',cis,genie,code,')'),S_Red)
      ELSE Say(Concat(' (>InterNet:',cis,genie,code,')'),S_Red);
    IF paren THEN Say('.)  ',S_Red) ELSE Say('.  ',S_Red);
   END;
 END;

BEGIN
  extext:= true;
  IF Get_Cust(kn,player,true) THEN Name_Say
    ELSE Say('not currently a player-controlled position.)',S_Red);
  _excldr:= -1;
  extext:= false;
 END;

begin
end.

