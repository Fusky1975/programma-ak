const ecunt: array[0..11] OF Str30 =
  ('Cordoba, ','Normandy, ','England, ','Germany, ','the Holy Roman Empire, ',
   'the Magyars, ','Byzantium, ','Baghdad, ','the Mongols, ','the Seljuk Turks, ',
   'the Novgorod Russians, ','Kievan Russia, ');

const wcunt: array[0..31] OF Str30 =
  ('Rome, ','Carthage, ','Persia, ','India, ','China, ',
   'the Aztecs, ','the Incas, ','the Rus Vikings, ','the Zulus, ','Egypt, ',
   'the Huns, ','the Mongols, ','the Siberians, ','Polynesia, ','Amazonia, ',
   'the Norse Explorers, ','the Indians, ','the Hudson Bay Company, ',
     'the Eskimos, ','Japan, ','the Dutch East India Company, ','Atlantis, ',
     'New Atlantis, ','Atlantis, ','Atlantis, ','Atlantis, ','Atlantis, ',
     'Atlantis, ','Atlantis, ','Atlantis, ','Atlantis, ','Atlantis, ');

const sa_lev: array[0..90] OF byte =
  (0,0,0,S_Batt,S_Prev,S_Batt,
   S_Admin,S_Admin,S_Admin,0,0,0,
   S_Admin,S_Admin,S_Admin,S_Admin,S_Batt,S_Admin,
   S_PCom,S_PCom,S_PCom,0,0,0,
   S_PCom,S_PCom,S_PCom,0,0,0,

   S_Prev,S_PCom,S_PCom,S_PCom,S_Prev,S_PCom,
   S_AA,S_PCom,S_Comm,S_PCom,S_Prev,S_PCom,
   S_Comm,S_PCom,S_Admin,S_PCom,S_Prev,S_Priv,
   S_Priv,S_PCom,S_Priv,S_PCom,S_Prev,S_Priv,
   S_Priv,S_PCom,S_Comm,S_PCom,S_Prev,S_Priv,

   S_AA,S_Admin,S_Batt,S_Priv,S_Admin,S_PCom,
   S_Priv,S_Admin,S_Admin,S_Adv,0,0,
   S_Priv,S_Batt,S_Priv,S_AA,S_Priv,S_Adv,
   S_PCom,S_Priv,S_Red,S_Priv,S_Red,S_Red,
   S_Priv,S_Priv,S_Priv,S_Priv,S_Priv,S_Priv,
   0);


PROCEDURE Check_EurSay(ldr: integer);
BEGIN
  CASE gametyp OF
    Europe_V: Say(Concat('the ruler of ',ecunt[ldr]),S_Red);
    Earth_V: IF ((gameno = 260) and (Company = ArkRoyal) and ((ldr = 19) or (ldr = 20))) THEN
        Say('the ruler of Atlantis',S_Red)
      ELSE Say(Concat('the ruler of ',wcunt[ldr]),S_Red);
   END;
 END;

PROCEDURE Get_VFN(vldr: integer; VAR vs: Str40; fno: integer);
VAR ano: integer;
BEGIN
  ano:= Max(1,Min(5,ord(lalign[vldr])));
  vs:= Concat('c:\tp\prose\',outname[outlook(ano)],'.x2');
  IF fno = 2 THEN Insert('2',vs,Pos('.',vs));
 END;

PROCEDURE Good_Fan; {Say good fanaticism}
BEGIN
  Say(' sang {out }their {fiery/Rthunderous }battle_hymns/Rheroic_ballads,',S_Batt);
  Say(' inspired/Rinfused with a{ spirit of}{ holy/Rrighteous,} fanatical fury/Relan by their exalted King.',S_Batt);
 END;

PROCEDURE Evil_Fan;
BEGIN
  Say(' screamed/Rshouted their {hideous }battle/Rwar cries, whipped/Rgoaded into a {terrible/Rwicked } fanatical',S_Batt);
  Say(' frenzy/Rfury by their diabolical King with {false }promises of {easy }plunder/Rconquest{ and slaves for all}.',S_Batt);
 END;

PROCEDURE FD2(fn: str40; spl,dex: integer);
{Write something from a file fn (D:*.x*) on the ramdisk}
BEGIN
  FD(fn,spl,dex+5*ord(_attl <> bestldr));
 END;

PROCEDURE Set_Excldr;
{Set _excldr, who will be the only king to receive the information written by "Say()" until _excldr is reset to equal noleader}
BEGIN
     _excldr:= LKing(_attl);
     IF _excldr = noleader THEN _excldr:= liege0[_attl];
     IF _excldr = noleader THEN _excldr:= mliege[_attl];
     IF _excldr = noleader THEN _excldr:= -1;
 END;

PROCEDURE Desc_Treas; {Describe the current treasure (_treas)}
BEGIN
   IF not NonCarry(_treas) THEN BEGIN
     Set_Excldr;
     IF _excldr < nkings THEN IF _excldr >= 0 THEN
      IF ((standby[_excldr] <> SB_Waiting) and
          (standby[_excldr] <> SB_STart)) THEN BEGIN
       Say('< examined the \ and discovered the following properties:',S_Priv);
       PR1;
      END;
     extext:= true;
     FD('c:\tp\prose\treasure.x2',S_Priv,1001+ord(_treas));
     extext:= false;
     PR1;
     _excldr:= -1;
    END;
 END;

PROCEDURE Say_Stuff; {The character says something in an encounter using the SA tactic}
VAR ci: integer;
BEGIN
  tmp:= '';
  REPEAT
    ci:= RInt;
    IF ci <> _LSayEnd THEN tmp:= Concat(tmp,chr(ci));
  UNTIL ci = _LSayEnd;
  IF tmp <> '' THEN IF Pos('$A',tmp) = 1 THEN Delete(tmp,1,2);
  Say('Sayeth <, ',S_PCom);
  extext:= true;
  WHILE ((Length(tmp) > 0) and (tmp[Length(tmp)] = ' ')) DO
    Delete(tmp,Length(tmp),1);
  tmp:= Concat('"',tmp,'"');
  Say(tmp,S_PCom);
  extext:= false;
 END;

PROCEDURE Wand_Say;
BEGIN
  Say('Your Majesty, I have news to report of wanderers in our kingdom:  ',
    S_Red);
  PR1;
 END;

PROCEDURE Inv_Say;
BEGIN Say('[1 heard/Rfound_out about the , an_interesting/Ra_fascinating invention/Rdevice used by ',S_Red); END;

PROCEDURE Imp_Code(code: integer);
label 10,11,13;
VAR ld,l,ldr,bres,fn,ap,nline,lp,col,outln,l2,t,t2,an,ssk,ssf,kng,ci,nls,
      bint,lconspic,trint,tattl: integer;
    outpage: array[0..23,0..10] OF Str20;
    qfact: longint;
    alt: array[1..2,0..2] of boolean;
    s: Str20;
    vs: Str40;
    at: army;
    n1,noch: boolean;
    aled: array[army] of integer;
    est: real;

PROCEDURE Assign_Rank(fn,nline: integer);
{Make "outpage", which contains the descriptive picture of the armies in a battle.}
VAR ap,ank,placebeg,linebeg,an,i,deletes: integer;
    astring: Str30;
    slashchar: string[1];
    kstring: Str10;
    anq: quality;
    is_skel: boolean;
BEGIN
  IF _linelen >= 9 THEN deletes:= 2 ELSE deletes:= 0;
  alt[fn,nline]:= false;
  linebeg:= _linelen*nline; {= side position of battle-rank line in apos}
  IF fn = 1 THEN placebeg:= (2-nline)*4 { = beginning of string placement}
    ELSE placebeg:= 12+nline*4;
  FOR ap:= linebeg+1 TO linebeg+_linelen DO BEGIN
    IF apos[fn][ap] < 0 THEN BEGIN
         an:= apos[fn][ap];
         ank:= noleader;
         anq:= Average;
        END
       ELSE BEGIN
         an:= apos[fn][ap] and $3ff;
         anq:= quality(apos[fn][ap] Shr 10);
         ank:= (ash[fn][ap] Shr 5) and 255;
         is_skel:= (ash[fn][ap] Shr 13) and 1 = 1;
        END;
    IF an <> -1 THEN BEGIN
      Make_AName(an,astring,0);
      slashchar:= '/';
      IF nline = 0 THEN BEGIN
        astring:= Concat(astring,'/',qname[anq][1]);
        slashchar:= '';
       END;
      IF is_skel THEN astring:= Concat(astring,slashchar,'S');

{      WRITE('D',an,' ',astring); WRITE(rname[arace[an]]);}

      C10(astring,10-deletes);
      outpage[placebeg+fn-1][ap-linebeg]:= astring;
      astring:= atdesig[Mod_LAType(an)];
      IF Mod_LAType(an) = Fleet THEN IF _terrain <> Sea THEN astring:= 'Marines';
      C10(astring,10-deletes);
      outpage[placebeg+fn][ap-linebeg]:= astring;
      astring:= ' |||||||| ';
      IF deletes > 0 THEN Delete(astring,5,deletes);
      IF not Mail_Send(playking) THEN IF Mod_LAType(an) <> hcav THEN FOR i:= 2 TO 9-deletes DO
        astring[i]:= ach[Mod_LAType(an)];
      IF ank <> noleader THEN kstring:=
          Concat(chr((ank DIV 10)+ord('0')+(7*ord(ank >= 100))),chr((ank MOD 10)+ord('0')))
        ELSE kstring:= 'GC';
      FOR i:= Length(kstring) DOWNTO 1 DO astring[7-(deletes Shr 1)-i]:= kstring[Length(kstring)-i+1];
      outpage[placebeg+4-(2*fn)][ap-linebeg]:= astring;
      alt[fn,nline]:= true;
     END;
   END;
 END;

FUNCTION Abort_Info: boolean; {ignore this one}
BEGIN
  Abort_Info:= false;
  IF repldr < noleader THEN
    IF lliege[repldr] < nkings THEN IF liege0[repldr] < nkings THEN
      IF lliege[repldr] <> liege0[repldr] THEN IF playking = liege0[repldr] THEN
        IF _rphase >= ps1[repldr] THEN BEGIN
          rdex:= 0;
          Abort_Info:= true;
         END;
 END;

PROCEDURE Tell_Inv; {describe a "discovery"}
BEGIN
  Say('the following benefits are conferred by the :',S_Red);
  PR1;
  extext:= true;
  FD('c:\tp\prose\descdisc.x2',S_Red,1001+ord(_discov));
  IF Company <> ArkRoyal THEN IF ((gdyear <= 1991) and (gdmonth <= 10)) THEN
    IF ((_discov >= bild10) and (_discov <= bild43)) THEN
      FD('c:\tp\prose\dd2.x2',S_Red,1001+ord(_discov) - ord(bild10));
  extext:= false;
  PR1;
 END;

PROCEDURE Runic_Intro;
BEGIN
  IF not begquote THEN BEGIN
    PR1;
    Say('Magic runes formed on the $\, saying "',S_PCom);
   END;
  begquote:= true;
 END;

PROCEDURE Runes_End;
BEGIN  IF begquote THEN Say('"',S_PCom); begquote:= false; END;

PROCEDURE Desc_PowCon;
BEGIN  FD('c:\tp\prose\pcond.x2',S_PCom,1001+ord(fpowcon)); saidcond:= true; END;

PROCEDURE Start_BI; BEGIN  bint:= 3; Bonus_Intel(bint); END;
PROCEDURE End_BI; BEGIN  bint:= -bint; Bonus_Intel(bint); END;

PROCEDURE Sps(sp: spell; fam: integer);
BEGIN  FD('c:\tp\prose\spnote.x2',fam,1001+ord(sp)); END;

PROCEDURE Check_BAList; {Write a battle picture}
VAR fn,ap,nline,col,outln: integer;
    pns: Str80;
BEGIN
  Say('the armies were drawn up into lines of battle as shown here:',S_Batt);
  PR1;
  gs:= chr(15);
  Spread(gs,0,true);
  PR1;
  Get_PN(_px,_py,pns);
  tmp:= Concat('ATTACKING ARMY, Battle of ',pname^[_px,_py],' (',pns,'):');
  IF _linelen >= 9 THEN Insert('#',tmp,Length(tmp)-5);
  Say(tmp,S_Batt); PR2;
  FOR fn:= 0 TO 23 DO FOR ap:= 1 TO 10 DO
    IF ap > _linelen THEN outpage[fn][ap]:= ''
      ELSE IF _linelen < 9 THEN outpage[fn][ap]:= '          '
      ELSE outpage[fn][ap]:= '        ';
  FOR fn:= 1 TO 2 DO FOR nline:= 0 TO 2 DO Assign_Rank(fn,nline);
  FOR ap:= 1 TO _linelen DO FOR col:= 1 TO _linelen DO
    IF _linelen < 9 THEN outpage[11][ap]:= '----------'
      ELSE outpage[11][ap]:= '--------';
  FOR outln:= 0 TO 23 DO BEGIN
    IF outln < 12 THEN nline:= (11-outln) DIV 4
      ELSE nline:= (outln-12) DIV 4;

{    WRITE(outln:2,':');
    FOR col:= 1 TO 7 DO WRITE(outpage[outln,col]);
    WRITELN;
}
    allow_excess:= true;
    IF alt[(outln DIV 12) +1,nline] THEN BEGIN
      FOR col:= 1 TO 10 DO Spread(outpage[outln,col],0,true);
      PR1;
     END;
    allow_excess:= false;
   END;
  Say('DEFENDING ARMY',S_Batt); PR2;
  WK;
  gs:= chr(18);
  Spread(gs,0,true);
  IF ksendmeth[playking] >= S_Printout THEN Elite_On;
 END;

PROCEDURE Check_BFace;
BEGIN
  PR1;
  ld:= Rint;
  IF attside <> playking THEN
    IF ld = 1 THEN ld:= 3 ELSE IF ld = 3 THEN ld:= 1;
  lp:= Rint;
  _adex:= apos[1][lp] and $3FF;
  descqual:= true;
  _qual:= quality(Rint);
  CASE ld OF
    0: Say('Across the entire/Rwhole front, =',S_Batt);
    1: Say('{out }on the left {outside }flank/Rwing, =',S_Batt);
    2: Say('{with}in the interior lines/Rfront, =',S_Batt);
    3: Say('{out }on the right {outside }flank/Rwing, =',S_Batt);
   END;
  CASE Rint OF
    _AGFan: BEGIN Good_Fan; Say('they',S_Batt); END;
    _AEFan: BEGIN Evil_Fan; Say('they',S_Batt); END;
    _ATFan: BEGIN FD('c:\tp\prose\gang.x2',S_Batt,1001+Rint-ord(Divineking)); Say('they',S_Batt); END;
    _ARFan: BEGIN
      trint:= Rint; tattl:= _attl; _attl:= prevchar[office(trint+ord(Humanking))];
      FD('c:\tp\prose\race.x2',S_Batt,1001+trint); Say('they',S_Batt);
      _attl:= tattl;
     END;
   END;
  Say(' faced/Rwere_arrayed_against ',S_Batt);
  _adex:= apos[2][lp] and $3FF;
  _qual:= quality(Rint);
  CASE Rint OF
    _AGFan: BEGIN Say('=, who',S_Batt); Good_Fan; END;
    _AEFan: BEGIN Say('=, who',S_Batt); Evil_Fan; END;
    _ATFan: BEGIN Say('=, who',S_Batt); FD('c:\tp\prose\gang.x2',S_Batt,1001+Rint-ord(Divineking)); END;
    _ARFan: BEGIN
      trint:= Rint; tattl:= _attl; _attl:= prevchar[office(trint+ord(Humanking))];
      Say('=, who',S_Batt);
      FD('c:\tp\prose\race.x2',S_Batt,1001+trint);
      _attl:= tattl;
     END;
    ELSE Say('=.',S_Batt);
   END;
  descqual:= false;
 END;

PROCEDURE Assign_Phase;
VAR kng: integer;
BEGIN
  _rphase:= Rint;
  undercov:= (Random > ISpy_Cover(_attl));
  _prov2:= 999; _defl:= noleader; needy:= false;
  firstp:= unkldr; secondp:= unkldr; lastp:= unkldr;
  FOR kng:= 0 TO nkings-1 DO phasewrit[kng]:= false;
  phasewrit[playking]:= true;
  Force_Return;
  IF not Abort_Info THEN CASE _rphase OF
    -1,0: FD('spring',S_Red,10);
    1: FD('esummer',S_Red,10);
    2: FD('lsummer',S_Red,10);
    3: FD('fall',S_Red,10);
    4: FD('ewinter',S_Red,10);
    5: ;
   END;
 END;

BEGIN {Imp_Code}
  say_on:= true;
  _impcode:= code;
  IF not say_trial THEN WRITE(code:5);
CASE code OF
0..255: BEGIN
  _ldr1:= code;  _attl:= code;
 END;
256..511: BEGIN
  _feat1:= code;  _attl:= code;
 END;
512..767: _treas:= treasure(code-512);
768..1023: BEGIN {********** no longer in use!!!!!!!!!!!!!!!}
  _prov:= code-768;
  WRITELN('768!! '); WEK;
13: _px:= _prov DIV XMULT; _py:= _prov MOD XMULT;
  FOR l2:= 0 TO nkings-1 DO
    IF Adj_King(l2,_px,_py) THEN spy_lev[l2]:= S_Army
      ELSE spy_lev[l2]:= S_IDipl;
  {$IFDEF Moderator}
  Set_Intel(_px,_py);
  {$ENDIF}
 END;
1024..1279: BEGIN
  _adex:= code-1024;
  code:= Rint;
  lastat[_adex]:= army(code);
  WRITELN('1024!!'); WEK;
 END;
1280..1535: BEGIN
  _ldr2:= code-1280;
  _defl:= code-1280;
 END;
1536..1791: BEGIN
  _feat2:= code-1280;
  _defl:= code-1280;
 END;
1792..1855: _spell:= spell(code-1792);  {}
1856..1871: _abil:= ability(code-1856); {}
1872..1887: _terrain:= terrain(code-1872);
1888..1919: _atype:= army(code-1888);
1920..1927: _dir:= code-1920;
1928..1935: _qual:= quality(code-1928);
1936..1951: _race:= race(code-1936);
1952..2015: _discov:= discovery(code-1952);
2016..2079: _office:= office(code-2016);
2272..2527: _qtrdex:= code-2272;
2528..2591: _qplotno:= reply(code-2528);
2592..2847: _qchar:= code-2592;
2848..2863: _qterr:= terrain(code-2848);
2864..2879: _qsubplot:= code-2864;
2880..2895: _align:= outlook(code-2880);
2896..2899: _temper:= temper(code-2896);
2900..2963: _mtype:= monster(code-2900);
2964..2984: _magfeat:= magfeat(code-2964);
10000..11255: BEGIN
  _prov2:= code-10000; _px2:= _prov2 DIV XMULT; _py2:= _prov2 MOD XMULT;
 END;
15000..15255: _excldr:= code-15000;
11300..11990: _qprov:= code-11300;
12000..12999: BEGIN
  _adex:= code-12000;
  code:= Rint;
  lastat[_adex]:= army(code);
 END;
13000..14999: BEGIN
  _prov:= code-13000;
  GOTO 13;
 END;
_TrRes: Say('< asked the Sages Guild to research \ and discovered the following information: ',S_Priv);
_TrDesc: Desc_Treas;
{_LMDesc: FD('c:\tp\prose\monsters.x2',S_Red,1001+ord(_mtype));}
_LWield: Say('< wielded/Rdrew_out > \.',S_PCom);
_TrDust: BEGIN Say('unfortunately, the \ used up its last charge.',S_Prev);
  Say('it crumbled to dust and merged with the sands of time.',S_Prev);
 END;
_TrShad: FD2('shadtr',S_PCom,4);
_TrImpl: FD2('flamerel',S_PCom,5);
_LDies: BEGIN
  t:= Rint;
  FD('hordeath',Min(S_Comm,event_lev+1),6{1001+Rint});
 END;
_LWDie: willdie:= _defl;
_LSick: BEGIN
Say('< fell into a deathly coma, and only the prayers of > troops kept <2 alive.Upon recovery, < was but a cowardly, ',S_Prev);
Say('imbecilic, unteachable shadow of > former self with no skills (a resurrection spell will restore <2.)',S_Prev);
 END;
_LSucc: Say('<3 was succeeded by > next-in-line (who will use > predecessor''s name until next turn).',S_Comm);
_LExpDiff: Say('< wasn''t in @ so ',S_Red);
_LExpImp: FD('expmove',S_Adv,0);
_LExpCo: FD('coexp',S_Red,1);
_LExpMax: BEGIN
  Say('< tried to explore @ but it seemed that it had already been completely explored.',S_Adv);
 END;
_LFRumor: BEGIN FD('frumor',S_Priv,3); PR1; END;
_LPOwns: Say('The {scenic/Rrich }province of @ belongs/Rowes_allegiance to thee/Ryour_Majesty.',S_Red);
_LOProv: BEGIN
Say('{the province of }@ belongs/Rowes_allegiance to [3.Listening to the stories/Rgossip of travellers/Rwanderers',S_Red);
  Say('{ and merchants/Rmercenaries}, one can deduce the rulership/Rownership of surrounding areas:/Rprovinces: ',S_Red);
 END;
_LSuOwn: BEGIN  secondp:= unkldr; Say('@- [; ',S_Red); END;
_LSuOwn2: BEGIN secondp:= unkldr; Say('@- [.',S_Red); END;
_LExpFail: ;
_LFind: FD('findfeat',S_Adv,2);
_MDead: Say('+ has already been killed; the &, sacked and looted.',S_Red);
_LTell:
  Say('Mortal/RYoung_fool, there is  interesting/Rdangerous feature/Rlair in @:  &  inhabited/Roccupied by +.',S_Priv);
_LHearInv: Say('<, responsible for the defense of @, learned/Rgot_wind of an enemy attack/Rmove on .',S_AA);
_LHearPat: Say('<, patrolling @, learned/Rgot_wind of a nearby intrusion by [.',S_Adv);
_LSplit:  Say('< decided to split > forces to attempt to defend both @ and .',S_AA);
_LRemain: Say('< decided to defend only @, as > forces were too small to also defend .',S_AA);
_LDefend: Say('< prepared > armies/Sforces to defend @ and the surrounding provinces.',S_AA);
_LPatrol: Say('< patrolled @ and the surrounding provinces for enemy characters.',S_Adv);
_ADefend: Say('< left = behind to defend @.',S_AA);
_LMarch: BEGIN
  Start_BI;
  FD('march',S_Admin,3);
  End_BI;
 END;
_LWWalk: BEGIN
  Start_BI;
  Say('< rode_the_Mystic_Winds/Rwind-walked into/Rover @.',S_Army);
  End_BI;
 END;
_LFly: BEGIN
  Start_BI;
  Say('< flew/Rrode_>_flying_armies into/Rover_to @.',S_Army);
  End_BI;
 END;
_LCMarch: BEGIN
  Start_BI;
  Say('< marched into @ from  to defend @ against its would-be conquerors.',S_Army);
  End_BI;
 END;
_LMove: BEGIN
  Start_BI;
  FD('trav',S_Adv,4);
  End_BI;
 END;
_LNoRand: Say('{in_>_travels/Rwhile_adventuring, }< saw/Rencountered no {wandering/Rmarauding }monster{s}.',S_Red);
_LCantPu: BEGIN
  Say('< attempted to pursue [ but was frustrated in his efforts because or some reason',S_Adv);
  Say(' (probably terrain barriers, insufficient movement capability, or being pinned down by enemy movements).',S_Adv);
 END;
_LNoPuI: Say('< decided not to pursue [ after learning that [1 led no armies.',S_Priv);
_LNoPuA: Say('< decided not to pursue [ after learning that [1 was inaccessible, surrounded by ] loyal armies.',S_Adv);
_LANoTr: Say('< could not Trail [ because > armies could not follow along on such a mission.',S_Priv);
_LCPurs: Say('< travelled/Rjourneyed in search of [.',S_Adv);
_LConfu: Say('< wandered/Rtravelled in search of [.',S_Adv);
_LCatch: Say('< caught up with [ in @.',S_Adv);
_LHFail: FD('refhire',S_Adv,5);
_LCounter: Say('[1 informed <2 that [1 would not sell ] services for less than # gold.',S_Adv);
_LHire: FD('acchire',S_Adv,6);
_LFire: FD('fireman',S_Adv,7);
_LThEnd: BEGIN Force_Return; Say('Thus endeth the adventures of <3 for this year.',S_Red); PR2; END;
_LAlly: FD('ally',S_Admin,8);
_LATreat: Say('< treated with > ally [3.',S_Admin);
_LRefA: BEGIN
  Say('< Treated with [3, but [1 did not respond/Rreact {favorably }to > friendly/Ramicable noises/Rovertures.',S_Priv);
  Say('it is hoped that next year, both Kings will see the wisdom of Treating.',S_Priv);
 END;
{_LSNews: Say('Your Highness, there is news concerning Affairs of State:  ',S_Red);}
_LHeavP: FD('heavp',S_Comm,4);
_LBreak: FD('break',S_Admin,9);
_LIncid: Say('a diplomatic furor erupted between the Realms of < and [, degrading their diplomatic relations # level(s)!',
  S_Admin);
_LTrade: Say('< gave the \ to [.',S_Priv);
_LGGive: Say('< gave/Rdonated to [ # gold from > treasury/Rown_funds.',S_Priv);
_LNHave: Say('< didn''t have on hand the full # gold requested, so ',S_Red);
_LNDeal: Say('< could not strike a deal with [ for the \.',S_Priv);

_LSpy: BEGIN  spy_rep:= true; FD('spy',S_PCom,10); END;
_LSTax: BEGIN event_lev:= S_Red; PR1; Say('Approximate Taxation: #',S_Red); END;
_LSAT: BEGIN PR1; Say('Province Army Type #: |',S_Red); END;
_LSList: BEGIN
  PR1;
  Say('the following elements are present in @:  ',S_Red);
 END;
_LSHere: Say('[ $ is here.',S_Red);
_LSLeads: Say('[ leads approximately .',S_Red);
_LSGarr: Say('there is a garrison of approximately .',S_Red);
_LSNone: BEGIN
  PR1;
  Say('there were no conspicuous characters or forces in @.',S_Red);
 END;
_LSNoCh: BEGIN
  PR1;
  Say('there were no conspicuous characters in @.',S_Red);
 END;
_LSCap: BEGIN PR1; Say('@ is the kingdom''s capital province.',S_Red); END;
_LSEtc: BEGIN
  PR1;
  Say('< also kept tabs on the characters in @ and any further news is in the General Intelligence Report.',S_Red);
  spy_rep:= false;
 END;

_LTrSpy: BEGIN  spy_rep:= true; Say('< discovered the following information: ',S_Red); END;
_LTaBase: Say('After talking to [, ',S_Priv);
_FuEst: Say('< judged that [ would normally have a # percent chance of honoring an agreement with <2.',S_Red);
_LChEst: IF _defl < 256 THEN Say('< judged [ $ to have .',S_Priv)
  ELSE Say('< judged [ $ to have .',S_Priv);
_LHasT: Say('[ has the \.',S_Priv);
_LOwns: Say('[ owns .',S_Priv);
_LSTBase: Say('[''s Kingdom has a total tax base of approximately # gold.',S_Priv);
_LKEn: Say('[3 is an Enemy.',S_Priv);
_LKAll: Say('[3 is an Ally.',S_Priv);

T_LSteal: FD('tlsteal',S_PCom,1);
T_MSteal: FD('tmsteal',S_PCom,2);
T_LSpoils: FD('tlspoils',S_PCom,3);
T_MSpoils: FD('tmspoils',S_PCom,4);
T_ISpoils: Say('While [ was locked/Rheld in ] frosty/Ricy prison/Rexoskeleton, < searched for treasure.',S_PCom);
G_ISpoils: Say('< walked/Sswam over to a glittering {pile/Rstash of }treasure and secured/Rnabbed the \.',S_PCom);
_LSpoilG: FD('lspoilg',S_PCom,5);
T_Conf: Say('of course, < confiscated all the possessions of [.',S_Priv);
_LBurn: Say('] possessions were burned with [3 on the funeral pyre.',S_Priv);
_LInher: BEGIN
  IF _attl = _defl THEN Say('The heir of < inherited/Rgained the \.',S_Red)
    ELSE Say('< inherited/Rgained the \.',S_Red);
 END;
_LWill: BEGIN
  PR1;
  Say('[''s will left {all }] {worldly }possessions to ] compatriots/Rfellow_adventurers.',S_Red);
 END;
_MGain: Say('< took the \.',S_PCom);
G_LSteal: FD('glsteal',S_PCom,0);
G_MSteal: FD('gmsteal',S_PCom,1);
G_LSpoils: FD('glspoils',S_PCom,2);
G_MSpoils: FD('gmspoils',S_PCom,3);
G_Conf: Say('the \ was taken.',S_PCom);
{G_Inher: Say('ERROR:G_INHER',S_Priv);}
_ThFail: FD('thfail',S_PCom,4);
_ThNoMI: Say('< could not find/Rlocate any magic{al} artifacts/Rtreasure.',S_PCom);
_LMisses: FD2('andmiss',S_PCom,5);
_LInfl: FD2('andinfl',S_PCom,1);
_LDevast: Say(' and devastated/Rannihilated [.',S_PCom);
_LMortB: FD2('mortwoun',S_PCom,5);
_LToBow: FD2('gobow',S_PCom,2);
_LDFite: Say('< decided to fight.',S_PCom);
_SWarp: BEGIN
  Say('<{''s body} seemed to twist/Rbob and weave/Rwobble unnaturally/Runpredictably, as_if/Rand_it_seemed_that',S_PCom);
  Say(' [ and < were caught_in/Rmoving_through a strange/Rbizarre extradimensional/Rnon-Euclidean geometry/Rvolume_of_space.',
      S_PCom);
  Say('< could see/Rtell it would be very_hard/Rtough to get a hit in melee, and even harder/Rtougher from bow range!',
    S_PCom);
 END;
_LToMel: FD2('gomel',S_PCom,3);
_LFArr: FD2('farr',S_PCom,4);
_LCast1: CASE _spell OF
  Tornado,Bless,Plague: Say('< cast a ~ spell.',S_PCom);
  ELSE Say('< cast a ~ spell and ',S_PCom);
 END;
_LCast: IF ((_attl < 256) or (_mtype <> Beholder)) THEN BEGIN
    IF _treas = notreasure THEN FD2('ccast',S_PCom,2)
      ELSE Say('< used/Rinvoked {the magical_powers/Rmagic of }> \',S_PCom);
   END
  ELSE BEGIN
    Say('rotating/Rturning one of its {10 }eyes{talks} toward [, < emitted/Rgave_off a {fiery/Rmulticolored }',S_PCom);
    Say('ray/Rbeam{ of light}, impacting/Rbursting with the power/Rforce of  ~ spell',S_PCom);
   END;
_MAnti: Say(', but the spell fizzled, seemingly because there is a strange anti-magic field in the &!',S_PCom);
_SDub: Say('< was dubious that the ~ spell would work here, so < tried to think of another strategem/Rtactic.',S_Priv);
_LUse: SAy('< invoked the \, from which ',S_PCom);
_LPUse: Say('< invoked/Rcalled_on the power/Rmagic of the $\_in_the_&/R&_$\, from which ',S_PCom);
_LOUse: Say('< used the Chancellor''s Crystal Ball from which, ',S_Priv);
_LPWand: Say('The Platinum Wand senses the \ in @.',S_Priv);
_LRead: Say('< read the \, and then it crumbled to dust.> skill in ^ rose by 1 level.',S_PCom);
_LCHoly: Sps(Holy_Symbol,S_PCom);
_LVuln: Say('the spell caused_[_to/Rmade_[ moan/Rshriek in {excruciating }pain/Ragony',S_PCom);
_LChEsc: Sps(Charm,S_PCom);
_LPsych: Say('< loyally returned to [, the Charm spell having worn off.',S_Adv);
_LCHOD: Sps(Hand_Of_Death,S_PCom);
_LCPsyBl: Sps(Psychic_Blast,S_PCom);
_LCInvis: Sps(Invisibility,S_PCom);
_LRecov: FD2('recstun',S_PCom,1);
_LStun: FD2('stun',S_PCom,4);
_LCSpir: Sps(Spiritwrack,S_PCom);
_LCContU: Sps(Control_Undead,S_PCom);
_LBers: Say('[ flew into a berserk rage and fought with increased strength.',S_PCom);
_LKillE: Say(', and destroyed/Rslew [ with > powerful/Rdark magic{k}.',S_PCom);
_LTrack:
  Say('< went berserk over the Kill-Enemy attempt.Guided by eerily accurate psychotic visions, ',S_PCom);
_LSpInEff: Say(' but the spell seemed ineffective against [.',S_PCom);
_LGDRef: Say(' but the Demon refused to fight against an opponent of [''s alignment.',S_PCom);
_LTFast: Say(' but [1 was just quick enough to evade it.',S_PCom);
_LSIBers: Say(' but the spell seemed ineffective, serving only to enrage [ to a berserk temper.',S_PCom);
_LCIceS: Sps(Ice_Suspend,S_PCom);
_LPIce:
Say('but the shell/Rice was not strong/Rthick enough to hold/Rstop [, and [1 began to break_out/Rcrack_through.',S_PCom);
_LBIce: Say('< struggled/Rattempted to break out of > {frosty }shell/Rprison of {cold/Rfrigid }ice.',S_PCom);
_LFIce: Say('with a mighty heave/Reffort, < broke out of > {frosty }shell/Rprison of {cold/Rfrigid }ice.',S_PCom);
_LIceCr: Say('[1 dropped/Rcrashed, suffering/Rtaking # damage points.',S_PCom);
_LIceGh: Say('but [''s translucent form easily glided through the ice.',S_PCom);
_LShIce: Say('[1 was immobilized_by/Rlocked_in the {frosty }shell/Rprison of {cold/Rfrigid }ice.',S_PCom);
_LWMelt: Say('< stood away from [ and waited for the ice to melt.',S_PCom);
_LSFroz: Say('< could not take the \ because what [1 carried was frozen in with [.',S_PCom);
_LUndWF: Sps(Fireball,S_PCom);
_LCMI: Sps(Mirror_Image,S_PCom);
_LM2Diss: Say(' and both summoned phantasms dissipated.',S_PCom);
_LMSwAtI: Say('the illusion/Rimage switched targets/Ropponents and now attacked/Rturned_on its {former }master.',S_PCom);
_LMDisb: Say('< disbelieved [ and it {gradually }faded_away/Rdisappeared.',S_PCom);
_LMDiss: Say('the illusion dissipated/Rfaded_away and was no_more/Rdispelled.',S_PCom);
_GDDisp: Say('[1 disappeared to whence [1 came.',S_PCom);
_LRevive: Say('< revived/Rrecovered from the illusion/Rtrance-state of {mental }death.',S_PCom);
_LSlit: Say('< slew/Rkilled [ while [1 was in ] unconscious state.',S_PCom);
_LTsColl: Say('some {small }fragments/Robjects flew/Rzipped towards [',S_PCom);
_LExper: Say('<''s experience/Refforts raised/Rimproved > skill/Rprowess in ^.',S_Priv);
_LGetAw: FD('tgetaway',S_PCom,6);
_LSeen: BEGIN
  FD('sneakup',S_PCom,7);
  CASE Rint OF
    0: Say(' melee range.',S_PCom);
    1: Say(' bow range.',S_PCom);
    2: Say(' spell range.',S_PCom);
   END;
 END;
_LSwing: FD2('swangat',S_PCom,3);
_LFlee: FD('fled',S_PCom,7);
_LCow: Say('<, deeming discretion the better part of valor, declined to encounter [.',S_PCom);
_LBeg: Say('<{, quaking with fear,} got/Rknelt down on > {knobby little }knees and begged/Rpleaded for mercy.',S_PCom);
_LKick: Say('but [1 just spat/Rlaughed in > face{ and kept attacking}.',S_PCom);
_LMerc: Say('[1, touched by <''s tears, relented and let <2 go free.',S_PCom);
_LCot: FD2('fleefail',S_PCom,3);
_LBung: FD('sbungle',S_PCom,8);
_LSquee: FD2('squeeze',S_PCom,5);
_LSquit: Say(' but did no damage, so < deactivated the spell.',S_PCom);
_LChall: FD('encatt',S_PCom,9);
_LSearch: FD('fsearch',S_Adv,10);
_LScout: Say('< searched/Rentered the & to see/Rfind what special magic/Rpower it_might_possess/Rmight_be_present.',S_Adv);
_LREnc: Say('during > travels/Scoastal_explorations{ this season}, ',S_Adv);
_LSacked: Say('< searched/Rscouted_out the & but it {apparently }had {already }been looted/Rsacked.',S_Adv);
_LImpr: FD('practice',S_Priv,0);
_APract: Say('< took_>_men_on/Rconducted tactical/Rmilitary maneuvers/Rexercises and = rose/Rimproved in quality.',S_AA);
_LInstead: Say('instead/Rso, ',S_Priv);
_LTeach: Say('< was tutored/Rinstructed in{ the art of} ^ by [.',S_Priv);
_LAlrMax: Say('< practiced ^ even though < had already reached the maximum skill level.',S_Red);
_LStudV: FD('pracvain',S_Priv,1);
_LNoDisc: Say('< discovered/Rinvented nothing {valuable/Rworthy_of_note }in > sagely researches/Rexperiments.',S_Priv);
_LDisc: BEGIN
  IF not stat_on THEN FD('discov',S_Priv,2);
  Tell_Inv;
 END;
_LSeeTit: Say('< leads the race for $O.',S_Red);
_ODesc: FD('c:\tp\prose\title.x2',S_Red,1001+ord(_office));
_OAlert: BEGIN
  FD('c:\tp\prose\titknow.x2',S_Red,1001+ord(_office));
  IF _office > nooffice THEN IF gamevers >= 4 THEN BEGIN
    Say('The title is worth ',S_Red);
    Str(ofcval[_office],tmp); Say(tmp,S_Red);
    Say(' prize percentage points on the Imperial Office Table.',S_Red);
   END;
 END;
_LDTell: BEGIN
  Runes_End;
  Say('< then learned that ',S_Priv);
  Tell_Inv;
 END;
_LFigI: BEGIN
  Say('[1 cleverly/Reasily deduced/Rascertained how to make/Rreproduce the .Now, we can use it too!',S_Red);
  Tell_Inv;
 END;
_LTakeG: FD('takeg',S_PCom,2);
_LRans: BEGIN
  Say('[1 caught <2 red-handed while < was rummaging through ] things in a bungled attempt at thievery.',S_Comm);
  Say('[1 forced <2 to pay [ half > treasury in ransom before letting him go.',S_Comm);
 END;
_Wand1: Wand_Say;
_LWandFr: BEGIN
  FD('lwandfr',S_Red,3);
 END;
_LWandTo: FD('lwandto',S_Red,4);
_LFRaid: BEGIN
  Say('@ was raided/Rplundered by <2, who came/Rstormed from out of the dark/Sdeep ',S_Admin);
  Say('{wilderness/Sseas }and pillaged or destroyed # gold worth of property.',S_Admin);
 END;
_LFThun: BEGIN
  Say('@ was attacked/Rraided by <2, but the Thunderbird stormed_down/Rsuddenly_flashed_in from the heavens/Rblue_sky ',
       S_Admin);
  Say('and defeated/Rbested <2 in {personal/Rheated }combat, putting_a_halt_to/Rpunishing_<2_for > raids/Rmischief.',S_Admin);
 END;
_LFOccu: BEGIN
   Say('The natives_of/Rpeople_in @ report/Rsay that the & there/Rin_@ has_been/Ris_now taken_over/Roccupied by <2.',S_AA);
  END;
_MUnDt:
  BEGIN PR1; Say('In > judgement, < was undaunted by the encounter and surely intends to continue plundering @.',S_Red); END;
_MNoBold: Say('< was intimidated by the encounter, and surely will not be raiding @ again for some time!',S_Red);
_LExec: Say('< was sentenced to die at the gallows, a fitting punishment for > dastardly crimes.',S_Adv);
_LBinoc: BEGIN
  FD('binocpr',S_Red,5);
 END;
_LPTell: Say(
'Far/Ra_long_distance {away, }to the * lies  $W ` province/Rarea called/Rnamed @ , populated by .It is ruled by [3.',
S_Priv);
_PFiteAs: IF Noid_Race(_race) THEN
    Say('their $R warriors/Rfighters {traditionally/Rprefer_to }fight/Rarray_themselves as/Rin_the_style_of |.',S_Red)
  ELSE Say('{if need be, }they can muster/Rcall_on  host/Rarmy of | to defend their territory/Rprovince.',S_Red);
_STZero: Say('@ was magically changed into a wasteland/Spolluted_sea, and its inhabitants all died or wandered away.',S_Army);
_STFite: Say('A wandering tribe of , who fight as |, settled there, adapting themselves to the scarred terrain.',S_Army);
_LSeeI: SPs(Illus_Terrain,S_Red);
_LNBinIce: BEGIN Say('to the north',S_Red); FD('icecap',S_Red,6); END;
_LSBinIce: BEGIN Say('to the south',S_Red); FD('icecap',S_Red,7); END;
{$IFNDEF More_Entry}
_LInfo: IF LKing(_defl) <> noleader THEN BEGIN
    Say('< spoke_with/Rtalked_to [.',S_PCom);
    IF Rint = 0 THEN ;
   END
  ELSE FD('ltalkok',S_PCom,8);
_LMCharm: Say('< used the \ to charm [, who gave ] treasure over to <2.',S_PCom);
_LSay: Say_Stuff;
_LRebuff: FD('lrebuff',S_PCom,9);
_LIgnore: FD('lignore',S_PCom,10);
_LCTalk: FD('lhail',S_PCom,5);
_MReply: FD('c:\tp\prose\mtalk.x2',S_PCom,1001+ord(_qplotno));
_LSpake: FD('c:\tp\prose\fulfill.x2',S_PCom,1001+ord(_qplotno));
_LHaHa: Say('snarleth/Rchortled [1, "Ha!You fool/Rbumpkin, I''ve tricked/Rdeceived you!',S_PCom);
_LBThen: Say('But then ',S_PCom);
_LRidAns: FD('rans',S_PCom,1000+_qsubplot);
_LWGrr: Say('[1 snarled/Rgrowled, "You impudent fool!I''ll teach YOU to show some respect!',S_PCom);
_LWTake:
Say('Sayeth [1, "{Ah, }thank you{ very much}.But I {will }always_TAKE/Rwrest_for_myself what I want/Rdesire!',S_PCom);
_LWErrand: Say('Sayeth [, "You have done/Rserved_me well/Radmirably{, and you have my thanks/Rgratitude}.',S_PCom);
_LPrDie: Say('now, prepare/Rget_ready to die/Rmeet_your_maker!"',S_PCom);
_LFWrong:
Say('Sayeth [, "No!That is not the answer I had_in_mind/Rwas_thinking_of.Why don''t you give up{, you fool/Ridiot}?"',S_PCom);
_LFProgr: Say('Sayeth [1, "You have served_me/Rdone well.I shall remember/Rnot_forget you{r kindness/Rdeed}."',S_PCom);
_LFNQual: Say('Sayeth [1, "You haven''t the skill required/Rnecessary to do as I''ve asked/Rrequested!Go away!"',S_PCom);
_LFNoPri: Say('Sayeth [1, "You have not met/Rbrought_me my asking price{ at all}!Go away!"',S_PCom);
_LFTryAg: Say('Sayeth [1, "You have not done_as/Rperformed_the_service I asked/Rwished{ at all}!Go away!"',S_PCom);
_LFKOnly: Say('But as < approached [, < lost > courage and ran away from [.',S_PCom);
_LFHero: Say('Sayeth [1, "That one did not taste like a Hero!Next time bring me something tastier.Now, go away!"',S_PCom);
_LFNoAg: Say('Sayeth [1, "Fulfill what?We have not talked over any agreement!Go away!"',S_PCom);
_LQDone: Say('Sayeth [1, "I have already given away the \ to a worthier adventurer.Go away!"',S_PCom);
_LLose: Say('<3''s death means you are out of the game.This is the last turn report you will receive.',S_Red);
_LPacif: BEGIN PR1; Say('in ] gratitude/Rappreciation, [1 swore off any raids/Rplundering_expeditions in @.',S_PCom); END;
_LFuVis: FD('c:\tp\prose\fuvis.x2',S_PCom,1000+_qsubplot);
_LWoff: Say('at year''s end, <3 became fully undead and wandered off into the darkness.',S_Red);
_LMSnow: Say('< made > Cosmic Snowball from the slush on the polar Icecap.',S_Adv);
_MFulf: BEGIN FD('c:\tp\prose\maccept.x2',S_PCom,1001+ord(_qplotno)); END;
{$ENDIF}
_LMDesc: FD('c:\tp\prose\monsters.x2',S_Red,1001+ord(_mtype));
_LDesert: FD('ldesert',S_PCom,0);
_LStandby: Say('< went unpaid this turn, but still stands loyally with [.',S_PCom);
_LKMeet: BEGIN
  Say('(As a result of the encounter, ',S_Red);
10: Say('< and [1 have established diplomatic contact.',S_Red);
11: _excldr:= _defl;
  IF ((gdipltype = 1) or (_attl >= nkings) or (kacct[_attl] = 0)) THEN BEGIN
    Say('< is ',S_Red);
    Check_EurSay(_attl);
    Enc_Say(_attl,false);
   END;
  _excldr:= _attl;
  IF ((gdipltype = 1) or (_defl >= nkings) or (kacct[_defl] = 0)) THEN BEGIN
    Say('[1 is ',S_Red);
    Check_EurSay(_defl);
    Enc_Say(_defl,_impcode <> _LKNex);
   END;
  _excldr:= -1;
  PR1;
 END;
_LKNext1: IF gdipltype = 1 THEN BEGIN
  PR1;
  IF gameturn > 0 THEN
    Say('(As a result of their Kingdoms becoming adjacent, ',S_Red);
  GOTO 10;
 END;
_LKNex: GOTO 11;
_LAvoid: Say('< declined/Rrefused to enter {personal }combat.',S_Batt);
_LAccept: BEGIN
  Say('[3 {bravely/Rcourageously }accepted/Ranswered the challenge/Rinvitation ',S_Batt);
  Say('to honorable/Rpersonal combat.',S_Batt);
 END;
_LAssume: Say('< assumed command of the forces of the realm of .',S_Batt);
_LNoNews:
  BEGIN Say('there is no news to report this turn.',S_Red); PR1; END;
_ADishK: BEGIN
  Say('The forces commanded by [3 were disheartened by ] death/Rdemise, ',S_Batt);
  Say('but/Ryet still they pressed/Rmoved forward/Rahead with some hope of victory.',S_Batt);
 END;
_ADishF: BEGIN
  Say('The forces commanded by <3 were disappointed/Rdismayed by > cowardice/Rfaint-heartedness.',S_Batt);
  Say('They {grimly/Rsteadfastly }marched on, though with lessened/Rshaken confidence.',S_Batt);
 END;
_LThAtt: FD('thatt',S_PCom,2);
_LFinance: Say('here is the financial report for <''s kingdom: ',S_Red);
_LRev: Say('this turn, the Kingdom collected # gold in revenue.',S_Red);
_LLCosts: Say('# gold was expended to finance our leaders.',S_Red);
_AUnpaid: Say('unfortunately, #% of your Majesty''s armies had to go without pay.',S_Red);
_LACosts: Say('# gold was expended to maintain our armies.',S_Red);
_LTreas: Say('< was left with # gold in the treasury.',S_Red);
_LRNoCo: BEGIN
  Say('< could not recruit armies for [ because they were in different provinces.',S_AA);
 END;
_FNoTr: Say('what treasure may lie there is unknown.',S_Red);
_FTr: Say('legend says the \ is hidden here.',S_Red);
_ARecr: BEGIN chief_on:= true; FD('recruit',S_AA,3); chief_on:= false; END;
_AHired: FD('hiremerc',S_AA,4);
_ADisb: Say('< disbanded =.',S_AA);
_AAPay: Say('< paid # gold to [ for the privilege of recruiting these troops.',S_AA);
_ALeave: BEGIN chief_on:= true; FD('leave',S_AA,5); chief_on:= false; END;
_APickup: FD('pickup',S_AA,6);
_ARises: Sps(Skeletal_Army,S_AA);
_ARedu:  Say('the underpayment of = resulted in a reduction of their quality level.',S_AA);
_ADesert: Say('= were underpaid and they have deserted > majesty to become mercenaries.',S_AA);
_AWandFr: FD('awandfr',S_Red,7);
_AWandTo: FD('awandto',S_Red,8);
_ATDestr: Sps(Tornado,S_AA);
_APDestr: Sps(Plague,S_AA);
_AEDestr: Say('the Tidal Wave struck = in @ and destroyed them.',S_AA);
_ABDestr: Say('the skeletal remains of = were Blessed and permanently destroyed.',S_Batt);
_TWPass: Say('the Wave then passed/Rcontinued {on }into parts_unknown/Rdistant_seas.',S_AA);
_ASlow: Sps(Flood,S_Batt);
_APSick,_ATTorn: Say('the ~ spell struck = in @ and reduced them by one quality level.',S_AA);
_NoDestr: Say('the ~ affected no armies in @.',S_AA);
_NoEDest: Say('the Tidal Wave affected no armies in @.',S_AA);
_ADig: Say(
'= dug graves for themselves, unwilling to serve anyone but their master, unless given to an Undead leader like themselves.',
S_AA);
_AQuals: Say('the battle affected the quality of our forces:  ',S_Red);
_AIncQ: FD('incq',S_Red,9);
_ADecQ: FD('decq',S_Red,10);
_MInc:
Say('= helped/Rwas_hired_by a local count/Rearl of @ to subdue a native_tribe/Rrebellious_baron and rose to  quality.',S_AA);
_MDec:
Say('= experienced/Rsuffered_from a hard_winter/Rdisastrous_raiding_attempt in @ and sank to  quality.',S_AA);
_MSplut: Say('= dissolved_their_company/Rlaid_down_their_swords and went_home/Rquit_the_mercenary_life.',S_AA);
_ATrain: BEGIN WRITE('\'); Say('= trained well and improved in quality.',S_AA); WRITE('/'); END;
_ABFList: BEGIN
  expand_adesc:= true;
  Say('< discovered/Rfound also that @ has been the site of terrible/Rhard-fought battles.',S_Red);
  Say('brave_and/Rmany renowned/Rintrepid warriors/Rsoldiers have perished/Rgiven_their_lives on its ',S_Red);
 END;
_ABFArmy: Say('soil:/Rfields: =.',S_Red);
_ABFEnd: expand_adesc:= false;
_AFly: Say('= soared_over/Rswooped_down_on ',S_Batt);
_AFly2: Say('= and attacked them/Rwithout_mercy.',S_Batt);
_AUWater: Say('= swam underwater/Rundersea and attacked.',S_Batt);
_AFlank: Say('= {out}flanked the {undermanned }enemy {lines }and attacked/Rcharged_in with full force/Rstrength.',S_Batt);
_ZEndEx: _excldr:= -1;
_IllEq: ill_addex:= Rint;
_SFizz: Say('the ~ spell cast by <2 seemed to have no effect.',S_PCom);
_SDisr: Say('[''s spell was disrupted by the event.',S_PCom);
_SPlague: Say('@ was hit by a plague.',S_Comm);
_SWave: Say('@ was hit_by/Rdeluged_with a humongous/Rcrushing Tidal Wave.',S_Comm);
_SFail: FD('sfail',S_Priv,0);
_SAnti: Say('a mysterious/Rstrange magical counterspell/Raura seemed_to/Rmay have worked_against/Rimpeded > spell.',S_PCom);
_SCounter: Say('the  (an anti-spell Sage Discovery) seemed to lessen the effect of the ~ spell.',
S_Priv);
_SComCtr: Say('but the ~ spell was thwarted by the , a Sage Discovery which counteracts all ~ spells.',S_PCom);
_SComRed: Say('The impact of the ~ spell seemed to have been reduced by the , an anti-spell Sage Discovery.',S_PCom);
_LEnc: FD('enco',S_Adv,1);
_LBEnc: Say('<3 stepped/Rstrode forward and challenged [ to honorable/Rpersonal combat.',S_Batt);
_LSafe: FD('safpat',S_Adv,1);
_LWEnc: BEGIN  randlevel:= 1; FD('rwenc',S_Adv,3); END;
_LPEnc: BEGIN  FD('patenc',S_Adv,4); randlevel:= 2; END;
_LPass: Say('< encountered/Rpassed_near [, but [1 seemed_to_have_no/Rhad_not_the mettle/Rtime for a fight.',S_Adv);
_LBefr: Say('< raised > hands/Rpalm in greeting/Ra_gesture_of_friendship and befriended/Rmade_friends_with [.',S_Adv);
_LTricks: Say('[1 was kind_enough/Rable to show <2 a few tricks/Rtips in ^.',S_PCom);
_LDense: Say('< was very impressed/Rinterested, but couldn''t {seem to }get_the_hang_of/Runderstand it.',S_PCom);
_LDona:Say('< explained {> and }''s {$a }cause/Rbeliefs and [1, greatly/Rvisibly impressed/Rmoved, gave us 1 gold.',S_PCom);
_LHear: Say('[1 spoke/Rtold of a{n interesting} feature in @:  &  inhabited/Roccupied by +.',S_PCom);
_LNice: Say('< and [ talked/Rdrank_wine for a while/Rtime, then {parted and }went their separate ways.',S_PCom);
_LGreet: Say('{but }< hailed/Rspoke_to [ with friendly/Rrespectful words, and combat/Ra_fight was avoided/Raverted.',S_Adv);
_DCConv: Say('while conversing_with/Rtalking_to > new{found} friend/Rcompadre, ',S_Red);
_LEncEnd: randlevel:= 0;

_DCBatt: Say('while at_the/Rgiving battle, ',S_Batt);
_DCSpy: BEGIN
  PR1;
  Say('while engaged_in/Rassigned_to espionage/Rspying, ',S_Red);
 END;
_NBatt: BEGIN Inv_Say; Say('the forces of <.',S_Red); END;
_NForm: BEGIN Inv_Say; Say('<.',S_Red); END;
_NComm: BEGIN Inv_Say; Say('<''s Kingdom.',S_Red); END;
_NProf: BEGIN Inv_Say; Say('<''s leaders.',S_Red); END;

_DAUse: Say('The ''s function/Reffect is to assist/Rhelp <2 and > compatriots/Rcomrades when they use ^.',S_Red);
_DCSUse: Say('The ''s function/Reffect is to counteract/Ract_as_an_antidote_to the ~ spell.',S_Red);
_DRvUse: Say('The ''s function/Reffect is to somewhat/Rslightly raise/Rincrease <''s revenue/Rtax_base.',S_Red);

_LDConf: Say('[1 could not discover/Rascertain the secret_of/Rkey_to the ''s mysteries/Rinner_workings.',S_Red);
_CProf: Say('But with each Spy action, there would be some chance for us to ',S_Red);
_CForm: Say('Spying would give us a slight chance of discovering the formula and to ',S_Red);
_CBatt: Say('More battles would be needed to study it and ',S_Red);
_LDCFin: Say('gain/Rreceive the benefits of the  for our Kingdom/Rrealm.',S_Red);

_CSSkel: Say('the Skeletal Armies fighting for < were reduced in quality one level because of their enemy''s .',S_Batt);
_CSOrat: Say('Only 33% of the armies fighting for <2 were affected by any Oratory spell because of their enemy''s .',S_Batt);
_CSIA: Say(
'the Illusory Armies fighting for < had only 33% of their normal effect because they were detected by their enemy''s .',
S_Batt);

_CSPA: Say(
'the Illusory Armies fighting for < were reduced by 50% because of their enemy''s magical power to detect illusions.',
S_Batt);

_CSIT: BEGIN
  Say('the terrain of @ appeared to be `, but <''s Ultraviolet Lenses revealed the actual terrain.',S_Prev);
 END;
_CSHF: BEGIN
  Say('the & had been hidden by a Hide Feature spell, but the Hand-Held Radar set revealed its location.',S_Prev);
 END;
_SResur:  Sps(Resurrection,S_PCom);
_SPart: Sps(Part_Sea,S_Comm);
_SBless: Sps(Bless,S_Admin);
_SNoSkel: Say('no skeletons answered the spell''s call.',S_PCom);
_SKill: Sps(Kill_Enemy,S_Adv);
_LOAss: Say('< ordered the assassination of [.',S_Priv);
_ASeek: BEGIN Say(
'While [1 was out_for_a_stroll/Rin_meditation, suddenly an{ unknown} assassin launched himself{ from out of the dark} at [!',
  S_Adv);
 END;
_AKill:
Say('[1 was wounded/Rstabbed by a_poisoned/Rhis_poisonous dagger!Cursed be the Assassin''s Guild and whoever heads it!',
S_Adv);
_AFail: BEGIN
  Say('Fortunately, [1 survived the attempt and the assassin (apparently, a member of the Assassin''s Guild) was killed.',
  S_Adv);
  Say('Of_course/RWithout_delay, the guard in/Rthroughout [''s kingdom was {immediately }doubled.',S_Adv);
 END;
_SSick: Say(
'[1 was made very ill by some strange Necromantic magic, so ill that [1 could do nothing but practice the rest of the turn!',
  S_Adv);
_SClairv: Sps(Clairvoyance,S_PCom);
_SFlood: Say('@ was magically flooded.',S_Comm);
_STorn: Say('magical tornadoes hit the defenders of @.',S_AA);
_SQuake: Sps(Earthquake,S_Comm);
_SCharm: Say('[1 was magically charmed by <2.',S_PCom);
_SOrat: Sps(Oratory,S_Adv);
_STerIl:
  Say(Concat('the ',tername[pterr[_px,_py]],' terrain of @ was magically made to appear as `.'),S_Comm);
_SIllAr: Sps(Illus_Armies,S_AA);
_SHideF: Sps(Hide_Feature,S_Adv);

_PPlague: Say('plague ravaged the province of @.',S_Comm);
{$IFNDEF More_Entry}
_BInvas: BEGIN
  chief_on:= true;
  event_lev:= S_Army;
  PR1;
  FD('invas',S_Army,1);
 END;
_BRevolt: BEGIN
  chief_on:= true;
  event_lev:= S_Army;
  PR1;
  Say('in @, <3 campaigned_against/Rbrought_to_bay {the forces of }[3.',S_Army);
 END;
_BCdrs: BEGIN
  Say('< commanded/Rwas_in_command_of the attacking/Rinvading armies/Sfleet.',S_Army);
  Say('the defenders/Rdefending_forces were led/Rcommanded by [.',S_Army);
 END;
_BLLen: _linelen:= Rint;
_BForces: BEGIN
  FOR fn:= 1 TO 2 DO FOR ap:= 1 TO 70 DO BEGIN
    t:= Rint; apos[fn][ap]:= t; {t = army#, upper 6 bits are quality}
    IF t <> -1 THEN BEGIN
      t2:= Rint; { t2 = type, upper 11 bits are owner.}
{      WRITE('[T1:',t,'\N',t and $3FF,'\Q',t shr 10,'/T2:',t2,'\T',t2 and $1F,'\O:',t2 Shr 5,']');}
      lastat[t and $3FF]:= army(t2 and $1F);
      ash[fn][ap]:= t2;
     END;
   END;
 END;
_BAWFlop: Say('The defending whales dove through the seawalls of the parted waters and flopped into their lines.',S_Batt);
_BStill: Say('Still/REven_so, ',S_Batt);
_BSpite: Say('in_spite_of/Reven_with =''s good luck/Rfortune, ',S_Batt);
_BAList: Check_BAList;
_AAResv: Say('the attackers had = in reserve.',S_Batt);
_ADResv: Say('the defenders had = in reserve.',S_Batt);
_LSlow: BEGIN
Say('[ did_not/Rfailed_to arrive at the battle{field} {in time }because ] skill in ^ was lacking/Rtoo_low.',S_Batt); PR1; END;
_LBGen: BEGIN
Say(
'[1''s forces fought in a battle in @, but a foreign general commanded it.The battle is in the General Intelligence Report.',
S_Batt);
 PR1; END;
_BLeaders: BEGIN
  tentdex[1]:= Rint; tentdex[2]:= Rint;
  cdrdex[1]:= Rint; cdrdex[2]:= Rint;
  FOR fn:= 1 TO 2 DO FOR ap:= 1 TO 20 DO ldrtent[fn][ap]:= Rint;
 END;
_BLList: BEGIN
  FOR fn:= 1 TO 2 DO BEGIN
    lp:= 1;
    WHILE lp <= tentdex[fn] DO BEGIN
      _attl:= ldrtent[fn][lp];
      IF lp <= cdrdex[fn] THEN FD('batldr',S_Batt,2)
        ELSE Say('< was there, leading no armies.',S_Adv);
      Inc(lp);
     END;
    IF lp = 1 THEN BEGIN
      _attl:= powner[_px,_py];
      Say('no generals were present to lead the forces of [.',S_Batt);
     END;
   END;
  PR1;
 END;
_AThirst:
  Say('<''s men/Rsoldiers, ill-supplied/Rwith_no_camels in/Rfor the {tortuous }desert{ campaign}, suffered from thirst.',
  S_Batt);
_BLuck: BEGIN
  batluck:= Rint;
  IF Odd(_px+_py+_attl+_defl+_rphase) THEN
      FD('c:\tp\prose\bluck.x2',S_Batt,1000+batluck)
    ELSE FD('c:\tp\prose\bluck2.x2',S_Batt,1000+batluck);
 END;
_BTac: BEGIN
  battac:= Rint;
  IF (((battac < 5) and (batluck > 9)) or ((battac > 5) and (batluck < 9))) THEN
      Say('but/Ron_the_other_hand ',S_Batt)
    ELSE IF (((battac < 5) and (batluck < 9)) or ((battac > 5) and (batluck > 9))) THEN
      Say('also/Rfurther, ',S_Batt);
  FD('c:\tp\prose\tactics.x2',S_Batt,Max(1001,Min(1009,1000+battac)));
  PR1;
 END;
_CLuck: BEGIN
  FD('luckint',S_Batt,7);
  IF Odd(_px+_py+_attl+_defl+_rphase) THEN
      FD('c:\tp\prose\cluck.x2',S_Batt,1000+Rint)
    ELSE FD('c:\tp\prose\cluck2.x2',S_Batt,1000+Rint);
 END;
_CLuck2: BEGIN
  trint:= Rint;
  IF Odd(_px+_py+_rphase) THEN
    IF trint > 20 THEN Say('the day/Routcome looked/Rseemed dark/Rbleak for {the brave_fighters/Rsoldiers of }=.',S_Batt)
      ELSE Say(
'it appeared/Rseemed {probable }that = would/Rmight {break_through/Rgain_the_upper_hand and }win{ the_battle/Ra_victory}.',
S_Batt);
  PR1;
  FD('luckint2',S_Batt,7);
  FD('c:\tp\prose\cluck2.x2',S_Batt,1000+trint);
 END;
_ANem: FD('c:\tp\prose\nemesis.x2',S_Batt,1000+Rint);
_BEleph: FD('elephant',S_Batt,1000+Rint);
_BMonst: BEGIN
  chief_on:= false;
  FD('mcome',S_Batt,0);
  FD('mfight',S_Batt,1001+Rint);
  chief_on:= true;
 END;
_BDefect: Say('= defected to <2.',S_Batt);
_BLoyal: Say('= stayed loyal to their brethren.',S_Batt);
_BAid: Say('= came to the aid of <, called by \.',S_Batt);
_BMagic: Say('The army of < used magic to aid their cause.',S_Batt);
_BIA: Say('Magical phantasmal armies/Snavies fought with <2''s soldiers.',S_Batt);
_BPersp: attside:= Rint;
_BFace: Check_BFace;
_BSwitch: BEGIN
  lp:= Rint; fn:= Rint;
  apos[fn][lp]:= _adex;
  PR1;
  Say(
'< switched/Rmaneuvered = to the front_line/Rfore, angling/Ras_a_strategem for a better/Rsuperior match-up/Rnemesis_effect.'
,S_Batt);
 END;
_BClash: BEGIN
  lp:= Rint;
  _adex:= apos[1][lp] and $3FF;
  Say('= fought/Rbattled {with }',S_Batt);
  _adex:= apos[2][lp] and $3FF;
  Say('=',S_Batt);
 END;
_BRes: BEGIN
  Say(' and',S_Batt); bres:= Rint;
  CASE bres OF
   -32000..-5: FD('minus5',S_Batt,3);
   -4: FD('minus4',S_Batt,4);
   -3: FD('minus3',S_Batt,5);
   -2: FD('minus2',S_Batt,6);
   -1: FD('minus1',S_Batt,7);
    0: FD('zero',S_Batt,8);
    1: FD('plus1',S_Batt,9);
    2: FD('plus2',S_Batt,10);
    3: FD('plus3',S_Batt,0);
    4: FD('plus4',S_Batt,1);
    5..32000: FD('plus5',S_Batt,2);
   END;
 END;
_BNoRet: Say('= were unable to retreat and were destroyed.',S_Batt);
_BMercs: Say('= were_unable_to/Rhad_no_path_of retreat and became/Rdisbanded_into mercenaries.',S_Batt);
_BQuit: Say('= were_unable_to/Rcould_not retreat/Rescape and were paroled/Rdisbanded into the {general }population.',S_Batt);
_BWinner: BEGIN PR1; FD('winner',S_Batt,3); END;
_BDestr: Say('=',S_Batt);
_BDie: FD('killarmy',S_Batt,4);
_BBite: Say(' bit/Rmangled =, and they will become werebeasts at the end of the year!',S_Batt);
_BDepl: Say(' severely depleted =.',S_Batt);
_BPurs: FD('pursuit',S_Batt,5);
_BPFail: Say(' were beaten/Rdriven off by = after/Rin a tough/Rhard-fought rearguard action/Rbattle.',S_Batt);
_BGoHome: Say('= travelled back to its home province of @.',S_Batt);
_BLRetr: FD('retreat',S_Batt,6);
_LRFlee: Say('> forces completely dispersed/Rdestroyed, < fled/Rescaped {frightened and }alone to .',S_Batt);
_BConq: BEGIN
  FD('conq',S_Army,7);
  Set_Excldr;
  Say('@ was found/Rdiscovered to have  tax_base/Rincome of # gold.',S_AA);
  _excldr:= -1;
 END;
_LNLRet: Say('The leaderless attacking armies turned back.',S_AA);
_BInv: FD('invwin',S_Army,8);
_BDef: FD('defwin',S_Army,9);
_LStays: BEGIN
  Say('{al}though <''s host/Rforces were victorious/Rtriumphant, ',S_Army);
  Say('[1 regrouped/Rrallied ] forces/Rmen and prepared/Rdecided to contest/Rfight_for @.',S_Army);
 END;
_LStrand: BEGIN
Say('< invaded @, but because [1 happened to meet and defeat the defenders first, [1 conquered the province instead.',S_Army);
  PR1;
 END;
_BBluff: FD('bluff',S_Batt,1);
_BNoEx: Say(
'< couldn''t/Rfailed_to think_of/Rcome_up_with a good/Rbelievable excuse/Rploy for_avoiding/Rto_get_out_of the duel, so ',
S_Batt);
_BFun: Say('The Skeletal Armies led by < marched into battle with a fanatical fervor.',S_Batt);
_BRWeap: Say(
'< waved/Rheld_aloft > \ and the/R>  cheered_wildly/Rwere_virtually_hypnotized{ with/Rin admiration/Rit''s_enchanted_glow}!',
S_Batt);
_BSpeech: BEGIN
  Set_Excldr;
  Say('using/Rcalling_upon > magical/Rarcane powers/RSpell of Oratory, ',S_Priv);
  _excldr:= -1;
Say(
'< gave/Rstarted_with  rousing/Rinspiring speech/Rharangue to > troops/Rarmy, raising/Rwhich_bolstered their courage/Rmorale.'
,S_Batt);
 END;
_BHome: Say(
'<''s troops/Rsoldiers were_prepared/Rswore to fight/Rstruggle desperately/Rlike_tigers for their homeland/Rfatherland.',
S_Batt);
_BNoDru: FD('nodru',S_Batt,1000+Rint);
(*_LRepo: Say('< took possession of the body of a strong lad who happened to be passing near.',S_PCom);
_LStake:
Say('< was finished off by White Magic: holy water was sprinkled on <2 and a stake was driven through > heart.',S_PCom);
_LPenta:
  Say('< was finished off by White Magic: a pentagram was drawn around the slain body, dooming <2 to the Abyss.',S_PCom);
_LRise: Say('Though < was returned to the soil, < slept in > grave and prepared to rise at the next full moon.',S_PCom);
_LImpris: Say('The spell imprisoned ] soul, and [1 became Evil.',S_Prev);*)
_LCHUnd:
  Say('< sank/Rbit > fangs into [ and drained/Rsucked_up {all }] blood.[1 changed to $o alignment!',S_Prev);
(*_LEQuit: Say('[1 was confused by the spell and quit the service of ] king.',S_Prev);*)
_TrReg: Say(
'After the battle{ was over}, the {dismembered }trolls regenerated/Rreformed into a disgruntled/Rhorrid band of mercenaries.'
,S_Batt);
{$ENDIF}
_LVLeave: BEGIN
  Say('< returned/Rwent_back to Valhalla, having tried/Rdone > best to fulfill/Rexecute > assignments/Rduties.',S_Red);
  PR1;
 END;
_LRiseV: Say('And_so/RIn_a_column_of_flame, < rose/Rascended once again/Rmore to Valhalla.',S_Prev);
_LPigeon: BEGIN
  PR1;
  Say('<3 received a message via homing pigeon, sent by [3:',S_Priv);
  PR1;
 END;
_LValHal: BEGIN
  Use_NewVal(true,true);
  Get_VFN(_attl,vs,1);
{  vs:= Concat('c:\tp\prose\',outname[lalign[_attl]],'.x2');}
  FD(vs,S_Red,1);
  Get_VFN(_attl,vs,2);
  FD(vs,S_Red,2000+vchoice); _defl:= valhero;
  PR1;
  FD('c:\tp\prose\valint.x2',S_Red,1);
  WRITE('?1');
  IF gameturn < 8 THEN IF not say_trial THEN BEGIN
    Dec(tdex); story^[tdex]:= (gameturn DIV 2) + 1;
    PR1;
    Say('[ can be given orders only for the first # phase(s) of the turn.',S_Red);
   END;
  PR2;
  Use_NewVal(false,true);
 END;
_EndPh: BEGIN event_lev:= S_Red; PR1; END;
_EndBat: BEGIN chief_on:= false; willdie:= noleader; END;
_Ass2: BEGIN
  t:= Rint;
  IF t <> playking THEN double_ldr:= t;
 END;
_End2: double_ldr:= noleader;
_AssRand: BEGIN RandSeed:= Rint+(longint(Rint) Shl 16); Clear_FD; END;
_AssPh: Assign_Phase;
_SQuote: BEGIN
  PR2;
  Say('Quote of the Week:',S_Red);
  PR2;
  qfact:= longint(gdyear)*366 +gdmonth*31-31 +gdday -(7*ord(gameturn=0));
  qfact:= ((qfact-startfact[company]) DIV 7) MOD 94;
{  WRITELN('qfact = ',qfact);}
  extext:= true; FD('c:\tp\prose\quotes.x2',S_Red,1001+qfact);
  extext:= false;
 END;
_SetPow: Set_Event(_feat1 and 255,false);
_EIntro: Runic_Intro;
_PowMsg: BEGIN
  trint:= Rint;
  Runic_Intro;
  FD('c:\tp\prose\powmsg.x2',S_PCom,1000+trint);
 END;
_EndQ: Runes_End;
_EDesc: BEGIN
  IF needy THEN Say('The $\ needs more information to perform its power.',S_PCom);
  FD('c:\tp\prose\fpdesc.x2',S_PCom,1001+ord(fpower));
  IF ((fpower = AnsPrayer) or (fpower = CastSpell)) THEN
    FD('c:\tp\prose\spdesc.x2',S_PCom,1001+setval);
  needy:= false;
 END;
_ECond: Desc_PowCon;
_MCond: BEGIN
  CASE fpowcon OF
    Drain_Courage,PayUp,Drain_Skill: ;
    ELSE Runic_Intro;
   END;
  FD('c:\tp\prose\mcond.x2',S_PCom,1001+ord(fpowcon));
 END;
_NeedI: needy:= true;
_NoNews: Say('< found no monster living in the &, and had no orders to scout it, so < left it empty-handed.',S_Adv);
_NoMeet: BEGIN
  Runic_Intro;
  Say('You don''t meet the conditions for using the $\.',S_PCom);
  IF not saidcond THEN Desc_PowCon;
  CASE fpowcon OF
    SameAlign:  Say('You are not $o, so begone/Rgo_away!',S_PCom);
    NeedKing: Say('You''re just  lowly/Rirrelevant hero/Rlackey, so get out of here/Rthis_&!',S_PCom);
    GTurn: Say('The power has already been used this turn, so go away!',S_PCom);
   END;
 END;
_MFDesc: BEGIN  PR1; FD('c:\tp\prose\magfeat.x2',S_PCom,1001+ord(_magfeat)); END;
_LMFApp: Say('< knelt_beside/Rhailed the $\.',S_PCom);
_ArmSay: BEGIN  Runic_Intro; Say('[ leads/Rcommands =.',S_PCom); END;
_AbSay: BEGIN  Runic_Intro; Say('I now drain away your skill in ^.',S_PCom); END;
_BMNoPay:
  Say('the Kingdom suffered an income reduction of # gold because of the social turmoil caused by unpaid blackmail.',S_Red);
_LEuro: FD('c:\tp\prose\europe.x2',S_Red,1001+_ldr1);
_LEarth: FD('c:\tp\prose\earth.x2',S_Red,1001+_ldr1);
_LExSpy: BEGIN
  Say('< was estimated to have the following skills: ',S_Red);
  Say(
'Tac #, March #, Naval #, Bow #, Melee #, White #, Necro #, Elem #, Psych #, Illus #, Druid #, Thief #, Expl #, Spy #, Sage #.'
,S_Red);
  PR1;
 END;
_LCong: BEGIN
  PR1;
  specials_on:= true;
  IF _qsubplot = 1 THEN {is first achievement}
      Say('Congratulations!Your_kingdom_has/RYou_have reached/Rattained {skill }level # in ^.',S_Red)
    ELSE t:= Rint;
  IF _next = 5 THEN FD('c:\tp\prose\sal.x2',S_Red,1001+ord(_abil));
  Say('all/Ryour characters of this high/Rexalted level are_awarded/Rgain the_following/Ra_new Advanced Ability: ',S_Red);
  PR1;
  FD('c:\tp\prose\sa.x2',S_Prev,1001+Rint);
  PR1;
  specials_on:= false;
 END;
_SANote: BEGIN
  trint:= Rint;
  FD('c:\tp\prose\sanote.x2',sa_lev[trint],1001+trint);
 END;
_LRApt: Say('> experience/Refforts raised/Rimproved > aptitude in ^.',S_Priv);
32100: Say('[1 evaded the challenge by <2.',S_PCom);
32101: Say('< did not have enough skill in archery to fire an arrow.',S_PCom);
32500: Say('< tried to move from  to @, a non-adjacent province.This is illegal!',S_Priv);
32501: BEGIN
  _next:= Rint;
  IF _next <> 5 THEN Say('< attempted an illegal move.',S_Priv);
  CASE _next OF
   -1: Say('< could not retreat into an occupied province.',S_Priv);
    100..149:
     Say('< tried to use water-borne movement to move from  to @, but > transport was insufficent for the task.',S_Priv);
    150..199:
     Say('< tried to move from  to @, but provincial flooding and insufficient transport thwarted the move.',S_Priv);
    200..249: Say('< was ordered to move with Mermen from  to @, but had insufficient air-transport.',S_Priv);
    ELSE FD('c:\tp\prose\illmove.x2',S_Priv,_next+1000);
   END;
 END;
32502..32599: FD('c:\tp\prose\illeg.x2',S_Priv,code-31500);
    ELSE BEGIN
      Say('?Unknown Event?',S_Priv);
      IF not autorun THEN BEGIN
        WRITE('Unknown code: ',code); WEK;
       END;
      PNum(code);
     END;
   END;
  IF Say_Code(code) THEN _prevact:= code;
  say_on:= false;
 END;

PROCEDURE Imp_Spab(ab: ability; lev: integer; cong: boolean);
BEGIN
  WRITE('?4');
{  IF Company = ArkRoyal THEN} BEGIN
      WRITE('Is');
  Imp_Code(2864+ord(cong));
  Imp_Code(1856+ord(ab));
  tdex:= 1;
  story^[1]:= lev;
  story^[2]:= spabord[ab,lev-4];
  Imp_Code(_LCong);
      WRITE(',');
  END;
 END;

PROCEDURE Write_SR;
BEGIN
    Page_Print;
    WRITELN(playfile,'SPECIAL RULES:       ');
    WRITE(playfile,elon);
 END;

PROCEDURE Start_ACF(ldr: integer; nupag: boolean);
VAR accf: Str20;
    l2: integer;
BEGIN
  WRITE('ACF',ldr);
  Get_MFN('ac',gameturn,ldr,accf);
  Assign(playfile,accf);
  Start_App(playfile);
  FOR l2:= 1 TO 2 DO WRITELN(playfile);
  WRITELN(playfile,'END MOVES REPORT');
  IF nupag THEN IF woe = 2 THEN Write_SR;
  WRITE('+x');
 END;

PROCEDURE Check_EOT(ldr: integer; ab: ability; VAR needeot: boolean; newhero: boolean);
VAR l2,max_kskill,ablev: integer;
BEGIN
  WRITE('?3');
  needeot:= true;
{  IF Company = ArkRoyal THEN} IF minewrit >= 2 THEN IF LKing(ldr) < nkings THEN BEGIN
    max_kskill:= 0;
    FOR l2:= 0 TO nleaders-1 DO IF LKing(l2) = LKing(ldr) THEN
      IF l2 <> ldr THEN BEGIN
        IF M_Skill(l2,ab) >= M_Skill(ldr,ab) THEN needeot:= false;
        IF M_Skill(l2,ab) > max_kskill THEN max_kskill:= M_Skill(l2,ab);
       END;
    IF needeot THEN FOR ablev:= Max(5,max_kskill) TO M_Skill(ldr,ab) DO BEGIN
      Start_ACF(LKing(ldr),true);
      Imp_Spab(ab,ablev,true);
      AClose(playfile);
     END;
   END;
 END;

PROCEDURE Check_NSpabs(ldr: integer; newhero: boolean);
VAR a: ability;
    needcong: boolean;
BEGIN
  FOR a:= Tactical TO Sage DO IF M_Skill(ldr,a) > 4 THEN
    Check_EOT(ldr,a,needcong,newhero);
 END;

