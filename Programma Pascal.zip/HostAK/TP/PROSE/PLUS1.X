3 1
 gradually pushed/Rshoved them back.
 was_able/Rmanaged to make some{ slow/Rmeasure_of} progress.
 moved/Rground ahead slowly/Rgrimly, contested/Rbattled for every foot/Ryard of their advance.
