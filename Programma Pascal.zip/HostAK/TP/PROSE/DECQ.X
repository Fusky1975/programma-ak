6 1
= was severely/Rbadly shaken during/Rin the battle and we must now rate/Rclassify it as   unit.
= took  thorough/Rsevere pounding/Rbeating and lost some key people/Rofficers.It should be considered/Rrated   unit now.
= was unlucky/Runfortunate enough to lose some of its most able/Rpromising officers{ in personal combat}, and we now rate/Rrank it   unit.
= had its morale/Rconfidence shaken/Rbattered by  bad/Revil omen which manifested_itself/Rreared_its_ugly_head during/Rbefore the battle.= has dropped_off/Rslipped in quality and now it's   unit.
the long{, hard/Rdifficult} campaign caused/Rforced = to lose some of its battle-lust/Rzeal, and now it can only {be counted_on/Rtrusted to }fight as   unit.
= was {severely }mauled/Rmangled in/Rduring the battle/Rfight and has fallen in stature/Rquality to  condition.
