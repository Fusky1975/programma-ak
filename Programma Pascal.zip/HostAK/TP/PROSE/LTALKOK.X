4 1
< talked_to/Rspoke_with [ and learned/Rfound_out that [1 could be hired/Rbought for # gold.
< spoke/Rconversed with [ for_some_time/Rat_length.< learned/Rdiscovered that [1 was available {for hire }at  price/Rcost of # gold.
< approached [ and asked/Rinquired if [1 was available.[1 said/Rdeclared [1 would pledge/Rrent ] allegiance/Rservices for # gold.
<  found [ {drinking ale/Rbeer }in  tavern/Rpub and had  few beers/Rdrinks with [.[1 told/Rinformed <2 that it would be ] honor/Rpleasure to serve/Rwork_for <2 at the price/Rcost of # gold.
