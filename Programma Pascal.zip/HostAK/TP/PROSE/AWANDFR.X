3 1
= grew tired_of/Rbored_with the {wines and }whores/Rcourtesans of @ and moved_on/Ssailed off to  where they hoped the pickings/Rentertainment would be more to their liking/Rtastes.
= lost hope of finding employment/Radventure in @, {and }so they mustered their strength and moved_on/Ssailed_away to .
the captain of = felt  wanderlust/Rthirst_for_adventure stirring/Rawakening in his breast/Rheart, and speaking highly/Reloquently of{ the lands and princes of} , persuaded/Rconvinced his men to march/Ssail with him to .
