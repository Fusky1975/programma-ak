5 1
 annihilated =.
 slew = almost to  man.
 destroyed =.
 demolished =.
 scattered = in all directions.
