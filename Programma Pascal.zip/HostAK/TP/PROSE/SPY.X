5 1
< {secretly }spied on @.Here is > report:__
< conducted espionage in @ and compiled/Rwrote this report.
< gathered information/Rintelligence in @ and wrote/Rcompiled this report.
< {covertly }spied on @ and gathered/Rcollected the following information:/Rintelligence.
< used/Rutilized > {fine }covert/Rspying skills to secretly observe/Rkeep_track_of events/Rhappenings in @ and reported the following{ information}.
