4 1
@ was overrun/Sconquered by the forces/Sfleets of <2.
<'s host/Sarmada concluded/Rended the campaign victoriously/Rsuccessfully and conquered {the province of }@.
<'s {well-planned }campaign effected/Raccomplished the conquest of @.
@ was overrun/Sconquered by <'s men/Rforces in a hard-fought/Rbloody campaign.
