3 1
< hired =,  {redoubtable/Rwell-drilled }mercenary army/Ssquadron which had made_its_way_to/Rarrived_in @.
< recruited  {rough/Rhard_fighting }band/Rforce of mercenary soldiers/Sships in @ who call_themselves/Rare_known_as =.
< negotiated_with/Rproposed_terms_to = for their allegiance/Rsupport, and succeeded in contracting_for/Rsecuring their services/Renlistment.
