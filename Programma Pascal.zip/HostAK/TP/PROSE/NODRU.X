6 1
the  led/Rcommanded by < were not_impressed_by/Rdisgusted_with > lack_of_leadership_ability/Rstrange_appearance.
< was_frustrated_by/Rcould_make_almost_no_use_of the , who virtually_ignored/Rcould_not_comprehend > commands/Rmilitary_strategy.
the  < commanded/Rled were rendered_worthless_by/Rineffective_because_of their intolerance_of/Rpoor_relations_with <2.
< soon_found/Rcould_see that >/Rthe  would rather/Rsooner swallow/Rget_plastered_with spears/Rpoison than follow/Robey a repulsive/Rdisgusting being/Rcreature like <2.
< soon_found/Rcould_see that >/Rthe  would rather/Rsooner swallow/Rget_plastered_with spears/Rpoison than follow/Robey a repulsive/Rdisgusting being/Rcreature like <2.
< soon_found/Rcould_see that >/Rthe  would rather/Rsooner swallow/Rget_plastered_with spears/Rpoison than follow/Robey a repulsive/Rdisgusting being/Rcreature like <2.
