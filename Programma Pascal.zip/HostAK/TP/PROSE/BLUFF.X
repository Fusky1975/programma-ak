3 1
< weaseled/Rwormed {> way }out of the duel/Rshowdown{ with <}{ at the last moment/Rsecond}, claiming/Rannouncing_that >_warhorse/R< was{ too} ill/Rhaving_arthritic_spasms.
[1 offered_to_duel/Rchallenged <2, but < {haughtily/Rbrazenly }informed/Rordained_to [/Rall_who_would_listen that because_of/Rdue_to > infinite/Rbenevolent mercy/Rpity, < would excuse_[_from/Rnot_hold_[_to ] ridiculous/Rchildish challenge/Roffer.
< cleverly/Rsecretly paid_off/Rbribed a camp_attendant/Rspy to produce_false_evidence_of/Rannounce_he_had_detected illegal_poison/R<''s_plans_to_cheat in ] army-camp/Rtent, and {so }< angrily/Rhaughtily backed_out_of/Rdeclined the challenge/Rduel.
