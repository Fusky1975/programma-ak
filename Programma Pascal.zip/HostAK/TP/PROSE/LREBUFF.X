3 1
< tried_talking/Rspoke to [, but {it seems that }] family/Rclan holds  grudge against {'s clan} and does not want/Rwish to associate_with/Rserve him.
< spoke to [ with {hopes for }friendship {in > heart}.[1 rebuffed > overtures/Rgreeting out of personal dislike/Rdistaste for .
< spoke kindly to [, but was {coldly/Rdisdainfully }rebuffed because, said [1, "you and your ilk/Rcronies are  gang/Rbunch of SNAKES/RROGUES!"
