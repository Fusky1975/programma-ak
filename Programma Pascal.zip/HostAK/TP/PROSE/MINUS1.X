3 1
 gradually gave_ground/Swas_pushed_back.
 were {slowly }bent/Spushed back by their attack/Rpressure.
 could not {quite }hold their ground/Sown against their savage/Rdetermined foe/Ropponent.
