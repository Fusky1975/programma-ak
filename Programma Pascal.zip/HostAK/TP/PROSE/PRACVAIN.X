4 1
< {really }tried hard to improve > ^, but < practiced in vain.
< practiced > ^ {diligently }for many_weeks/Rmonths, but could make no {significant }headway/Rprogress.
< practiced > ^ well{, and even consulted a_palm_reader/Ran_astrologer,} but could not improve > {skill in }^.
< worked {hard }on > ^ but was thwarted/Rfrustrated in > {self-improvement }efforts.
