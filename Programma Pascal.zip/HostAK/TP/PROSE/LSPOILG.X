3 1
< took/Rlooted # gold from the treasure {trove }of [.
< found/Rlocated  treasure of # gold{ and bagged_it/Rsnarfed_it_up}.
< found # gold in the treasure/Rhoard of [.
