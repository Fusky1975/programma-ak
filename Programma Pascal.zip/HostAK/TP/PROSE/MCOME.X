3 1
[, hearing/Rlearning of the peril/Rjust_cause of the Druidic king/Rmonarch, arrived_at/Rrushed_to the battle{field} to fight/Rjoin_forces with =.
word/Rnews of the impending/Rperilous battle had spread {far and wide }throughout/Rwithin @, so_that/Rand even [ heard/Rgot_wind of it and made_an_appearance/Rarrived_for_the_show, where [ fought/Rparticipated alongside/Rwith =.
fighting_with/Rhelping = in the_battle/Rthis_contest was [, who_had_come/Rcoming to the aid/Rdefense of ] friend/Rally, the Druidic King/Rruler.
