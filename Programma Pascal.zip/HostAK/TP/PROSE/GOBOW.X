3 1
< {quickly/Rspeedily }moved {in}to bow range.
< loped/Sswam along smoothly/Rsteadily{, conserving > energy,} and closed to bow range.
< {menacingly/Rcautiously }advanced to bow range.
