3 1
 was {almost }powerless to stop/Rhalt their {determined }advance.
 was forced to retreat in disorder/Rdisarray.
 buckled/Rcrumpled under the heavy attack/Rpressure, retreating in disarray/Rdisorder.
