1 1
< spoke {urgently/Reloquently }to [ {of the greatness/Rgrandness of 's realm/Rempire }and convinced [ to pledge ] allegiance/Rservices to .
