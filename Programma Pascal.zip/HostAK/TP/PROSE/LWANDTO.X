4 1
< {has }just recently wandered into  from @.
< has arrived in  from @{, attracted/Rdrawn by the fine/Rgreat (or infamous?/Rterrible?) reputation of its king}.
< hiked/Ssailed into .< had grown bored/Rtired with @ and was attracted/Rdrawn there by tales/Rrumors of its fine/Rwonderful scotch/Rwines{ and even more_wonderful/Rfiner courtesans/Rchampagnes}.
< rode/Scruised into  in search of {worthy }adventure/Remployment{, having found none/Rnothing_much in @}.
