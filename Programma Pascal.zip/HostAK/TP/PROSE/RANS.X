7 1 {if you change this, change get_reply}
Sayeth [, "Yes, 'Riddle' is the correct answer!You're very good at this game."
Sayeth [, "'Coffin' is right.What a lucky guess!"
Sayeth [, "'Bridge' is the true answer.Hmm, you must have heard this riddle elsewhere."
Sayeth [, "'Candle' is indeed what I had in mind.You're not as dumb as you look!"
Sayeth [, "Yes, 'Smoke' is the right answer.How did you ever guess this one?"
Sayeth [, "You got it, 'Onion' is right.But it took you LONG ENOUGH to solve it!Hah!"
Sayeth [, "Yes!'Man' is the right answer, as recorded by Greek mythology (which you must be well-acquainted with.)"
