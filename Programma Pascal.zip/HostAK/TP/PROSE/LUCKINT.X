4 1
In this engagement/Rmatch,_
Here,_
On this field/Rbattleground,_
In this sector/Rarea,_
