4 1
< cautiously/Rcarefully laid_hands_on/Rreached for the treasure.
< slid/Rslipped > hands cautiously/Rfondly over the treasure.
< succeeded in laying > {greedy }hands/Rfingers on the treasure.
the treasure seemed {almost }to call out to <2.< carefully/Rcautiously reached out for it.
