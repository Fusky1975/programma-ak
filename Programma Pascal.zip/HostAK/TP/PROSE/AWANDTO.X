3 1
= has {just recently }arrived in , having travelled/Rcome from @{ in search of employment}.
= has wandered/Ssailed into  from @.
newly come/Rarrived from @ is =, which army/Snavy is seeking employment/Ra_liege in .
