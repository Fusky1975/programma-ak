3 1
 advanced {almost }at will.
 drove/Rthrust them back{ with  savage fury}.
 overpowered/Rovercame them with their thundering/Sdetermined charge.
