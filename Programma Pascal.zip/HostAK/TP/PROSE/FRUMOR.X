4 1
{While carousing/Rdrinking with fellow/Rother adventurers/Rtravellers in a bar/Rtavern, }< heard {mention/Rtell }of a{n interesting} feature in  $#:  & inhabited/Roccupied by +, who guards/Rholds the \.
{While }conversing/Rspeaking with {passing/Rfriendly }merchants/Radventurers, < heard/Rlearned a rumor about  previously/Rheretofore unknown/Runheard_of & in  $#, held/Rinhabited by +, who according to legend possesses the \.
< heard a rumor telling of  {perilous }feature in  $#{ previously unknown to us},  & inhabited_by/Rwhere_dwells +.the & is reputed to contain the \.
{while }talking/Rspeaking to some {friendly }locals/Rfarmers, < heard a rumor about  & in  $#, occupied/Rinhabited by +.They/Rsome say/Rmaintain that + {actually }owns the \.
