4 1
< caressed/Rlifted the treasure fondly/Rlovingly.
< {then }beheld the treasure, which lay there just for the taking.
< succeeded in laying > {greedy }hands/Rfingers on the {valuable }treasure.
< could see the glittering/Rgleaming{, shiny/Rglowing} treasure which seemed to {seductively }beckon/Rcall_out to > greedy/Rtrembling fingers.
