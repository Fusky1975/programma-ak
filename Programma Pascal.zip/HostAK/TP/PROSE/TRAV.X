4 1
< travelled to @.
< rode/Ssailed into @.
< moved into @.
< journeyed/Scruised_over to @.
