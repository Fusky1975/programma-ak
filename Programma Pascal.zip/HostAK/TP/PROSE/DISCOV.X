1 1
in > sagely researches, < discovered  fabulous invention called the !
