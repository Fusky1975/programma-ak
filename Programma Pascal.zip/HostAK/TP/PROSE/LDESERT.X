4 1
< quit/Rretired_from the service of [, grumbling/Rcarping about the lack of pay.
< {grew }tired of working/Rfighting for [ with/Rfor no pay and handed_in/Rsubmitted > resignation.
< left [ to find employment/Radventure elsewhere, hoping to find  more_consistent/Rbetter source of income.
< could not {be persuaded to }stay {in the service of [ }without {getting > back }pay, {and }so < left [ to answer the {high }call of adventure.
