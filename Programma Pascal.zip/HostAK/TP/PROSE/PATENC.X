4 1
< was ambushed/Rchased, tied_up/Rpinned_down and severely_beaten/Rbloodied_up by wild-eyed_soldiers/Rangry_vigilantes.< {finally }escaped/Rbroke_free.a King's/RRoyal Ranger/RMarshal tracked_<2_down/Rcaught_up_with_<2.
< was stopped/Rspotted by a {local }patrol/Rband_of_militia.Their commanding officer/Rcaptain suspiciously/Rthreateningly challenged <2.
< was challenged/Rconfronted by a Royal_bounty_hunter/Rlocal_sheriff who apparently/Revidently thought/Rbelieved < was a spy/Rwanted_criminal.
< was badgered/Raccosted by  {drunken/Rboorish }officer/Rrogue who insulted/Rridiculed the respected/Rproud name_of_</RKingdom_of_.< killed/Rslew him in a duel, but the rogue's older_brother/Rbest_friend was a marshal/Rcolonel, and he came after <2!
