3 1
but after searching {fruitlessly }for {half }an hour, < failed to find any treasure{ of significant/Rhigh value}.
< {patiently/Rcarefully }searched the {entire }area, but {< }could not find any {valuable }treasure and departed/Rleft in {total }frustration.
< had {high }hopes of hauling/Rcarting away  {great/Rvaluable }hoard/Rtreasure.But {any amount of }searching could not reveal/Runcover treasure of any {measureable/Rappreciable }value/Rworth.
