5 1
< approached/Rinvestigated the &, intending/Rmeaning to root_out/Runcover its mysteries/Sdark_secrets.
< searched/Rapproached the & with every/Rthe intention of overcoming/Rprevailing_over it and whatever {vile }guardian {beast }lay within{ it}.
< unsheathed/Rgirded > weapon and entered the & warily/Rcautiously.
< downed/Rtook  {deep/Rlarge, }nervous draught/Rgulp from > flask/Rbottle of {old }vodka/Rscotch, and entered/Rapproached the &.
< gathered > courage {and > wits }and {cautiously/Rnervously }entered the &.
