3 1
the Shadow Sword transferred/Rconducted the {lost }life energy/Ressence to <2 and > hit points rose/Rjumped {back up }to #.
the Shadow Sword sucked_in/Rdrained_away the life energy/Ressence lost by [ and > hit points rose/Rjumped {back up }to #.
the Shadow Sword {gleefully/Rgreedily }inhaled/Rsucked_in ['s life energy/Ressence and imbued/Rinfused <2 with enough/Rsufficient energy/Rwarmth to raise > hit points to #.
