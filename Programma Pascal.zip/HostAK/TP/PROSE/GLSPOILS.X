3 1
< grabbed/Rtook the \{ from ] hoard/Rtreasure}.
< discovered/Rfound the \.
< rummaged/Rsearched through ['s belongings/Rpossessions and took/Rfound the \.
