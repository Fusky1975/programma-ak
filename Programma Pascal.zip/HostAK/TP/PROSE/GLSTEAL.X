4 1
< {expertly }pickpocketed/Rrobbed_him_of ] \.
< {skillfully }stole the \ belonging_to/Rowned_by [.
< {greedily }pilfered ] \.
[1 lost ] \ to > stealthy/Rdexterous fingers.
