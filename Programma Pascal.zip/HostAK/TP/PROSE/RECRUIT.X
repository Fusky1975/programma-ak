4 1
< recruited/Rlevied = from among the people/Rpopulation of @, to serve under [.
< levied/Renlisted = in @ to serve [.
< announced  plea/Rcall for volunteers/Rrecruits in @ and was able to form/Renlist = to fight for [.
< enlisted/Rrecruited enough men in @ to create/Rform = for the army of [.
