4 1
< tried to sneak by [, but was seen/Rdetected at
despite > {great/Rremarkable }caution/Rstealth, < was detected/Rperceived by [ {before anything/Rany_treasure could be stolen/Rtaken }and engaged at
< stole quietly/Rsilently up to the treasure of [, but unfortunately < was noticed/Rseen.< had to encounter [ at
< hoped/Rtried to steal/Rtake the {great/Rvaluable }treasures of [ {without being noticed/Rseen, }but [1 spotted/Rnoticed < at
