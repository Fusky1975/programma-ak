3 1
 could not stop their steady/Rdetermined advance.
 fought courageously/Rbravely, but was steadily pushed back.
 could not stand_their_ground/Rhold_the_line and executed/Rconducted a_fighting/Ran_orderly retreat.
