3 1
 steadily/Rstout-heartedly advanced against them.
 {determinedly }plowed into their opponents.
 aggressively/Rquickly knifed into them.

