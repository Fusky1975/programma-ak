4 1
< attempted/Rtried to flee from the fight/Rcombat, but [1 {cleverly }cornered <2.
< turned {around so as }to flee from [, but found/Rsaw that > path_of_retreat/Rretreat_route had been magically blocked by  wall/Rcurtain of fire/Rshimmering_force.
< ran/Sswam_away from the melee/Rcombat, but slipped_and_fell/Sscraped_against_a_submerged_rock.< injured > leg/Rankle and could not escape/Rget_away!
desiring_only/RHoping to escape from > vicious/Rterrible opponent/Rfoe, < ran/Sswam like the_wind/Sa_crazed_shark.But < was too_tired/Rexhausted and{, even with great effort,} could not gain {any }ground/Sdistance on [.
