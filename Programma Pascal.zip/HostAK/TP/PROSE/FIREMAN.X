4 1
< told/Rinformed [ that [1 was no longer  useful employee/Rasset to , and relieved [ of ] position/Rduties.
< canned/Rfired [, saying_to/Rtelling [ that [1 "was no longer worth ] salt".
< relieved [ of ] responsibilities/Rduties and released [ into private life.
< fired/Rblackballed [ and told [ to find employment/Rwork elsewhere.
