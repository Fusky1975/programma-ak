2 1
< urged/Rasked [3 to improve {diplomatic }relations with > {great }Kingdom, speaking at_length/Reloquently of the great advantages/Rbenefits of such  agreement.{After some deliberation, }the offer/Rproposal was wisely/Rgraciously accepted by [.
< {formally }proposed  treaty with [{'s Kingdom}, and the {magnanimous }offer was {graciously and wisely }accepted.{May the treaty between < and [3 last forever/Rfor_eternity!}
