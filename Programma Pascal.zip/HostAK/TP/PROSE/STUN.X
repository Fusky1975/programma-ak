6 1
< stood/Sstayed stunned, unable to regain > senses/Rbalance.
stunned, < could only shake > head in bewilderment/Rperplexity.
< was stunned and staggered/Sflopped around at_random/Runsteadily.
< stood dazed{ and bewildered/Rperplexed}, stunned out of > wits/Rmind.
< could do nothing {but stand/Shover and stare }in > stunned state.
in > {pathetic }stunned state, < could not decide/Rdetermine what to do{ about > predicament}.
