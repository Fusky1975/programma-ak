4 1
< stooped/Rkneeled to recover/Rcollect the {personal }belongings of [.
< took the bag/Rpack [1 had been_carrying/Rborne.
< retrieved/Rtook the treasure [1 was carrying/Rbearing.
< stripped/Rrelieved [ of {all of }] treasure.
