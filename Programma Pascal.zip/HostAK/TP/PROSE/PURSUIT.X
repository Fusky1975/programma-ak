4 1
= pursued the enemy and
= gave chase and
= overtook the enemy {in their headlong/Rpanicky retreat }and
= chased after the enemy and
