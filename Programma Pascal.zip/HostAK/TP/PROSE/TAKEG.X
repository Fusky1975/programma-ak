3 1
< stole # gold from [.
< stole/Rpilfered # gold from ] treasure chest.
< robbed [ of # gold{ while [1 was sleeping}.
