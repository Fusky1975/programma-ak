5 1
< left = with [ in @.
< dropped off = in @ for [.
< ordered/Rdirected = to remain {encamped/Sanchored }in @ with [.
< instructed/Rcommanded = to stay_behind/Rremain in @ with [.
< transferred/Rassigned = to [ in @.
