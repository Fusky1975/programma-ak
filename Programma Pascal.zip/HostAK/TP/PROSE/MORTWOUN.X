4 1
[1 was mortally/Rfatally wounded.
[1 fell/Ssank_down, fatally/Rmortally injured.
[1 dropped/Ssank to the ground/Sbottom, fatally/Rmortally pierced.
[1 staggered/Sflailed_about, stunned by {the force of }the deadly/Rmortal blow.
