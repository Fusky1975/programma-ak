4 1
the defenders turned_back/Rdefeated <'s forces and drove/Schased them out of @.
<'s armies/Sfleets were beaten/Rdefeated and pushed/Schased out of @.
the attacking Kingdom was defeated {and turned back }in its attempt/Rmove to conquer/Rtake @.
{the host/Sarmada of }the attacking Kingdom was defeated and driven/Rforced out of @.
