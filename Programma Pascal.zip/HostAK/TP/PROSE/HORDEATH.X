2 1
and so it was/Rcame_to_pass that < met > unseemly/Rtragic end.
thus did < {finally }die,  brave_end/Rdefiant_death by any standard.
