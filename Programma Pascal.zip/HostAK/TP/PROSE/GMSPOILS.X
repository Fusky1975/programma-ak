1 1
< {walked/Sswam over to  pile/Rmound of treasure and }bagged/Rsecured the \.
< took/Rstripped the \ from the corpse/Rremains of [.
the \ lay nearby, and < picked_up/Rretrieved the treasure.
