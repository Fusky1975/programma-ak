6 1
to the * lies  $W ` province/Rarea called/Rnamed @ , populated by .It is ruled by [3.
looking/Rturning to the *, one can_see/Respies  $W ` area, which is known as @ .It is populated by  and [3 rules there.
* of here is @ ,  $W ` province/Rarea owned/Rruled by [3, where  dwell.
to the * there lies/Ris  ` province known as @ ,  $W land/Sarea of  where [3 rules/Rreigns.
viewing the *ern horizon, a_man/Rone can see  $W ` province called/Rknown_as @ .It is said that [3 reigns/Ris_the_ruler there.It is known to be occupied/Rpopulated by .
* of here lies the $W province of @ , ruled by [3.It is said/Rknown to be  ` province inhabited/Roccupied by .
