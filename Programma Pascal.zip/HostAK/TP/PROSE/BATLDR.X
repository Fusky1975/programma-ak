5 1
<3 led > armies/Snavies {boldly/Rcourageously }into the battle/Rfray.
<3 stood ready/Rdeterminedly at the head of > thousands/Sships.
<3 commanded/Rled a_host/San_armada of loyal_soldiers/Sfighting_sail{ into the battle}.
standing at_the_ready/Rtall with > warriors/Sships was <3.
<3 marched/Ssailed with > loyal troops/Ssquadrons, eyes/Rjaws set in grim/Rterrible determination/Rresolution.
