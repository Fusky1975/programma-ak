4 1
 lay  icy wasteland/Rexpanse which extends as far as the_eye/Ra_man can see.
 is  {forbidding }land/Rmass of glaciers/Rice which {seemingly/Rapparently }has no end.
, the landscape is marred/Rscarred by a_broad/Ran_unending expanse of {frigid }ice.
 icy wastes stretch/Rextend to meet/Rjoin the {far }horizon.
