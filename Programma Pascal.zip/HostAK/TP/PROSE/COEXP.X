6 1
< observed the area/Rterrain while we were on_the_march/Scruising_forward and now #% of @ has been explored.
< found some time to explore/Rinvestigate @ while marching/Ssailing_ahead.#% of it has been explored to date.
< marched_along/Snavigated some previously/Rheretofore unexplored paths/Schannels, raising our exploration knowledge to #%.
while on_the_march/Son_the_move, < took  interest in the terrain/Sislands of @, exploring some unknown areas/Rterritory.We have now explored #% of @.
< made some side trips while marching/Ssailing through @ and now #% of @ has been explored.
< marched/Ssailed along  unusual/Runconventional route/Scourse through @ and raised our {level of }exploration there to #%.
