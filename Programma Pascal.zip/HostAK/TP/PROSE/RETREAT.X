6 1
< retreated/Rfell_back to  with {the_remnants/Rwhat_remained of }> forces.
< retreated/Rwithdrew {with > command/Rforces }to .
< made/Rset_out for {the safety of } with > motley army/SFleet.
< pulled/Rfell back to  with{ the_remnants/Rwhat_was_left of} > command.
< withdrew/Rretreated to  with > defeated/Rvanquished warriors/Sships.
< retired/Rwithdrew to , beaten/Rdefeated but not broken/Rdiscouraged.
