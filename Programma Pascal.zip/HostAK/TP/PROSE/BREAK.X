2 1
< informed/Rnotified [3 that our {former }friendship/Ramicable_relationship has been rendered worthless/Rmeaningless by ['s outrageous/Rdespicable provocations.
[3 has been notified/Rinformed by < that ] cooperation has become expendable/Runnecessary, and thus/Rtherefore our formerly/Rpreviously friendly/Ramicable relations are now severed/Rbroken.
