3 1
 were cut/Rmowed down like cattle/Rsheep.
 were sliced and diced like  knife/Rblade cutting through butter/Rlard.
 had their booties/Rswords kicked {all the way }up their throats.
