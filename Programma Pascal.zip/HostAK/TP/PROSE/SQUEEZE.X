6 1
< clenched > fist{ tightly}, squeezing the intestines/Rinnards of [
< wrapped/Rcurled > phantasmal hand around ['s heart/Rliver and squeezed it{ mercilessly/Rviciously}
< brought > hands together and pulled/Ryanked them apart in  ripping/Rtearing motion/Rgesture, provoking  {terrible/Rblood-curdling }squeal {of pain }from [
< grabbed/Rseized ] spine/Rneck with unseen/Rphantasmal hands and shook it{ violently/Rruthlessly}
<'s invisible/Runseen fingers pierced the eyes/Rforehead of [ and clawed_at/Rdug_into ] brain
the invisible/Runseen hands of < grasped/Rgrabbed ] lungs/Rthroat, choking/Rsqueezing{ the breath/Rlife out of} [
