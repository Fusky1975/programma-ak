5 1
< tried to_talk/Rtalking to [, but [1 reacted angrily/Rnervously and bounded/Sswam forward.
< spoke_to/Rapproached [, hoping to initiate/Rstart  conversation, but [1 belligerently charged/Radvanced.
< spoke kindly/Rin_a_friendly_manner to [, but was attacked/Rcharged by [.
< hailed/Rgreeted [ with words of friendship, but [1 reacted/Rresponded with  ferocious/Rbelligerent charge.
< approached [ and spoke/Rspake to [ with friendly/Rkindly words of greeting.However,/RBut [1 charged forward/Rtowards_<2{ angrily/Rmenacingly}.
