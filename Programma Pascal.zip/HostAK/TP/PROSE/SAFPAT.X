3 1
but when < was taken to the judge/Rlocal_sheriff, < showed_him/Rheld_forth the official_seal/Rinsignia of , and was let_go/Rmerely_run_out_of_town.
but he was easily/Rjust dazzled/Rawed by <'s {fantastic/Rwonderful }tales of > heroism/Radventures.he {respectfully/Radmiringly }bowed_before/Rsaluted <2 and {then }marched_away/Rdeparted.
but < wasn't_listed_as_/Rwas_obviously_no {wanted/Rrenegade }outlaw/Rspy, and_that_got_<2/Rso_<_got off_the_hook/Rout_of_trouble.
