1 1
< {waved/Rheld_forth  white flag/Rhandkerchief and }hailed/Rshouted_out_to [ with {friendly }words of greeting.
