6 1
< {stealthily }crept_up_on/Rstole_towards ['s treasure, hoping/Rwishing to steal  great treasure.
< {furtively }stole/Rmoved towards ['s treasure, visions of wealth/Rgreat_treasure dancing before > eyes.
< searched {soundlessly }for ] treasure.> greedy/Rnervous fingers twitched in anticipation when < saw the chest/Rvault.
the eyes of < brightened {greedily }when they alighted_on/Rsaw the treasure trove/Rchest of [.
< {quietly }searched for the treasure of [.Finally < espied/Rfound  hidden/Rconcealed bag/Rchest, and  {black }tide of greed/Ravarice welled/Rgushed up out of > soul/Rheart{ and filled > dry throat}.
< crept/Rglided {stealthily }into {what I thought was }the treasure room of [, hands tingling/Rtwitching with anticipation/Rexcitement.
