6 1
= proved its mettle/Rvalor in/Rduring the battle/Rfight and we now rate/Rrank it   unit.
= was greatly buoyed/Rinspired by the victory/Rexciting_battle.We now rate/Rdesignate it  {proud } unit.
= was_tested/Rfought_determinedly during the battle and came through with flying_colors/Ra_good_effort.We can now call/Rrank it   unit.
we could not have been more_pleased/Rbetter_satisfied with the elan/Rfighting_spirit of =, and we have elevated/Rraised its rating/Rranking to .
the fun_head-bashing/Rmayhem_wreaked by = in/Rduring the battle has raised/Relevated the spirits/Rmorale of its warriors/Ssailors, and {all agree that }it has achieved/Rrisen_to  status/Rquality.
we can {now }raise the rating/Rranking of = to , its officers/Rmen having displayed {especially }great/Radmirable elan/Rcourage.
