6 1
< grew bored_with/Rtired_of {the scenery in }@ and departed/Rleft for .
< awoke/Rarose one morning/Rday with  desire/Rwhim to see , and so left {from }@ to travel/Rjourney to that province.
< heard that  old buddy/Rfriend was trapping_furs/Spearl-diving in  and left @ to see > old acquaintance/Rfriend.
< got/Rfell into trouble with the_law/Ra_sheriff in @ and escaped {imprisonment/Ra_posse }by riding/Ssailing away/Roff to .
< heard stories/Rtales of excellent/Rfine hunting/Sfishing in  and left @ to have_some_fun/Rtake_a_vacation there.
< left @ to attend/Rpreside_over  reunion of > old regiment/Rbattalion in .
