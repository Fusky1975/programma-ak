6 1
<3 sent/Rordered  invasion force into the {adjacent }` province of @, owned by [3.
a {great }host/Sfleet of {savage/Smighty }warriors/Sships carried the banner of <3 into the ` province of @, ruled/Rheld by [3.
a conquering_horde/Sfleet owing their allegiance to <3 invaded the province of @,  ` area owned/Rruled by [3.
an_army/Sa_fleet coming_from/Rsent_by the empire of <3 invaded/Rentered @, hoping to conquer/Rsubjugate that province owned/Rruled by [3 and made up of great/Rextensive `s.
<3's minions/Rforces initiated  campaign of conquest directed_at/Rin @,  ` province owing {its }allegiance to [3.
soldiers/Sships bearing/Rcarrying the battle-standards of the <ian empire marched_on/Scruised_into the ` province of @,  land garrisoned/Rdefended by the forces/Rsoldiers of [3.
