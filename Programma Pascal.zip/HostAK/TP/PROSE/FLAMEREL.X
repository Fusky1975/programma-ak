3 1
the Flaming Scimitar released/Rburped  fireball which imploded inside [{, bursting ] body into shreds}.
the magic of the Flaming Scimitar was triggered/Ractivated by the impact/Rblow and  {mighty }fireball imploded inside {the stomach of }[, blowing [ to bits.
the Flaming Scimitar ignited/Rcombusted  imploding fireball in the innards/Rbelly of [, splattering/Rshowering ] guts/Rintestines all over in  sordid/Rhorrible puke-fest/Rscene.
