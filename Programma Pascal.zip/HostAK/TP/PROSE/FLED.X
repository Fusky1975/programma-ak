3 1
< stuck > tail/Stailfin between > legs and fled from [ as fast as > legs could carry <2!
< ran/Sswam shamelessly/Rfuriously and fled from the combat/Rencounter.
{deciding/Rrealizing that discretion is often/Rsometimes the better part of valor, }< fled {unceremoniously }from the {dangerous }combat/Rscene.
