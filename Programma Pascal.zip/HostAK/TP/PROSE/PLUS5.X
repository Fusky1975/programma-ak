3 1
 mowed/Rcut them down like weeds/Rbeanstalks.
 squashed/Rsmashed them like rotten tomatoes/Roranges.
 crushed/Rsmashed their heads/Rskulls as if they were eggshells/Reggplants.
