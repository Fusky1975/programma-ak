4 1
{But }then the tide {of battle }turned/Rreversed.
But the battle/Raffair was not yet over/Rdone.
But might/Rwould victory_yet_be_snatched_from_the_jaws_of_defeat/Rdefeat_now_be_snatched_from_the_jaws_of_victory?
The {ongoing }battle/Rstruggle went_on/Rblazed with a {terrible/Rmurderous }fury/Rfrenzy.
