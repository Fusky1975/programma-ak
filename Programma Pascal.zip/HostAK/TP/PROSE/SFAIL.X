4 1
< attempted/Rtried  ~ spell, but bungled/Rbotched it.
< failed in > {ineffectual }attempt to cast  ~ spell.
<'s attempted cast of the ~ spell was_unsuccessful/Rdidn't_work.
<'s ~ spell backfired/Rfizzled and < wound_up/Rwas_left {with > face }covered with psycho-kinetic slime/Rgoo.
