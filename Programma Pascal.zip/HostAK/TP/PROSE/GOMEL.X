3 1
< charged/Sdarted into the_melee/Rmelee_range.
< rushed/Sswam {eagerly/Rlustily }into melee combat.
< closed to melee range, seething/Rfilled with {uncontrolled/Rmaniacal }blood-lust.
