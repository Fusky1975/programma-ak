4 1
< practiced well/Renthusiastically and improved > skill/Rability in ^.
< practiced {hard/Rdiligently }for many_weeks/Rmonths and > skill in ^ increased.
< {studied and }practiced > ^ and > skill in ^ went up.
< {rehearsed and }practiced > ^ and improved substantially/Rnoticeably.
