4 1
< looked {down }with satisfaction/Rpride at the remains/Rcorpse of [.
< shifted/Rturned > attention to the treasure/Rhoard of [.
< sacked/Rcleared_out the treasure {chest/Rroom }of [.
< took/Rappropriated the treasure {chest/Rtrove }that once belonged to [.
