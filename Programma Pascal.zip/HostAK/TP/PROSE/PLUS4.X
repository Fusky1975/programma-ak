3 1
 beat/Rtrampled them down as if they were midgets/Rinvalids.
 easily/Rviciously crushed/Rdestroyed them.
 lost/Rwasted no time in smashing/Rcrushing their formation/Rlines.
