4 1
<'s forces conquered/Rtook @ without any major battles/Rengagements.
<'s armies/Snaval_forces took control/Rpossession of @ practically uncontested.
@ was conquered/Roverrun{ and occupied} by <'s host/Sfleet.
<'s forces encountered/Rexperienced little resistance/Ropposition in @ and < there established our rule/Rreign.
