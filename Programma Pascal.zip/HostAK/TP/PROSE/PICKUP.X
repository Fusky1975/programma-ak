4 1
< picked up = in @.
in @, < ordered/Rcommanded = to join forces with > army/Snavy.
< strengthened/Raugmented > forces in @ with =.
< added = to > host/Sfleet in @.
