5 1
[ was of some slight help/Rassistance in the battle/Rcontest.
[ increased/Raugmented the strength of = considerably/Rsignificantly.
It is_safe_to_say/Rappeared that [ greatly/Rpowerfully magnified/Renhanced the efforts/Rpower of =.
the presence/Raid of [ was almost/Rjust like having another army!
[ more_than_doubled/Ralmost_tripled the strength of =!
