3 1
midsummer's day/Rnight passed/Rcame_and_went and {a_hot/Ra_pleasant }late summer came/Rarrived.
in late summer,_
with the advent/Rcoming of the late summer season{,}_
