6 1
< explored @ {well }and now #% of it has been explored.
< travelled/Ssailed throughout/Rabout @, exploring its features/SIslands.After > {exploration }efforts, #% of it has been explored to date.
< roamed/Scruised through/Raround_in @, exploring the terrain/Schannels there, and now #% of it has been explored.
< explored @, taking careful/Rprecise notes of the terrain/Sislands and features, and now #% of it has been explored.
< wandered/Scruised freely/Rfar_and_wide in/Rabout @, exploring/Runcovering its secrets/Rmysteries, and raising our exploration level in @ to #%.
< explored/Snavigated @ carefully/Rthoroughly, leaving no stone_unturned/Sisland_uncharted, and our exploration level there has risen to #%.
