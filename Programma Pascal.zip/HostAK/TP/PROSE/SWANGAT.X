11 1
< {circled right/Rleft and }{angrily/Rviolently }assailed/Rattacked [
{undaunted/Rshowing_no_fear, }< {moved in/Rcloser and }$S [
< {whirled around/Rabout and }{daringly/Raudaciously }$S [
< {summoned all > will/Rstrength and bravely/Rdesperately }$S > {fearsome/Rvaunted }enemy/Rnemesis
< {feinted/Rfaked in_one_direction/Rone_way, then crossed/Rswitched over and }{treacherously/Rviciously }$S [
< {acrobatically/Rflamboyantly flipped/Rvaulted over [ and }{deftly/Rcontemptuously }$S [
< {feigned/Rpretended_to retreat/Rpanic, then pivoted/Rwhirled and }{treacherously/Rarrogantly }$S [
{with amazing/Rsurprising speed/Rquickness, }< {immediately/Renergetically }$S [
{seeking/Rhoping to exploit/Rtake_advantage_of  gap/Rweak_point in ['s defenses/Rprotection, }< {skillfully/Rdeftly }$S [
{< maneuvered/Rshifted_over for/Rto a better/Rgood attacking/Rdefensive position/Rvantage.then }< $S [{ with all > might/Rstrength}
{< forced/Rturned back/Raway [ with > aggressive/Rspirited assault/Rtactics.}< then $S [{ with terrific/Rmaximum force/Rstrength}