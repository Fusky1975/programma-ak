4 1
< searched {all }throughout @ for {some sign of }[.
< looked {around }for [ in @.
< searched/Rlooked for [ in the bars/Rtaverns and whorehouses/Rinns of @.
< scouted {around }for [ in {the province of }@.
