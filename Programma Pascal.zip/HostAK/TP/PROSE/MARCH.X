3 1
< marched_on/Ssailed_into @  with > {formidable }command/Rforces.
< {boldly }marched/Ssailed > forces/Rcommand into @ .
< moved into @  with > {redoubtable/Rhigh-spirited }army/SFleet.
