6 1
= fought/Rbattled hard/Raggressively, but panicked/Rwent_on_an_uncontrollable_rampage and considerably/Rsomewhat damaged/Rhurt themselves/Rtheir_allies!
= became confused/Rdisoriented {by/Rin the din/Rmayhem of battle }and did_not/Rdidn't fight/Rperform well/Rsatisfactorily.
= fought satisfactorily/Radequately, if/Rthough {somewhat }uninspiredly/Rsluggishly.
= acquitted/Rconducted themselves well/Rmost_satisfactorily{ in battle}.
= fought/Rattacked with  admirable/Rcommendable zeal/Rbattle-lust.
= attacked/Rassaulted_them ferociously/Rrecklessly and trampled/Rknocked down/Rover their enemies/Ropponents{ left and right}.
