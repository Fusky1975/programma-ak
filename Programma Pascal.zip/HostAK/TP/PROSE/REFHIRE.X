3 1
[1 refused to join/Rassociate with , citing/Rtelling_of  {long-held }clan/Rfamily enmity/Rfeud with 's alignment.
[1 rebuffed/Rrejected <'s offer of employment, disdaining/Rridiculing 's alignment and saying "That  is the most infamous/Rtyrannical ruler/Rdespot in the land/Rworld!"
[1 turned down {the offer of }employment, expressing/Rtelling_of ] disgust/Rdisdain for 's alignment and criticizing/Rberating  for "Holding/R"Keeping  palace court staffed/Rfilled with buffoons/Rgoons{ and slimy/Robsequious weasels/Rrodents}!"
