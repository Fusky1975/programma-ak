3 1
the {sultry/Rhot days of }summer surrendered_to/Rmellowed_into {a_colorful/Rthe }fall.
in/Rduring fall,_
with the advent/Rcoming of the fall season{,}_
