6 1
weaving/RChanting > silver/Rartful words of magic into  mighty/Rgreat ~ spell, < waved/Rgestured_with > hands/Rarms
< incanted/Rchanted > mysterious/Rstrange words of magic and cast  ~ spell
gesturing_with/Rwaving > hands/Rarms, < orchestrated/Rjuxtaposed supernatural/Rotherworldly forces of magic, casting  ~ spell
raising/Rlifting > hands high in the air/Swaves, < cast  ~ spell
chanting/RUttering > words/Rsyllables of magic with breathless/Rtrained precision, < let go/Rfly  ~ spell
incanting/RCasting  ~ spell, < directed/Rchannelled glowing/Rscintillating, interlacing/Rwrithing strands of magic
