1 1
< prayed/Rsacrificed to the_Gods/Rthe_Demi-God_Aardbull {devoutly }for{ many/R12} months, and at_last/Rfinally the Hand/RMight of Heaven/Rthe_Most_High elevated/Rraised > Kingdom/Rrealm to the level/Rstatus of "Heavenly Empire of Great Peace!"
