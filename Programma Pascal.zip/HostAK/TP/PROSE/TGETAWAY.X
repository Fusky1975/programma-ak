3 1
but the treasure/Rwealth of [ was encased/Rcontained in thick steel/Rglass, and < could not find  way into the treasure.
< slid/Rstole up to the treasure {chest }of [, but could not pick/Ropen the lock and had to leave without any treasure.
< found {what seemed to be }the treasure of [, but after < had stolen/Rtaken it < examined/Rlooked_at it {more carefully }and discovered {to > chagrin/Rdismay }that it was just  cheap imitation/Rfake.
