6 1
the forces of < broke through {the lines of their enemy/Ropposition }and were victorious.
<'s armies/Ssquadrons vanquished/Rshattered the army/Sfleet opposing them with  final {determined }charge/Ssally.
the host/Sfleet of < {finally }broke/Rcrushed the army/Sfleet of ['s morale/Rfighting_spirit with one last{, great} push.
the battle ended victoriously/Rin_victory for the soldiers/Sships of < as they broke through {the lines }at  critical/Rcrucial moment.
having found  weak/Rvulnerable point/Rspot in the line of the host/Sarmada of [,  final savage/Rdetermined thrust/Rslashing_attack finished_off/Rdefeated their enemy/Ropponent and won the day/Rbattle for <2.
<'s great horde/Sarmada overwhelmed/Roverpowered the army/Sfleet of [ and took_the_field/Scleared_the_seas_of_their_squadrons, dispersing/Rscattering their enemies.
