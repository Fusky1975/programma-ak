4 1
< discovered/Rfound a{n interesting} feature in @:  &  inhabited/Roccupied by +.
< discovered/Rlocated  previously/Rheretofore unknown/Runheard_of &  in @, held/Rinhabited by +.
< was informed/Rtold by some peasants/Rsheepherders of  {perilous }feature in @{ previously unknown to us},  &  inhabited_by/Rwhere_dwells +.
< {also }found/Rdiscovered  &  in @, occupied/Rinhabited by +.
