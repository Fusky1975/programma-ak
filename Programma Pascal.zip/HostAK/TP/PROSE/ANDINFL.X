5 1
 and inflicted # damage points.
 and scorched/Rwalloped [ with # damage points.
 and damaged [, scoring/Rinflicting # damage points.
 and scored on [, inflicting/Rdoing # points of damage.
 and scored/Rinflicted # damage points on [.
