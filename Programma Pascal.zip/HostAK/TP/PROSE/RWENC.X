4 1
< was crossing_an_open_field/Sswimming_in_a_lagoon when [1 spotted <2 from a distance.
< was {unexpectedly }approached_by/Rfaced_with [.
[1 {suddenly/Runexpectedly }came_at/Rrushed_at <2 from_out_of_nowhere/Rlike_a_bolt_from_the_blue.
< encountered/Rwas_confronted_by [.