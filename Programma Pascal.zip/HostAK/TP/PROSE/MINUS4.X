3 1
 were beaten_down/Rtrampled_over like overripe/Roversized pumpkins/Rwatermelons.
 were easily/Reffortlessly overrun/Rbeaten by the enemy.
 were knocked out of the battle/Rfight by the enemy's ferocious/Rfanatical charge/Sattack.
