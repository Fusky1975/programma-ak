5 1
 and missed{ by_a_mile/Rbadly}.
 but [1 dodged/Revaded the blow/R.
 but >  whiffed/Sdarted {harmlessly }through the air/Smurky_water.
 but > aim was just/Rslightly off{ the mark}.
 and would have struck/Rhit [ if [1 hadn't ducked/Rsidestepped{ just then}.
