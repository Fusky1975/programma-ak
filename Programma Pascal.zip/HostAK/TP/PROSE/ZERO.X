6 1
 fought/Rbattled them to  standstill.
 fought/Rbattled them tooth and nail, neither side/Sfleet willing to give ground/Sup.
 could neither gain the upper_hand/Radvantage nor could the enemy make any progress/Rheadway.
 the fighting here proved/Rwas indecisive/Rinconclusive.
 neither army/Sfleet could gain  advantage/Redge over the other.
 the two armies/Runits slugged/Rfought it out in  evenly/Rwell matched{, indecisive/Rinconclusive} contest/Rbattle.
