Standard of Command
Register of March Orders
Conch of Seamanship
Longbow of Accuracy
Bracelets of Swordsmanship
Holy Grail
Amulet of Orgoth
Crucible of Elements
Helm of Psychic Projection
Spectral Crystal
Everlasting Mistletoe
Cloak of Stealth
Crystal of Direction
X-Ray Spyglass
Quaagoth's Portable Laboratory
Rod of Resurrection
Staff of Sea Mastery
Tome of Blessings
Golden Cross
Horn of Ghastly Revenge
Needles of the Black Mage
Obsidian Vermin
Glove of Death
Feathers of Rain-Dancing
Bag of Dust-Devil Seeds
Stone of Shaking
Wand of Fire
Cologne of Charming
Silver Horn of Oratory
Crystal of Seeing
Antennae of Psychic Blasting
Projector of Scenic Illusions
Reflector of Armies
Dome of Opacity
Ring of Invisibility
Holy Sword
Shadow Sword
Flaming Scimitar
Psychic Flail
Invisible Sword
Sword Excalibur
Bow of the Elven Kings
Axe of the Dwarven Lords
Scimitar of Orc Mastery
Shrunken-Head Amulet
The True Cross
Orb of Elemental Stability
Helm of Psychic Dampening
Crystal of True Seeing
Crown of Dragon Command
Feather of the Great Eagle
Horn of Neptune
Hannibal's Grimoire
Manual of Speedy Marches
Ship's Log of Nautilus III
Manual of Archery
Handbook of Swordsmanship
Scriptures of Holy Thoughts
Necronomicon
Periodic Table of Elements
Codex of Mental Prowess
Libram of Illusions
Book of Druidic Incantations
Black Notebook of Thievery
Journal of Many Wanderings
Manual of Spying
Library of Science
Large Hoard of Gold
Huge Hoard of Gold
Fabulous Hoard of Gold
Quest of the Cosmic Snowball
Cosmic Snowball
Completed Snowball Quest
Sapphire Ring Quest
Completed Ring Quest
Lucky Penny Quest
Completed Lucky-Penny Quest
Quest of the Gods
Fulfilled Quest of the Gods
Mermaid-Charming Amulet Quest
Fulfilled Mermaid Quest
Riddle of the Hunted Monster
Riddle of the Refused
Riddle of the Dread Weakness
Riddle of the Eyless Weeper
Riddle of the Wingless Bird
Riddle of the Woman's Tears
Riddle of the Legs
Quest of Revenge
Fulfilled Quest of Revenge
Unsigned Diabolical Contract
Signed Diabolical Contract
no treasure
unknown treasure
unknown treasure
unknown treasure
unknown treasure
unknown treasure
unknown treasure
unknown treasure
unknown treasure
unknown treasure
unknown treasure
unknown treasure
unknown treasure
unknown treasure
unknown treasure
unknown treasure
unknown treasure
unknown treasure
unknown treasure
unknown treasure
unknown treasure
unknown treasure
unknown treasure
unknown treasure
unknown treasure
unknown treasure
unknown treasure
unknown treasure
unknown treasure
unknown treasure
unknown treasure
