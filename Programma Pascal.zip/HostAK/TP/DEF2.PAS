PROCEDURE WWEKW;
BEGIN WRITELN; WEK; WRITELN; END;

FUNCTION Stay_End(ldr: integer): integer;
BEGIN
  IF ((modprog_vers >= 18) and (ldr = valhero)) THEN
      Stay_End:= Min(4,(gameturn-1) DIV 2)
    ELSE Stay_End:= 4;
 END;

PROCEDURE WS;
BEGIN  IF not modprog THEN Write(miscfile,' '); END;

PROCEDURE WrCr;
BEGIN
  WRITELN(miscfile);
  writc:= 1;
 END;

PROCEDURE WrS(s: Str80);
VAR si: integer;
BEGIN
  si:= 1;
  WHILE si <= Length(s) DO BEGIN
    WRITE(miscfile,s[si]);
    Inc(writc);
    IF not modprog THEN IF writc >= 75 THEN IF s[si] = ' ' THEN BEGIN  WrCr; WS; END;
    Inc(si);
   END;
 END;

PROCEDURE WrN(n: longint);
VAR s: Str80;
BEGIN
  Str(n,s); s:= Concat(s,' ');
  WrS(s);
 END;

PROCEDURE GhostW;
BEGIN
  {$IFDEF Moderator}
  WrCr;
  {$ENDIF}
 END;

PROCEDURE W_List(tacptr: desigptr; mode: byte);
BEGIN
{  WRITE('WL');}
  WHILE tacptr <> Nil DO BEGIN
{    WRITE(tacptr^.dn);}
    WrN(tacptr^.dn);
    IF mode = AT_Bytes THEN
      totspent:= totspent +ATCost(army(tacptr^.dn));
    IF mode = Tac_Bytes THEN CASE maneuver(tacptr^.dn) OF
      CCast,CGive,CUse_MI: WrN(tacptr^.dobj);
      CSay: BEGIN
        WrCr; WS;
        WrS(tacptr^.sayeth^); WrCr; WS;
{$IFNDEF Moderator} WrCr; WS; {$ENDIF}
       END;
     END;
    GhostW;
    tacptr:= tacptr^.nextbyte;
   END;
  WrS('-1 '); GhostW;
{  WRITE('x');}
 END;

PROCEDURE W_HPlan(VAR lnplan: planrec; old: boolean);
VAR m: actionrange;
    tl: integer;
    trt: treasure;

PROCEDURE Write_More(sp: spell);
BEGIN
  WITH lnplan DO CASE sp OF
    Illus_Terrain: BEGIN WrN(pexrec[m].n1); GhostW; END;
    Charm,Resurrection: IF m < 4 THEN W_HPLan(pexrec[m].newchptr^,old);
   END;
 END;

BEGIN
  WITH lnplan DO BEGIN

{    WRITELN('Action Plans: '); WS; }

    {$IFDEF Moderator}
    WrS('Action Plans: '); WrCr;
    {$ELSE}
    WrS('AP: ');
    {$ENDIF}

{    WRITELN(planstart,' ',planend,' ');}

    WrN(planstart); WrN(planend); GhostW;
    IF not old THEN BEGIN

{      WRITELN('Special Plan:');}

      WrS('SP: '); GhostW;
      W_List(septr,Tac_Bytes);
     END;
    IF planstart > -1 THEN
      FOR m:= planstart TO planend DO BEGIN
        {$IFNDEF Moderator}
        IF m = 2 THEN BEGIN WrCr; WS; END;
        {$ENDIF}
        tl:= lextra[m];

{        WRITELN('P',m,': ');}

        WrS('P'); WrN(m); WrS(': '); GhostW;

{        WRITELN(ord(lactions[m]),' ',lobjects[m],' ',tl,
          ' (',actab[lactions[m]],'-',lobjects[m],')');
}
        WrN(ord(lactions[m])); WrN(lobjects[m]); WrN(tl); GhostW;
        CASE lactions[m] OF
          Search,Challenge,Pursue: W_List(pexrec[m].firstbyte,Tac_Bytes);
          Cast: Write_More(spell(lobjects[m]));
          Use_MI: BEGIN
            trt:= treaslist[lobjects[m]];
            IF ((trt >= wcp) and (trt <= pic)) THEN
              Write_More(spell(ord(trt)-ord(wcp)));
           END;
          Trade: BEGIN WrN(pexrec[m].n1); GhostW; END;
          Hire: BEGIN
            totspent:= totspent+lextra[m];
            IF m < 4 THEN W_HPlan(pexrec[m].newchptr^,old);
           END;
          Disband,Leave,Pick_Up: W_List(pexrec[m].firstbyte,AN_Bytes);
          Recruit: W_List(pexrec[m].firstbyte,AT_Bytes);
         END;
       END;
   END;
  WrCr; WS;
 END;

PROCEDURE Bit_Write(wb: byte);
BEGIN  WRITE(miscfile,chr(32+(wb Shr 4)),chr(32+(wb and 15))); END;

PROCEDURE Write_ShieldVars(VAR shield: shieldrec);
VAR scol,srow: integer;
BEGIN
  WITH shield DO BEGIN
    FOR scol:= 0 TO 3 DO BEGIN
      WRITE(miscfile,' H');
      FOR srow:= 0 TO 29 DO IF ((srow <> 14) and (srow <> 15)) THEN
        Bit_WRITE(shieldarr[scol,srow]);
      WRITELN(miscfile,',');
     END;
    WRITE(miscfile,' C');
    FOR scol:= 0 TO 1 DO FOR srow:= 0 TO 1 DO Bit_WRITE(qtr_bc[scol,srow]);
    FOR scol:= 0 TO 1 DO FOR srow:= 0 TO 1 DO Bit_WRITE(qtr_fc[scol,srow]);
    WRITELN(miscfile,',');
    WRITELN(miscfile,' B',chr(32+ord(bottom_forecolor)),'                ,');
    WRITELN(miscfile,' M',motto,'.');
   END;
 END;

FUNCTION Clear_Shield(VAR test_shield: shieldrec): boolean;
VAR row,col: integer;
BEGIN
  Clear_Shield:= true;
  FOR col:= 0 TO 3 DO FOR row:= 0 TO 29 DO IF ((row < 14) or (row > 15)) THEN
    IF test_shield.shieldarr[col,row] <> 0 THEN Clear_Shield:= false;
 END;

{$IFDEF More_Entry}
{$IFNDEF Moderator}
PROCEDURE Clear_Message;
BEGIN
  GOTOXY(1,25);
  WRITE('               ');
 END;

PROCEDURE CLI; inline($FA);
PROCEDURE STI; inline($FB);

PROCEDURE Prep_Card;
BEGIN
  CLI;
  PortW[$3C4]:= $100;
  PortW[$3C4]:= $402;
  PortW[$3C4]:= $704;
  PortW[$3C4]:= $300;
  STI;
  PortW[$3CE]:= $204;
  PortW[$3CE]:= $5;
  PortW[$3CE]:= $6;
 END;

PROCEDURE Close_Card;
BEGIN
  CLI;
  PortW[$3C4]:= $100;
  PortW[$3C4]:= $302;
  PortW[$3C4]:= $304;
  PortW[$3C4]:= $300;
  STI;
  PortW[$3CE]:= $4;
  PortW[$3CE]:= $1005;
  PortW[$3CE]:= $E06;
 END;

{PROCEDURE Upload_Shield;
VAR scol,srow: integer;
BEGIN
  FOR scol:= 0 TO 3 DO FOR srow:= 0 TO 1 DO
    Upload_Chars(ord(s8_char[scol,srow]),ord(s8_char[scol,srow]));
 END;
}
PROCEDURE QtrShield_To_Font(putdex: integer);
VAR scol,srow: integer;
BEGIN
  IF disk_info[_BoolVars] and _NoHerald = 0 THEN BEGIN
    Prep_Card;
    FOR srow:= 0 TO 15 DO FOR scol:= 0 TO 1 DO
      Mem[$A000:(32*(putdex+scol))+srow]:= tshield.shieldarr[scol,srow];
    Close_Card;
   END;
 END;

PROCEDURE Shield_To_Font(VAR shield: shieldrec);
VAR scol,srow: integer;
BEGIN
  IF disk_info[_BoolVars] and _NoHerald = 0 THEN BEGIN
  Prep_Card;
  FOR srow:= 0 TO 31 DO FOR scol:= 0 TO 3 DO
    IF ((srow and 15 <> 14) and (srow and 15 <> 15)) THEN
        Mem[$A000:(32*ord(s8_char[scol,srow DIV 16])) +(2*ord((char_height = 16) and (srow < 16))) +(srow and 15)]:=
          shield.shieldarr[scol,srow]
      ELSE IF char_height = 16 THEN
        Mem[$A000:(32*ord(s8_char[scol,srow DIV 16]))+(srow and 15) - (14*ord(srow < 16))]:= 0;
  Close_Card;
   END;
 END;

PROCEDURE EditShield_To_Font;
BEGIN  Shield_To_Font(shieldp^[edit_hernum]); END;

PROCEDURE Write_T1Names;
VAR ndex: integer;
BEGIN
  FOR ndex:= 1 TO 3 DO WITH t1names[ndex] DO BEGIN
    WRITE(miscfile,' N');
    Bit_Write(lptoname);
    WRITELN(miscfile,namefor,',');
   END;
 END;

PROCEDURE Ck_D(ch: char);
BEGIN
  WRITE('CKD:',ch,'.'); WEK;
 END;

PROCEDURE Write_Moves(kng: krange);
VAR a: ability;
   ldr: integer;
   fs: Str30;
BEGIN
  Get_FN('AK',gameturn,kng,fs);
  Assign(miscfile,fs);
  WRITELN; WRITELN('Saving ',fs,'...');
(*  Ck_D('a');*)
  REWRITE(miscfile); WS;
(*  Ck_D('A');*)
  WRITELN(miscfile,'   This moves file contains the moves of your King and his characters.'); WS;
  WRITELN(miscfile,'It is read in by the game moderator''s computer.  Don''t alter anything!'); WS;
  WRITELN(miscfile,'If you have any comments, write them at the very bottom of this file.'); WS;
  WRITELN(miscfile); WS;
(*  Ck_D('B');*)
  WRITELN(miscfile,'Moves for ',lname^[kng],'''s Kingdom (',fs,'):'); WS;
  WRITELN(miscfile,sex[kng],' ',interp_vers,' ',allreq[kng],' ',brreq[kng],' ',
      kacct[kng],' ',kpmode[kng],' ',kprevgold[kng],' ',ksendmeth[kng]); WS;
(*  Ck_D('C');*)
  FOR a:= Tactical TO Sage DO
    WRITE(miscfile,lskill^[kng][a],' ',aptitude^[kng][a],' ');
(*  Ck_D('D');*)
  WRITELN(miscfile,ord(ltemper[kng])); WS;
  WRITELN(miscfile,lname^[kng]); WS;
  WRITELN(miscfile,ktit^[kng]); WS;
(*  Ck_D('E');*)
  totspent:= 0; writc:= 1;
  FOR ldr:= 0 TO nleaders-1 DO IF LKing(ldr) = kng THEN BEGIN
(*  Ck_D('F');*)
    WRITELN(miscfile,ldr,' -',lname^[ldr]); WS;
{    W_List(lplan^[ldr].septr,Tac_Bytes);}
    W_HPlan(lplan^[ldr],false);
   END;
(*  Ck_D('G');*)
  IF gameturn = 1 THEN IF t1names[1].lptoname > 0 THEN BEGIN
    WRITELN(miscfile,'250');
    Write_T1Names;
    WRITE(miscfile,' ');
   END;
(*  Ck_D('H');*)
  IF heraldry_enabled THEN IF not Clear_Shield(shieldp^[playkg]) THEN BEGIN
    WRITELN(miscfile,'254');
    Write_ShieldVars(shieldp^[playkg]);
    WRITE(miscfile,' ');
   END;
(*  Ck_D('I');*)
  WRITELN(miscfile,'255');
  IF m_lines > 0 THEN BEGIN
    WRITELN(miscfile);
    FOR i:= 1 TO m_lines DO WRITELN(miscfile,mess^[i]);
   END;
  Close(miscfile);
(*  Ck_D('J');*)
 END;
{$ENDIF}
{$ENDIF}
PROCEDURE Write_Shield(shield_num: integer; VAR write_name: Str30);
VAR woe: integer;
BEGIN
{$IFNDEF Moderator}
  IF Length(write_name) = 0 THEN BEGIN
    GOTOXY(1,17);
    WRITELN('Filename?      ');
    READLN(write_name);
    GOTOXY(1,25);
   END;
{$ENDIF}
  Assign(miscfile,write_name);
  REWRITE(miscfile);
  woe:= IOResult;
  IF woe = 0 THEN BEGIN
      IF option <> 'R' THEN WRITE('Saving Heraldry');
{$IFDEF Moderator}
      Write_ShieldVars(mod_shield);
{$ELSE}
      Write_ShieldVars(shieldp^[shield_num]);
{$ENDIF}
      Close(miscfile);
     END
    ELSE BEGIN
      WRITE('Write fail #',woe);
      WEK;
     END;
 END;

PROCEDURE Start_App(VAR f1: text);
VAR res: word;
    woe: integer;
BEGIN
{$IFDEF Moderator}
  WRITE('I:',IOResult);
{$ENDIF}
  Append(f1);
  woe:= IOResult;
  IF woe = 2 THEN REWRITE(f1)
    ELSE IF woe <> 0 THEN BEGIN WRITE('Append error: ',woe); WEK; END;
 END;

{$IFDEF Moderator}
{$IFDEF More_Entry}
PROCEDURE Check_RWish(VAR quote: Str130; cldr,fnplus: integer);
VAR rep,rep2: reply;
    tn: integer;
    tmp: Str10;
    wc: char;
BEGIN
  Get_Reply(cldr,fnplus,rep,rep2);
  IF ((rsp) or (option = 'E')) THEN CASE rep OF
    RWish: BEGIN
      WRITE('This seems to be a wish.  Will you type the treasure number now (Y/N)? ');
      wc:= REURK;
      IF wc = 'Y' THEN BEGIN
        WRITE('>'); READLN(tn);
        Str(tn,tmp); tmp:= Concat('$w',tmp);
        quote:= Concat(quote,tmp);
       END;
     END;
    RRiddle: BEGIN
      WRITE('This seems to be a riddle answer.  Will you judge the answer now (Y/N)? ');
      wc:= REURK;
      IF wc = 'Y' THEN BEGIN
        WRITE('Is the answer good enough for ',trname[treasure(ord(RA_Riddle)+_qsubplot-1)],' (Y/N)?');
        quote:= Concat(quote,'$r',EURK);
       END;
     END;
   END;
 END;
{$ENDIF}
{$ENDIF}
PROCEDURE RS; VAR c: char;
BEGIN
  IF rsp THEN IF not EOLN(miscfile) THEN BEGIN
    Read(miscfile,c);
    IF c <> ' ' THEN
      BEGIN WRITELN('Each line must begin with a space character!'); READLN; END;
   END;
 END;

PROCEDURE GhostR(cond: boolean); BEGIN IF not cond THEN Readln(miscfile); END;

PROCEDURE R_List(VAR tacptr: desigptr; mode: byte; abbrev: boolean; sldr,sfeat: integer);
label 5,10;
CONST
    spdex: array[25..34] OF integer =
      (C_GA,C_WH,
       C_ST,C_GD,
       C_MW,C_LP,
       C_LO,C_AC,
       C_IF,C_IH);

VAR itac,garb: integer;
     ca_ns,repsteal: boolean;
BEGIN
{$IFDEF Moderator} WRITE('RB '); {$ENDIF}
  tacptr:= nil; ca_ns:= false;
5: READ(miscfile,itac);
{$IFDEF Moderator}  WRITE(' it',itac); {$ENDIF}
  repsteal:= ((mode = Tac_Bytes) and (pitac = itac) and (itac = ord (CSteal)));
{$IFDEF Moderator}
  IF ((mode = Tac_Bytes) and (itac = ord(CSteal))) THEN cover[sldr]:= Thief;
{$ENDIF}
  IF itac = -1 THEN BEGIN
      GhostR(abbrev);
      tacptr:= Nil;
     END
    ELSE IF repsteal THEN GOTO 5
    ELSE BEGIN
      New(tacptr);
      tacptr^.dn:= itac;
      IF mode = AT_Bytes THEN IF itac <> ord(noarmy) THEN
        totspent:= totspent +ATCost(army(itac));
      tacptr^.nextbyte:= Nil;
      IF mode = Tac_Bytes THEN CASE maneuver(itac) OF
        CCast,CGive,CUse_MI: BEGIN
          READ(miscfile,tacptr^.dobj);
          IF ((itac = ord(CGive)) and (sfeat >= 0) and (tacptr^.dobj = 0)) THEN BEGIN
              tacptr^.dn:= ord(CScout);
              itac:= ord(CScout);
             END
            ELSE IF maneuver(itac) = CCast THEN
              IF tacptr^.dobj = ord(nospell) THEN ca_ns:= true;
{$IFDEF Moderator}          WRITE('/',tacptr^.dobj); {$ENDIF}
         END;
        CSay: BEGIN
          READLN(miscfile); RS;
          New(tacptr^.sayeth);
          tacptr^.sayeth^:= '';
          REPEAT
            READLN(miscfile,tmp); RS;
            IF tmp <> '' THEN
              tacptr^.sayeth^:= Concat(tacptr^.sayeth^,tmp,' ');
          UNTIL ((tmp = '') or (tmp = ' '));
{$IFDEF Moderator}
{$IFDEF More_Entry}
          IF tacptr^.sayeth^ <> '' THEN IF tacptr^.sayeth^[1] <> '$' THEN BEGIN
            Prep_EBottom; WRITELN('Say tactic: ',tacptr^.sayeth^);
            IF sfeat = -1 THEN BEGIN
              WRITE('Press <Return> if OK (or type replacement)? '); Beep; Readln(tmp); IF tmp <> '' THEN
                tacptr^.sayeth^:= tmp;
              Insert('$A',tacptr^.sayeth^,1);
             END;
           END;
          IF sfeat >= 0 THEN Check_RWish(tacptr^.sayeth^,sldr,sfeat+256);
{$ENDIF}
{$ENDIF}
          GOTO 10;
         END;
       END;
      GhostR(abbrev);
10:   pitac:= itac;
      WRITE('R1:');
      IF ca_ns THEN R_List(tacptr,mode,abbrev,sldr,sfeat)
        ELSE R_List(tacptr^.nextbyte,mode,abbrev,sldr,sfeat);
     END;
{$IFDEF Moderator}  WRITE('RE '); {$ENDIF}
 END;

PROCEDURE R_HPlan(VAR lnplan: planrec; old: boolean; abbvar: shortint;
            sldr: integer);
const spdex: array[25..34] OF integer =
      (C_GA,C_WH,
       C_ST,C_GD,
       C_MW,C_LP,
       C_LO,C_AC,
       C_IF,C_IH);

VAR m: actionrange;
    la,tl: integer;
    trt: treasure;
    planc,tc: char;
    abbrev: boolean;

PROCEDURE GR2(lc: char);
BEGIN
  GhostR(abbrev);
  IF lc <> 'z' THEN IF abbrev THEN
    REPEAT READ(miscfile,tc); {$IFDEF Moderator} WRITE(tc); {$ENDIF} UNTIL lc = tc;
 END;

PROCEDURE Read_HPlan;
BEGIN
{$IFDEF Moderator} WRITE('RH2 '); {$ENDIF}
  WITH lnplan DO BEGIN
    pexrec[m].ertype:= Extra_CPlan;
{$IFDEF Moderator} WRITE('1 '); {$ENDIF}
    New(pexrec[m].newchptr);
{$IFDEF Moderator} WRITE('2 '); {$ENDIF}
    IF old THEN pexrec[m].newchptr^.septr:= Nil;
    IF m < 4 THEN R_HPLan(pexrec[m].newchptr^,old,ord(abbrev),lobjects[m]);
   END;
 END;

PROCEDURE Read_More(sp: spell);
BEGIN
{$IFDEF Moderator} WRITE('RM '); {$ENDIF}
  WITH lnplan DO CASE sp OF
    Illus_Terrain: BEGIN READ(miscfile,pexrec[m].n1); pexrec[m].ertype:= Numbers; GR2('z'); END;
    Charm,Resurrection: Read_HPlan;
   END;
 END;

PROCEDURE Clear_M;
BEGIN
  WITH lnplan DO BEGIN
    lactions[m]:= No_Action;
    lextra[m]:= 0;
    lobjects[m]:= 0;
    pexrec[m].ertype:= Nuthin;
   END;
 END;

BEGIN
{$IFDEF Moderator} WRITE('RHP '); {$ENDIF}
  WITH lnplan DO BEGIN
    CASE abbvar OF
      -1: BEGIN READ(miscfile,tc,planc); abbrev:= ((planc='P') or ((tc = ' ') and (planc = 'A'))); END;
       ELSE abbrev:= boolean(abbvar);
      END;
    GR2(':');
    READ(miscfile,planstart,planend); GR2('z');
{$IFDEF Moderator} WRITE(' p',planstart,planend); {$ENDIF}
    IF not old THEN BEGIN
      GR2(':'); {,'Special Plan:');}
      WRITE('R2:');
      pitac:= -1; R_List(septr,Tac_Bytes,abbrev,sldr,-1);
     END;
    IF planstart > -1 THEN BEGIN
        FOR m:= 0 TO 4 DO lactions[m]:= No_Action;
        FOR m:= planstart TO planend DO BEGIN
          IF abbrev THEN IF m = 2 THEN BEGIN Readln(miscfile); RS; END;
          pexrec[m].ertype:= Nuthin;
          GR2(':');
          READ(miscfile,la,lobjects[m],tl); GR2('z');
{$IFDEF Moderator} WRITE(' la',la,'-',lobjects[m],'-',tl); {$ENDIF}
          lactions[m]:= action(la);
          lextra[m]:= tl;
          pitac:= -1;
          CASE lactions[m] OF
            Challenge,Pursue: BEGIN
      WRITE('R3:');
              R_List(pexrec[m].firstbyte,Tac_Bytes,abbrev,sldr,-(lobjects[m]+1));
              pexrec[m].ertype:= Tac_Bytes;
             END;
{$IFDEF Moderator}  
            Trail,ASpy: cover[sldr]:= Spy;
{$ENDIF}
            Search: BEGIN
      WRITE('R4:');
              R_List(pexrec[m].firstbyte,Tac_Bytes,abbrev,sldr,lobjects[m]);
              pexrec[m].ertype:= Tac_Bytes;
             END;
            Cast: Read_More(spell(lobjects[m]));
            Use_MI: BEGIN
                  trt:= treaslist[lobjects[m]];
                  IF ((trt >= wcp) and (trt <= pic)) THEN
                    Read_More(spell(ord(trt)-ord(wcp)));
             END;
            Trade: BEGIN
              READ(miscfile,pexrec[m].n1); GhostR(abbrev);
              IF tl = sldr THEN IF modprog THEN
                IF lobjects[m] >= 25 THEN IF lobjects[m] <= 34 THEN
                  IF Has_SA(sldr,spdex[lobjects[m]]) THEN BEGIN
                    lextra[m]:= 0;
                    lactions[m]:= Cast;
                   END;
              IF not abbrev THEN RS;
              pexrec[m].ertype:= Numbers;
             END;
            Hire: BEGIN
              totspent:= totspent +tl;
              Read_HPlan;
             END;
            Disband,Leave,Pick_Up: BEGIN
{              WRITE('RL ANB: ',i,' ');}
              IF intvers < 17 THEN IF lactions[m] = Leave THEN
                lextra[m]:= noleader;
      WRITE('R5:');
              R_List(pexrec[m].firstbyte,AN_Bytes,abbrev,sldr,-1);
              pexrec[m].ertype:= AN_Bytes;
             END;
            Recruit: BEGIN
{              WRITE('RL ATB: ',i,' ');}
      WRITE('R6:');
              R_List(pexrec[m].firstbyte,AT_Bytes,abbrev,sldr,-1);
              pexrec[m].ertype:= AT_Bytes;
             END;
           END;
         END;
        IF sldr = valhero THEN IF gameturn <= 8 THEN BEGIN
          planend:= ((gameturn+1) DIV 2) -1;
          FOR m:= planend+1 TO 4 DO Clear_M;
         END;
       END
      ELSE FOR m:= 0 TO 4 DO Clear_M;
   END;
  READLN(miscfile); RS;
 END;

PROCEDURE Bit_Read(VAR wb: byte);
VAR tc,tc2: char;
BEGIN  READ(miscfile,tc,tc2); wb:= ((ord(tc)-32) Shl 4) +(ord(tc2)-32); END;

PROCEDURE Read_ShieldVars(VAR rshield: shieldrec);
VAR scol,srow: integer;
    tc,tc2: char;
BEGIN
  WITH rshield DO BEGIN
      FOR scol:= 0 TO 3 DO BEGIN
        READ(miscfile,tc,tc);
        FOR srow:= 0 TO 29 DO IF ((srow <> 14) and (srow <> 15)) THEN
          Bit_Read(shieldarr[scol,srow]);
        READLN(miscfile);
       END;
      READ(miscfile,tc,tc);
      FOR scol:= 0 TO 1 DO FOR srow:= 0 TO 1 DO Bit_Read(qtr_bc[scol,srow]);
      FOR scol:= 0 TO 1 DO FOR srow:= 0 TO 1 DO Bit_Read(qtr_fc[scol,srow]);
      READLN(miscfile);
      READLN(miscfile,tc,tc,tc,tmp);
      bottom_forecolor:= boolean(tc <> ' ');
      IF ((Length(tmp) = 0) or (tmp[Length(tmp)] = '.')) THEN motto:= ''
        ELSE BEGIN
          READLN(miscfile,tmp);
          IF Length(tmp) >= 4 THEN motto:= Copy(tmp,3,Length(tmp)-3)
            ELSE motto:= '';

         END;
   END;
 END;

FUNCTION Message_Char(ss: string; look_key: Str10): integer; {king#, or 1000 = to:all}
label 75;
VAR mess_char,spos,sp2,keypos: integer;
    ts: Str10;
BEGIN
  mess_char:= No_Mess;
  UpC_Str(ss);
  keypos:= Pos(look_key,ss); IF keypos > 5 THEN keypos:= 0;
  IF keypos = 0 THEN BEGIN
    Delete(look_key,Length(look_key),1);
    keypos:= Pos(look_key,ss);
    IF keypos > 5 THEN keypos:= 0;
    IF keypos > 0 THEN IF Pos(':',ss) <> Length(ss) THEN keypos:= 0;
   END;
  IF keypos > 0 THEN BEGIN
    spos:= keypos+Length(look_key); sp2:= No_Mess;
    IF ((look_key = 'TO:') and (Abs(Pos('ALL',ss)-(spos+1)) <= 1)) THEN
        sp2:= All_Mess
      ELSE IF ((look_key = 'TO:') and (Abs(Pos('GM',ss)-(spos+1)) <= 1)) THEN
        sp2:= GM_Mess
      ELSE WHILE spos <= Length(ss) DO BEGIN
        IF ss[spos] >= '0' THEN IF ss[spos] <= '9' THEN BEGIN
          sp2:= spos+1;
          WHILE ((sp2 <= Length(ss)) and
                 (ss[sp2] >= '0') and (ss[sp2] <= '9')) DO Inc(sp2);
          GOTO 75;
         END;
        Inc(spos);
       END;
75: IF sp2 <> -1000 THEN BEGIN
      IF sp2 < 0 THEN mess_char:= sp2
        ELSE BEGIN
          ts:= Copy(ss,spos,sp2-spos);
          Val(ts,mess_char,vcode);
         END;
     END;
   END;
  IF look_key = 'FROM:' THEN IF mess_char >= nkings THEN BEGIN
    mess_char:= LKing(mess_char);
    IF mess_char >= nkings THEN mess_char:= No_Mess;
   END;
  Message_Char:= mess_char;
 END;

PROCEDURE Read_Moves(kng: krange; turnmod: shortint; justsep: boolean);
label 10,50,75,94,99;
VAR a: ability;
    addcoms,tkk,tka,tpm,fct,lt,ldr,spos,sp2,tochar,temp_tochar,last_tochar,
      cur_tochar,vcode,t: integer;
    playon,sendtried,signif_com: boolean;
    tks: word;
    fs: Str30;
    ss,ts: String;
    splan: planrec;
    fspos: integer;

{$IFDEF Moderator}
    readin_shield: boolean;

PROCEDURE Read_T1Names;
VAR ctoname,ndex: byte;
BEGIN
  FOR ndex:= 1 TO 3 DO BEGIN
    READ(miscfile,tc,tc);
    Bit_Read(ctoname);
    READLN(miscfile,tmp);
    Delete(tmp,Length(tmp),1);
    IF Length(tmp) > 0 THEN CASE ctoname OF
      250: pname^[bornx[kng],borny[kng]]:= tmp;
      0..249: IF LKing(ctoname) = kng THEN lname^[ctoname]:= tmp;
     END;
   END;
 END;
{$ELSE}
PROCEDURE Read_T1Names;
VAR ctoname,ndex: integer;
    tc: char;
BEGIN
  FOR ndex:= 1 TO 3 DO WITH t1names[ndex] DO BEGIN
    READ(miscfile,tc,tc);
    Bit_Read(lptoname);
    READLN(miscfile,tmp);
    Delete(tmp,Length(tmp),1);
    namefor:= tmp;
    CASE ndex OF
      1: pname^[bornx[playkg],borny[playkg]]:= tmp;
      ELSE lname^[lptoname]:= tmp;
     END;
   END;
 END;
{$ENDIF}

{$IFDEF More_Entry}
PROCEDURE Disp_Files;
VAR path: Str20;
    instance: Searchrec;
    f: file;
BEGIN
  Prep_EBottom;
  fct:= 0;
  Str(kng,path); 
  path:= Concat('ak*.k',path);
  FindFirst(path,0,instance);
  WHILE DosError = 0 DO BEGIN
    WRITE(instance.name: 20);
    FindNext(instance);
    Inc(fct);
   END;
 END;
{$ENDIF}

PROCEDURE Assign_Disk(dd: char);
BEGIN  fs:= Concat(dd,':\',fs); END;

PROCEDURE Read_Him;
VAR i: integer;
BEGIN
        RS;
{$IFDEF Moderator}        WRITELN('Ldr: ',ldr); {$ENDIF}
        pitac:= -1;
        IF LKing(ldr) = kng THEN BEGIN
      WRITE('R7:');
            IF intvers <= 1 THEN
              R_List(lplan^[ldr].septr,Tac_Bytes,intvers >= 11,ldr,-1);
            R_HPlan(lplan^[ldr],intvers <= 1,-1,ldr);
           END
          ELSE BEGIN
            splan:= lplan^[kng];
      WRITE('R8:');
            IF intvers <= 1 THEN
              R_List(lplan^[kng].septr,Tac_Bytes,intvers >= 11,kng,-1);
            R_HPlan(lplan^[kng],intvers <= 1,-1,kng);
            lplan^[kng]:= splan;
           END;
        READLN(miscfile,ldr);
        IF ldr = -1 THEN BEGIN
          FOR i:= 1 TO 3 DO Readln(miscfile);
          RS;
          Readln(miscfile,ldr);
         END;
{$IFDEF Moderator}        WRITELN('LE'); {$ENDIF}
 END;

PROCEDURE WWEKW12;
BEGIN
  TextColor(11);
  WWEKW;
  TextColor(15);
 END;

BEGIN
  totspent:= 0; succread:= false; playking:= kng;
{$IFNDEF Moderator}
  m_lines:= 0; tag_line:= '';
{$ENDIF}
  Get_FN('AK',gameturn+turnmod,kng,fs);
{$IFDEF Moderator}
  readin_shield:= false;
  IF ksendmeth[kng] = S_Disk THEN IF sendint = 0 THEN
    CASE kpmode[kng] OF
      1: Assign_Disk('a');
      2: ;
      ELSE Assign_Disk('b');
     END;
{$ENDIF}
  Assign(miscfile,fs);
  RESET(miscfile);
  IF IOResult <> 0 THEN BEGIN
      {$IFDEF Moderator}
      IF not autorun THEN BEGIN
{$IFDEF More_Entry}
        Disp_Files;
{$ENDIF}
        IF fct > 0 THEN BEGIN
          WRITE('Which file? '); Readln(fs);
          IF fs = '' THEN GOTO 99;
          Assign(miscfile,fs);
          RESET(miscfile);
          GOTO 10;
         END;
       END;
      {$ELSE}
      IF justread = 2 THEN GOTO 94;
      {$ENDIF}
{$IFDEF Moderator}
{$IFDEF More_Entry}
      IF not autorun THEN BEGIN
        Prep_EBottom;
        WRITELN('Can''t find AK moves file! ');
        WEK;
       END;
{$ENDIF}
{$ENDIF}
94: ;
     END
    ELSE BEGIN
{$IFDEF Moderator}      WRITE('A'); {$ENDIF}
10:   WRITELN; WRITELN('Reading ',fs,'...');
      succread:= true;
      FOR ldr:= 1 TO 5 DO READLN(miscfile,tmp);
      rsp:= Pos(' Moves',tmp) = 1; RS;
      IF justsep THEN Readln(miscfile,rc,intvers)
        ELSE READLN(miscfile,sex[kng],intvers,allreq[kng],
                    brreq[kng],tka,tpm,kprevgold[kng],tks);
      RS;
{$IFDEF Moderator}
      odinvers[kng]:= intvers;
{$ENDIF}
{$IFDEF Moderator}      WRITE('B'); {$ENDIF}
      IF ((not justsep) and (Total_USkill(kng) < 7)) THEN BEGIN
{$IFDEF Moderator}          WRITE('Us'); {$ENDIF}
          FOR a:= Tactical TO Sage DO READ(miscfile,lskill^[kng][a],t);
          FOR a:= Tactical TO Sage DO aptitude^[kng][a]:=
            Min(5,lskill^[kng][a] + 2*Apt_Mod(kng,a));
{$IFDEF Moderator}
          IF Total_USkill(kng) > 7+ord((lalign[kng] = Heavenly) or (lalign[kng] = Undead)) THEN BEGIN
            Window(1,1,80,25);
            WRITELN('This player seems to have altered his file to give his King illegal skill levels.');
            WRITELN('This may be cheating.'); WEK;
           END;
{$ENDIF}
{$IFDEF Moderator}
          IF lalign[kng] = Heavenly THEN BEGIN
            aptitude^[kng,Necromancy]:= 0;
            IF aptitude^[kng][White] < 5 THEN Inc(aptitude^[kng][White]);
            IF Total_USkill(kng) <= 7 THEN Inc(lskill^[kng][White]);
           END;
          IF lalign[kng] = Undead THEN BEGIN
            IF Total_USkill(kng) <= 7 THEN Inc(lskill^[kng][Necromancy]);
            aptitude^[kng,White]:= 0;
            IF aptitude^[kng][Necromancy] < 5 THEN Inc(aptitude^[kng][Necromancy]);
           END;
{$ENDIF}
          READ(miscfile,lt);
          ltemper[kng]:= temper(lt);
          READLN(miscfile); RS;
          READLN(miscfile,tmp); RS;
          IF tmp <> '' THEN lname^[kng]:= tmp;
{$IFDEF Moderator}
          spos:= Pos(' ',lname^[kng]);
          IF spos > 0 THEN BEGIN
            ksuff^[kng]:= Copy(lname^[kng],spos+1,99);
            Delete(lname^[kng],spos,99);
           END;
{$ENDIF}
          READLN(miscfile,tmp); RS;
          IF tmp <> '' THEN ktit^[kng]:= tmp;
{$IFDEF Moderator} ksuff^[kng]:= ''; WRITE('E'); {$ENDIF}
         END
        ELSE FOR ldr:= 1 TO 3 DO BEGIN READLN(miscfile); RS; END;
{$IFDEF Moderator}      WRITE('C'); {$ENDIF}
      READLN(miscfile,ldr);
{$IFDEF Moderator}      WRITE('D'); {$ENDIF}

      IF LKing(ldr) <> kng THEN ldr:= 255;
      WHILE ldr <> noleader DO BEGIN
        CASE ldr OF
          0..249: Read_Him;
          250: BEGIN
            Read_T1Names; {heraldry flag}
            READLN(miscfile,ldr);
           END;
          254: BEGIN
{$IFDEF Moderator}
            Read_ShieldVars(mod_shield); {heraldry flag}
            readin_shield:= true;
{$ELSE}
            Read_ShieldVars(tshield);
{$ENDIF}
            READLN(miscfile,ldr);
           END;
          ELSE ldr:= noleader;
         END;
       END;
{$IFDEF Moderator}      WRITELN('LX'); {$ENDIF}
      addcoms:= 0; tochar:= No_Mess; playon:= false; sendtried:= false;
      last_tochar:= No_Mess; signif_com:= false;
      fspos:= Pos(':',fs);
      IF not justsep THEN REPEAT
50:     READLN(miscfile,ts);
        IF addcoms = 0 THEN BEGIN
          Window(1,1,80,25);
          ClrScr;
{$IFDEF Moderator}
          WRITELN('Additional Comments from King #',kng);
          WRITELN;
{$ENDIF}
         END;
        temp_tochar:= tochar;
        tochar:= Message_Char(ts,'TO:');
        IF tochar > No_Mess THEN BEGIN
          last_tochar:= temp_tochar;
          cur_tochar:= tochar;
          IF playon THEN BEGIN
            IF last_tochar = GM_Mess THEN WRITE(playfile,chr(12));
            Close(playfile);
            playon:= false;
           END;
          IF ((tochar < GM_Mess) or (tochar = noleader) or (tochar >= nleaders)) THEN
              cur_tochar:= No_Mess
{$IFDEF Moderator}
            ELSE IF tochar = GM_Mess THEN BEGIN
              IF echo_mode = 0 THEN BEGIN
                WRITE('Do you want to echo messages to the GM to the printer (Y/N)?');
                IF EURK = 'Y' THEN echo_mode:= 1 ELSE echo_mode:= -1;
               END;
              IF echo_mode = 1 THEN BEGIN
                Assign(playfile,'PRN');
                REWRITE(playfile);
                playon:= true;
               END;
             END
{$ENDIF}
            ELSE BEGIN
              TextColor(11);
              WRITE('The following is a message from #',kng);
              IF tochar = All_Mess THEN WRITELN(' to all kings')
                ELSE WRITELN(' to #',tochar);
              TextColor(15);
{$IFDEF Moderator}
              IF not playon THEN BEGIN
                {$V-}
                Get_FN('KM',gameturn,-1,tmp);
                {$V+}
                Assign(playfile,tmp);
                Start_App(playfile);
                playon:= true;
               END;
              WRITELN(playfile);
              WRITELN(playfile,'M>>');
              WRITELN(playfile,kng,' ',tochar);
              WRITELN(playfile,'From: ',kng);
{$ENDIF}
             END;
         END;
{$IFNDEF Moderator}
        IF cur_tochar >= GM_Mess THEN BEGIN
          Inc(m_lines);
          mess^[m_lines]:= ts;
          tono[m_lines]:= cur_tochar;
         END;
{$ENDIF}
        WRITELN(ts);
        Inc(addcoms);
        IF Length(ts) > 2 THEN signif_com:= true;
{$IFDEF Moderator}
        IF playon THEN WRITELN(playfile,ts);
        IF cur_tochar <> GM_Mess THEN IF addcoms MOD 20 = 19 THEN BEGIN
          WWEKW12;
          signif_com:= false;
         END;
{$ENDIF}
      UNTIL ((eof(miscfile)) or (IOResult <> 0));
      IF signif_com THEN WWEKW;
      Close(miscfile);
      IF sendtried THEN BEGIN
        Erase(miscfile);
        vcode:= IOResult;
       END;
     {$IFDEF Moderator}
      IF not sendtried THEN IF ksendmeth[kng] = S_Disk THEN BEGIN
        sendtried:= true;
        IF fs[2] = ':' THEN Delete(fs,4,99) ELSE fs:= '';
        Str(kng,tmp);
        fs:= Concat(fs,'AK.',tmp);
        Assign(miscfile,fs);
        RESET(miscfile);
        IF IOResult = 0 THEN GOTO 50;
        Str(kng,tmp);
        Delete(fs,Pos(fs,'.')+1,4);
        fs:= Concat(fs,tmp);
        Assign(miscfile,fs);
        RESET(miscfile);
        IF IOResult = 0 THEN GOTO 50;
       END;
      IF playon THEN BEGIN
        WRITELN(playfile);
        WRITELN(playfile,'END MESSAGE');
        WRITELN(playfile);
        IF cur_tochar = GM_Mess THEN WRITE(playfile,chr(12));
        Close(playfile);
       END;
{$IFNDEF Moderator}
      CASE ksendmeth[kng] OF
        S_Printout:
          Cmt('This player is registered as playing by mail.  Change the playing mode?',LightRed,false);
        S_Disk: IF fspos = 0 THEN
          Cmt('This player is registered as playing by disk.  Change the mode to EMail?',LightRed,false);
        S_Forum,S_CServe,S_GEnie: IF Pos(':',fs) <> 0 THEN
          Cmt('This player is registered as playing by EMail.  Change the mode to Disk?',LightRed,false);
       END;
{$ENDIF}
     {$ENDIF}
     END;
99: rsp:= false;
{$IFDEF Moderator}
  IF readin_shield THEN BEGIN
    Get_FN('AH',-1,kng,fs);
    Write_Shield(-1,fs);
   END;
{$ENDIF}
 END;

{$IFDEF Moderator}
PROCEDURE King_Chars(i: integer);
VAR j,n: integer;
    a: ability;
BEGIN
      FOR a:= Tactical TO Sage DO lskill^[i][a]:= 0;
      Inc(lskill^[i][Melee]);  Inc(lskill^[i][Sage]);  Inc(lskill^[i][Archery]);
      FOR a:= Tactical TO Sage DO aptitude^[i][a]:=
        Min(5,(lskill^[i][a]+2)*Apt_Mod(i,a));
      ksuff^[i]:= '';
{      lgenp[i]:= 0;
      ladmp[i]:= 0;
      lmhpp[i]:= 0;
      lfdisc[i]:= 0;
      ldiscp[i]:= 0;
      lwmsp[i]:= 0;}
 END;

{$ENDIF}