unit yak;

interface

uses crt,textseek,defines;
{$I modflag.pas}
{$I pro.pas}
{$I noble.pas}

{$V-}
PROCEDURE Shorten_PName(VAR s: Str80);
PROCEDURE Make_Des(n: integer; VAR s: Str30);
PROCEDURE Make_AName(an: integer; VAR s: Str30; caller: byte);
{$IFDEF Moderator}
PROCEDURE Set_Event(fn: integer; wr_play: boolean);
PROCEDURE Rum_Close(ldr: integer);
PROCEDURE Disk_Rum(ldr,gt: integer; init: boolean);
PROCEDURE Get_LFN(ldr,gt: integer; VAR s: Str20);
PROCEDURE Ensure_Rum(ldr: integer);
PROCEDURE PR1;
PROCEDURE PR2;
PROCEDURE PR_Lines(n: integer);
PROCEDURE Spread(VAR s: String; prn: integer; igspace: boolean);
PROCEDURE UL;
PROCEDURE NUL;
PROCEDURE Elite_On;
PROCEDURE Elite_Off;
FUNCTION End_Punct(c: char): boolean;
FUNCTION End2_Punct(c: char): boolean;
PROCEDURE NIO_Check(s: Str20; c: integer);
{$ENDIF}
{$IFDEF Moderator}
VAR rumfile: ^rtextarr;

type storyarr = array[1..2208] of integer; {used as 2048-byte buffer too}
VAR story: ^storyarr;

{$ENDIF}
implementation

{$IFDEF Moderator}
{PROCEDURE ACom(ac: char; kng: longint);
BEGIN
  IF playking <> 0 THEN BEGIN
    WRITE(ac,':',kng,'.'); WEK;
   END;
 END;
}
PROCEDURE Make_Des(n: integer; VAR s: Str30);
label 89;
BEGIN
  Str(n,s);
  IF Company = Roland THEN CASE n MOD 10 OF
      1: s:= Concat(s,'er');
      ELSE s:= Concat(s,'e');
     END
    ELSE CASE n MOD 10 OF
      1: IF n MOD 100 <> 11 THEN s:= Concat(s,'st') ELSE GOTO 89;
      2: IF n MOD 100 <> 12 THEN s:= Concat(s,'nd') ELSE GOTO 89;
      3: IF n MOD 100 <> 13 THEN s:= Concat(s,'rd') ELSE GOTO 89;
      ELSE
89:     s:= Concat(s,'th');
     END;
 END;
{$ELSE}
PROCEDURE Make_Des(n: integer; VAR s: Str30);
BEGIN
  Str(n,s);
    CASE n MOD 10 OF
      1: s:= Concat(s,'st');
      2: s:= Concat(s,'nd');
      3: s:= Concat(s,'rd');
      ELSE s:= Concat(s,'th');
     END;
 END;
{$ENDIF}
PROCEDURE Make_AName(an: integer; VAR s: Str30; caller: byte);
BEGIN
  Make_Des(an,s);
  r:= Mod_ARace(an);
  IF Noid_Race(r) THEN
    IF caller = 2 THEN s:= Concat(s,' ',radj[r])
      ELSE IF caller <> 0 THEN IF rab3[r] <> '' THEN s:= Concat(s,' ',rab3[r]);
  IF caller = 1 THEN s:= Concat(s,' ',atdesig[Mod_AType(an)]);
 END;

PROCEDURE Shorten_PName(VAR s: Str80);
BEGIN
  IF Pos('the ',s) = 1 THEN Delete(s,1,4);
  IF Pos('Mare ',s) = 1 THEN Delete(s,2,3);
  IF Pos('Oceanus ',s) = 1 THEN Delete(s,3,5);
 END;

FUNCTION Get_News(kng: integer): boolean; {Does foreign "kng" get a copy of the string in his general intelligence report?}
VAR gn: boolean;
BEGIN
  gn:= false;
{$IFDEF Moderator}
{  IF playking = 3 THEN intel_lev[7]:= 4;}
  IF not say_trial THEN IF (((event_lev >= S_IDipl) and
       (kkmet[Min(kng,playking)] and (longint(1) Shl Max(kng,playking)) = 1)) or
      (event_lev >= spy_lev[kng]) or
      (event_lev >= intel_lev[kng])) THEN BEGIN
    IF ((eot_ldr <> kng) and (double_ldr <> kng) and
        (say_on) and (eot_on)) THEN
      IF LKing(double_ldr) <> kng THEN  BEGIN
        IF ((prov_spy[kng] <> noleader) or ((not Either_King(_attl,kng,true)) and
            (not Either_King(_defl,kng,true)))) THEN gn:= true;
       END;
   END;
{    IF not gn THEN IF kng = 7 THEN IF playking = 3 THEN
      IF prov_spy[kng] = 7 THEN IF justecho THEN BEGIN
        WRITE('GN:',intel_lev[kng],'/',double_ldr,'/',_attl,'/',_defl,'.');
        WRITE(''); READLN;
        justecho:= false;
       END;}
{$ENDIF}
{  IF _attl = 162 THEN IF kng = 17 THEN BEGIN
    WRITE('GN:',ord(say_trial),'/EL',event_lev,'/SL',spy_lev[17],'/IL',
      intel_lev[17],'/PK',playking,'/EOTL',eot_ldr,'/DL',double_ldr,'/SO',
      ord(say_on),'/EO',ord(eot_on),'/LKD',LKing(double_ldr),'/EKA',
      ord(Either_King(_attl,kng,true)),'/EKD',ord(Either_King(_defl,kng,true)),'.');
    READLN;
   END;}
  Get_News:= gn;
 END;

{$IFDEF Moderator}
PROCEDURE UL; BEGIN gs:= Concat(chr(27),'-',chr(1)); Spread(gs,0,true); END; {underline}
PROCEDURE NUL; BEGIN gs:= Concat(chr(27),'-',chr(0)); Spread(gs,0,true); END;

PROCEDURE Elite_On;
BEGIN  IF ((ksendmeth[playking] >= S_Printout){ or (gameturn = 0)}) THEN Spread(elon,0,true); END;
PROCEDURE Elite_Off;
BEGIN  IF ((ksendmeth[playking] >= S_Printout){ or (gameturn = 0)}) THEN Spread(eloff,0,true); END;

PROCEDURE New_Paragraph(kng: krange);
BEGIN
  WITH rumstats[kng] DO BEGIN
    _col:= 1; _line:= 1; _pspace:= 2;
   END;
  lastp:= unkldr; firstp:= unkldr; secondp:= unkldr;
 END;

FUNCTION End_Punct(c: char): boolean;
BEGIN End_Punct:= ((c = '.') or (c = '?') or (c = '!')); END;

FUNCTION End2_Punct(c: char): boolean;
BEGIN End2_Punct:= ((c = '"') or (c = ')')); END;

PROCEDURE NIO_Check(s: Str20; c: integer);
VAR woe: integer;
BEGIN
  woe:= IOResult;
  IF woe <> 0 THEN BEGIN
    WRITELN('I/O Error: ',woe,' in ',s,' #',c,' (Press Return)');
    READLN;
   END;
 END;

PROCEDURE Check_KK(ldr: integer; readem: longint);
BEGIN
  IF ldr < nleaders THEN IF ldr >= 0 THEN kknows^[ldr]:= kknows^[ldr] or readem;
 END;

PROCEDURE Spread(VAR s: String; prn: integer; igspace: boolean); {Spread "s" to the turn reports}
VAR apsaid,kng:integer;
    makeup,gn: boolean;
    ss: String;
    readkings: longint;
    ts: Str10;

PROCEDURE PlayW(s: string; n: integer; skipctrl: boolean); {actually write the string to playfile or rumfile[]}
VAR i,krum: integer;
    armyline: boolean;
BEGIN
  IF ((playmode) or (kng = playking)) THEN BEGIN {kng is current turn report}
      IF Length(s) <> 0 THEN
        WRITE(playfile,s);
      IF n <> 0 THEN WRITELN(playfile);
     END
    ELSE BEGIN {kng is foreign}
      Ensure_Rum(kng); {make sure general-intel file is open}
      krum:= rumdex[kng];
      IF tfilepos(rumfile^[krum]) = -128 THEN BEGIN
        WRITELN(rumfile^[krum]);
        IF not Mail_Send(kng) THEN s:= '' ELSE s:= chr(14);
        WRITELN(rumfile^[krum]);
        IF Company = Roland THEN WRITE(rumfile^[krum],s,'RAPPORT D''ESPIONNAGE GENERAL')
          ELSE WRITE(rumfile^[krum],s,'GENERAL INTELLIGENCE REPORT');
        IF ksendmeth[kng] >= S_Printout THEN WRITE(rumfile^[krum],elon);
        IF catchup THEN BEGIN
          WRITELN(rumfile^[krum]);
          WRITELN(rumfile^[krum]);
          IF Company = Roland THEN WRITE(rumfile^[krum],'(Les �v�nements suivants, s''il y en a, ont eu lieu au tour ',
              gameturn-1,' suite � des ordres tardifs)')
            ELSE WRITE(rumfile^[krum],'(The following events, if any, occured in turn ',gameturn-1,
              ' after a late move submission:)');
         END;
       END;
      IF Length(s) <> 0 THEN BEGIN
        armyline:= false;
        IF skipctrl THEN FOR i:= 1 TO Length(s) DO
          IF ((s[i] < ' ') or (s[i] >= chr(128))) THEN {replace army-symbol codes used by saga with "|"}
            IF ((armyline) or ((i < Length(s)) and (s[i] = s[i+1]))) THEN BEGIN
              s[i]:= '|';
              armyline:= true;
             END;
        WRITE(rumfile^[krum],s);
        rumtime[krum]:= rumorder;
        Inc(rumorder);
       END;
      IF n <> 0 THEN WRITELN(rumfile^[krum]);
     END;
 END;

FUNCTION Incld(k: integer): boolean; {if _excldr <> -1, only _excldr gets copy of "s".}
BEGIN  Incld:= ((_excldr = k) or (_excldr = -1)); END;

PROCEDURE Write_It;
VAR wl,picel: integer;

FUNCTION Actual_Len: integer;
BEGIN
  IF Length(ss) = 0 THEN Actual_Len:= 0
    ELSE IF ss[1] = chr(27) THEN Actual_Len:= 0
    ELSE Actual_Len:= Length(ss)-ord(ss[1] < chr(32));
 END;

BEGIN {write_it}
  WITH rumstats[kng] DO BEGIN
    picel:= 77+19*ord((ksendmeth[kng] = S_Printout) and (not specials_on) and
      (not say_trial))+ 4*ord(allow_excess); {line width of turn report}
    wl:= Actual_Len;
    IF _col+wl > picel THEN IF ((Length(ss) <> 1) or
          ((UpCase(ss[1]) >= 'A') and (UpCase(ss[1]) <= 'Z'))) THEN BEGIN
      _col:= 1;
      Inc(_line);
      PlayW('',1,false);
     END;
    IF ((ss <> ' ') or ((_pspace = 2) and (_line = 1) and (_col <= 2)) or
        ((_col <> 1) and (_col <= picel))) THEN BEGIN
      PlayW(ss,0,true);
      NIO_Check('Rum Write',kng);
      _col:= _col+wl;
      IF Length(ss) > 0 THEN IF not extext THEN
       IF ((ss <> 'Atl.') and (ss <> 'Pac.') and (ss <> 'Ind.') and (ss <> 'Ant.') and
           (ss <> 'Med.') and (ss <> 'E.') and (ss <> 'S.') and (ss <> 'W.') and (ss <> 'N.')) THEN
        IF End_Punct(ss[Length(ss)]) THEN _pspace:= 2
          ELSE IF Length(ss) > 1 THEN IF End2_Punct(ss[Length(ss)]) THEN
            IF End_Punct(ss[Length(ss)-1]) THEN _pspace:= 2;
      IF _pspace = 2 THEN BEGIN
        IF firstp <> lastp THEN firstp:= unkldr;
        IF secondp <> lastp THEN secondp:= unkldr;
       END;
     END;
   END;
 END;

PROCEDURE Wr_Spaces(n: integer);
VAR i: integer;
BEGIN
  FOR i:= 1 TO n DO BEGIN
    ss:= ' ';
    Write_It;
   END;
 END;

BEGIN {Spread}
  readkings:= 0;
  apsaid:= 0;
  IF s <> '' THEN FOR kng:= 0 TO nkings-1 DO IF Incld(kng) THEN
   IF ((s[1] >= ' ') or (Mail_Send(kng))) THEN
    IF (((kng = playking) and (apsaid = 0)) or ((kng <> playking) and (Get_News(kng)))) THEN WITH rumstats[kng] DO BEGIN
      readkings:= readkings or (longint(1) Shl kng);
      IF not phasewrit[kng] THEN BEGIN
        PlayW('',1,true);
        New_Paragraph(kng);
       END;
      IF kng <> playking THEN IF not kingwrit[kng] THEN BEGIN
        PlayW('',1,true);
        IF Mail_Send(kng) THEN PlayW(Concat('-',chr(1)),0,false);
        Str(playking,ts);
        PlayW(Concat('Kingdom of ',lname^[playking],' (#',ts,'):'),1,true);
        IF Mail_Send(kng) THEN PlayW(Concat('-',chr(0)),0,false);
        kingwrit[kng]:= true;
       END;
      makeup:= false;
      IF ((not igspace) and (_pspace = 2) and (s <> '"')) THEN BEGIN
        Wr_Spaces(2);
        _pspace:= 0;
        makeup:= true;
        IF Length(ss) > 0 THEN IF ss[1] = ',' THEN Delete(ss,1,2);
       END;
      IF not phasewrit[kng] THEN BEGIN
        IF prov_spy[kng] <> noleader THEN BEGIN
{          IF prov_spy[kng] = 248 THEN BEGIN
            WRITE(' From:',lname^[prov_spy[kng]]);
            READLN;
           END;}
          IF Company = Roland THEN ss:= Concat('De ',lname^[prov_spy[kng]],':  ')
            ELSE ss:= Concat('From ',lname^[prov_spy[kng]],':  ');
          Write_It;
         END;
        IF Company = Roland THEN ss:= Concat('En ',seasname[seastype(Max(0,Min(4,_rphase)))],', ')
          ELSE ss:= Concat('In ',seasname[seastype(Max(0,Min(4,_rphase)))],', ');
        makeup:= false;
        Write_It;
        phasewrit[kng]:= true;
       END;
      IF ((kng = playking) and (Length(s) > 1) and (Length(alt_pro) > 0)) THEN BEGIN
          ss:= alt_pro;
          Inc(apsaid);
         END
        ELSE ss:= s;
      IF makeup THEN IF Length(ss) > 0 THEN ss[1]:= UpCase(ss[1]);
      IF ss <> ' ' THEN Write_It
        ELSE Wr_Spaces(1);
      IF rum_num <> '' THEN IF rum_ldr <> ruml[kng] THEN
        IF not Either_King(rum_ldr,kng,false) THEN BEGIN
          ruml[kng]:= rum_ldr;
          Wr_Spaces(1);
          ss:= rum_num;
          Write_It;
         END;
     END;
  rum_num:= '';
  WHILE prn > 0 DO BEGIN
    FOR kng:= 0 TO nkings-1 DO IF Incld(kng) THEN
      IF ((kng = playking) or (Get_News(kng))) THEN BEGIN
        PlayW('',1,true);
        New_Paragraph(kng);
       END;
    Dec(prn);
   END;
  IF _excldr <> -1 THEN WRITE(s);
  Check_KK(_attl,readkings);
  Check_KK(_defl,readkings);
 END;

PROCEDURE PR_Lines(n: integer); {"n" writelns to turn report}
BEGIN
  gs:= '';
  Spread(gs,n,false);
 END;

PROCEDURE PR1; BEGIN PR_Lines(1); END;
PROCEDURE PR2; BEGIN PR_Lines(2); END;

PROCEDURE Get_LFN(ldr,gt: integer; VAR s: Str20);
VAR ext: Str20;
BEGIN
  CASE gt OF
    -3: BEGIN WRITE(ldr:3,gt:3,' let?'); Readln; END;
    -2: Get_FN('ru',gameturn,ldr,s);
    -1: Get_FN('zz',-1,ldr,s);
    ELSE Get_MFN('tu',gameturn,ldr,s);
   END;
  IF gt = -1 THEN s:= Concat(ramdrive[Company],s);
 END;

PROCEDURE Rum_Close(ldr: integer);
BEGIN
  IF rumdex[ldr] <> 255 THEN BEGIN
    AClose(rumfile^[rumdex[ldr]]);
    kingrum[rumdex[ldr]]:= noleader;
    rumdex[ldr]:= 255;
   END;
 END;

PROCEDURE Disk_Rum(ldr,gt: integer; init: boolean);
VAR s: str20;
    woe,rfn,findrumno,desprumno: integer;
    oldest: longint;
BEGIN
  New_Paragraph(ldr);
  Get_LFN(ldr,gt,s);
  WRITE(' DRU',s);
  findrumno:= 255; oldest:= 99999999; desprumno:= 255;
  FOR rfn:= MAXRUMS DOWNTO 0 DO
    IF kingrum[rfn] = noleader THEN findrumno:= rfn
      ELSE IF findrumno = 255 THEN IF rumtime[rfn] < oldest THEN BEGIN
        desprumno:= rfn;
        oldest:= rumtime[rfn];
       END;
  IF findrumno = 255 THEN BEGIN
    Rum_Close(kingrum[desprumno]);
    findrumno:= desprumno;
   END;
  rumdex[ldr]:= findrumno;
  kingrum[findrumno]:= ldr;
  rumtime[findrumno]:= rumorder;
  Inc(rumorder);
  Assign(rumfile^[findrumno],s);
  Append(rumfile^[findrumno]);
  woe:= IOResult;
  WRITELN(woe);
  IF woe = 2 THEN BEGIN
      ARewrite(rumfile^[findrumno]);
     END
    ELSE IF woe <> 0 THEN
      BEGIN WRITELN(s,' Dos error ',woe); READLN; END
    ELSE IF init THEN IF option = 'M' THEN IF tfilepos(rumfile^[findrumno]) > -128 THEN BEGIN
      WRITELN(rumfile^[findrumno]);
      WRITELN(rumfile^[findrumno]);
      IF Company = Roland THEN WRITE(rumfile^[findrumno],'(Les �v�nements suivants survinrent au tour ',gameturn,')')
        ELSE WRITE(rumfile^[findrumno],'(The following events occured in turn ',gameturn,':)');
      IF ((ksendmeth[ldr] >= S_Printout) or (gameturn = 0)) THEN
        WRITE(rumfile^[findrumno],elon);
     END;
 END;

PROCEDURE Ensure_Rum(ldr: integer);
BEGIN  IF rumdex[ldr] = 255 THEN Disk_Rum(ldr,-2,false); END;

PROCEDURE Set_Event(fn: integer; wr_play: boolean);
CONST rspell: ARRAY[0..7] OF spell =
  (Oratory,Clairvoyance,Bless,Skeletal_Army,Earthquake,Plague,Tornado,Illus_Armies);

const powname: array[power] OF String[17] = ('Nothing','Change Sex','New Temper','New Race','+','+',
              '-','-',
              'Anti-Magic','Anti-','Warp Space',
              'Cast ','Pray ',
              'Map Feat.','Map Prov.','Sage Disc.',

              'Orac/Align','Orac/Power','Orac/Ofc.',
              'Orac/Gold','Orac/Trea.',

              'Recharge',
              'Wish','Gamble',

              'Chance');

VAR ft: feature;
    tries,modval: integer;

PROCEDURE Set_FCon(con1,con2: powco; perc: integer);
const coname: array[powco] OF str10 =
      ('','g','=','-Skill','King','1/Turn','-Cour.');
BEGIN
  IF Min(35,perc)*2 > ((fn+2)*ord(ftype[fn]) MOD 100) THEN fpowcon:= con1
    ELSE IF perc > (((fn+5)*ord(fx[fn]) MOD 100)*(100-(perc*2))) DIV 100 THEN fpowcon:= con2;
  CASE fpowcon OF
    PayUp: fpay:= Trunc((perc*0.05)+0.999);
    Drain_Skill: fpay:= Trunc((perc*0.025)+0.999);
    SameAlign: BEGIN
      tries:= 0;
      REPEAT powalign:= outlook((fn+modval+tries) MOD ord(Mechanical)); Inc(tries);
      UNTIL powalign <> Hellish;
      _align:= powalign;
{      IF (modval+ord(ft)) and 1 = 1 THEN fpowcon:= SimAlign;}
     END;
   END;
  IF wr_play THEN IF fpowcon <> PCNone THEN BEGIN
    WRITE(playfile,':');
    CASE fpowcon OF
      PayUp: WRITE(playfile,fpay,'g');
      SameAlign: WRITE(playfile,outname[_align]);
      ELSE WRITE(playfile,coname[fpowcon]);
     END;
   END;
 END;

PROCEDURE Set_Abil;
BEGIN
  setval:= modval MOD 15; _abil:= ability(setval);
  IF wr_play THEN WRITE(playfile,abab[_abil]);
 END;

PROCEDURE Set_Spell;
VAR found: boolean;
BEGIN
  found:= false;
  tries:= 0;
  REPEAT
    REPEAT
      setval:= (modval+tries) MOD ord(Gate_Angel);
      Inc(tries);
    UNTIL ((tries MOD 3 = 0) or (Spell_College(spell(setval),0) = White) or
           (fpower <> AnsPrayer));
    CASE spell(setval) OF
      Resurrection,Charm,Holy_Symbol,Hand_Of_Death,Fireball,
        Psychic_Blast,Invisibility,Spiritwrack,Control_Undead,
        Ice_Suspend,Telek_Storm,Mirror_Image: ; {Plus extra spells}
      Part_Sea,Flood: IF pterr[fx[fn],fy[fn]] <> MTNS THEN found:= true;
      Earthquake: IF pterr[fx[fn],fy[fn]] <> SEA THEN found:= true;
      ELSE IF miscwrit and 2 = 2 THEN found:= true;
     END;
  UNTIL found;
  _spell:= spell(setval);
  IF wr_play THEN WRITE(playfile,spab[_spell]);
 END;

BEGIN
  ft:= ftype[fn]; modval:= fn+ord(ft); fpay:= 0; powalign:= Mechanical;
  setval:= -1; setval2:= -1; saidcond:= false; begquote:= false;
  fintro:= intro(ord(fintro1[ft]) + IRand MOD (ord(fintrof[ft])-ord(fintro1[ft])+1));
  fcomfeat:= comfeat(ord(cf1[ft]) + modval MOD (ord(cff[ft])-ord(cf1[ft])+1));
  tries:= 0; _abil:= noabil;
  fpow2:= PNone;   fpowcon:= PCNone; fpower:= PNone; fmagfeat:= MFNone;
  IF gameno <> 999 THEN BEGIN
      fmagfeat:= magfeat(ord(mf1[ft]) + modval MOD (ord(mff[ft])-ord(mf1[ft])+1));
      IF ((fmagfeat >= Gastrap) and (fmagfeat <= Seal)) THEN BEGIN
          fmagfeat:= MFNone;
          fpower:= PNone;
         END
        ELSE IF (fn+fx[fn]) and 1 = 1 THEN REPEAT
          fpower:= power(ord(mfpow1[fmagfeat]) + ((tries+modval+(Min(10,tries)*(modval+Min(20,tries)))) MOD
            (ord(mfpowf[fmagfeat])-ord(mfpow1[fmagfeat])+1)));
          Inc(tries);
        UNTIL ((fpower = CastSpell) or (fpower = AnsPrayer) or (tries > 2))
        ELSE fmagfeat:= MFNone;
     END
    ELSE BEGIN
      fmagfeat:= magfeat((fn MOD ord(Itself))+1);
      IF fn < 12 THEN fpower:= CastSpell
        ELSE IF fn < 24 THEN fpower:= AnsPrayer
        ELSE fpower:= power((fn MOD ord(Chance)) +1);
     END;
  _magfeat:= fmagfeat;
  IF wr_play THEN WRITE(playfile,powname[fpower]);
  CASE fpower OF
    PNone: ;
    NewSex: ;
    NewTemp: BEGIN  Set_FCon(PayUp,SameAlign,10); setval:= modval MOD 3 +1; _temper:= temper(setval); END;
    NewRace: BEGIN  Set_FCon(PayUp,SameAlign,10); setval:= modval and 3; _race:= race(setval); END;
    UpSkill: BEGIN  Set_Abil; Set_FCon(PayUp,Drain_Courage,200); END;
    UpApt:   BEGIN  Set_Abil; Set_FCon(PayUp,Drain_Courage,35); END;
    DnSkill, DnApt: Set_Abil;
    DampCollege: BEGIN
      setval:= 5 + (modval MOD 5); _abil:= ability(setval);
      IF wr_play THEN WRITE(playfile,'/',abab[_abil]);
     END;
    DampMagic: ;
    WarpSpace: ;
    CastSpell: BEGIN  Set_Spell; Set_FCon(PayUp,Drain_Skill,35); END;
    AnsPrayer: BEGIN  Set_Spell; Set_FCon(SameAlign,PayUp,35); END;
    MapFeat: Set_FCon(PayUp,SameAlign,20);
    MapProv: Set_FCon(PayUp,SameAlign,10);
    SageDisc: Set_FCon(PayUp,Drain_Courage,300);
    OracAlign: Set_FCon(SameAlign,PayUp,20);
    OracPower: Set_FCon(SameAlign,PayUp,20);
    OracOffice: Set_FCon(SameAlign,PayUp,20);
    OracGold: Set_FCon(SameAlign,PayUp,20);
    OracTreas: Set_FCon(SameAlign,PayUp,20);
    Recharge: Set_FCon(PayUp,SameAlign,20);
    GrantWish: Set_FCon(GTurn,Drain_Skill,70);
    Gamble: Set_FCon(NeedKing,SameAlign,20);
    Chance: CASE ((gameturn+gdday) and 7) OF
      0: BEGIN  fpow2:= NewSex; END;
      1: BEGIN  fpow2:= NewTemp; setval:= (modval MOD 3) +1; _temper:= temper(setval); END;
      2,3: BEGIN  fpow2:= UpSkill; IF not wr_play THEN Set_Abil; END;
      7: BEGIN  fpow2:= DnSkill; IF not wr_play THEN Set_Abil; END;
      4,5: BEGIN  fpow2:= CastSpell; setval:= ord(rspell[IRand and 7]); _spell:= spell(setval); END;
      6: BEGIN  fpow2:= SageDisc; END;
     END;
   END;
 END;

{$ENDIF}


begin
end.