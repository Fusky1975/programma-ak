const
    ntrtypes = 92;
    magtr = 67;
    Import = 253;
    Batt_Import = 32000;
    Spell_Import = 32001;
    Enctr_Import = 32002;

    MAXRUMS = 10;
    fuckerr = 0;

    Trial_V = 0;
    {normal = 1}
    Europe_V = 2;
    Earth_V = 3;
    Valhalla_V = 4;
    Arcanes_V = 10;


type
{$IFDEF Noble}
  xcrange = 0..38;
  ycrange = 0..29;
  lrange = 0..250;
  krange = 0..125;
  treasrange = 0..ntrtypes;
  trsrange = 0..250;
  featrange = 0..230;
{$ELSE}
  xcrange = 0..29;
  ycrange = 0..14;
  lrange = 0..250;
  krange = 0..32;
  treasrange = 0..ntrtypes;
  trsrange = 0..250;
  featrange = 0..230;
{$ENDIF}
type str10 = string[10];
     str15 = string[15];
     str20 = string[20];
     str30 = string[30];
     str40 = string[40];
     str60 = string[60];
     str80 = string[80];
     Str130 = string[130];
     dirstr = array[1..6] of string[10];
     xystr20 = array[xcrange,ycrange] of Str20;
     rtextarr = array[0..MAXRUMS] of text;

const
     TR_Letter = 16000;
     TR_End = 16001;
     TR_Prose = 16002;
     TR_ATs = 16003;
     TR_LLs = 16004;
     TR_SA = 16005;
     TR_T2 = 16006;
     TR_HK = 16007;


     S_Prev = 0; S_Red = 1; S_Priv = 2; S_PCom = 3; S_Adv = 4;
     S_Batt = 5; S_AA = 6; S_Admin = 7; S_Army = 8; S_Comm = 9;
     S_IDipl = 10;

     Ac_Norm = 0; Ac_Def = 1; Ac_Purs = 2; Ac_Both = 3; Ac_Trail = 4;
     Ac_Hex = 8; Ac_Pat = 16;

     KEnemy = 0; KNeutral = 1; KAllied = 2; KTeamed = 3;

{     interphase = (Winter,LSpring,MSummer,EFall,LFall);}

type month = (Nomonth,January,February,March,April,May,June,
       July,August,September,October,November,December);
     moname = array[month] of Str10;
     mobytes = array[month] of byte;

{$IFNDEF Noble}
type seastype = (Spring,ESummer,LSummer,Fall,EWinter);
     stname = array[seastype] of str20;

const seasname: stname =
        ('spring','early summer','late summer','fall','early winter');
{$ELSE}
type seastype = (Winter,Spring,ESummer,LSummer,Fall);
     stname = array[seastype] of str20;
const seasname: stname =
        ('winter','spring','early summer','late summer','fall');
{$ENDIF}

{$IFDEF Moderator}
     monthname: moname = ('No Month','January','February','March','April',
       'May','June','July','August','September',
       'October','November','December');
     modays: mobytes = (0,31,28,31,30,31,30,31,31,30,31,30,31);
{$ENDIF}

{** IF YOU CHANGE THIS, CHANGE THE FILES TOO!!!! **}
type action = (LMove,Explore,Search,Recruit,Disband,    {0-4}
               Hire,Fire,Leave,                        {5-7}
               Pick_Up,Cast,Use_MI,Challenge,Practice, {8+}
               ASpy,Trade,Defend,Pursue,Trail,Wait,No_Action, {13+}
               Succ_Trail,Move_Abort);

    actdinks = array[action] of string[2];
    actbytes = array[action] of byte;
    actchars = array[action] of char;

const
{    actimp: actbytes = (100,20,50,60,10,
      70,5,2,
      80,55,56,54,17,
      35,30,90,110,65,0,0);}

    actab: actdinks = ('MO','EX','SE','RE','DI',
      'HI','FI','LE',
      'PI','CA','US','EN','PR',
      'SP','GI','DE','PU','TR','WA','NA','ST','MA');

type maneuver = (CCast,CUse_MI,CSqueeze,CTalk,CSay,
                 CGive,CFulfill,CSteal,CShoot,CMelee, {5-9}
                 CFlee,CBeg,CNone,CScout);
    mandinks = array[maneuver] of string[2];

const
    manab: mandinks = ('CA','US','SQ','TA','SA',
      'GI','FU','ST','FI','ME',
      'FL','BE','NM','SC');

type
    ability = (Tactical,ForcedMarch,Naval,Archery,Melee,
             White,Necromancy,Elemental,Psychic,Illusionist,
             Druid,Thief,Explorer,Spy,Sage,noabil);
    skillrange = 0..9;

    abstrs = array[ability] of str20;
    abdinks = array[ability] of string[2];
    abarr = array[ability] of byte;
    skillarr = array[ability] of skillrange;
    lskarr = array[lrange] of skillarr;

const

    anoun: abstrs = ('Tactics','Marches','Navigation','Archery','Meleeing',
      'White Magic','Necromancy','Element Magic','Psychic Magic','Illusions',
      'Druidism','Thievery','Exploring','Spying','Sageness','None');
    adesc: abstrs = ('Tactical','March','Naval','Archery','Melee',
      'White Magic','Necromancy','Elemental','Psychic','Illusionist',
      'Druid','Thief','Explorer','Spy','Sage','None');
    abab: abdinks = ('TA','MA','NA','AR','ME',
      'WH','NE','EL','PS','IL',
      'DR','TH','EX','SP','SA','no');


    Ta10 = 0;
    Ta15 = 1;
    Ta20 = 2;
    Comb_Arms = 3;
    Training = 4;
    Halve_AT = 5;

    March_12 = 6;
    March_345 = 7;
    Ferry = 8;

    Na10 = 12;
    Na15 = 13;
    Na20 = 14;
    Hug_Coast = 15;
    Nav_Comb = 16;
    Nav_Defend = 17;

    Free_Fire = 18;
    Spell_Fire = 19;
    Melee_Fire = 20;

    Me10 = 24;
    Contr_Temp = 25;
    Duelling = 26;
    HP5 = 27;
    Evade_Mon = 28;

    Same_Align = 30;
    Evil_Symb = 31;
    C_GA = 32;
    C_WH = 33;
    White_Places = 34;
    Detect_Align = 35;

    Leave_Skels = 36;
    More_Targets = 37;
    C_ST = 38;
    C_GD = 39;
    Necro_Places = 40;
    Witchsight = 41;

    Tidal_Wave = 42;
    Waterball = 43;
    C_MW = 44;
    C_LP = 45;
    Elem_Places = 46;
    Make_Gems = 47;

    Expand_Clair = 48;
    Expand_Charm = 49;
    C_LO = 50;
    C_AC = 51;
    Psych_Places = 52;
    Sense_Danger = 53;

    Improve_IT = 54;
    Improve_Invis = 55;
    C_IF = 56;
    C_IH = 57;
    Illus_Places = 58;
    Detect_Illus = 59;

    Know_Forces = 60;
    Whale_Trans = 61;
    Brave_Horses = 62;
{    Trans_Ents = 63;}
    Lead_Dinos = 63;
    Trans_Ents = 64;
    Trade_Treas = 65;

    Plus_Steal = 66;
    Banditry = 67;
    Piracy = 68;
    Ripoff_Palace = 69;

    Mil_Maps = 72;    {up to 150-200%}
    Oases = 73;
    Expl_Soc= 74;
    Trade_Routes = 75;
    Expl_Diff = 76;
    Find_Mines = 77;  {up to 150-200%, depending on mil-map thingy}

    Assassinate = 78;
    Blackmail = 79;
    Double_Agent = 80; {= get mucho turn report by trail/hire, shows up as independent hero}
    Brainwash = 81;    {= become closer alignment to king if talk}
    Super_Sleuth = 82;     {increase p/t percs}
    Expand_Info = 83;  {trail & spy actions: features, skills, offices}

    College_Plus = 84; {at first PR-SA site}

    ab_places: array[White..Illusionist] of integer =
      (White_Places,Necro_Places,Elem_Places,Psych_Places,Illus_Places);

type office = (Emperor,Chancellor,Treasurer,Marshal,Admiral,
       Defender,Priest,Mage,NoOffice,
        {9+}Humanking,Elvenking,Dwarvenking,Orclord,Dragonlord,
            Eagleking,Whaleking,Ele_Mage,Mermanking,Entking,
            Trollking,Wereking,Illus_Mage,Divineking,Goodking,
            Druidking,Neutralking,Paganking,Evilking,Necro_Mage,

            Undeadking,Plainsking,Desertking,Jungleking,Forestking,
            Mountainking,Seaking,Thiefprince,Battlefool,Airforce,
            Chief_Of_Staff,Curator,Diplomat,Teacher,Assassin,
            Duellist,Praetor,Psychic_Mage,Flagship,Wingman,
            Cravenest,Bravest,Notitle);

type ofcstrs = array[office] of str30;
    ltints = array[0..1000] of integer;
    ltbytes = array[0..1000] of byte;
    ltypes = array[0..1000] of office;
    ofcbytes = array[office] of byte;
    ofcbools = array[office] of boolean;
    points = array[0..249,Emperor..Bravest] of integer;

{$IFDEF Moderator}
const ofcuse: ofcbools = (True,True,True,True,True,
            True,True,True,False,

            True,True,True,True,True,
            True,True,True,True,True,
            True,True,False,True,True,
            True,True,True,True,False,

            True,False,False,False,False,
            False,False,True,False,True,
            False,True,False,False,False,
            False,True,False,True,False,
            True,True,False);

const minpts: ofcbytes =
        (1,1,1,1,1,
         1,1,1,0,
         15,10,10,10,6,
         6,4,20,4,4,
         4,4,20,25,25,
         25,25,25,25,20,

         25,4,4,4,4,
         4,2,2,2,1,
         7,3,50,5,2,
         5,1,20,1,5,
         5,15,0);

const ofcval: ofcbytes =
        (20,10,10,10,10,
         10,10,10,0,
         4,3,3,3,2,
         2,2,2,2,2,
         2,2,2,3,4,
         4,4,4,4,2,

         3,2,2,2,2,
         2,2,2,1,2,
         2,2,2,2,2,
         2,2,2,2,3,
         1,2,0);
{$IFNDEF Noble}

const ofcname: ofcstrs =
  ('World Emperor','Esteemed High Chancellor',
   'Imperial Treasurer','Imperial Grand Marshal',
   'Imperial Grand Admiral','Lord High Defender',
   'High Priest Palatine','Arch-Mage Palatine','no office',
           'Savior of Humankind','First Elder of Elvenkind','King Under the Mountain',
             'Khan of the Orcish Hordes','Dragon Lord',
           'Ace of Eagles','Whale League Commissioner','Master of Elements',
             'King of Atlantis','Tsar of the Trees',
           'High Mucky-Muck of Trolls','Lord of Lycanthropes','Amazing Houdini',
             'Divine Archangel','Most Blessed of Kings',
           'Great Druid of Life','Defender of Freedom','Warlock of the Pagan Gods',
             'King of Pain','Sorceror of Black Magic',

           'Angel of Death','Ranger of the Plains','Desert Rat',
             'Lord of the Jungle','Warden of the Forests',
           'Mountain Man','Ruler of the Waves','Prince of Thieves',
             'Fool of Battles','Royal Air Force',
           'Chief of Staff','Curator of Artifacts','Silver Tongue',
             'Professor Whizdumb','Grandfather of Assassins',
           'Captain of the Musketeers','Praetorian Guard','Master Mind',
             'Imperial Flag Squadron','Air Force Commander',
           'King of Cowards','Bravest of the Brave','no title');
{$ENDIF}
{
Emperor: Emerald Crown, Know Rivals.
Chancellor: Crystal Ball, Visions.
Treasurer: Golden Abacus, see all taxbases & treasuries
Marshal: Silver Marshal's Baton, +1 recruit or move
Admiral: Sapphire Compass, Sea_Recruit,Dolphin_Patrol,Pirate_Tribute
Defender: Duel_Respect,
Priest: Random Visions
Mage: Treasure_lore,magic_sense(mi)

Humanking,Elvenking,Dwarvenking,Orclord,Dragonlord,
Eagleking,Whaleking: race_recruit

Ele_Mage,

(Mermanking,Entking,Trollking,Wereking,)

Illus_Mage,

Divineking,Goodking,Druidking,Neutralking,Paganking,Evilking,

Necro_Mage,

(Undeadking,)

Plainsking,Desertking,Jungleking,Forestking,Mountainking,Seaking,

Thiefprince,

Battlefool,

Airforce,
            Chief_Of_Staff,Curator,Diplomat,Teacher,Assassin,
            Duellist,Praetor,Psychic_Mage,Flagship,Wingman,
            Cravenest,Bravest,Notitle);
Emperor: ?none? int'l law}
{     No_Abil = 0;
     Dolphin_Patrol = 1;
     Animal_Patrol = 2;
     Thieves_Guild = 3;
     Assasin_Guild = 4;
     Know_Rivals = 5; {Imp-ofc rival-know)
     Visions = 6; {clairv)
     See_Rival = 7; {clairv-rival)
     Treasure_Lore = 8;
     Cast_Extra = 9;
     Extra_Chance =
     Familiar = 10;
     Racial_Home = 11;
     Racial_Tax = 12;
     Race_Recruit
     Duel_Respect = 13;
     Shape_Change = 14;
     Flying_Express = 15;
     Regeneration = 16;
     Element_Merge = 17;
     Vanish = 18;
     Speak_Dead = 19;
     Become_Undead = 20;
     Read_Tarot
     Summon_Pestilence
     Loose_Demon
     Curse
     Summon_Hero/Sense_Hero_Sent
     Detect_Alignment
     Sense_Danger
     Align_Map
     Knight_Aid

     Air_Academy
     Navy_Academy
     Army_Academy
     Recruit_Air
     Recruit_Nav
     Recruit_Army

     Terrain_Explore (but cements office)
     Terrain_Natives
     Ranger_Guild

     Recruit_Bonus
     Weapon_Discount

     Inc_Temper
     Inc_TacApt

     MI_Research- divide owner/abil etc?

     Plus_Sage
     Plus_Apt

     Unit_Qual
     Unit_March
     Unit_Recruit

     Torture
     Respect/Fear
     Extortion/Terrorism money

     Thieves_Dues
     Bandits

     Know_Relations
     Align_Abils
     Sage_Treaties
     Sense_Align

     Muskets
     Panache
     Battle_Leadership
     Persuade_Temper

     Office Gold?
 }

{$ENDIF}
type outlook = (Heavenly,Good,Druidic,Worldly,Animal,
       Evil,Hellish,Undead,Mechanical,Special);
     intlevel = (Mech,Semi,Low,Medium,High,Godlike);

type outstrs = array[outlook] of Str10;
     outreals = array[outlook] of real;
     abilout = array[ability] of outlook;

{$IFNDEF Noble}
     temper = (Cowardly,Cautious,Brave,Berserk);
     tempstrs = array[temper] of Str10;
const
     tempername: tempstrs = ('Cowardly','Cautious','Brave','Berserk');
const prefout: abilout = (Special,Special,Special,Special,Special,
       Good,Evil,Animal,Druidic,Worldly,
       Druidic,Evil,Animal,Worldly,Good,Special);
{$ELSE}
type temper = (Cowardly,Wary,Opportunist,Cautious,Spirited,Brave,Fierce,Ferocious,Berserk);
     tempstrs = array[temper] of Str10;
const
     tempername: tempstrs = ('Cowardly','Wary','Opportunist','Cautious','Spirited',
       'Brave','Fierce','Ferocious','Berserk');

type trait = (Virtue,Charisma,Intelligence,Willpower,Dexterity,Strength,TX1,TX2,TX3,TX4);
     traitstrs = array[trait] of Str10;

const
    traitname: traitstrs = ('Virtue','Charisma','Intelligence','Willpower','Dexterity',
                            'Strength','TX1','TX2','TX3','TX4');
{$ENDIF}

type monster = (Roc,Gryphon,Couatl,GiEagle,Sphinx,
       RDragon,BDragon,GrDragon,SDragon,GoDragon,
       GiWorm,Titan,Giant,Bigfoot,Archer,Swordsman,
       WhiteMage,NecMage,EleMage,PsyMage,IllMage,Witch,

       Dryad,Centaur,Genie,Golem,Gargoyle,Basilisk,Medusa,
       BalDemon,MarDemon,Succubus,Rakshasha,IceDevil,
       BoneDevil,Imp,Werewolf,Chimera,Hydra,Beholder,
       Troll,Minotaur,GiWolverine,Treant,GiAmoeba,GiPMantis,

       GiScorpion,GiWasp,GiSpider,Ghost,Vampire,
       Mummy,Banshee,Lich,Spectre,GiOctopus,GiClam,
       Elasmosaurus,GWWhale,Mermaid,Nomonster,
       em1,em2,em3,em4,em5,em6,em7,em8,em9,em10);

       mstrs = array[monster] of str20;
       mtconst = array[monster] OF byte;
       mtboo = array[monster] OF boolean;
       mintarr = array[monster] OF intlevel;
       mtoutl = array[monster] OF outlook;
       mttemp = array[monster] OF temper;

const nmonsters = 60;

    mtname: mstrs = ('Roc','Gryphon','Couatl','Giant Eagle','Sphinx',
      'Red Dragon','Black Dragon','Green Dragon','Silver Dragon','Gold Dragon',
      'Giant Worm','Titan','Giant','Bigfoot','Renegade Archer',
      'Renegade Swordsman','Renegade Priest','Renegade Necromancer','Elemental Sorceror','Renegade Psychic',
      'Renegade Illusionist','Witch',

      'Dryad','Centaur','Genie','Golem','Gargoyle','Basilisk','Medusa',
      'Balrog Demon','Marilith Demon','Succubus','Rakshasha','Ice Devil',
      'Bone Devil','Imp','Werewolf','Chimera','Hydra','Beholder',
      'Troll','Minotaur','Giant Wolverine','Treant','Giant Amoeba','Giant Praying Mantis',

      'Giant Scorpion','Giant Wasp','Giant Spider','Ghost','Vampire',
      'Mummy','Banshee','Lich','Spectre','Giant Octopus','Giant Clam',
      'Elasmosaurus','Great White Whale','Mermaid','no monster',
      'em1','em2','em3','em4','em5','em6','em7','em8','em9','em10');

{$IFDEF Moderator}
    dirname: dirstr = ('northeast','east','southeast',
                      'southwest','west','northwest');

{    moffset: mtconst = (0,0,0,0,0,

       5,6,6,6,6,
       6,6,6,6,6,

       8,8,8,8,9,
       9,
       14,14,14,15,
       15,15,

       21,21,21,
       22,22,22,22,22,
       22,22,22,22,
       0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0);}

    mtmate: mtboo = (true,true,true,true,true,
       true,true,true,true,true,
       true,true,true,true,false,false,
       false,false,false,false,false,false,

       false,true,false,false,true,true,false,
       false,false,false,true,true,
       false,false,true,true,true,true,
       true,false,true,true,false,false,

       false,false,true,true,true,
       true,false,true,true,true,true,
       true,true,false,false,
       true,true,true,true,true,true,true,true,true,true);
{$ENDIF}
type weapon = (Talons,Fangs,Claws,Maw,Jaws,
       Fists,Sword,Dagger,Staff,Hooves,MedTeeth,
       ChimHeads,Club,Axe,UTouch,Tentacles,
       Beak,Boulder,Bow,FlameBreath,SpitAcid,PoisBreath,BScream,
       EndoPod,Mandible,Stinger,Limb,Gaze,NoWeap);

       mweaps = array[monster] of weapon;
       mwstrs = array[weapon] of string[21];


       hprange = 0..100;
       speedrange = 1..3;

type
    race = (Human,Elven,Dwarven,Orcish,Dragons,
            Eagles,Whales,Norace,Mermish,Entish,
            Trollish,Werefolk,Saurian,
            Vampish,Rohan,er3,er4,er5,
            er6,er7,er8,er9,er10);
    rstrs= array[race] of str20;
    rabs = array[race] of string[3];
    rbytes = array[race] of byte;

const
    lastrace = Rohan;
    rpname: rstrs = ('Humans','Elves','Dwarves','Orcs','Dragons',
      'Eagles','Whales','no races','Mermen','Ents',
      'Trolls','Werefolk','Dinosaurs',
      'Vampires','Riders','er3','er4','er5','er6','er7','er8','er9','er10');
    rab3: rstrs = ('','Elf','Dwf','Orc','',
      '','','','','','','','','','','Roh','','','','','','','');
    rname: rstrs = ('Human','Elf','Dwarf','Orc','Dragon',
      'Eagle','Whale','no race',
      'Merman','Ent','Troll','Were','Dinosaur',
      'Vampire','Rohan','er3','er4','er5','er6','er7','er8','er9','er10');
    radj: rstrs = ('Human','Elven','Dwarven','Orcish','serpentine',
      'feather-brained','aquatic','no race','Mermanic','forest-folk',
      'Trollish','shape-changing','Saurian',
      'Vampiric','Rohan','er3','er4','er5','er6','er7','er8','er9','er10');
{$IFDEF Moderator}
    rcolor: rbytes = (15,10,14,8,12,
                      11,9, 13,
                      11,13,4,5,5,
                      4,10,5,5,5,
                      5,5,5,5,5);
{$ENDIF}
type
  treasure =  (hla,lkdf,ali,gil,abjil,
               alih,vile,abjle,bmweu,bnhum,
               aehnm,bjiue,aliue,blie,lhl,

               wcp,elia,biler,anhile,
               algh,aliemn,hgli,alzn,
               bfnmz,alien,alizb,xle,
               bnl,alxu,bnaw,bmen,
               azx,bneaz,amei,pic,

               helplev0,helplev1,helplev2,helplev3,helplev4,

               rlev0,rlev1,rlev2,rlev3,

               kil0,kil1,kil2,kil3,kil4,

               make0,make1,make2,

               alr,vmoi,einb,klsi,vnia,
               aeli,bxai,zeil,jlsi,lmie,
               vmlia,lhjbi,bnmui,liem,rali,

               LargeTr,HugeTr,FabTr,

{trcharges records origin:}
               Snow_Quest,Snowball,Snow_Fu,
               Sapph_Ring,Sapph_Fu,
               Lucky_Penny,Luck_Fu,
               Gods_Quest,Gods_Fu,
               Amulet,Mermaid_Fu,

               RA_Riddle,RA_Coffin,RA_Bridge,RA_Candle,RA_Smoke,RA_Owner,RA_Man,
               Kill_Quest,Kill_Fu,
               Contract,Contract_Fu,

               notreasure,
               Crown_Rohan,Amulet_Power,Scepter_Life,
                 Map_Marauders,Fang_Vampire,Hammer_Power,{Arcane's Valor}
               etr7,etr8,etr9,etr10,
               etr11,etr12,etr13,etr14,etr15,etr16,etr17,etr18,etr19,etr20);

    trstrs = array[treasure] of Str30;
    trbytes = array[treasure] of byte;

type
    spell = (Resurrection,Part_Sea,Bless,Holy_Symbol,
      Skeletal_Army,Kill_Enemy,Plague,Hand_Of_Death,
      Flood,Tornado,Earthquake,Fireball,
      Charm,Oratory,Clairvoyance,Psychic_Blast,
      Illus_Terrain,Illus_Armies,Hide_Feature,Invisibility,
      Spiritwrack,Control_Undead,Ice_Suspend,Telek_Storm,
      Mirror_Image,

      Gate_Angel,Heal, {25+}
      Scar_Terrain,Gate_Demon,
      Mystic_Winds,Lava_Pool,
      Locate_Object,Augur_Combat,
      Illus_Fog,Illus_Hero,

      nospell,
      es1,es2,es3,es4,es5,es6,es7,es8,es9,es10,
      es11,es12,es13,es14,es15,es16,es17,es18,es19,es20);

    sstrs = array[spell] of str30;
    sdinks = array[spell] of string[2];
    spbyte = array[spell] of byte;

const
    ssdex: array[Gate_Angel..Illus_Hero] of byte =
      (C_GA,C_WH, C_ST,C_GD, C_MW,C_LP, C_LO,C_AC, C_IF,C_IH);

    spname: sstrs = ('Resurrection','Part Sea','Bless','Holy Symbol',
      'Skeletal Army','Kill Enemy','Plague','Hand Of Death',
      'Flood','Tornado','Earthquake','Fireball',
      'Charm','Oratory','Clairvoyance','Psychic Blast',
      'Illusory Terrain','Phantasmal Armies','Hide Feature','Invisibility',
      'Spiritwrack','Control Undead','Ice Suspension','Telekinetic Storm',
      'Mirror-Image Phantasm',

      'Gate Angel','Words of Healing',
      'Scar Terrain','Gate Demon',
      'Mystic Winds','Lava Pool',
      'Locate Object','Augur Combat',
      'Illusory Fog','Illusory Hero',

      'Extra Spell 1','Extra Spell 2','Extra Spell 3','Extra Spell 4','Extra Spell 5',
      'Extra Spell 6','Extra Spell 7','Extra Spell 8','Extra Spell 9','Extra Spell 10',
      'Extra Spell 11','Extra Spell 12','Extra Spell 13','Extra Spell 14','Extra Spell 15',
      'Extra Spell 16','Extra Spell 17','Extra Spell 18','Extra Spell 19','Extra Spell 20',
      'No spell');
{$IFDEF Moderator}
    {3 = illegal, 1 = only illegal if on another player's land,
     2= only illegal if on another player's character, 0 = legal always}
    splate: spbyte = (0,1,1,0,
      1,2,3,0,
      3,1,3,0,
      2,2,3,0,
      3,2,0,0,

      0,0,0,0,0,

      3,0,
      1,0,
      2,0,
      0,0,
      0,0,

      0,0,0,0,0,
      0,0,0,0,0,
      0,0,0,0,0,
      0,0,0,0,0,
      0);

{$ENDIF}

    spab: sdinks = ('RE','PA','BL','HO',
      'SK','KI','PL','HA',
      'FL','TO','EA','FI',
      'CH','OR','CL','PS',
      'IL','PH','HI','IN',
      'SP','CO','IC','TE',
      'MI',

      'GA','WH',
      'ST','GD',
      'MW','LP',
      'LO','AC',
      'IF','IH',

      'S1','S2','S3','S4','S5',
      'S6','S7','S8','S9','SA',
      'SB','SC','SD','SE','SF',
      'SG','SH','SI','SJ','SL',

      'NS');

type
    discovery =
      (fix0,fix1,fix2,fix3,fix4,
       fix5,fix6,fix7,fix8,fix9,

       wreck0,wreck1,wreck2,wreck3,wreck4,
       wreck5,wreck6,wreck7,wreck8,wreck9,

       bild10,bild11,bild12,bild13,
       bild20,bild21,bild22,bild23,
       bild30,bild31,bild32,bild33,
       bild40,bild41,bild42,bild43,

       crunch0,crunch1,crunch2,crunch3,crunch4,
       crunch5,crunch6,crunch7,crunch8,crunch9,
       crunch10,crunch11,crunch12,crunch13,crunch14,
       crunch15,crunch16,crunch17,crunch18,crunch19,
       crunch20,crunch21,crunch22,crunch23,crunch24,
       crunch25,crunch26,crunch27);

    dstrs = array[discovery] of str40;
    discbyte = array[discovery] of byte;

const ndisc = 64;
    discval: discbyte = (19,19,20,20,18,18,3,3,3,3,
       17,17,2,2,2,2,16,16,1,1,
       17,17,18,2,
       17,18,15,2,
       14,17,16,2,
       17,18,1,1,
       10,11,12,13,
       10,11,12,13,
       10,11,12,13,
       10,11,12,13,
       10,11,12,13,
       10,11,12,13,
       10,11,12,13);


type
    feature = (Pyramid,Tomb,Catacombs,Crypt,Cave,
      Cavern,VolcTunnel,Dungeon,Maze,Labyrinth,
      Tower,Castle,GreatHall,Monastery,Temple,
      PetForest,SacredRock,ASMonument,Altar,DesRuins,
      SunkCity,LostCity,LostTemple,HollowTree,Glade,
      HangValley,MountPeak,MagPool,Loch,UndCavern,
      Maelstrom,Noftype,ef1,ef2,ef3,ef4,ef5,ef6,ef7,ef8,ef9,ef10);


      fstrs = array[feature] of str20;

const
    ftname: fstrs = ('Pyramid','Tomb','Catacombs','Crypt','Cave',
      'Cavern','Volcanic Tunnel','Dungeon','Maze','Labyrinth',
      'Tower','Castle','Great Hall','Monastery','Temple',
      'Petrified Forest','Sacred Rock','Ancient Megaliths','Altar','Desert Ruins',
      'Sunken City','Lost City','Lost Temple','Hollow Tree','Glade',
      'Hanging Valley','Mountain Peak','Magic Pool','Loch','Undersea Cavern',
      'Maelstrom','encounter area',
      'f1','f2','f3','f4','f5','f6','f7','f8','f9','f10');

type monfeat = array[monster] of feature;

{$IFDEF Moderator}
const mfeat1: monfeat = (PetForest,PetForest,LostCity,PetForest,PetForest,
       Pyramid,Pyramid,Pyramid,Tower,Tower,
       Pyramid,Tower,PetForest,PetForest,PetForest,Pyramid,
       Pyramid,Pyramid,Pyramid,Pyramid,Pyramid,Pyramid,

       HollowTree,HollowTree,Tower,Pyramid,Pyramid,Pyramid,Pyramid,
       Pyramid,Pyramid,Pyramid,Pyramid,Pyramid,
       Pyramid,Pyramid,Pyramid,Pyramid,Pyramid,Pyramid,
       Pyramid,Maze,HollowTree,HollowTree,PetForest,PetForest,

       PetForest,PetForest,PetForest,Pyramid,Pyramid,
       Pyramid,Pyramid,Pyramid,Pyramid,MagPool,MagPool,
       MagPool,MagPool,MagPool,Tomb,Tomb,
       Tomb,Tomb,Tomb,Tomb,Tomb,Tomb,Tomb,Tomb,Tomb);

     mfeat2: monfeat = (MountPeak,MountPeak,LostTemple,MountPeak,SunkCity,
       Labyrinth,Labyrinth,Labyrinth,LostTemple,LostTemple,
       MountPeak,Temple,MountPeak,MountPeak,MountPeak,MountPeak,
       MountPeak,MountPeak,MountPeak,MountPeak,MountPeak,MountPeak,

       HangValley,HangValley,Temple,LostTemple,LostTemple,HangValley,MountPeak,
       Dungeon,Dungeon,Dungeon,Dungeon,Dungeon,
       Dungeon,Dungeon,MountPeak,HangValley,HangValley,HangValley,
       MountPeak,Labyrinth,HangValley,HangValley,HangValley,HangValley,

       HangValley,HangValley,HangValley,Crypt,Crypt,
       Crypt,Crypt,Crypt,Crypt,Maelstrom,Maelstrom,
       Maelstrom,Maelstrom,Maelstrom,Tomb,
       Tomb,Tomb,Tomb,Tomb,Tomb,Tomb,Tomb,Tomb,Tomb,Tomb);
{$ENDIF}
{$IFDEF Noble}
type
    terrain = (MTNS,HILLS,PLAINS,SWAMP,SEA,
                 noterr,et1,et2,et3);
    water =   (nowater,R1,R2,R3,R4,
                 R5,R6,R0,WATERWAY,ISLAND,L_ISLE,
                 LAKE,WSEA,OCEAN,LAKE1,LAKE2,LAKE3,LAKE4,LAKE5,LAKE6);
    vegie =   (novegie,WASTELAND,TUNDRA,DESERT,CLEAR,GRASSLAND,
                 MIXED,FOREST,JUNGLE,URBAN,BANKS,
                 SHELF,ABYSS);

    clime = (No_Clime,Arctic,Cold,Cool,Steppy,Temperate,Warm,Hot,Tropical);

    clarr = array[xcrange,ycrange] of clime;
    clstrs = array[clime] of str10;

    racket = (No_Racket,Agric,Forestry,Rangeland,Fishing,
              Shipping,Drugs,Slaves,Crafts,Clothing,
              Mining,Religious,Attraction,Imperial,Military,
              Caravan,sr16,sr17,sr18,sr19,
              sr20,sr21,sr22,sr23,sr24,
              sr25,sr26,sr27,sr28,sr29,
              sr30,sr31,sr32,sr33,sr34,
              sr35,sr36,sr37,sr38,sr39,
              sr40,sr41,sr42,sr43,sr44,
              sr45,sr46,sr47,sr48,sr49);

    rastrs = array[racket] of Str10;

const
    clname: clstrs = ('No Clime','Arctic',' Cold','Cool','Steppy',
        'Temperate','Warm','Hot','Tropical');

const rackname: rastrs = ('No_Racket','Agric','Forestry','Rangeland','Fishing',
              'Shipping','Drugs','Slaves','Crafts','Clothing',
              'Mining','Religious','Attraction','Imperial','Military',
              'Caravan','sr16','sr17','sr18','sr19',
              'sr20','sr21','sr22','sr23','sr24',
              'sr25','sr26','sr27','sr28','sr29',
              'sr30','sr31','sr32','sr33','sr34',
              'sr35','sr36','sr37','sr38','sr39',
              'sr40','sr41','sr42','sr43','sr44',
              'sr45','sr46','sr47','sr48','sr49');

type city = (No_City,Paris,Tours,Rouen,Poitiers,
             Bordeaux,Toulouse,Narbonne,Dijon,Marseilles,
             Lyons,Nantes,Bruges,Troyes, Dublin,
             Abberfraw,Edinburgh,Portsmouth,London,Chester,
             York,Man,  Oslo,Bergen,Trondheim,

             Uppsala,Wisby,Roskilde,Lund,Reykjavik,
             Lulea,Helsinki,  Pamplona,Coruna,Bilbao,
             {if Aragon, add Huesca}
             CBarcelona,Lisbon,CCordova,Seville,CBadajoz,
             CToledo,Almeria,CSaragossa,  Cologne,Trier,
             Bremen,Madgeburg,Mainz,Strasbourg,Regensburg,

             Prague,Danzig,Amsterdam,Vienna,  CVenice,
             CMilan,CGenoa,CPisa,Rome,Bridisi,
             Palermo,CAmalfi,Pavia,Salerno,  Memel,
             Riga,  Budapest,Warsaw,Krakow,Satu_Mare,
             Belgrade,Skopje,Ragusa,Zara,  CKiev,

             CNovgorod,CSmolensk,CMoscow,Galicz,CTumarakan,
             Sarkel,Bulgar,Gorki,Voronezh,Itil,
             Uralsk,Kraznovodsk,Aralsk,Kazalinsk,Bucharest,
             Odessa,Donetsk,  Adrianople,Corinth,Salonika,
             Constan,Trebizond,Sinope,Antioch,Tarsus,

             Melitene,Nicaea,Ankara,Smyrna,Adalia,
             Candia,Famagusta,Cherson,  Kutaisi,Tiflis,
             Ani,Grozny,Soch,  Fez,Tangier,
             Oran,Algiers,Tunis,Kairouan,Tripoli,
             Djelfa,  Barca,Alexandria,Cairo,Damietta,

             Asyut,Aydhab,Jerusalem,Acre,Suez,
             Aqabah,Medina,Mecca,  Hail,Riyadh,
             Kuwait,Damascus,Sidon,STripoli,Aleppo,
             CEdessa,CMosul,Baghdad,Kufa,Wasit,
             Basra,  Irbil,Baku,Derbent,Tabriz,

             Astarabad,Rayy,Nishapur,Merv,CHamadan,
             CEsfahan,Shiraz,Ahvaz,  Gurganj,Bukhara,
             Samarkand,Tashkent,Breslau,Cagliari,Mallorca,
             Vladimir,Ryazan,Stettin,C168,C169,
             C170,C171,C172,C173,C174,

             C175,C176,C177,C178,C179,
             C180,C181,C182,C183,C184,
             C185,C186,C187,C188,C189,
             Yukon,Anchorage,Vancouver,Quebec,Hudson_Bay,
               New_York,New_Orleans,St_Louis,California,Oregon,
             Mexico,Panama,West_Indies,Brazil,Peru,
               Argentina,  Ghana,Guinea,Congo,Capetown,
             Madagascar,Mozambique,Zanzibar,Somaliland,Ethiopia,
             Sudan,Rhodesia,  Yemen,Oman,Pakistan,
             Afghanistan,Bombay,Madras,Calcutta,Delhi,
             Tibet,Burma,Thailand,Indochina,Canton,
             Foochow,Shanghai,Peking,Wuhan,Chungking,
             Tien_Shan,Mongolia,Siberia,Manchuria,Korea,
             Japan,East_Indies,Phillipines,Australia,New_Zealand,
             Antarctica, C246,C247,C248,C249);

    rackarr = array[city,1..20] of racket;

    cxyarr = array[xcrange,ycrange] of city;

    vegstrs = array[vegie] of str20;
    vegbytes = array[vegie] of byte;
    vegchars = array[vegie] of char;

    h2ostrs = array[water] of str20;
    h2obytes = array[water] of byte;
    h2ochars = array[water] of char;

    vegarr = array[xcrange,ycrange] of vegie;
    h2oarr = array[xcrange,ycrange] of water;

const
    vcolor: vegbytes = (15,13,11,12,15,14,
                         10,2,10,4,10,
                         11,9);

    h2oname: h2ostrs = ('No waterway','River','River','River','River','River',
                        'River','River','Waterway','Island','Large Isle',
                        'Lake','Sea','Ocean','LAKE1','LAKE2','LAKE3','LAKE4','LAKE5','LAKE6');

    vegname: vegstrs = ('None','Wasteland','Tundra','Desert','Clear','Grassland',
                        'Mixed','Forest','Jungle','Urban','Banks',
                        'Shelf','Abyss');

type
    terstrs = array[terrain] of str20;
    terbytes = array[terrain] of byte;
    terchars = array[terrain] of char;

const
    tername: terstrs = ('Mountain','Hill','Plain','Swamp','Sea',
      'No Terrain');
    tercolor: terbytes = (7,6,0,3,1,5);
    renc: terbytes = (20,20,10,20,5,0);
    terc: terchars = ('^','~','_','@',' ',' ');
    terexp: terbytes = (15,20,50,15,25,0);
    lastland = SWAMP;
    firstland = MTNS;

    religion =   (norel,
               Jewish,
               Catholic,Orthodox,Protestant,Monophysite,C5,
               Sunni,Shiite,Sufi,I4,I5,
               Norse,Slavic,Animist,Finnic,Steppic,
               Hinayana,Mahayana,Lamaism,B4,B5,
               Confucian,Taoist,Shinto,E4,E5,
               M1,M2,M3,M4,M5);


    relstrs = array[religion] of str10;
    relbytes = array[religion] of byte;
    relchars = array[religion] of char;

const
    rcolor: relbytes = (0,
                        11,
                        15,13,15,15,15,
                        14,12,11,12,12,
                        10,10,10,10,10,
                        9,9,9,9,9,
                        9,9,9,9,9,
                        9,9,9,9,9);

    relname: relstrs = ('None',
               'Jewish',
               'Catholic','Orthodox','Protestant','Monophysite','C5',
               'Sunni','Shiite','Sufi','I4','I5',
               'Norse','Slavic','Animist','Finnic','Steppe',
               'Hinayana','Mahayana','Lamaism','B4','B5',
               'Confucian','Taoist','Shinto','E4','E5',
               'M1','M2','M3','M4','M5');

type people = (norace,
               Irish,Welsh,Scottish,Breton,
               Basque,
               Gothic,Frankish,Germanic,Dutch,English,
               Italian,
               Norwegian,Swedish,Danish,
               Prussian,Lithuanian,
               Finnish,Estonian,Lapps,Mordvins,Pomeranians,Cheremiss,Burtas,
               Hungarian,
               Russian,Polish,
               Bulgarian,Serbs,Croats,
               Romanian,
               Khazar,Cumans,Alans,
               Indian,
               Oghuz,Pecheneg,
               Georgian,
               Mongolian,
               Illyrian,
               Greek,
               Moorish,Arab,Berber,
               Persian,Armenian,Kurdish,
               African,
               Egyptian,Palestinian,Syrian,Iraqi,Yemeni,
               Czech,Slovak,Catalan,Portuguese,Flemish,
               Albanian,Iberian,Karakhanids,
               RP0,RP1,RP2,RP3,RP4,RP5,RP6,RP7,RP8,RP9,
               RP10,RP11,RP12,RP13,RP14,RP15,RP16,RP17,RP18,RP19,
               RP20,RP21,RP22,RP23,RP24,RP25,RP26,RP27,RP28,RP29,
               RP30,RP31,RP32,RP33,RP34,RP35,RP36,RP37,RP38,RP39,
               RP40,RP41,RP42,RP43,RP44,RP45,RP46,RP47,RP48,RP49);

      pcolor: rbytes = (9,
                  15,10,14,8,
                  12,
                  11,13,4,15,10,
                  14,
                  8,12,11,
                  13,4,
                  15,10,14,8,12,11,13,
                  4,
                  15,10,
                  14,8,12,
                  11,
                  13,4,15,
                  8,
                  10,14,
                  8,
                  12,
                  11,
                  13,
                  4,15,10,
                  14,8,12,
                  11,
                  13,4,15,10,14,
                  8,12,11,13,4,
                  14,10,15,
                  10,14,8,12,11,13,4,15,5,4,
                  10,14,8,12,11,13,4,15,5,4,
                  10,14,8,12,11,13,4,15,5,4,
                  10,14,8,12,11,13,4,15,5,4,
                  10,14,8,12,11,13,4,15,5,4);

const rname: rstrs = ('no People','Irishman','Welshman','Scot','Breton',
               'Basque',
               'Goth','Frank','German','Dutchman','Englishman',
               'Italian',
               'Norseman','Swede','Dane',
               'Prussian','Lithuanian',
               'Finn','Estonian','Lapp','Mordvin','Pomeranians','Cheremis','Burta',
               'Hungarian',
               'Russian','Pole',
               'Bulgarian','Serb','Croat',
               'Romanian',
               'Khazar','Cuman','Alan',
               'Indian',
               'Oghuz','Pecheneg',
               'Georgian',
               'Mongolian',
               'Illyrian',
               'Greek',
               'Moor','Arab','Berber',
               'Persian','Armenian','Kurd',
               'African',
               'Egyptian','Palestinian','Syrian','Iraqi','Yemeni',
               'Czech','Slovak','Catalan','Portuguese','Flemish',
               'Albanian','Iberian','Karakhanid',
               'RP0','RP1','RP2','RP3','RP4','RP5','RP6','RP7','RP8','RP9',
               'RP10','RP11','RP12','RP13','RP14','RP15','RP16','RP17','RP18','RP19',
               'RP20','RP21','RP22','RP23','RP24','RP25','RP26','RP27','RP28','RP29',
               'RP30','RP31','RP32','RP33','RP34','RP35','RP36','RP37','RP38','RP39',
               'RP40','RP41','RP42','RP43','RP44','RP45','RP46','RP47','RP48','RP49');

type house = (
{**12}           Capetians,Anjou(*Maine-Anjou-Blois*),Normandy,Aquitaine,Gascony,
                 CToulouse,Fr_Burgundy,Lo_Burgundy,Up_Burgundy,Brittany,
                     Flanders,Champagne,
{*8}            Ireland,Wales,Scotland,
                 Wessex,Essex,Northumbria,Mercia,
                     Orkney,
{6}            Norway,Sweden,Denmark,
                   Iceland,Lapland,Finland,
{*11}            Navarre,Asturias,Castile,Aragon,Barcelona,Portugal,{A French/Spanish knightly destiny}
                 Cordova,Badajoz,Toledo,Granada,Saragossa,
{11}           LoLorraine,UpLorraine,Saxony,Franconia,Alemannia,Bavaria,
                 Bohemia,Caspian,{or 3 marcher lordships to saxony etc.?}Frisia,
                     Carinthia,Red_Sea,{same?}
{9}            Venice,Milan,Genoa,Pisa_Florence,
                Papal_States,S_Italy,Sicily,
                   Amalfi,Lombardy,
{*3}            Pomerania,Volhynia,Lithuania,
                   (*Esthonia*)
{6}            Hungary,Poland,Romania{Transylvania},
                 Free_Bulgaria,Serbia,Croatia,
{9}            Kiev,Novgorod,Smolensk,Moscow,Galicia,Tmutarakan, {Incl. Sarkel?}
                  Volga_Bulgaria,Cheremissia,Mordvinia,
{*6}            Khazaria,Ural_Ogs,Seljuk_Ogs,Othman_Ogs,Kangar_Pech,Boro_Pech,
{7}            Byz_Bulgaria,Greece,Thrace,
                 Byz_Armenia,Cappadocia,Opsicia,Anatolia,
{3}           (*Iberia*)Georgia,Armenia,Alania,
{*5}            Morocco,Berberia,Algeria,Tunisia,Barbary_Coast,
{*7}           Cyrenacia,Up_Egypt,Mid_Egypt,Lo_Egypt,
                 Palestine,N_Hejaz,S_Hejaz,
{*9}           Arabia,Syria,Edessa,Diyarbekr,Mosul,Bu_Baghdad,Bu_Basrah,Bu_Kufa,
                 Ab_Caliphate,
{*11}          Kurdistan,S_Azerbaijan,N_Azerbaijan,
                 Tabaristan,Khorasan{Ghazn.},Hamadan,Esfahan,Fars,
                   Khwarizm,Sughd,Farghana,
               Baltic,Atlantic,Mediter,Black_Sea,No_House {or, for noleader?} );

    rarr = array[xcrange,ycrange] of religion;
    harr = array[xcrange,ycrange] of house;
    hstrs= array[house] of str20;
    rstrs= array[people] of string[12];
    rabs = array[people] of string[3];
    rbytes = array[people] of byte;
    hbytes = array[house] of byte;
    cstrs = array[city] of Str10;
    cbytes = array[city] of byte;

const hcolor: hbytes = (15,10,14,8,12,11,13,4,5,2,
                        15,10,14,8,12,11,13,4,5,2,
                        15,10,14,8,12,11,13,4,5,2,
                        15,10,14,8,12,11,13,4,5,2,
                        15,10,14,8,12,11,13,4,5,2,
                        15,10,14,8,12,11,13,4,5,2,
                        15,10,14,8,12,11,13,4,5,2,
                        15,10,14,8,12,11,13,4,5,2,
                        15,10,14,8,12,11,13,4,5,2,
                        15,10,14,8,12,11,13,4,5,2,
                        15,10,14,8,12,11,13,4,5,2,
                        15,10,14,8,12,11,13,4,5,2,
                        15,10,14,8,12,11,13,4);

      city1 = No_City; cityf = C249;

const thname: hstrs = (
              'King of','Duke of',(*Maine-A-B*)'Duke of','Duke of','Duke of',
                'Count of','Duke of'{French},'King of',{Coastal}'Count of'{Upper},'Duke of',
                  'Count of','Count of',
              'King of','King of','King of',
                'King of'{Wessex},'Earl of','Earl of','Earl of',
                  'Jarl of',
              'King of','King of','King of',
                'Elders of','Elders of ','Elders of ',
              'King of ','King of ','Count of ','Count of ','Count of ','Count of ',{A French/Spanish knightly destiny}
                'Caliph of ','Emir of ','Emir of ','Emir of ','Emir of ',
              'Duke of ','Duke of ','Duke of ','Duke of ','Duke of ','Duke of ',
                'Duke of ','Marquis of ','Duke of ',
                  'Duke of ','Count of ',{same?}
              'Doge of ','Free City-State of ','Free City-State of ','Free City-State of ',
                'Pontiff of the ','Strategos of ','Emir of ',
                  'Free City-State of ','King of ',
              'Elders of ','Elders of ','Elders of ',
                {Esthonia: to Finland}
              'King of ','King of ','Elders of '{Transylvanian Vlachs},
                'King of ','King of ','King of ',
              'Grand Prince of ','Republic of ','Prince of ','Prince of ','Prince of ','Prince of ', {Incl. Sarkel?}
                'King of ','Elders of ','Elders of ',
              'Kagan of ','Khan of ','Khan of ','Khan of ','Khan of ','Khan of ',
                'Strategos of ','Strategos of ','Emperor of ',
                  'Strategos of ','Strategos of ','Strategos of ','Strategos of ',
             'King of '{Incl. Iberia},'Princes of ','Khan of ',
             'Emir of ','Elders of ','Emir of ','Emir of ','Emir of ',
               'Emir of '{Cyrenaica},'Emir of ','Fatimid Caliph of ','Emir of ',
                 'Emir of ','Emir of ','Emir of ',
             'Emir of ','Emir of ','Emir of ','Emir of ','Emir of ',
               'Emir of '{Buhid},'Emir of ','Emir of ',
                 'Abbasid Caliph of ',{Abbasid}
             'Emir of ','Emir of ','Emir of ',
               'Shah of ','Emir of '{Ghazna},'Shah of ','Shah of ','Shah of ',
                 'Khan of ','Khan of ','Khan of ',
             'Grand Master of ','Grand Master of ','Grand Master of ','Grand Master of ','No King');

{$ELSE}

type
    terrain = (PLAINS,DESERT,JUNGLE,FOREST,MTNS,SEA,noterr,
      SWAMP,LAVA,{=lastdev!!}ET1,ET2,ET3,ET4,ET5);
    terstrs = array[terrain] of str20;
    terbytes = array[terrain] of byte;
    terchars = array[terrain] of char;

const
    lastdev = Lava;
    tername: terstrs = ('Plain','Desert','Jungle','Forest','Mountain',
      'Sea','No Terrain','Swamp','Lava',
      'ExTer1','ExTer2','ExTer3','ExTer4','ExTer5');
    btercolor: terbytes = (0,7,0,0,6, 1,5,3,4,0,0,0,0,0);
    ftercolor: terbytes = (2,15,2,2,7, 11,5,2,7,0,0,0,0,0);
    terfreq: terbytes =   (10,60,75,60,25, 0,0,25,25,0,0,0,0,0);
    old_tercolor: terbytes = (8,7,3,2,6, 1,0,5,4,0,0,0,0,0);
    old_terbackg: terbytes = (0,7,3,2,6, 1,5,5,4,5,5,5,5,5);

    renc: terbytes = (10,15,25,20,15, 5,0,20,5,0,0,0,0,0);
    old_terc: terchars = ('_','.','&','+','^', ' ',' ','-','~',' ',' ',' ',' ',' ');
    new_terc: terchars = (#139,#139,#158,#$91,#169,  ' ',' ',#139,#169,' ',' ',' ',' ',' ');
    disp_terc: terchars = (#140,#140,#159,#$92,#243,' ',' ',#140,#243,' ',' ',' ',' ',' ');
    terexp: terbytes = (50,25,10,15,15, 25,0,10,10,20,20,20,20,20);
    lastland = MTNS;
    firstland = Plains;
{$ENDIF}

{$IFNDEF Noble}
type
    army = (garrison,bowmen,axemen,phalanx,legion,lcav,
      hcav,chariots,elephants,camels,wargriders,
      dragonwing,eaglewing,whaleleague,fleet,noarmy,
      mermen,ents,trolls,weres,dinosaurs,
      vampires,marauders,ea3,ea4,ea5,
      ea6,ea7,ea8,ea9,ea10,
      ea11,ea12,ea13,ea14,ea15,
      ea16,ea17,ea18,ea19,ea20);



    quality = (Depleted,Green,Average,Veteran,Crack,Elite);

type
    ararr = array[army] of shortint;
    arabs = array[army] of string[2];
    arstrs = array[army] of str20;
    ardes = array[army] of string[9];
    arterr = array[army] of terrain;
    arnemarr = array[army] of army;
    racearms = array[race] of army;
    state = (Dead,Hired,Mercenary,Zomboid,Bold,Sold,Loser,Calm);
    qstrs = array[quality] of str20;
    ststrs = array[state] of str20;
    qbyte = array[quality] of byte;


const
    lastarmy = vampires;
    best_atype: racearms = (Legion,Bowmen,Axemen,Phalanx,
      dragonwing,eaglewing,whaleleague,noarmy,Mermen,
      ents,trolls,weres,dinosaurs,vampires,lcav,ea3,ea4,ea5,
      ea6,ea7,ea8,ea9,ea10);
    need_arace: array[army] of race =
     (Human,Human,Human,Human,Human,Human,
      Human,Human,Human,Human,Orcish,
      Dragons,Eagles,Whales,Human,Norace,
      Mermish,ENtish,Trollish,Werefolk,Saurian,
      Vampish,Human,er3,er4,er5,
      er6,er7,er8,er9,er10,
      er3,er3,er3,er4,er5,
      er6,er7,er8,er9,er10);


    qname: qstrs = ('Depleted','Green','Average','Veteran','Crack','Elite');
    qimpr: qbyte = (100,25,5,1,0,0);


const
    atdesig: ardes = ('Garrison','Bowmen','Axemen','Phalanx','Legion','Lt Cav',
      'Hvy Cav','Chariots','Elephants','Camels','Wargs',
      'Dragons','Eagles','League','Fleet','None',
      'Mermen','Ents','Trolls','Weres','Dinosaurs',
      'Vampires','Marauders','ea3','ea4','ea5',
      'ea6','ea7','ea8','ea9','ea10',
      'ea11','ea12','ea13','ea14','ea15',
      'ea16','ea17','ea18','ea19','ea20');
    atab: arabs = ('Ga','Bo','Ax','Ph','Le','LC',
      'HC','Ch','El','CC','WR',
      'Dr','Ea','Wh','Fl','--','Me','En','Tr','We','Di',
      'Va','Ma','a3','a4','a5',
      'a6','a7','a8','a9','aA',
      'aB','aC','aD','aE','aF',
      'aG','aH','aI','aJ','aK');
    atab2: arabs = ('GA','BO','AX','PH','LE','LC',
      'HC','CH','EL','CC','WR',
      'DR','EA','WH','FL','','ME','EN','TR','WE','DI',
      'VA','MA','a3','a4','a5',
      'a6','a7','a8','a9','aA',
      'aB','aC','aD','aE','aF',
      'aG','aH','aI','aJ','aK');
    atspeed: ararr = (1,2,2,2,2,4, 3,3,2,3,3, 5,5,4,2, 0, 3,1,2,3,3,
    4,3,3,3,3,
    3,3,3,3,3,
    3,3,3,3,3,
    3,3,3,3,3);

    atname: arstrs = ('Garrison','Bowmen','Axemen','Phalanx','Legion','Light Cavalry',
      'Heavy Cavalry','Chariots','Elephants','Camel Corps','Warg Riders',
      'Dragons','Eagles','Whales','Fleet','None',
      'Mermen','Ents','Trolls','Were-Beasts','Dinosaurs',
      'Vampires','Marauders','ea3','ea4','ea5',
      'ea6','ea7','ea8','ea9','ea10',
      'ea11','ea12','ea13','ea14','ea15',
      'ea16','ea17','ea18','ea19','ea20');

    ach: array[army] of char =
      (#9,'}',#175,#240,#237,#11,
       #26,#232,#144,#234,#153,
       #21,#238,#247,#29,'?',
       #$F8,#$E2,#$E4,#$E5,#244,
       #254,#255,'|','|','|',
       '|','|','|','|','|',
       '|','|','|','|','|',
       '|','|','|','|','|');

    athome1: arterr = (noterr,forest,forest,plains,noterr,plains,
      plains,plains,forest,desert,noterr,
      noterr,mtns,sea,sea, noterr,
      sea,jungle,mtns,forest,noterr,
      noterr,swamp,noterr,noterr,noterr,
      noterr,noterr,noterr,noterr,noterr,
      noterr,noterr,noterr,noterr,noterr,
      noterr,noterr,noterr,noterr,noterr);
    athomef: arterr = (noterr,forest,mtns,plains,noterr,desert,
      plains,plains,forest,desert,noterr,
      noterr,mtns,sea,sea, noterr,
      swamp,forest,mtns,mtns,noterr,
      noterr,swamp,noterr,noterr,noterr,
      noterr,noterr,noterr,noterr,noterr,
      noterr,noterr,noterr,noterr,noterr,
      noterr,noterr,noterr,noterr,noterr);
    atadv1: arterr = (noterr,noterr,noterr,jungle,sea,jungle,
      jungle,jungle,forest,jungle,sea,
      noterr,jungle,plains,plains, noterr, desert,desert,sea,sea,sea,
      desert,plains,noterr,noterr,noterr,
      noterr,noterr,noterr,noterr,noterr,
      noterr,noterr,noterr,noterr,noterr,
      noterr,noterr,noterr,noterr,noterr);
    atadvf: arterr = (noterr,noterr,noterr,sea,sea,sea,
      sea,sea,sea,sea,sea,
      noterr,forest,mtns,mtns, noterr, mtns,desert,sea,sea,sea,
      desert,desert,noterr,noterr,noterr,
      noterr,noterr,noterr,noterr,noterr,
      noterr,noterr,noterr,noterr,noterr,
      noterr,noterr,noterr,noterr,noterr);
    atstren: ararr = (3,2,2,3,3, 2,4,3,1,2, 3,6,4,5,3, 0, 2,6,5,3,5,
      4,3,3,3,3,
      3,3,3,3,3,
      3,3,3,3,3,
      3,3,3,3,3);

    atnem1: arnemarr = (dinosaurs,noarmy,noarmy,legion,hcav,chariots,
      chariots,elephants,noarmy,noarmy,eaglewing,
      bowmen,bowmen,mermen,noarmy, noarmy, bowmen,axemen,axemen,noarmy,Phalanx,
      bowmen,lcav,noarmy,noarmy,noarmy,
      noarmy,noarmy,noarmy,noarmy,noarmy,  {CHeck Nemo function in rumors.pas}
      noarmy,noarmy,noarmy,noarmy,noarmy,  {carefully!!!}
      noarmy,noarmy,noarmy,noarmy,noarmy);
    atnemf: arnemarr = (dinosaurs,noarmy,noarmy,legion,hcav,dragonwing,
      dragonwing,dragonwing,noarmy,noarmy,eaglewing,
      bowmen,bowmen,mermen,noarmy, noarmy, bowmen,axemen,axemen,noarmy,Phalanx,
      bowmen,lcav,noarmy,noarmy,noarmy,
      noarmy,noarmy,noarmy,noarmy,noarmy,
      noarmy,noarmy,noarmy,noarmy,noarmy,
      noarmy,noarmy,noarmy,noarmy,noarmy);

{$ELSE}
type
    retainer = (Noret,Heralds,Armorers,Entertainers,Courtesans,Engineers,
            Spies,Diplomats,Monks,Artists,Rt0,
            Rt1,Rt2,Rt3,Rt4,Rt5,
            Rt6,Rt7,Camels,Horses,Paladins,
            Rangers,Guardsmen,Bowmen,Light_Inf,Medium_Inf,
            Heavy_Inf,Light_Cav,Medium_Cav,Heavy_Cav,Chariots,
            Elephants,Riverboat,Longship,Galley,Transport,
            Knights,Longbow,Crossbow,Slingers,Grenadiers,
            Ex5,Ex6,Ex7,Ex8,Ex9,
            Ex10,Ex11,Ex12,Ex13,Ex14,
            Ex15,Ex16,Ex17,Ex18,Ex19);
    ararr = array[retainer] of byte;
    arabs = array[retainer] of string[2];
    arstrs = array[retainer] of str20;
    ardes = array[retainer] of string[9];
    arterr = array[retainer] of terrain;
    arnemarr = array[retainer] of retainer;

const
    atab: arabs = ('--','He','Ar','En','Co','Sa',
      'Sp','Di','Ho','Cr','R0',
      'R1','R2','R3','R4','R5',
      'R6','R7','R8','R9','Pa',
      'Rg','Gd','Bo','LI','MI',
      'HI','LC','MC','HC','Ch',
      'El','RB','LS','Ga','Tr',
      'E0','E1','E2','E3','E4',
      'E5','E6','E7','E8','E9',
      'F0','F1','F2','F3','F4',
      'F5','F6','F7','F8','F9');

    atspeed: ararr = (
                      0,10,10,10,10,10,
                      15,10,10,10,10,
                      10,10,10,10,10,
                      10,10,10,10,12, {x-champs}
                      15,10,8,8,7,6,    {Rangers-HI}
                      14,12,10,9,6, {lc-el}
                      90,100,80,60, {rivbs-Transports}
                      0,0,0,0,0,
                      0,0,0,0,0,
                      0,0,0,0,0,
                      0,0,0,0,0);

    atdesig: ardes = ('None','Heralds','Armorers','Entertainers','Courtesans','Engineers',
      'Spies','Diplomats','Holy Men','Craftsmen','Retain0',
      'Retain1','Retain2','Retain3','Retain4','Retain5',
      'Retain6','Retain7','Retain8','Retain9','Paladins',
      'Rangers','Guardsmen','Bowmen','Lt Inf','Med Inf',
      'Hvy Inf','Lt Cav','Med Cav','Hvy Cav','Chariots',
      'Elephants','Riverboats','Longships','Galleys','Transports',
      'Extra0','Extra1','Extra2','Extra3','Extra4',
      'Extra5','Extra6','Extra7','Extra8','Extra9',
      'Extra10','Extra11','Extra12','Extra13','Extra14',
      'Extra15','Extra16','Extra17','Extra18','Extra19');

    at_cost: ararr = (0,10,4,6,7,8,
                      7,10,5,4,0,
                      0,0,0,0,0,
                      0,0,0,0,15,
                      8,10,3,2,3,
                      4,6,5,8,7,
                      7,3,4,5,4,
                      0,0,0,0,0,
                      0,0,0,0,0,
                      0,0,0,0,0,
                      0,0,0,0,0);

    ach: array[retainer] of char =
      ('?','H','A','E','C','e',
       'S','D','h','c','0',
       '1','2','3','4','5',
       '6','7','8','9','X',
       'R','G','}',#175,#240,
       #237,#11,#234,#26,#232,
       #144,#$F8,#29,#247,'T',
       '0','1','2','3','4',
       '5','6','7','8','9',
       '0','1','2','3','4',
       '5','6','7','8','9');

{$IFDEF Moderator}
    atstren: ararr = (0,9,7,2,0,4,
                      5,4,2,2,0,
                      0,0,0,0,0,
                      0,0,0,0,15,
                      9,11,5,7,9,
                      10,7,8,9,10,
                      9,9,9,9,5,
                      0,0,0,0,0,
                      0,0,0,0,0,
                      0,0,0,0,0,
                      0,0,0,0,0);

                      {open-melee strength;
                      diff=  0 = 50% chance victory
                            +1 = 60% chance change from 50%.
                            +2 = 68%  5-diff = no chance
                            +3 = 74%  5-diff = no chance
                            +4 = 80%  5-diff = no chance
                            +5 = 86%  5-diff = no chance
                            +6 = 90%  5-diff = no chance
                            +7 = 94%  5-diff = no chance
                            +8 = 96%  5-diff = no chance
                            +9 = 98%  5-diff = no chance
                            10+= 99%  5-diff = no chance}

    atshock: ararr = (0,10,6,2,0,3,
                      4,2,2,2,0,
                      0,0,0,0,0,
                      0,0,0,0,20,
                      10,12,4,6,8,

                      10,8,12,15,7,
                      20,9,9,7,3,
                      0,0,0,0,0,
                      0,0,0,0,0,
                      0,0,0,0,0,
                      0,0,0,0,0);

{$ENDIF}
    atname: arstrs =
     ('None','Heralds','Armorers','Entertainers','Courtesans','Engineers',
      'Spies','Diplomats','Holy Men','Craftsmen','Retain0',
      'Retain1','Retain2','Retain3','Retain4','Retain5',
      'Retain6','Retain7','Retain8','Retain9','Paladins',
      'Rangers','Guardsmen','Bowmen','Light Infantry','Medium Infantry',

      'Heavy Infantry','Light Cavalry','Medium Cavalry','Heavy Cavalry','Chariots',
      'Elephants','Riverboats','Longships','Galleys','Transports',
      'Extra0','Extra1','Extra2','Extra3','Extra4',
      'Extra5','Extra6','Extra7','Extra8','Extra9',
      'Extra10','Extra11','Extra12','Extra13','Extra14',
      'Extra15','Extra16','Extra17','Extra18','Extra19');

{$ENDIF}

const
{$IFDEF Moderator}
    statname: ststrs = ('Dead','Hired','Mercenary','Skeletal','Emboldened','Sold Soul','Loser','Calmed');
{$ENDIF}

    noleader = 255;
    unkldr = 254;

    Extra_Str = 0;
    Extra_CPlan = 1;
    Byte_List = 2;
    Numbers = 3;
    Nuthin = 255;

    AN_Bytes = 0;
    AT_Bytes = 1;
    Tac_Bytes = 2;

type
  efftarget = integer;
  actionrange = 0..4;
  anrange = -1..5;
  taxrange = 0..10;
  chancearr = array[0..4,firstland..noterr] of byte;
  kintarr = array[krange] of word;
  klintarr = array[krange] of longint;
  knowarr = array[lrange] of longint;
  integfile =  file of integer;
  liegearr = array[lrange] of byte;
  intarr = array[lrange] of integer;
  lintarr = array[lrange] of longint;
  dbool = array[discovery] of boolean;
  kdbool = array[krange] of dbool;
  ptarr = array[xcrange,ycrange] of terrain;
  mapbyte = array[xcrange,ycrange] of byte;
  mapint = array[xcrange,ycrange] of integer;
  map2byte = array[xcrange,ycrange,0..1] of byte;
  map2army = array[xcrange,ycrange,0..1] of army;
  aphasebyte = array[lrange] of array[actionrange] of byte;
  aphaseint = array[lrange] of array[actionrange] of integer;
  fbool = array[featrange] of byte;
  kfbool = array[krange] of fbool;
{$IFNDEF Noble}
  kmapbyte = array[krange] of mapbyte;
{$ENDIF}

  armybytes = array[0..1000] of byte;
  armysis = array[0..1000] of shortint;
  lsvar = array[lrange] of state;
  lnamarr = array[lrange] of String[15];
  knamarr = array[krange] of String[15];
{  s40ptr = ^Str40;}
  stringptr = ^Str130;

  desigptr = ^desigrec;
  desigrec = record
    dn,dobj: integer;
    sayeth: stringptr;
    nextbyte: desigptr;
   END;

  planptr = ^planrec;
  planrec = record
    planstart: shortint;
    planend: shortint;
    septr: desigptr;
    lactions: array[actionrange] of action;
    lobjects: array[actionrange] of integer;
    lextra: array[actionrange] of integer;
    pexrec: array[actionrange] of record
      case ertype: byte OF
{        Extra_Str:   (string_ptr: s40ptr);}
        Extra_CPlan: (newchptr: planptr);
        Byte_List:   (firstbyte: desigptr);
        Numbers:     (n1,n2,n3,n4: byte);
     END;
   END;
  lparr = array[lrange] of planrec;

{  extrec = record
    N: byte;
    s: str30;
   end;}
  textrec = record
    _col,_line,_pspace: byte;
   end;

const
    F_Hid = 1;
    F_Sacked = 2;

    Part_Eff = 1;
    Bless_Eff = 2;
    Flood_Eff = 4;
    Quake_Eff = 8;
    Plague_Eff = 16;
    Illus_Eff = 1*256;
    Illus_Exp = 8*256;
    Fog_Eff = 16*256;
    Raid_Eff = 32*256;

    L_IA = 2; {2-4-8}
    L_Orat = 16;
    L_Dead = 32;
    L_Clairv = 256;

    L_GotM = 1; {gotmsg bits}
    L_Winds = 2;

    Map_Menu = 0;
    Order_Menu = 1;

    Pol_Disp = 0;
    Char_Disp = 1;
    Mil_Disp = 2;
    Pic_Disp = 3;

      outname: outstrs = ('Divine','Good','Druidic','Neutral','Pagan',
        'Evil','Anti-Holy','Undead','Mechanical','Special');

{$IFDEF Moderator}
{$IFNDEF Noble}
    terchance: chancearr =
      ((6,0,0,17,7,70, 0),
       (8,5,0,10,7,70, 0),
       (7,13,0,3,7,70, 0),
       (7,5,11,0,7,70, 0),
       (5,3,15,0,7,70, 0 ));
{
    terrain = (PLAINS,DESERT,JUNGLE,FOREST,MTNS,SEA,noterr,
      SWAMP,LAVA,{=lastdev!!ET1,ET2,ET3,ET4,ET5);
}
    maxtax: terbytes = (9,2,6,7,8,2,0, 3,1,5,5,5,5,5);

{$ELSE}
    terchance: chancearr =
      ((0 ,  2, 27,  1 , 70 ,  0) ,
       (0 ,  2, 27,  1 , 70 ,  0) ,
       (0 ,  2, 27,  1 , 70 ,  0) ,
       (0 ,  2, 27 , 1 , 70 ,  0) ,
       (0 ,  2, 27 , 1 , 70 ,  0 ));

    maxtax: terrarr = (5,8,9,2,2, 0);
{$ENDIF}

      tempab: tempstrs = ('Cowrd','Caut','Brave','Bersk');
      outab: outstrs = ('Divin','Good','Druid','Neutr','Pagan',
        'Evil','Hell','Undea','Mech','Spec');
      outred: outreals = (0.20, 0.12, 0.15, 0.20, 0.15, 0.12, 0.20,0.20,0.20,0.20);
{$ENDIF}

const
    S_Forum = -1;
    S_CServe = 0;
    S_GEnie = 1;
    S_Disk = 2;
    S_Printout = 3;
    S_Both = 4;

    Vote_Turn = 31000;

    SB_No = 0;
    SB_Int = 1;
    SB_Waiting = 2;
    SB_Start = 3;
    SB_Rising = 4;

    Disp_1Plan = 0;
    Disp_All = 1;
    Print_All = 2;

{$IFDEF Moderator}
    sendms: array[S_Forum..S_Both] of string[10] =
      ('PBM Forum','CompuServe','GEnie','Mail Disk','Mail Print','Send Both');

    sbs: array[SB_No..SB_Rising] OF string[10] =
      ('No','Wanted','Waiting','Started','Rising');

    gds: array[0..1] OF string[20] = ('Limited-Diplomacy','Full-Diplomacy');
{$ELSE}
CONST _Boolvars = 1; {disk_info for saga}
        _DiskChar = 1; {first bit of Boolvars}
        _FastMap = 2;
        _NoHerald = 4; {if =1, deactivates all font-heraldry}
        _PrefVGA = 8; {if on, prefer VGA on startup.}
        _DisMouse = 16; {disable mouse handling}

      _Fontpref = 2;
        _Skull = 1;

      _DelLen = 3;
      _DefAcct = 4;
      _SeenVers = 5;
      _TBC = 6;


type namerec = record
       lptoname: byte;
       namefor: String[15];
      END;
{$ENDIF}
const      _Question = 2; {to alert saga.exe that a questionnaire is put in "GAME NEWS".}
           _LibCheck = 1; {for flagvar xk-file checking}
type qcolarr = array[0..1] OF array[0..1] of byte;

     shieldrec = record
       shieldarr: array[0..3] OF array[0..29] OF byte; {4 columns wide, 2x14 bytes/rows deep}
       bottom_forecolor: boolean;
       qtr_fc,qtr_bc: qcolarr;
       motto: Str60;
      END;
     shields = array[krange] of shieldrec;

{*****************************************************************************

****Not implemented yet:
  type office = (Pope,Caliph,Shaman,Emperor,King,Duke,Prince,Notitle);

  const ofcname: ofcstrs =
    ('Pope','Caliph','High Shaman','Emperor','King','Duke','Prince','no title');
  type
    traitarr = array[trait] of skillrange;
    ltrarr = array[lrange] of traitarr;
    treasure =  (Holy_Grail,True_Cross,Turin_Shroud,Noahs_Ark,Excalibur,
               Moses_Staff,Invis_Sword,notreasure);

    trstrs = array[treasure] of str20;
    trbytes = array[treasure] of byte;

  const
      trname: trstrs =  ('Holy_Grail','True_Cross','Turin_Shroud','Noahs_Ark','Excalibur',
               'Moses_Staff','Invis_Sword','no treasure');}


const canaly: array[0..17] of byte = (6, 6, 7, 7, 8, 6, 3, 4, 3, 2, 14,5, 6, 1, 1, 3, 4, 3);
      canalx: array[0..17] of byte = (25,26,26,27,26,27,15,15,16,1, 14,22,22,24,25,17,17,18); {change for:= 0 to 10!!}

CONST GM_Mess = -2;
      All_Mess = -1;
      No_Mess = -1000;

