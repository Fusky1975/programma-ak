unit speak;
{$I-}
{$I pro.pas}
{$I Noble.pas}
{$I Russian.pas}

{$O+}
interface

uses dos,crt,textseek,defines,yak,mboth,rumors,map;

PROCEDURE Check_ESpab(ldr: integer; ab: ability);
PROCEDURE Check_MSpab(ldr: integer; tr: treasure);
PROCEDURE Check_DSpab(ldr: integer; d: discovery);
PROCEDURE Unk_Spabs(kng: integer);
PROCEDURE Imp_Code(code: integer);
  {This procedure interprets an integer code from 0 to 32767 and takes action
   depending on what the code is defined to mean.}

PROCEDURE Get_VFN(vldr: integer; VAR vs: Str40; fno: integer);
{This procedure returns the name of a file of valhalla heroes, such as "C:\tp\prose\good.x2"}
PROCEDURE Imp_Spab(ab: ability; lev: integer; cong: boolean);
PROCEDURE Write_SR;
PROCEDURE Start_ACF(ldr: integer; nupag: boolean);
PROCEDURE Check_EOT(ldr: integer; ab: ability; VAR needeot: boolean; newhero: boolean);
PROCEDURE Check_NSpabs(ldr: integer; newhero: boolean);

implementation
{$I modflag.pas}
{$V-}

PROCEDURE PW_Spab(ab: ability; lev: integer; cong: boolean);
BEGIN
{  IF Company = ArkRoyal THEN} BEGIN
    PW(2864+ord(cong));
    PW(1856+ord(ab));
    PW2(_LCong,lev);
    PW(spabord[ab,lev-4]);
   END;
 END;

PROCEDURE Check_ESpab(ldr: integer; ab: ability);
VAR needcong: boolean;
BEGIN
  IF M_Skill(ldr,ab) > 4 THEN BEGIN
    Check_EOT(ldr,ab,needcong,false);
    PW_Spab(ab,M_Skill(ldr,ab),needcong);
   END;
 END;

PROCEDURE Check_DSpab(ldr: integer; d: discovery);

PROCEDURE Check_It(a: ability);
VAR l2,maxl: integer;
BEGIN
  maxl:= 0;
  FOR l2:= 0 TO nleaders-1 DO IF LKing(l2) = LKing(ldr) THEN
    maxl:= Max(maxl,M_Skill(l2,a));
  IF maxl >= 5 THEN
    IF stat_on THEN Imp_Spab(a,maxl,true) ELSE PW_Spab(a,maxl,true);
 END;

BEGIN
  CASE d OF
    fix0..fix9: Check_It(ability(ord(d) Shr 1));
    wreck0..wreck9: Check_It(ability(5+(ord(d) Shr 1)));
   END;
 END;

PROCEDURE Check_MSpab(ldr: integer; tr: treasure);
BEGIN
  IF ldr < nleaders THEN CASE tr OF
    hla..lhl: Check_ESpab(ldr,ability(ord(tr)));
    Crown_Rohan: BEGIN  Check_ESpab(ldr,ForcedMarch); Check_ESpab(ldr,Tactical); END;
    Amulet_Power: BEGIN  Check_ESpab(ldr,Psychic); Check_ESpab(ldr,White); Check_ESpab(ldr,Elemental); END;
    Scepter_Life: BEGIN  Check_ESpab(ldr,SAge); Check_ESpab(ldr,Illusionist); Check_ESpab(ldr,Melee); END;
    Map_Marauders: CHeck_ESpab(ldr,Naval);
    Fang_Vampire: BEGIN  Check_ESpab(ldr,Melee); Check_ESpab(ldr,Necromancy); END;
    Hammer_Power: BEGIN  Check_ESpab(ldr,Melee); Check_ESpab(ldr,Druid); END;
   END;
 END;

PROCEDURE Unk_Spabs(kng: integer);
label 10;
VAR none: boolean;
    ldr,skil: integer;
    ab: ability;

PROCEDURE Write_Spab;
BEGIN
  IF none THEN BEGIN
    none:= false;
    Write_SR;
   END;
  Imp_Spab(ab,skil,true);
 END;

BEGIN
  none:= (woe = 2); {from start_acf routine-- start_app}
  IF ((minewrit = 1) or ((gametyp = Valhalla_V) and (gameturn = 0)) or
      (standby[kng] = SB_Start) or (standby[kng] = SB_Waiting)) THEN
{   IF Company = ArkRoyal THEN} BEGIN
    FOR ab:= Tactical TO Sage DO FOR skil:= 5 TO 9 DO BEGIN
      FOR ldr:= 0 TO nleaders-1 DO IF LKing(ldr) = kng THEN
        IF lskill^[ldr,ab] > 1 THEN IF M_Skill(ldr,ab) >= skil THEN BEGIN
          Write_Spab;
          GOTO 10;
         END;
10: ; {skip other leaders}
     END;
   END;
 END;

FUNCTION Mod_LAType(an: integer): army; {ignore this procedure}
BEGIN  Mod_LAType:= lastat[an]; END;

PROCEDURE Force_Return; {If a sentence has begun printing, perform carriage return}
BEGIN  WITH rumstats[playking] DO IF _col+_line > 2 THEN PR1; END;

{$I say.pas}

{$V+}

end.
