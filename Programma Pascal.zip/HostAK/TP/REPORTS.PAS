unit reports;
{$I-}
{$o+}
interface
{$undef Russian}
{$I Noble.pas}
uses dos,crt,textseek,defines,yak,mboth,rumors,speak,map;

FUNCTION Ofc_Pts(ldran: integer; ofc: office; inclemp: boolean): integer;
FUNCTION Align_Est(ln,agent: integer): integer;
FUNCTION Temper_Est(ln,agent: integer): integer;
PROCEDURE Disk_Int(ldr,gt: integer; VAR f: integfile);
FUNCTION Disk_Read(ldr,gt: integer): boolean;
PROCEDURE Disk_Play(ldr,gt: integer);
PROCEDURE Read_Story(ldr,sk: integer);
PROCEDURE Start_Rpt(ldr: lrange);
PROCEDURE Title_Page(tit: Str40; kng: integer);
PROCEDURE Letter_Reports(kng: integer);
PROCEDURE Desc_Lands(kng: integer; dk: dbool; pex: mapbyte);
PROCEDURE Desc_Forces(kng,gt: integer);
FUNCTION Tit_Pts(ldr: integer; tit: office): integer;
PROCEDURE Desc_Adventure(kng: integer; pex: mapbyte; fdis: fbool);
{$IFNDEF Noble}
PROCEDURE Pray_Report(kng: krange; regrep: boolean);
FUNCTION Rank(ldran,lpts: integer; ofc: office;
              VAR ftoppts: integer): integer;
{$ENDIF}
PROCEDURE Basic_Report(kng: integer);
PROCEDURE Get_HName(ldr,maxl: integer; VAR s: Str20);
PROCEDURE Gab(ldr: integer);
PROCEDURE Prep_Stats;
PROCEDURE Init_Points;
PROCEDURE Birth_Title(kng: integer);
PROCEDURE Desc_Summary(ldr: integer);
PROCEDURE Say_Menu;

implementation

{$I modflag.pas}
{$I pro.pas}
{$V-}

FUNCTION Align_Est(ln,agent: integer): integer;
VAR bali: integer;
BEGIN
  IF ln < 256 THEN bali:= ln ELSE bali:= ord(fmonst[ln-256]);
  IF ((titchar[Psychic_Mage] = agent) or (Has_SA(agent,Detect_Align))) THEN Align_Est:= 2880+ord(Agent_Align(ln,bali))
    ELSE Align_Est:= 2880+Max(0,Min(ord(Special),
      ord(Agent_Align(ln,bali))+(ln and 1) - (agent and 1)));
 END;

FUNCTION Temper_Est(ln,agent: integer): integer;
VAR btemp: temper;
BEGIN
  IF ln < 256 THEN btemp:= ltemper[ln]
    ELSE btemp:= mtemper[fmonst[ln and 255]];
  IF titchar[Psychic_Mage] = agent THEN Temper_Est:= 2896+ord(btemp)
    ELSE Temper_Est:= 2896+Max(0,Min(ord(Berserk),ord(btemp)+(ln and 1) - (bornx[agent] and 1)));
 END;


{PROCEDURE ItalicOn; BEGIN IF not email THEN BEGIN gs:= Concat(chr(27),'4'); Spread(gs,0,true); END; END;
PROCEDURE ItalicOff; BEGIN IF not email THEN BEGIN gs:= Concat(chr(27),'5'); Spread(gs,0,true); END; END;}

{PROCEDURE EOP;
BEGIN
  IF not email THEN BEGIN
    gs:= chr(12); Spread(gs,0,true); END;
 END;}

PROCEDURE Title_Page(tit: Str40; kng: integer);
VAR s: Str20;
BEGIN
  PR2;
  Center_Write(kng,tit);
  PR1;
{$IFDEF Russian}
Center_Write(kng,'���');
{$ELSE}
  Center_Write(kng,'FOR');
{$ENDIF}
  PR1;
  KStr(kng,tit);
  UpC_Str(tit);
  Center_Write(kng,tit);
{  EOP;}
 END;

PROCEDURE Expand_Write(s: str40; kng: integer);
BEGIN
  IF Mail_Send(kng) THEN WRITE(playfile,chr(14));
{$IFDEF Russian}
WRITELN(s,': ��஫�#',kng);
{$ELSE}
WRITELN(s,': King#',kng);
{$ENDIF}
WRITELN(playfile,s);
 END;

PROCEDURE Desc_Lands(kng: integer; dk: dbool; pex: mapbyte);
VAR none: boolean;
    needpr: boolean;

PROCEDURE Rep_Allies;
VAR nok,k2,l2: integer;
    knowpow,knowtreas: boolean;

PROCEDURE Begin_List(s:str30);
BEGIN
  PR1;
{$IFDEF Russian}
WRITELN(playfile,
    '  ��� ��ᯮ���, ᫥���騥 ��஫� ',s,' � ��訬');
WRITELN(playfile,
    '���������� ������⢮�:                    ');
{$ELSE}
WRITELN(playfile,
    '  My lord, the following Kings ',s,' with thy ever-');
  WRITELN(playfile,
    'victorious majesty:                    ');
{$ENDIF}
 END;

{$IFNDEF Noble}
PROCEDURE Write_List(allstate: integer);
VAR k2: krange;

PROCEDURE Desc_Align(ali: boolean);
BEGIN
  kknows^[k2]:= kknows^[k2] or (longint(1) Shl kng);
{$IFDEF Russian}
  IF knowpow THEN WRITE(playfile,', ',Tax_Base(k2), '����� ��������� ����');
  IF knowtreas THEN WRITE(playfile,', ',lgold[k2], '����� � �����');
  IF ali THEN
    IF Company = Roland THEN WRITE(playfile,' est d''��魮��� ',outname[lalign[k2]],'.')
      ELSE WRITE(playfile,' - �� ',outname[lalign[k2]],' ��魮���.');
{$ELSE}
  IF knowpow THEN WRITE(playfile,', ',Tax_Base(k2), 'g taxbase');
  IF knowtreas THEN WRITE(playfile,', ',lgold[k2], 'g in treasury');
  IF ali THEN
    IF Company = Roland THEN WRITE(playfile,' est d''alignement ',outname[lalign[k2]],'.')
      ELSE WRITE(playfile,' is of ',outname[lalign[k2]],' alignment.');
{$ENDIF}
 END;

BEGIN
  PR1;
  none:= true;
  FOR k2:= 0 TO nkings-1 DO IF k2 <> kng THEN IF kallst[kng,k2] = allstate THEN BEGIN
    WRITE(playfile,'  ',lname^[k2],' (#',k2,')');
    knowpow:= (((gamevers >= 4) or (gdyear >= 1992)) and
      (prevchar[Emperor] = kng) and ((not New_Rules) or (kkmet[kng] and (longint(1) Shl k2) <> 0)));
    knowtreas:= (((gamevers >= 4) or (gdyear >= 1992)) and
      (prevchar[Treasurer] = kng) and ((not New_Rules) or (kkmet[kng] and (longint(1) Shl k2) <> 0)));
    IF ((kkmet[kng] and (longint(1) Shl k2) <> 0) and
        ((((lalign[k2] = Heavenly)) and (not Brian_Game2)) or (lalign[k2] = Undead))) THEN Desc_Align(true)
      ELSE IF ((gamevers >= 4) and (lalign[kng] = lalign[k2])) THEN Desc_Align(true)
      ELSE IF ((knowpow) or (knowtreas)) THEN Desc_Align(false);
    WRITELN(playfile);
    kknows^[k2]:= kknows^[k2] or (longint(1) Shl kng);
    Dec(nok);
    none:= false;
   END;
{$IFDEF Russian}
IF none THEN WRITELN(playfile,'  ᥩ�� ��祣�    ');
{$ELSE}
IF none THEN WRITELN(playfile,'  None at present    ');
{$ENDIF}
  PR1;
 END;
{$ENDIF}

PROCEDURE Check_KKSugg(kng,fork: integer);
VAR lk1,lk2,px,py: byte;
BEGIN
  IF kng = 11 THEN IF fork = 18 THEN BEGIN
    WRITE('k11/18:',kkmet[kng] and (longint(1) Shl 18));
   END;
  IF kng >= 0 THEN IF kng < nkings THEN IF fork < nkings THEN
   IF kng <> fork THEN FOR px:= left TO right DO FOR py:= top TO bottom DO
    IF powner[px,py] = kng THEN IF Adj_King(fork,px,py) THEN BEGIN
      lk2:= Max(LKing(kng),LKing(fork)); lk1:= Min(LKing(kng),LKing(fork));
      WRITE(' KK:',lk1,'/',lk2,'/',kkmet[lk1] and (longint(1) Shl lk2),'/',
            mknext1[kng] and (longint(1) Shl fork),'.');
      IF ((kkmet[lk1] and (longint(1) Shl lk2) = 0) or
          (standby[fork] = SB_Start)) THEN BEGIN
          mknext1[kng]:= mknext1[kng] or (longint(1) Shl fork);
          mknext1[fork]:= mknext1[fork] or (longint(1) Shl kng);
         END
        ELSE ;
      IF not catchup THEN BEGIN
        kkmet[lk1]:= kkmet[lk1] or (longint(1) Shl lk2);
        kkmet[lk2]:= kkmet[lk2] or (longint(1) Shl lk1);
       END;
     END;
{
  IF kng = 11 THEN IF fork = 18 THEN BEGIN
    WRITE(' =>k2:',kkmet[kng] and (longint(1) Shl 18));
    READLN;
   END;
}
 END;

BEGIN
  PR2;
{$IFDEF Russian}
  Expand_Write('���������� ',kng);
  nok:= nkings-1;
{$IFNDEF Noble}
  Begin_List('�����ࠧ㬭� �����稫 ��'); Write_List(KAllied);
  Begin_List('������㤭� ���� �����'); Write_List(KEnemy);
  Begin_List('�।�ᬮ��⥫쭮 ����ࠫ��'); Write_List(KNeutral);
{$ENDIF}
{$ELSE}
  Expand_Write('DIPLOMACY ',kng);
  nok:= nkings-1;
{$IFNDEF Noble}
  Begin_List('have wisely allied'); Write_List(KAllied);
  Begin_List('are foolishly at war'); Write_List(KEnemy);
  Begin_List('are cautiously neutral'); Write_List(KNeutral);
{$ENDIF}
{$ENDIF}
  PR1;
{
{$IFDEF Russian]
  IF nok <> 0 THEN WRITELN(playfile,
    '  �� �����ᠫ� ������� � ����ࠫ��� � ',nok,' ��⠫�묨 ��஫ﬨ-��ப���.          ');
{$ELSE]
  IF nok <> 0 THEN WRITELN(playfile,
    '  We have Neutral relations with the ',nok,' other player-kings.          ');
{$ENDIF]
?|?  FOR k2:= 0 TO nkings-1 DO IF k2 <> kng THEN BEGIN
    knowpow:= (((gamevers >= 4) or (gdyear >= 1992)) and
      (prevchar[Emperor] = kng) and ((not New_Rules) or (kkmet[kng] and (longint(1) Shl k2) <> 0)));
    knowtreas:= (((gamevers >= 4) or (gdyear >= 1992)) and
      (prevchar[Treasurer] = kng) and ((not New_Rules) or (kkmet[kng] and (longint(1) Shl k2) <> 0)));
    IF ((kkmet[kng] and (longint(1) Shl k2) <> 0) and
        ((((lalign[k2] = Heavenly)) and (not Brian_Game2)) or (lalign[k2] = Undead))) THEN Desc_Align(true)
      ELSE IF ((gamevers >= 4) and (lalign[kng] = lalign[k2])) THEN Desc_Align(true)
      ELSE IF ((knowpow) or (knowtreas)) THEN Desc_Align(false);
   END;
  PR2;
}
  FOR k2:= 0 TO nkings-1 DO Check_KKSugg(kng,k2);
  CASE gametyp OF
    Europe_V, Earth_V, Arcanes_V: IF gameturn = 0 THEN FOR l2:= 0 TO nkings-1 DO
      IF l2 <> kng THEN IF Dist(lx[l2],ly[l2],lx[kng],ly[kng]) <=
          5-(2*ord((l2 >= 21) or (kng >= 21))) THEN
        mknext1[kng]:= mknext1[kng] or (longint(1) Shl l2);
   END;
  IF gdipltype > 0 THEN BEGIN
    FOR l2:= 0 TO nkings-1 DO IF (mknext1[kng] and (longint(1) Shl l2)) <> 0 THEN BEGIN
      Elite_On;
        WRITE('Di');
      Imp_Code(kng); Imp_Code(l2+1280);
      Imp_Code(_LKNext1);
        WRITE(',');
      Elite_Off;
     END;
    FOR l2:= 0 TO nkings-1 DO IF (mknext1[kng] and (longint(1) Shl l2)) = 0 THEN
      IF kkmet[kng] and (longint(1) Shl l2) <> 0 THEN IF kng <> l2 THEN BEGIN
        Elite_On;
        WRITE('D2');
        Imp_Code(kng); Imp_Code(l2+1280);
        Imp_Code(_LKNex);
        Elite_Off;
        WRITE(',');
       END;
   END;
 END;

PROCEDURE Rep_Econ;
VAR k1,an,ln,px,py,exp,dval: integer;
    d: discovery;
    sex1: boolean;

BEGIN
  PR2;
{$IFDEF Russian}
  Expand_Write('�������',kng);
  PR1;
  WRITELN(playfile,
    '� �������, � �।�⠢��� �� ��� ��ᬮ�७�� ᫥���騥 �����');
  WRITELN(playfile,
    '�⭮�⥫쭮 䨭��ᮢ ��襩 ������� ��樨:                     ');
{$ELSE}
  Expand_Write('FINANCES',kng);
  PR1;
  WRITELN(playfile,
    '  O Great One, I submit for thy examination the following figures');
  WRITELN(playfile,
    'concerning the finances of our great nation:                     ');
{$ENDIF}
  PR1;
  exp:= 0;
  FOR an:= 0 TO narmies-1 DO IF an <> 255 THEN IF A_Led(an,kng) THEN
    exp:= exp+ ACost(an);
  FOR ln:= 0 TO nleaders-1 DO IF ln >= nkings THEN IF LKing(ln) = kng THEN
    exp:= exp+LCost(ln,kng);
{$IFDEF Russian}
  WRITELN(playfile,'  ����� � �����:  ',lgold[kng]:3);
  IF NR_Or_G4 THEN BEGIN
    IF titchar[Evilking] = kng THEN WRITELN(playfile,'  (� ⮬ �᫥ +5 ���� ����)    ');
    IF LKing(titchar[ThiefPrince]) = kng THEN WRITELN(playfile,'  (� ⮬ �᫥ +10 ��஢᪠� ���줨�)    ');
   END;
  WRITELN(playfile,  '  �������� ��室: ',Tax_Base(kng):3);
  IF Inv_Bonus(kng) > 0 THEN
    WRITELN(playfile,'   + �६�� �� �����⥭��: ',Inv_Bonus(kng):3,'%');
  WRITELN(playfile,  '  �������� ���室�: ',exp:3);
  PR2;
  WRITELN(playfile,
  '  ��� ��஫���⢮ ⠪�� ��������� ����� �� ᫥����� ����⨩ ���殢:');
{$ELSE}
  WRITELN(playfile,'  Gold in treasury:  ',lgold[kng]:3);
  IF NR_Or_G4 THEN BEGIN
    IF titchar[Evilking] = kng THEN WRITELN(playfile,'  (Including +5 Black Knights)    ');
    IF LKing(titchar[ThiefPrince]) = kng THEN WRITELN(playfile,'  (Including +10 Thieves Guild)    ');
   END;
  WRITELN(playfile,  '  Expected Revenues: ',Tax_Base(kng):3);
  IF Inv_Bonus(kng) > 0 THEN
    WRITELN(playfile,'   +Invention Bonus: ',Inv_Bonus(kng):3,'%');
  WRITELN(playfile,  '  Expected Expenses: ',exp:3);
  PR2;
  WRITELN(playfile,
  '  Our Kingdom is also benefited by the following Discoveries of the Sages:');
{$ENDIF}
  none:= true;
  PR1;
{$IFNDEF Noble}
  FOR dval:= 20 DOWNTO 0 DO FOR d:= fix0 TO crunch27 DO
    IF discval[d] = dval THEN IF dk[d] THEN BEGIN
      needpr:= false;
      WRITE(playfile,'  ',dname[d],' ':25-Length(dname[d]),'(');
{$IFDEF Russian}
      CASE d OF
        fix0..fix9: WRITE(playfile,'+1 �஢��� � ',anoun[ability(ord(d) Shr 1)]);
        wreck0..wreck9: WRITE(playfile,'+1 �஢��� � ',anoun[ability((ord(d)+10) Shr 1)]);
        bild10..bild43: WRITE(playfile,'��⨧���������: ',spname[spell(ord(Skeletal_Army)+ord(d)-ord(bild10))]);
        crunch0..crunch27:WRITE(playfile,'+',1+((ord(d)-ord(crunch0)) and 3),'% ��室�');
{$ELSE}
      CASE d OF
        fix0..fix9: WRITE(playfile,'+1 skill in ',anoun[ability(ord(d) Shr 1)]);
        wreck0..wreck9: WRITE(playfile,'+1 skill in ',anoun[ability((ord(d)+10) Shr 1)]);
        bild10..bild43: WRITE(playfile,'Anti-spell: ',spname[spell(ord(Skeletal_Army)+ord(d)-ord(bild10))]);
        crunch0..crunch27:WRITE(playfile,'+',1+((ord(d)-ord(crunch0)) and 3),'% revenue');
{$ENDIF}
       END;
      WRITELN(playfile,')');
      sex1:= true;
      FOR k1:= 0 TO nkings-1 DO IF kexch[k1,kng] = ord(d) THEN BEGIN
{$IFDEF Russian}
        IF sex1 THEN WRITE(playfile,'(����祭� �� ��ப�(��) #',k1)
           ELSE WRITE(playfile,', k1');
{$ELSE}
        IF sex1 THEN WRITE(playfile,'(Received from player(s) #',k1)
          ELSE WRITE(playfile,', ',k1);
{$ENDIF}
        sex1:= false;
        needpr:= true;
       END;
      IF ((not sex1) or (gameturn = 0) or ((kinfo[playking] and 1 = 0) and (d >= bild10) and (d <= bild43))) THEN BEGIN
{$IFDEF Russian}
        IF not sex1 THEN WRITELN(playfile,'ᮣ��᭮ ���筮�� ��������)    ');
{$ELSE}
        IF not sex1 THEN WRITELN(playfile,' by scientific treaty)    ');
{$ENDIF}
        Elite_On;
      WRITE('Ld');
        Imp_Code(1952+ord(d));
        Imp_Code(_LDisc);
      WRITE(',');
        Check_DSpab(kng,d);
        Elite_Off;
        needpr:= true;
       END;
      sex1:= true;
      FOR k1:= 0 TO nkings-1 DO IF kexch[kng,k1] = ord(d) THEN BEGIN
{$IFDEF Russian}
        IF sex1 THEN WRITE(playfile,'(��।��� ��ப�(��) #',k1)
           ELSE WRITE(playfile,', ',k1);
{$ELSE}
        IF sex1 THEN WRITE(playfile,'(Sent to player(s) #',k1)
          ELSE WRITE(playfile,', ',k1);
{$ENDIF}
        needpr:= true;
        sex1:= false;
       END;
{$IFDEF Russian}
      IF not sex1 THEN WRITELN(playfile,'ᮣ��᭮ ���筮�� ��������)    ');
{$ELSE}
      IF not sex1 THEN WRITELN(playfile,' by scientific treaty)    ');
{$ENDIF}
      none:= false;
      IF needpr THEN PR1;
     END;
{$ENDIF}
{$IFDEF Russian}
  IF none THEN WRITELN(playfile,'  ��祣� � ����� ������    ');
{$ELSE}
  IF none THEN WRITELN(playfile,'  None at present    ');
{$ENDIF}
 END;

PROCEDURE Rep_Provs;
VAR tt,an,px,py: integer;
BEGIN
  PR2;
{$IFDEF Russian}
  Expand_Write('���������',kng);
  PR1;
  WRITELN(playfile,
    '  � ���⮩���訩, � �����⮢�� ᯨ᮪ ���  �஢��権, �����');
  WRITELN(playfile,
    '�����ࠧ㬭� ���稭����� ��襩 �����.  ��� �����, �室�騥 � ���� ������:');
{$ELSE}
  Expand_Write('PROVINCES',kng);
  PR1;
  WRITELN(playfile,
    '  O superfluous one, I have kept well a list of all provinces which have had');
  WRITELN(playfile,
    'the wisdom to submit to thy yoke.  Here, then, are the lands of thy Empire:');
{$ENDIF}
  PR1;
  none:= true;
  FOR tt:= 11 DOWNTO 0 DO FOR px:= left TO right DO FOR py:= top TO bottom DO
    IF powner[px,py] = kng THEN IF Min(11,ptax[px,py] +
        8*ord((px = bornx[kng]) and (py = borny[kng]))) = tt THEN BEGIN
      IF none THEN BEGIN
        UL;
{$IFDEF Russian}
       WRITELN(playfile,
'                                               ���� ���� ��� �����:');
        WRITELN(playfile,
'�஢����        �����  ��� ���⭮���  ��᫥�%     ��� 1      ��� 2');
{$ELSE}
        WRITELN(playfile,
'                                                    Recruiting Types:');
        WRITELN(playfile,
'Province            Tax   Race   Terrain  Expl%     Type 1     Type 2');
{$ENDIF}
        NUL;
       END;
      WRITELN(playfile,pname^[px,py],'':20-Length(pname^[px,py]),ptax[px,py]:3,
        rname[Mod_PRace(px,py)]:8,tername[pterr[px,py]]:9,pex[px,py]:6,'%',
        atdesig[Mod_PAT(px,py,0)]:11,atdesig[Mod_PAT(px,py,1)]:11);
{$IFDEF Russian}
      IF pt2^[px,py] <> noterr THEN
        WRITELN(playfile,'':30,'(',tername[pt2^[px,py]],' ���஢)');
      none:= false;
     END;
  IF none THEN WRITELN(playfile,'��祣� ᥩ��   ');
{$ELSE}
      IF pt2^[px,py] <> noterr THEN
        WRITELN(playfile,'':30,'(',tername[pt2^[px,py]],' Island)');
      none:= false;
     END;
  IF none THEN WRITELN(playfile,'None at present    ');
{$ENDIF}
 END;

BEGIN
{$IFNDEF Noble}
  IF emp < No_King THEN Pray_Report(kng,true);
  PR2;
{$ENDIF}
{$IFDEF Russian}
Expand_Write('��������� �����:',kng);
  PR1;
  WRITELN(playfile,
    '  ��� ��ᯮ��� � ������⥫�, ����砩訩 �� ��஫��, � ᬨ७�� ���� ��襣� ���������� ᤥ����');
  WRITELN(playfile,
    '���� � ���ﭨ� ��� � ��襬 ��஫���⢥, ����� ����� ������ᮢ��� ��� ������������ ������⢮.');
{$ELSE}
  Expand_Write('STATE OF THE NATION:',kng);
  PR1;
  WRITELN(playfile,
    '  My lord and sovereign, greatest of Kings, I humbly beg thy leave to make');
  WRITELN(playfile,
    'report of matters of this Kingdom that may concern thy divine majesty.');
{$ENDIF}
  WRITELN(' RA:',lgold[kng]);
  Rep_Allies;
  Rep_Econ;
  Rep_Provs;
  WRITELN(' RAx:',lgold[kng]);
 END;

PROCEDURE Get_HName(ldr,maxl: integer; VAR s: Str20);
BEGIN
  IF maxl <> 255 THEN BEGIN
      Str(ldr,s);
      s:= Concat(' (',s,')');
     END
    ELSE s:= '';
  IF ((ldr < nkings) and (gameturn > 0) and (Total_USkill(ldr) < 7)) THEN BEGIN
{$IFDEF Russian}
      IF Company = Roland THEN s:= Concat('H_ritier Royal',s)
        ELSE s:= Concat('��᫥���� ���⮫�',s)
{$ELSE}
      IF Company = Roland THEN s:= Concat('H_ritier Royal',s)
        ELSE s:= Concat('Royal Heir',s)
{$ENDIF}
     END
    ELSE s:= Concat(lname^[ldr],s);
  WHILE Length(s) > maxl DO Delete(s,Pos('(',s)-1,1);
 END;

FUNCTION Army_Office(ofc: office): boolean;
BEGIN  Army_Office:= ((ofc = Praetor) or (ofc = Flagship) or (ofc = Airforce)); END;

PROCEDURE List_Treas(tro: integer; advrep: boolean);
VAR skil,tn,t,qfn,ftop: integer;
    owtreas,ntreas: byte;
    s,ds: Str80;
    tnt: treasure;
    specab,l80: boolean;
    ab: ability;
    ofc: office;
    ofp: integer;

PROCEDURE Desc_Apt; VAR sk: ability;
BEGIN
  WRITE(playfile,Total_Skill(tro)+M_Skill(tro,ForcedMarch)*2:2,'  ');
  FOR sk:= tactical to Sage DO
    WRITE(playfile,aptitude^[tro,sk]:2+ord((sk <> Tactical) and (ord(sk) MOD 5 = 0)));
 END;

PROCEDURE Check_Spec;
BEGIN
{$IFDEF Russian}
  IF not specab THEN WRITELN(playfile,'�������⥫�� ���ᮡ����:  ');
{$ELSE}
  IF not specab THEN WRITELN(playfile,'Special Abilities:  ');
{$ENDIF}
  specab:= true;
 END;

BEGIN
  ntreas:= 0; owtreas:= NT_Owned(tro,hla,Contract_Fu,t);
  FOR tn:= 0 TO ntreasures-1 DO IF trowner[tn] = tro THEN BEGIN
    tnt:= treaslist[tn];
    l80:= ((Fulf_Treas(tnt)) or ((tnt >= wcp) and (tnt <= pic)));
    IF advrep THEN BEGIN
{        WRITE(':',ntreas,'/',owtreas,'/',ord(last_feat),'.'); readln;}
        IF ntreas = owtreas-1 THEN IF last_feat THEN UL;
        WRITE(playfile,'':27,'/');
       END
      ELSE BEGIN
        IF ntreas = owtreas-1 THEN
          IF ((owtreas > 1) or (not l80)) THEN UL;
        WRITE(playfile,'/');
       END;
    Str(tn,s); s:= Concat(Tr_Name(tnt),' (#',s,'): ');
    ds:= File_Name('C:\tp\prose\treasab.x2',ord(tnt));
    IF ((ntreas > 0) or (Length(ds) + Length(s) <= 39)) THEN BEGIN
        s:= Concat(s,ds);
        ds:= '';
       END
      ELSE ds:= Concat('  ',ds);
    WRITE(playfile,s);
    IF advrep THEN WRITE(playfile,'':35-Length(s))
      ELSE IF ntreas = 0 THEN BEGIN
        WRITE(playfile,'':40-Length(s));
        Desc_Apt;
        IF l80 THEN PR1;
       END;
    qfn:= trcharges[tn];
    IF l80 THEN IF ntreas = owtreas-1 THEN IF owtreas = 1 THEN
      IF not advrep THEN UL;
    CASE tnt OF
      Snow_Quest..notreasure: BEGIN
{$IFDEF Russian}
        WRITE(playfile,' (�� ',mtname[fmonst[qfn]],' � ',
{$ELSE}
        WRITE(playfile,' (from the ',mtname[fmonst[qfn]],' in the ',
{$ENDIF}
          ftname[ftype[qfn]],' (#',qfn,'))');
        CASE tnt OF
          Snow_Quest..Contract: IF fstate[qfn] = Dead THEN BEGIN
            trowner[tn]:= noleader;
            PR1;
{$IFDEF Russian}
            WRITE(playfile,' (���, �४��� ��� ���᪨. ������ 㦥 �ਪ���� ����� ����.)');
{$ELSE}
            WRITE(playfile,' (Sire, ignore this quest.  The monster no longer lives in this world.)');
{$ENDIF}
           END;
         END;
       END;
      wcp..pic: IF not advrep THEN BEGIN
{$IFDEF Russian}
         WRITE(playfile,' (',qfn,' ��易�����)');
{$ELSE}
        WRITE(playfile,' (',qfn,' charges)');
{$ENDIF}
       END;
     END;
    IF Length(ds) > 0 THEN BEGIN
      PR1;
      WRITE(playfile,ds);
     END;
    PR1;
    IF tro < 256 THEN IF ((tro = valhero) or (standby[LKing(tro)] = SB_Start) or
       (standby[LKing(tro)] = SB_Waiting)) THEN BEGIN
      Elite_On;
      WRITE('Td');
      Imp_Code(tro);
      Imp_Code(512 +ord(tnt));
      Imp_Code(_TrDesc);
      WRITE(',');
      Elite_Off;
      PR1;
     END;
    Inc(ntreas);
   END;
  IF advrep THEN BEGIN
      IF ntreas = 0 THEN PR1;
      IF ntreas = owtreas THEN IF last_feat THEN NUL;
     END
    ELSE BEGIN
      IF ntreas = 0 THEN BEGIN UL; WRITE(playfile,'':41); Desc_Apt; PR1; END;
      NUL;
      specab:= false;
{$IFNDEF Noble}
      IF gameturn <> 0 THEN FOR ofc:= Emperor TO Bravest DO IF not Army_Office(ofc) THEN IF ofc <> NoOffice THEN
       IF ((gamevers >= 4) or (ofcuse[ofc])) THEN BEGIN
        ofp:= Ofc_Pts(tro,ofc,false);
        IF not Brian_Game THEN IF ofp >= minpts[ofc] THEN IF Rank(tro,ofp,ofc,ftop) = 1 THEN BEGIN
          Check_Spec;
          FD('c:\tp\prose\ioname.x2',S_Red,1001+ord(ofc));
          PR1;
         END;
       END;
{$ENDIF}
{      IF Company = ArkRoyal THEN}
      FOR ab:= Tactical TO Sage DO IF lskill^[tro,ab] > 1 THEN
        FOR skil:= 5 TO Min(9,lskill^[tro,ab]+3) DO 
         IF M_Skill(tro,ab) >= skil THEN BEGIN
          Check_Spec;
      WRITE('Ts');
          IF ab = Sage THEN
            Imp_Code(10000 + (bornx[tro] and 31)*XMULT +borny[tro]);
          FD('c:\tp\prose\saname.x2',S_Red,1001+spabord[ab,skil-4]);
          PR1;
      WRITE(',');
         END;
      IF specab THEN BEGIN
        UL;
        WRITELN(playfile,'':77);
        NUL;
       END;
     END;
 END;

PROCEDURE Desc_Forces(kng,gt: integer);
VAR none: boolean;

PROCEDURE Rep_Leaders;
VAR ldr,fn,an,impulse,tcp,kaldr,inival,sk_mod,space_sub,trdex: integer;
    c: char;
    sk: ability;
    ts,s,ps: str20;
    ldr_init: array[lrange] of byte;
    tr: treasure;

FUNCTION Dispable(ldr: integer): boolean;

FUNCTION Was_Clairved: boolean;
VAR l2: integer;
    clobj: integer;
BEGIN
  Was_Clairved:= false;
  FOR l2:= 0 TO nleaders-1 DO IF LKing(l2) = kng THEN
    IF Has_SA(l2,Expand_Clair) THEN BEGIN
      clobj:= ((longint(lspec[l2]) and longint(longint(L_Clairv)*longint(255))) DIV longint(L_Clairv)) -1;
      IF clobj = ldr THEN Was_Clairved:= true;
     END;
 END;

BEGIN
  CASE impulse OF
    1: Dispable:= ((LKing(ldr) = kng) or (Was_Clairved));
    2: Dispable:= ((ldr <> valhero) and (Known_Loc(ldr,kng,0,true)));
    3: Dispable:= ((LKing(tcp) = kng) and
         (ldr < nkings) and (LDist(tcp,lx[ldr],ly[ldr]) <= 4) and
         (not ((ldr <> valhero) and (Known_Loc(ldr,kng,0,true)))));
   END;
 END;

PROCEDURE Desc_Stranger;
VAR as,s: Str80;
    td,ta: integer;
    ga: outlook;

PROCEDURE Tell_Align;
VAR tdmod: integer;
BEGIN
  WRITELN;
  td:= LDist(tcp,lx[ldr],ly[ldr]);
  tdmod:= (td+1) Shl ord(ldr >= nkings);
  ta:= ord(lalign[ldr]) + (((lx[ldr]+ly[tcp]) MOD tdmod) Shr 1) -
                          (((100+ly[ldr]-lx[tcp]) MOD tdmod) Shr 1);
  IF ta > ord(Undead) THEN ta:= ord(Undead);
  IF ta < ord(Heavenly) THEN ta:= ord(Heavenly);
{  ga:= outlook(Max(ord(Divine),Min(ord(Undead),ta)));}
{$IFDEF Russian}
  IF Company = Roland THEN WRITE(playfile,'  ...�������� ���� "',outname[outlook(ta)],'"')
    ELSE WRITE(playfile,'  ...�������� ���� "',outname[outlook(ta)],'"');
{$ELSE}
  IF Company = Roland THEN WRITE(playfile,'  ...the Rod senses "',outname[outlook(ta)],'"')
    ELSE WRITE(playfile,'  ...the Rod senses "',outname[outlook(ta)],'"');
{$ENDIF}
 END;

BEGIN
{$IFDEF Russian}
  IF lstate[ldr] = Dead THEN as:= Concat(': ���஭�� � ',pname^[lx[ldr],ly[ldr]])
    ELSE IF LKing(ldr) = noleader THEN as:= ': ��࠭����騩 ��ன  '
    ELSE IF ldr < nkings THEN as:= ': ���ᮭ�� ��஫�'
    ELSE IF Company = Roland THEN as:= Concat(': ',lname^[LKing(ldr)],'''��ன')
    ELSE as:= Concat(': ',lname^[LKing(ldr)],'''��ன');
{$ELSE}
  IF lstate[ldr] = Dead THEN as:= Concat(': buried in ',pname^[lx[ldr],ly[ldr]])
    ELSE IF LKing(ldr) = noleader THEN as:= ': a wandering Hero  '
    ELSE IF ldr < nkings THEN as:= ': a King character'
    ELSE IF Company = Roland THEN as:= Concat(': ',lname^[LKing(ldr)],'''s Hero')
    ELSE as:= Concat(': ',lname^[LKing(ldr)],'''s Hero');
{$ENDIF}
IF Length(as) > 26 THEN Delete(as,27,99);
  WRITE(playfile,as); IF Length(as) < 26 THEN WRITE(playfile,'':26-Length(as));
  IF impulse = 3 THEN Tell_Align
    ELSE IF LKing(ldr) <> kng THEN BEGIN
      Get_AbDesc(ldr,s);
      Delete(s,1,1); Delete(s,Length(s),1);
      WRITE(playfile,s);
      IF lstate[ldr] = Mercenary THEN IF LCost(ldr,kng) <= 3 THEN
         IF LKing(ldr) = noleader THEN BEGIN
        PR1;
{$IFDEF Russian}
        WRITELN(playfile,
          '  (��� ��, ��� �� ��蠫�, ������ ����㯨�� �� �㦡� � ��襬� �������� ',
          LCost(ldr,kng),' ����� �� ���)');
{$ELSE}
        WRITELN(playfile,
          '  (who, we hear, desires to enter thy Majesty''s service for ',
          LCost(ldr,kng),' gold per annum)');
{$ENDIF}
       END;
      IF tcp < nleaders THEN IF LDist(tcp,lx[ldr],ly[ldr]) <= 2 THEN BEGIN
        PR1;
        Tell_Align;
       END;
     END;
 END;

BEGIN {Rep_Leaders}
  tcp:= noleader;
  IF ((gamevers >= 4) or (gdyear >= 1992)) THEN IF LKing(titchar[Priest]) = kng THEN
    tcp:= titchar[Priest];
  Use_NewVal(true,true);
  IF Mail_Send(kng) THEN BEGIN
{   Page_Print;}
    WRITELN(playfile,chr(12));
   END;
  PR1;
{$IFDEF Russian}
  Expand_Write('���������   ',kng);
{$ELSE}
  Expand_Write('CHARACTERS   ',kng);
{$ENDIF}
  PR1;
{$IFDEF More_Entry}
  IF kng = viskng THEN IF gameturn = 0 THEN BEGIN
      WRITE('Va');
    Imp_Code(kng);
    Elite_On;
    Imp_Code(_LValHal);
    Elite_Off;
      WRITE(',');
   END;
{$ENDIF}
{$IFDEF Russian}
    WRITELN(playfile,
      '  ��� ��ᯮ���, ����⨭� ������� ���㤠�� ��襣� ��म�� ��஫���⢠.  ���� �᫨ ��');
    WRITELN(playfile,
      '����� �� ���, � ����� �� � ᯨ᮪ �� ��� ��ᬮ�७�� (��ࢠ� ��ப�     ');
    WRITELN(playfile,
      '�����뢠�� ������ � ������⢮, ��ப� 2 �����뢠�� ᪮���� ��६�饭�� � ᯮᮡ����.)       ');
{$ELSE}
    WRITELN(playfile,
      '  My Lord, Great indeed are the leaders of our proud kingdom.  Though thee');
    WRITELN(playfile,
      'knows them well, I list them here for thy consideration (the first line    ');
    WRITELN(playfile,
      'shows pay and abilities; line 2 shows move precedence and aptitude.)       ');
{$ENDIF}
  none:= true;
  FOR ldr:= 0 TO nleaders-1 DO ldr_init[ldr]:= Total_Skill(ldr)+M_Skill(ldr,ForcedMarch)*2;
  FOR impulse:= 1 TO 2+ord(LKing(tcp) = kng) DO BEGIN
   PR1;
{   FOR inival:= 100 DOWNTO 0 DO} FOR ldr:= 0 TO nleaders-1 DO
{    IF ldr_init[ldr] = inival THEN} IF Dispable(ldr) THEN BEGIN
{    na:= 0; nt:= 0;
  IF k2 = 0 THEN ACom('D',kng);
    kknows^[ldr]:= kknows^[ldr] or (longint(1) Shl kng);
    FOR fn:= 0 TO nfeatures-1 DO IF trowner[fn] = ldr THEN Inc(nt);
    FOR an:= 0 TO narmies-1 DO IF an <> 255 THEN IF aleader[an] = ldr THEN Inc(na);}
    IF none THEN BEGIN
{$IFDEF Russian}
WRITELN(playfile,
'                                       ����� ������.�஢��/���.���ᮡ����:');
      WRITELN(playfile,
'             �஢����                    /   �����    �����᪨� ��㣨�');
      UL;
      WRITELN(playfile,
'���ᮭ��     ��� ���  ��ࠪ� �/�  ��� ���� �������⏮ �������ራ �����ᘯ��');
{$ELSE}
      WRITELN(playfile,
'                                         Pay Modified Skills/Aptitudes:');
      WRITELN(playfile,
'             Province                     /  Combat     Magical    Other');
      UL;
      WRITELN(playfile,
'Character      Loc Align  Temp M/F  Race Ini TaMaNaArMe WhNeElPsIl DrThExSpSa');
{$ENDIF}
      NUL;
      WRITE(playfile,
'                                             ');
      FOR sk:= Tactical TO Sage DO BEGIN
        IF sk <= Melee THEN
            sk_mod:= ord(dknow^[kng,discovery(2*ord(sk))])
                    + ord(dknow^[kng,discovery(2*ord(sk)+1)])
          ELSE IF sk >= Druid THEN
            sk_mod:= ord(dknow^[kng,discovery(2*ord(sk)-10)])
                    + ord(dknow^[kng,discovery(2*ord(sk)-9)])
          ELSE sk_mod:= 0;
        CASE sk_mod OF
          0:   ts:= '  ';
          1:   ts:= '^ ';
          ELSE ts:= '^^';
         END;
        WRITE(playfile,ts);
        CASE sk OF Melee,Illusionist: WRITE(playfile,' '); END;
       END;
      WRITELN(playfile);
     END;
    Get_HName(ldr,14,s);
    WRITE(playfile,s); IF Length(s) < 14 THEN WRITE(playfile,' ':14-Length(s));
    IF Gender(ldr) < 0 THEN c:= 'F' ELSE c:= 'M';
    IF impulse <= 2 THEN BEGIN
        Get_PN(lx[ldr],ly[ldr],ps);
        WRITE(playfile,ps:4);
       END
      ELSE WRITE(playfile,'    ');
    IF impulse = 1 THEN BEGIN
        IF ldr = titchar[Cravenest] THEN IF ltemper[ldr] < Berserk THEN
          Inc(ltemper[ldr]);
        WRITE(playfile,outab[lalign[ldr]]:6,tempab[ltemper[ldr]]:6,
                       c:3,rname[lrace[ldr]]:7,LCost(ldr,kng):3,' ');
        IF ldr = prevchar[BattleFool] THEN IF aptitude^[ldr,Tactical] < 5 THEN
          Inc(aptitude^[ldr,Tactical]);
        space_sub:= 0;
        FOR sk:= tactical to Sage DO BEGIN
          WRITE(playfile,M_Skill(ldr,sk):2 -space_sub +ord(ord(sk) MOD 5 = 0));
          tr:= treasure(ord(sk)+ord(hla));
          space_sub:= NT_Owned(ldr,tr,tr,trdex);
          IF space_sub > 0 THEN CASE space_sub OF
            1: WRITE(playfile,'''');
            ELSE WRITE(playfile,'"');
           END;
          IF space_sub > 1 THEN space_sub:= 1;
         END;
       END
      ELSE Desc_Stranger;
    PR1;
    IF impulse = 1 THEN List_Treas(ldr,false);
    none:= false;
   END;
  END;
{$IFDEF Russian}
  IF none THEN WRITELN(playfile,'��祣� ᥩ��');
{$ELSE}
  IF none THEN WRITELN(playfile,'None at present');
{$ENDIF}
  Use_NewVal(false,true);
 END;

PROCEDURE Rep_Armies;
VAR pac,lac,aq,l,ldr,na,nt,fn,an,px,py,llen,apres,alled,provand: integer;
    Strx: Str40;
    s,ps: Str20;
    elf_dinos,thirsty,magldr,strip: boolean;
    passtype: state;

FUNCTION Eligible(an: integer): boolean;
BEGIN
  IF passtype = Hired THEN Eligible:= Commanded(an)
    ELSE Eligible:= Known_Merc(an,kng);
 END;

FUNCTION Prov_Armies(px,py,kng,ldr: integer): byte;
VAR an,ac: integer;

PROCEDURE Count;
BEGIN  Inc(ac); IF atype[an] = Camels THEN IF A_Led(an,kng) THEN thirsty:= false; END;

BEGIN
  ac:= 0;
  FOR an:= 0 TO narmies-1 DO IF an <> 255 THEN IF ax[an] = px THEN IF ay[an] = py THEN
    IF Eligible(an) THEN
      IF passtype = Hired THEN
        CASE ldr OF
         -1: Count;
         -2: IF LKing(aleader[an]) = kng THEN Count;
          ELSE IF aleader[an] = ldr THEN Inc(ac);
         END
        ELSE Count;
  Prov_Armies:= ac;
 END;

PROCEDURE Doit;
VAR an,fkn: integer;
BEGIN
  alled:= Prov_Armies(px,py,kng,ldr); lac:= 0;
  Get_PN(px,py,ps);
  FOR an:= 0 TO narmies-1 DO IF an <> 255 THEN IF aleader[an] = ldr THEN IF Eligible(an) THEN
    IF ax[an] = px THEN IF ay[an] = py THEN BEGIN
      IF strip THEN BEGIN
        IF passtype = Mercenary THEN BEGIN
          PR1;
{$IFDEF Russian}
           WRITELN(playfile,'  �� ����� ������ ᫥���騥 ����� ������ᨬ�� ���������:    ');
          PR1;
         END;
        WRITE(playfile,
          '                                                            ��ଠ���');
        IF passtype = Hired THEN WRITELN(playfile,'  ������஢����') ELSE PR1;
        UL; WRITE(playfile,
          '�஢����         �����          �����祭��           ��� ���ᯮᮡ�����');
        IF passtype = Hired THEN WRITELN(playfile,'  ���ᯮᮡ�����') ELSE PR1;
{$ELSE}
          WRITELN(playfile,'  The following unit(s) are independent mercenaries which you may Recruit:    ');
          PR1;
         END;
        WRITE(playfile,
          '                                                              Normal');
        IF passtype = Hired THEN WRITELN(playfile,'  Modified') ELSE PR1;
        UL; WRITE(playfile,
          'Province          Leader         Designation           Race   Quality');
        IF passtype = Hired THEN WRITELN(playfile,'  Quality') ELSE PR1;
{$ENDIF}
        NUL;
       END;
      Inc(pac); Inc(lac);
      IF lac = alled THEN UL;
      IF none THEN BEGIN
          IF ksendmeth[kng] < S_Disk THEN IF passtype = Hired THEN PR1;
{$IFDEF Russian}
          s:= pname^[px,py]; IF Pos('',s) = 1 THEN Delete(s,1,4);
{$ELSE}
          s:= pname^[px,py]; IF Pos('the',s) = 1 THEN Delete(s,1,4);
{$ENDIF}
          IF apres <= 1 THEN BEGIN
            IF Length(s) > 12 THEN Delete(s,13,99);
            s:= Concat(s,'/',ps,' ');
           END;
          none:= false;
          strip:= false;
         END
        ELSE IF ((pac = 2) and (apres >= 2)) THEN s:= Concat('(#',ps,')')
        ELSE s:= '';
      WRITE(playfile,s,'':18-Length(s));
      IF magldr THEN BEGIN
          IF ldr = noleader THEN BEGIN
{$IFDEF Russian}
              IF passtype = Hired THEN s:= '��୨���' ELSE s:= '';
{$ELSE}
              IF passtype = Hired THEN s:= 'Garrison' ELSE s:= '';
{$ENDIF}
             END
            ELSE s:= Copy(lname^[ldr],1,15);
         END
        ELSE s:= '';
      WRITE(playfile,s,'':15-Length(s));
      magldr:= false;
      Make_Des(an,s);
{$IFDEF Russian}
      IF astate[an] = Zomboid THEN strx:= Concat(s,' ���� ',atdesig[Mod_AType(an)])
{$ELSE}
      IF astate[an] = Zomboid THEN strx:= Concat(s,' Skel ',atdesig[Mod_AType(an)])
{$ENDIF}
        ELSE strx:= Concat(s,' ',atname[Mod_AType(an)]);
      WRITE(playfile,strx,'':20-Length(strx));
      WRITE(playfile,rname[Mod_ARace(an)]:7);
      fkn:= LKing(aleader[an]);
      IF ((fkn <> kng) and (fkn < nkings)) THEN BEGIN
{$IFDEF Russian}
          IF Company = Roland THEN WRITELN(playfile,' (� ',lname^[fkn],')')
            ELSE WRITELN(playfile,' (',lname^[fkn],'''�)')
{$ELSE}
          IF Company = Roland THEN WRITELN(playfile,' (hommes de ',lname^[fkn],')')
            ELSE WRITELN(playfile,' (',lname^[fkn],'''s men)')
{$ENDIF}
         END
        ELSE BEGIN
          WRITE(playfile,qname[aqual[an]]:9);
          IF passtype = Hired THEN BEGIN
            aq:= ord(aqual[an])+Qual_Modfr(an,ldr,kng,noleader,thirsty)+
              ord((gamevers >= 2) and (ax[an] = bornx[playking]) and
                  (ay[an] = borny[playking]));
            IF aq < ord(Depleted) THEN strx:= 'Sub-Depl'
              ELSE IF aq > ord(Elite) THEN strx:= 'Super-El'
              ELSE strx:= qname[quality(aq)];
            WRITE(playfile,strx:9);
           END;
          WRITELN(playfile);
         END;
      IF lac = alled THEN NUL;
     END;
 END;

BEGIN
  elf_dinos:= false;
  FOR an:= 0 TO narmies-1 DO IF an <> 255 THEN BEGIN
    IF atype[an] = Dinosaurs THEN IF arace[an] = Elven THEN BEGIN
      arace[an]:= Saurian;
      elf_dinos:= true;
     END;
   END;
  PR2;
{$IFDEF Russian}
Expand_Write('�����',kng);
  PR1;
  WRITELN(playfile,
    '   �ॢ��室���訩, ��� �ନ� �⫨筮 ���७�஢��� � �� ��㦨� ���祭�.');
  WRITELN(playfile,
    '������� ����쥬 ��� ������ �㦨�� ��襬� ��������, � ��� ������� ���� �ਪ����.');
{$ELSE}
  Expand_Write('ARMIES',kng);
  PR1;
  WRITELN(playfile,
    '  Excellence, thy armies have trained hard and honed their weapons to a fine');
  WRITELN(playfile,
    'edge.  Proudly they serve thy imperial majesty, and they await thy commands.');
{$ENDIF}
  PR1;
  FOR passtype:= Hired TO Mercenary DO BEGIN
    strip:= true;
    IF passtype = Hired THEN provand:= 5 ELSE provand:= 8;
    FOR px:= left TO right DO FOR py:= top TO bottom DO IF provpres[px,py] and provand <> 0 THEN BEGIN
      none:= true;
{$IFNDEF Noble}
      thirsty:= pterr[px,py] = Desert;
{$ELSE}
      thirsty:= false;
{$ENDIF}
      apres:= Prov_Armies(px,py,kng,-1-ord(powner[px,py] <> kng));
      IF apres > 0 THEN BEGIN
        pac:= 0;
        FOR l:= 0 TO nleaders-ord((passtype = Hired) and (powner[px,py] <> kng)) DO BEGIN
          IF l = nleaders THEN ldr:= noleader ELSE ldr:= l;
          magldr:= true;
          IF ((ldr = noleader) or (LKing(ldr) = kng) or
              (powner[lx[ldr],ly[ldr]] = kng)) THEN Doit;
         END;
       END;
     END;
{$IFDEF Russian}
    IF strip THEN IF passtype = Hired THEN WRITELN(playfile,'��祣� ᥩ��');
{$ELSE}
    IF strip THEN IF passtype = Hired THEN WRITELN(playfile,'None at present');
{$ENDIF}
    PR1;
   END;
  IF elf_dinos THEN WRITELN(playfile,'***Important Note: The race of Dinosaurs has changed from Elven to Saurian.');
{$IFDEF Russian}
  WRITELN(playfile,'  �ਬ�砭��: "������஢����� ���ᯮᮡ�����" ����砥� ����䨪���� ��� ��襩 ����譥� �஢��樨,    ');
  WRITELN(playfile,'����뭭�� ���⭮��, ᯥ樠��� �����᪨� �।����, ��� � ������⢮ ��㨤�.       ');
{$ELSE}
  WRITELN(playfile,'  Note: "Modified Quality" includes the modifiers for your home-province    ');
  WRITELN(playfile,'bonus, desert terrain, special magic items, race and druidic ability.       ');
{$ENDIF}
 END;

BEGIN
  WRITELN(' RL:',lgold[kng]);
  Rep_Leaders;
  WRITELN(' RA:',lgold[kng]);
  Rep_Armies;
  WRITELN(' RLx:',lgold[kng]);
 END;

PROCEDURE Prep_Stats;
VAR an,fn,lk,x,y: integer;

PROCEDURE Or_It(VAR xyl: byte; orn: byte);
BEGIN xyl:= xyl or orn; END;

BEGIN
{$IFDEF Russian}
WRITE('�ਣ�⮢����� �����...');
{$ELSE}
  WRITE('Preparing stats...');
{$ENDIF}
  FOR x:= left TO right DO FOR y:= top TO bottom DO BEGIN
    provpres[x,y]:= 0;
    IF powner[x,y] = playking THEN Or_It(provpres[x,y],1);
   END;
  FOR lk:= 0 TO nleaders-1 DO
    IF LKing(lk) = playking THEN Or_It(provpres[lx[lk],ly[lk]],2)
      ELSE Or_It(provpres[lx[lk],ly[lk]],32);
  FOR an:= 0 TO narmies-1 DO IF an <> 255 THEN
    IF astate[an] = Mercenary THEN Or_It(provpres[ax[an],ay[an]],8)
      ELSE IF A_Led(an,playking) THEN Or_It(provpres[ax[an],ay[an]],4);
  FOR fn:= 0 TO nfeatures-1 DO IF fdisc^[playking,fn] > 0 THEN
    Or_It(provpres[fx[fn],fy[fn]],16);
 END;

{$IFNDEF Noble}

FUNCTION Tit_Pts(ldr: integer; tit: office): integer;
VAR tix: integer;
BEGIN
  tix:= Find_Record(ldr,tit);
  IF tix >= 0 THEN Tit_Pts:= tipts^[tix] ELSE Tit_Pts:= 0;
 END;

FUNCTION Ofc_Pts(ldran: integer; ofc: office; inclemp: boolean): integer;
label 99;
VAR pts,x,y,tr,lk,t: integer;
    a: ability;
BEGIN
  Check_Debug('!');
  IF init_ofc THEN IF not Army_Office(ofc) THEN IF ((inclemp) or (ofc <> Emperor)) THEN BEGIN
    Ofc_Pts:= oops^[ldran,ofc];
    pts:= oops^[ldran,ofc];
    GOTO 99;
   END;
  Check_Debug('@');
  pts:= 0;
  IF Army_Office(ofc) THEN lk:= A_Owner(ldran) ELSE lk:= LKing(ldran);
  Check_Debug('$');
  IF lk < nkings THEN CASE ofc OF
    Emperor:  IF ldran < nkings THEN pts:= alltax[ldran] +
      512*ord((inclemp) and (emp = ldran));
    Chancellor: BEGIN
      pts:= M_Skill(ldran,Spy) +M_Skill(ldran,Sage) +M_Skill(ldran,Explorer)
        +(2*lfdisc[ldran]) +ldiscp[ldran];
     END;
    Treasurer: IF ldran < nkings THEN pts:= lgold[ldran];
    Marshal: pts:= lgenp^[ldran];
    Admiral: BEGIN
      pts:= ladmp^[ldran] + M_Skill(ldran,Naval);
      IF lk < nkings THEN pts:= pts+seatax[lk];
     END;
    Defender: pts:= lmhpp^[ldran];
    Priest: pts:= lwmsp[ldran]+2*(M_Skill(ldran,Druid)+M_Skill(ldran,White));
    Mage: BEGIN
      pts:= ltro[ldran];
      FOR a:= White TO Illusionist DO pts:= pts+M_Skill(ldran,a);
     END;
    Humanking..WhaleKing,Mermanking..Wereking:
      pts:= Tit_Pts(ldran,ofc) Shl ord(lrace[ldran] = race(ord(ofc)-ord(HumanKing)));
    Wingman,Cravenest,Bravest,Plainsking..Seaking,Thiefprince,Diplomat,
      Teacher,Assassin,Duellist,Ele_Mage,Illus_Mage,Psychic_Mage,Necro_Mage:
        pts:= Tit_Pts(ldran,ofc);
    Divineking..Evilking,UndeadKing: IF ldran < nkings THEN
      IF lalign[ldran] = outlook(ord(ofc)-ord(DivineKing)) THEN
        pts:= Tax_Base(ldran);
    Battlefool: pts:= -(lgenp^[ldran]+ladmp^[ldran]);
    Airforce: IF aqual[ldran] >= Crack THEN IF Air_Unit(ldran,false) THEN IF A_Owner(ldran) < nkings THEN
      pts:= Army_Str(ldran,empldr,empldr,empldr,bornx[empldr],borny[empldr],
              Tactical,noarmy,true,false,true,true,0,false);
    Chief_Of_Staff: pts:= M_Skill(ldran,Tactical)+
                          M_Skill(ldran,ForcedMarch)+
                          M_Skill(ldran,Naval)+
                          M_Skill(ldran,Druid);
    Curator: pts:= NT_Owned(ldran,hla,rali,t);
    Praetor: IF aqual[ldran] >= Crack THEN IF not Air_Unit(ldran,false) THEN IF A_Owner(ldran) < nkings THEN
      pts:= Army_Str(ldran,empldr,empldr,empldr,bornx[empldr],borny[empldr],
              Tactical,noarmy,true,false,true,true,0,false) + atspeed[atype[ldran]];
    Flagship: IF aqual[ldran] >= Crack THEN CASE atype[ldran] OF Mermen,Whaleleague,Fleet:
      IF A_Owner(ldran) < nkings THEN
        pts:= Army_Str(ldran,empldr,empldr,empldr,ax[ldran],ay[ldran],
                Naval,noarmy,true,false,true,true,0,false);
     END;
   END;
  Ofc_Pts:= pts;

99:{      IF ((playking = 2) or (playking = 5)) THEN IF ((ldran = 2) or (ldran = 25)) THEN
  IF ofc = Chancellor THEN BEGIN
        WRITE(' Ch-',ldran,':',pts,'.'); READLN;
       END;
    }
  Check_Debug('#');
 END;

FUNCTION Rank(ldran,lpts: integer; ofc: office;
              VAR ftoppts: integer): integer;
VAR tlpts,tldran,betters,rftop,alltops,lak,tlak,btlak,lanfin: integer;

PROCEDURE Change_Best;
BEGIN
  bestofficer:= tldran;
  IF ofc = Emperor THEN
    IF emp <> No_King THEN empldr:= emp ELSE empldr:= bestofficer;
  btlak:= tlak;
  alltops:= tlpts;
{  IF ofc = Praetor THEN IF playking = 4 THEN BEGIN
    WRITE('[P',tldran,'/',tlpts,'/',btlak,']');
    READLN;
   END;}
 END;

PROCEDURE Keep_Best; BEGIN  END;

BEGIN
  ftoppts:= 0; betters:= 0; alltops:= 0; bestofficer:= noleader;
  rftop:= 0;
  IF not Army_Office(ofc) THEN BEGIN
      lak:= LKing(ldran);
      lanfin:= nleaders-1;
     END
    ELSE BEGIN  lak:= A_Owner(ldran); lanfin:= narmies-1; END;
  FOR tldran:= 0 TO lanfin DO IF tldran <> noleader THEN BEGIN
    IF not Army_Office(ofc) THEN tlak:= LKing(tldran)
      ELSE tlak:= A_Owner(tldran);
    IF tlak < nkings THEN BEGIN
      tlpts:= Ofc_Pts(tldran,ofc,true);
      IF tlpts > alltops THEN Change_Best
        ELSE IF tlpts = alltops THEN IF tlpts > 0 THEN
          IF ((ofc >= Humanking) and (titchar[ofc] = tldran)) THEN Change_Best
            ELSE IF ((ofc >= Humanking) and (titchar[ofc] = bestofficer)) THEN
              Keep_Best
            ELSE IF lgold[tlak] > lgold[btlak] THEN Change_Best
            ELSE IF lgold[tlak] = lgold[btlak] THEN
              IF Tax_Base(tlak) > Tax_Base(btlak) THEN Change_Best
                ELSE IF Tax_Base(tlak) = Tax_Base(btlak) THEN
                  IF tldran < bestofficer THEN Change_Best;
      IF lak <> tlak THEN IF tlpts > ftoppts THEN BEGIN
        ftoppts:= tlpts;
        IF ldran <> tldran THEN rftop:= Ofc_Pts(tldran,ofc,false);
       END;
      IF tlpts > lpts THEN Inc(betters);
     END;
   END;
  IF bestofficer <> ldran THEN IF betters = 0 THEN betters:= 1;
  Rank:= betters+1;
  ftoppts:= rftop;
 END;
{$ENDIF}

PROCEDURE Tell_Mem;
{$IFDEF Russian}
BEGIN WRITELN('Heap MemAvail: ',Memavail,'  MaxAvail: ',MaxAvail); READLN; END;
{$ELSE}
BEGIN WRITELN('Heap MemAvail: ',Memavail,'  MaxAvail: ',MaxAvail); READLN; END;
{$ENDIF}

PROCEDURE Init_Points;
VAR x,y,lk,ldr,bestpts,t: integer;
    ofc,last_office: office;
BEGIN
  Check_Debug('1');
  FOR lk:= 0 TO nkings-1 DO BEGIN
    seatax[lk]:= 0;
    alltax[lk]:= Tax_Base(lk);
   END;
  Check_Debug('2');
  FOR lk:= 0 TO nleaders-1 DO
    ltro[lk]:= NT_Owned(lk,wcp,pic,x);
  Check_Debug('3');
  FOR x:= left TO right DO FOR y:= top TO bottom DO
    IF powner[x,y] < nkings THEN IF pterr[x,y] = Sea THEN
      IF ptax[x,y] > 1 THEN Inc(seatax[powner[x,y]]);
  Check_Debug('4');
{$IFDEF Russian}
  WRITELN('���樠������ 誠�� �������⥩...');
{$ELSE}
  WRITELN('Initializing office points...');
{$ENDIF}
{  Release(jptr);}
  Check_Debug('5');
{$IFNDEF Noble}
  New(oops);
  Check_Debug('6');
  bestpts:= Ofc_Pts(0,Emperor,false); {+Sets empldr}
  bestpts:= Rank(0,bestpts,Emperor,t);
  Check_Debug('7');
  IF ((NR_Or_G4) and (gameturn > 0)) THEN last_office:= Bravest
    ELSE last_office:= Mage;
  Check_Debug('8');
  FOR ofc:= Emperor TO last_office DO IF ofc <> NoOffice THEN IF not Army_Office(ofc) THEN BEGIN
    WRITELN(ord(ofc));
    FOR ldr:= 0 TO nleaders-1 DO oops^[ldr,ofc]:= Ofc_Pts(ldr,ofc,true);
  Check_Debug('9');
   END;
{$ENDIF}
  init_ofc:= true;
  Check_Debug('0');
 END;

{$IFNDEF Noble}
PROCEDURE Pray_Report(kng: krange; regrep: boolean);
label 10,90;
VAR ldr,l2,lpts,lp2,ftoppts,bestpts,bestldr,nextpts,nextldr,perc,rnk,k,k2,tk,
      empperc,bestperc,posperc,trdex,bestlk,totpoints,trp,lanfin,lak,bestrnk,
      bestlak,acc1,team,maxteam,best_team,team2,dec_perc,dec_gt,reqperc: integer;
    last_office,ofc: office;
    krank: array[krange] of krange;
    ofcpoints: array[office] of real;
    kingpoints,k_indivpoints: array[krange] of real;
    team_points: array[0..16] of real;
    team_taxes,team_kings,trank: array[0..16] of integer;
    team_treas: array[0..16] of longint;
    min_al,max_al: outlook;
    tkp,hip,lasthip: real;
    rivstr: str10;
    ostr,ts,namstr: Str40;
    kalign,empalign: outlook;
    prcred: longint;
    reduct: real;
    y,m,d,dw: word;
    main_rep,need_pr: boolean;
    diff_steps: integer;

FUNCTION Read_SA(kn: integer): boolean;
VAR i,vcode: integer;
BEGIN
  acc1:= 0;
  GetDate(y,m,d,dw);
  Str(gameno,ts);
{$IFDEF Russian}
  tmp:= Concat('���������',ts);
{$ELSE}
  tmp:= Concat('SETUP',ts);
{$ENDIF}
  Assign(miscfile,tmp);
  AReset(miscfile);
  IF IOResult <> 0 THEN Read_SA:= false
    ELSE BEGIN
      FOR i:= 1 TO 12 DO READLN(miscfile);
      IF kn > 0 THEN FOR i:= 1 TO kn*17 DO READLN(miscfile);
      READLN(miscfile,tmp);
      Delete(tmp,Pos(' ',tmp),99);
    {$R-}
      Val(tmp,acc1,vcode);
    {$R+}
      Read_SA:= vcode = 0;
      IF vcode <> 0 THEN acc1:= 0;
      WRITELN(kn,': Acc= ',acc1);
      AClose(miscfile);
     END;
 END;

PROCEDURE Induct_Val(vldr: integer);

PROCEDURE Write_VF(vdex: integer);
VAR vs: Str40;
    mf2: text;
    vmembs,vperl,trt,trn,vline: integer;
BEGIN
  Get_VFN(vldr,vs,vdex);
  Assign(miscfile,vs);
  AReset(miscfile);
  IF IOResult = 0 THEN BEGIN
    Assign(mf2,'C:\tp\prose\vxx');
    ARewrite(mf2);
    IF IOResult = 0 THEN BEGIN
        READLN(miscfile,vmembs,vperl);
        Inc(vmembs);
        WRITELN(mf2,vmembs,' ',vperl);
        IF vdex = 2 THEN BEGIN
            Write_Ldr(vldr,mf2);
            trt:= IRand and 31;
            FOR trn:= 0 TO ntreasures-1 DO IF trowner[trn] = vldr THEN
              IF treaslist[trn] < LargeTr THEN trt:= ord(treaslist[trn]);
            WRITELN(mf2,sex[vldr],' ',trt,' ',kacct[kng]);
{$IFDEF Russian}
           END
          ELSE BEGIN
            WRITELN(mf2,'< �� ���饭 ��஥� �� �������� �� ����� ',lname^[vldr],
              '!��ࠪ���⨪� �⮣� �������� ��஫� ',gameno,' ���� � ��襬 ���� "���������".');
{$ELSE}
           END
          ELSE BEGIN
            WRITELN(mf2,'< was visited by a hero from Valhalla, named ',lname^[vldr],
              '!The characteristics for this great King from Game ',gameno,' are given in your "CHARACTERS" report.');
{$ENDIF}
            FOR vline:= 1 TO 3 DO WRITELN(mf2);
           END;
        REPEAT
          READLN(miscfile,tmp);
          WRITELN(mf2,tmp);
        UNTIL ((eof(miscfile)) or (IOResult <> 0));
        AClose(miscfile);
        AClose(mf2);
        Erase(miscfile);
        Get_VFN(vldr,vs,vdex);
        rename(mf2,vs);
       END
      ELSE AClose(miscfile);
   END;

 END;

BEGIN {Induct_Val}
  Write_VF(2);
  Write_VF(1);
 END;

FUNCTION LMin(i1,i2: longint): longint;
BEGIN IF i1 < i2 THEN LMin:= i1 ELSE LMin:= i2; END;

PROCEDURE Tell_Items(scen: integer);
VAR trdex,tro: integer;
    writ_tit: boolean;
BEGIN
    writ_tit:= false;
    FOR trdex:= 0 TO ntreasures-1 DO BEGIN
      tro:= trowner[trdex];
      bestlk:= LKing(tro);
      IF gametyp = Arcanes_V THEN CASE treaslist[trdex] OF
          Crown_Rohan..Scepter_Life: trp:= ord(tro < unkldr);
          ELSE trp:= 0;
         END
        ELSE trp:= trvic[treaslist[trdex]];
      IF trp > 0 THEN BEGIN
        IF not writ_tit THEN BEGIN
          PR2;
{$IFDEF Russian}
          WRITELN(playfile,'� ��� ᥩ�� ᫥���騥 �����᪨� �।����:     ');
{$ELSE}
          WRITELN(playfile,'The following Greater Magic Items are in play:     ');
{$ENDIF}
          PR1;
          writ_tit:= true;
         END;
        WRITE(playfile,Tr_Name(treaslist[trdex]),': ');
        IF scen = Arcanes_V THEN
            WRITELN(playfile,'in ',pname^[lx[tro],ly[tro]])
          ELSE IF bestlk < nkings THEN BEGIN
            kingpoints[bestlk]:= kingpoints[bestlk]+trvic[treaslist[trdex]];
            IF tro < nkings THEN
              k_indivpoints[bestlk]:= k_indivpoints[bestlk] + trvic[treaslist[trdex]];
            WRITELN(playfile,lname^[bestlk]);
           END
{$IFDEF Russian}
          ELSE IF tro < 256 THEN WRITELN(playfile,' ����ﭭ� ���䠪�.   ')
          ELSE WRITELN(playfile,'',mtname[fmonst[tro and 255]],' �ᯮ����� � ���⮯ਬ��⥫쭮�� #',
            tro and 255);
{$ELSE}
          ELSE IF tro < 256 THEN WRITELN(playfile,' a lost artifact.   ')
          ELSE WRITELN(playfile,'the ',mtname[fmonst[tro and 255]],' located in feature #',trowner[trdex] and 255);
{$ENDIF}
       END;
     END;
 END;

BEGIN {Pray_Report}
  main_rep:= ((regrep) and (not summ_write));
  IF not regrep THEN BEGIN
    PR2;
{$IFDEF Russian}
    WRITELN(playfile,'    ����� �� ����    ',gameno,':');
{$ELSE}
    WRITELN(playfile,'GAME REPORT FOR GAME ',gameno,':');
{$ENDIF}
    WRITELN(playfile,'--------------------------');
    PR1;
   END;
  IF tktax > 0 THEN BEGIN
    PR2;
{$IFDEF Russian}
    Expand_Write('����� �������    ',kng);
    PR1;
      WRITELN(playfile,
    '   �� �⮬ �⠯� ���� �뫮 �஢����� ����ᮢ���� ',gameno,'.  ��� ��� १�����:');
    PR1;
    UL;
    WRITELN(playfile,'                   �����');
    WRITELN(playfile,'��஫�              ������   ����ᮢ �� ��஫�   ����祭� ����ᮢ');
{$ELSE}
    Expand_Write('ELECTION REPORT    ',kng);
    PR1;
      WRITELN(playfile,
    '   A vote was held this turn in game ',gameno,'.  Here are the results:');
    PR1;
    UL;
    WRITELN(playfile,'                   Votes');
    WRITELN(playfile,'King                Cast  Voted for King   Votes Received');
{$ENDIF}
    NUL;
    FOR k2:= 0 TO nkings-1 DO BEGIN
      kknows^[k2]:= kknows^[k2] or (longint(1) Shl kng);
      WRITE(playfile,lname^[k2],'':19-Length(lname^[k2]));
{$IFDEF Russian}
      IF kprevgold[k2]=No_King THEN WRITE(playfile,'   0   �� ������           ')
{$ELSE}
      IF kprevgold[k2]=No_King THEN WRITE(playfile,'   0   No one           ')
{$ENDIF}
        ELSE BEGIN
          namstr:= lname^[kprevgold[k2]];
          WRITE(playfile,kpower[k2]:4,'   ',namstr,'':17-Length(namstr));
         END;
      WRITELN(playfile,kvotes[k2]:4,' votes (',Trunc(kvotes[k2]/tottax*100.0),'%)');
     END;
    WRITELN(playfile,'Neutral Characters ',tottax-tktax:4,'   No one');
   END;
  IF NT_Owned(emp,Crown_Rohan,Scepter_Life,trdex) >= 3 THEN BEGIN
    PR2;
    KStr(emp,tmp);
    WRITELN(playfile,'  The Crown of Rohan, Scepter of Life and Amulet of Power have been united!');
    WRITELN(playfile,'All races are unified under the awesome power of "Arcane''s Valor" and its');
    WRITELN(playfile,'glorious wielder, ',tmp,'!');
   END;
  bestperc:= 0; empperc:= 0;
  PR2;
{$IFDEF Russian}
Expand_Write('����� � ������������� ���������� �������',kng);
  PR1;
  IF emp = No_King THEN BEGIN
      WRITELN(playfile,
    '  � ���� ��ந�᪨� ����� ���� ��� ��ᯮ᫠���� ��� �������, �������襥 �');
      WRITELN(playfile,
  '���� �ᯥ�� �� ��� � ����祭�� �����᪮� ��������. �� ����� ᬥ��� ��஫� �����');
      WRITELN(playfile,
    '�����, �� ��������� � ��� �� ���訥 ��������, �� �ᥢ�譨� �������� ���');
      WRITELN(playfile,
    '㧭��� ��� ���� �� �쥤��⠫�, � ��� ᮮ⭮襭�� � ����묨 �������묨');
      WRITELN(playfile,
    '��⥭���⠬� �� ������ ��������� (ᬮ�� ��� "����%" ��� ��業�: ��� �窨, ������� �� ');
      WRITELN(playfile,'�窨 ��襣� ᮯ�୨�� � 㬭������ �� 100.)');
{$ELSE}
Expand_Write('IMPERIAL OFFICE REPORT',kng);
  PR1;
  IF emp = No_King THEN BEGIN
      WRITELN(playfile,
    '  Into thy heroic dreams cometh an apparition heaven-sent, to speak to thee of');
      WRITELN(playfile,
  'thy progress in thy ambitions for Imperial Office.  It is not for mortal Kings');
      WRITELN(playfile,
    'to know who rivals them for high offices, but the Divine One will allow you to');
      WRITELN(playfile,
    'know thy place in the standings, and how thee compares to thy fiercest foreign');
      WRITELN(playfile,
    'rival for each office (shown under "Riv%" as a percentage: your points divided');
      WRITELN(playfile,'by your rival''s points, times 100.)');
{$ENDIF}
     END
    ELSE BEGIN
      KStr(emp,ts);
{$IFDEF Russian}
WRITELN(playfile,
    '  ��� ��ꥤ������ ������� ��� ������� ������ �������.  ��');
      WRITELN(playfile,
    '��஫� ���㫨 �� ��୮��� ',ts,'!');
      WRITELN(playfile,
    '   ��� ���砩��� ������, ������� ��।���� ���訥 �������� ����ਨ');
      WRITELN(playfile,
    '����� ��⠫�묨 ��஫ﬨ � ᮮ⢥��⢨� � �� ���㣠��.  � ��஫�, ��। ���� ������ ��� �⮩ ᫠����');
      WRITELN(playfile,
    '����ਨ, ⠪��, ��� � ᮮ⢥�����騥 ���訥 ��������� ��� ��襣� ᮡ�⢥����� ��஫���⢠:');
{$ELSE}
      WRITELN(playfile,
    '  The world has finally been united under the rule of one Emperor.  All');
      WRITELN(playfile,
    'Kings now owe their allegiance to ',ts,'!');
      WRITELN(playfile,
    '   In his Divine wisdom, the Emperor has distributed high imperial office to');
      WRITELN(playfile,
    'those Kings who merit it most.  O King, here are the Officers of this glorious');
      WRITELN(playfile,
    'Empire, as well as the highest corresponding Officer in thine own Kingdom:');
{$ENDIF}
END;
  PR1;
  UL;
{$IFDEF Russian}
  IF emp = No_King THEN WRITELN(playfile,
'�����᪠� ���������    �᭮���� �������  ������ ����%  ��㣠� ������� ������ ����%')
    ELSE WRITELN(playfile,
'�����᪠� ���������       �����᪨� ���/��஫���⢮   ��஫��᪨� ��� ������ ����%');
{$ELSE}
  IF emp = No_King THEN WRITELN(playfile,
'Imperial Office           Best Hope     Rank  Riv%   Second Hope   Rank  Riv%')
    ELSE WRITELN(playfile,
'Imperial Office           Imperial Officer/Kingdom   Royal Officer  Rnk  Riv%');
{$ENDIF}
  NUL;
  totpoints:= 0;
  FOR k:= 0 TO nkings-1 DO BEGIN
    kingpoints[k]:= 0;
    k_indivpoints[k]:= 0;
   END;
  IF ((NR_Or_G4) and (gameturn > 0)) THEN last_office:= Bravest ELSE last_office:= Mage;
  IF Brian_Game THEN last_office:= Mage;
{  IF standby[kng] <> SB_Waiting THEN} FOR ofc:= Emperor TO last_office DO IF ofc <> NoOffice THEN
   IF ((gamevers >= 4) or (gametyp = Valhalla_V) or (ofcuse[ofc])) THEN BEGIN
    ofcpoints[ofc]:= 0.0;
    bestpts:= 0; nextpts:= 0; bestldr:= noleader; nextldr:= noleader;
    bestlak:= noleader; bestrnk:= 9999;
    IF Army_Office(ofc) THEN lanfin:= narmies-1 ELSE lanfin:= nleaders-1;
    WRITELN; WRITELN;
    FOR ldr:= 0 TO lanfin DO IF ldr <> noleader THEN BEGIN
     IF not Army_Office(ofc) THEN lak:= LKing(ldr)
       ELSE lak:= A_Owner(ldr);
     IF lak < nkings THEN IF ((Army_Office(ofc)) or (ldr <> valhero)) THEN
       IF ((emp <> No_King) or (lak = kng)) THEN BEGIN
        lpts:= Ofc_Pts(ldr,ofc,true);
        IF lpts > bestpts THEN BEGIN
10:         IF bestlak = kng THEN BEGIN
              nextldr:= bestldr;
              nextpts:= bestpts;
             END;
            bestpts:= lpts; bestldr:= ldr; bestlak:= lak;
           END
          ELSE IF lpts = bestpts THEN BEGIN
            IF Rank(ldr,lpts,ofc,ftoppts) <=
                Rank(bestldr,bestpts,ofc,ftoppts) THEN GOTO 10;
           END
          ELSE IF lpts > nextpts THEN IF lak = kng THEN BEGIN
            nextpts:= lpts;
            nextldr:= ldr;
           END;
         END;
       END;
    ostr:= ofcname[ofc]; While Length(ostr) < 26 DO ostr:= Concat(ostr,' ');
    IF bestldr <> noleader THEN BEGIN
        IF ofc = Emperor THEN empldr:= bestldr;
        bestpts:= Ofc_Pts(bestldr,ofc,false);
        rnk:= Rank(bestldr,bestpts,ofc,ftoppts);
        bestrnk:= rnk;
        posperc:= 100;
{$IFDEF Russian}
        IF ftoppts = 0 THEN rivstr:= ' ��祣�'
          ELSE BEGIN
            WRITE(' PP:',bestpts,'/',ftoppts{,'/',bestldr,'/',ord(ofc),'/',rnk,'/',kng,'/',ord(regrep),'.'});
{$ELSE}
        IF ftoppts = 0 THEN rivstr:= ' None'
          ELSE BEGIN
            WRITE(' PP:',bestpts,'/',ftoppts{,'/',bestldr,'/',ord(ofc),'/',rnk,'/',kng,'/',ord(regrep),'.'});
{$ENDIF}
            posperc:= LMin(30000,Trunc(100*(bestpts/ftoppts)));
            IF ofc = Emperor THEN empperc:= Min(100,posperc)
              ELSE IF ofc < NoOffice THEN bestperc:= Max(posperc,bestperc);
            Str(posperc,rivstr);
            IF ofc > Mage THEN IF bestpts < ftoppts DIV 2 THEN GOTO 90;
           END;
        IF ofc > Mage THEN IF bestpts < minpts[ofc] THEN GOTO 90;
        WRITE(playfile,ostr);
        IF Army_Office(ofc) THEN Make_AName(bestldr,namstr,1)
          ELSE namstr:= lname^[bestldr];
        IF bestlak = kng THEN IF bestpts >= minpts[ofc] THEN
          IF rnk = 1 THEN
            IF not catchup THEN titchar[ofc]:= bestldr;
        IF emp <> No_King THEN BEGIN
          bestlk:= bestlak;
          IF not Army_Office(ofc) THEN BEGIN
              IF bestldr < nkings THEN KStr(bestldr,namstr)
                ELSE IF bestlk < nkings THEN
                  namstr:= Concat(namstr,'/',lname^[bestlk]);
             END
            ELSE IF bestlk < nkings THEN
              namstr:= Concat(namstr,'/',lname^[bestlk]);
          IF ofc = Emperor THEN BEGIN
            empalign:= lalign[bestldr];
{$IFDEF Russian}
            ts:= Concat('',outname[empalign],' ');
{$ELSE}
            ts:= Concat('The ',outname[empalign],' ');
{$ENDIF}
            IF Length(namstr)+Length(ts) > 24 THEN Delete(ts,1,4);
            IF Length(namstr)+Length(ts) <= 24 THEN namstr:= Concat(ts,namstr);
           END;
          WHILE Length(namstr) > 24 DO Delete(namstr,Length(namstr),1);
          kalign:= lalign[bestlk];
          diff_steps:= abs(Min(ord(kalign),ord(Hellish))-Min(ord(Hellish),ord(empalign)));
          IF diff_steps > 0 THEN IF kteam[bestlk] <> 0 THEN
            IF kteam[bestlk] MOD 100 = kteam[emp] MOD 100 THEN BEGIN
              Dec(diff_steps);
              IF gameno = 405 THEN IF gdyear <= 1997 THEN
                IF kteam[bestlk] MOD 100 = 1 THEN diff_steps:= 0;
             END;
          reduct:= outred[kalign] * diff_steps;
          IF reduct > 1.0 THEN reduct:= 1.0;
          IF ((ofc < NoOffice) or (gamevers >= 4) or (gametyp = Valhalla_V) or
              ((Company = ArkROyal) and (gameno = 400))) THEN BEGIN
              ofcpoints[ofc]:= ((ofcval[ofc]) * (1.0 - reduct));
              IF gameno = 400 THEN ofcpoints[ofc]:= ofcpoints[ofc] * 3/5;
             END
            ELSE ofcpoints[ofc]:= 0;
          kingpoints[bestlk]:= kingpoints[bestlk]+ofcpoints[ofc];
          IF bestldr < nkings THEN
            k_indivpoints[bestlk]:= k_indivpoints[bestlk] + ofcpoints[ofc];
         END;
        WRITE(playfile,namstr);
        IF emp = No_King THEN
            WRITE(playfile,'':15-Length(namstr),rnk:3,rivstr:6)
          ELSE WRITE(playfile,'':24-Length(namstr));
        IF ((nextldr < unkldr) and
            ((emp < No_King) or (nextpts*5 >= bestpts))) THEN BEGIN
            rnk:= Rank(nextldr,nextpts,ofc,ftoppts);
            posperc:= 100;
{$IFDEF Russian}
            IF ftoppts = 0 THEN rivstr:= ' ��祣�'
              ELSE BEGIN
                posperc:= Trunc(100*(nextpts/ftoppts));
{$ELSE}
            IF ftoppts = 0 THEN rivstr:= ' None'
              ELSE BEGIN
                posperc:= Trunc(100*(nextpts/ftoppts));
{$ENDIF}
                Str(posperc,rivstr);
               END;
            IF Army_Office(ofc) THEN Make_AName(nextldr,namstr,1)
              ELSE namstr:= lname^[nextldr];
            WRITE(playfile,'   ',
                namstr,' ':15-Length(namstr),
                rnk:3,rivstr:6);
{$IFDEF Russian}
            END
          ELSE WRITE(playfile,'   ��祣�');
        WRITELN(playfile);
       END
      ELSE IF ofc <= Mage THEN WRITELN(playfile,ostr,'��祣�                   ��祣�');
{$ELSE}
           END
          ELSE WRITE(playfile,'   None');
        WRITELN(playfile);
       END
      ELSE IF ofc <= Mage THEN WRITELN(playfile,ostr,'None                       None');
{$ENDIF}
    need_pr:= false;
    IF ofc > nooffice THEN IF bestpts >= minpts[ofc] THEN
      IF ((gamevers >= 4) or (gdyear >= 1992)) THEN BEGIN
        IF (((gamevers = 3) and (gdmonth <= 7+2*ord(COmpany <> ArkRoyal)) and (gdyear = 1992))
            or (knowit[ofc] and (longint(1) Shl kng) = 0)) THEN BEGIN
          knowit[ofc]:= knowit[ofc] or (longint(1) Shl kng);
          Elite_On;
      WRITE(',');
          Imp_Code(2016+ord(ofc));
          Imp_Code(_OAlert);
      WRITE('Oa');
          PR1;
          Elite_Off;
          need_pr:= true;
         END;
       END;
    IF bestlak = kng THEN
      IF ((titchar[ofc] <> prevchar[ofc]) or
          ((gamevers = 3) and (gdmonth <= 7+2*ord(COmpany <> ArkRoyal)) and (gdyear = 1992)) or
          ((gdyear = 1992) and (gdmonth = 6) and (ofc <= Chancellor))) THEN
     IF bestrnk = 1 THEN IF not catchup THEN
      IF ((gamevers >= 4) or (gdyear >= 1992)) THEN BEGIN
        Elite_On;
        need_pr:= true;
      WRITE('Ao');
        IF Army_Office(ofc) THEN BEGIN
            _adex:= titchar[ofc];
            lastat[_adex]:= atype[_adex];
           END
          ELSE Imp_Code(titchar[ofc]);
        Imp_Code(2016+ord(ofc));
        Imp_Code(_ODesc);
        PR1;
        Elite_Off;
      WRITE(',');
       END;
     IF need_pr THEN PR1;
90: END; {for ofc}
  powperc[kng]:= Min(100,(bestperc+empperc) DIV 2);
  maxperc[kng]:= Max(Max(Min(maxperc[kng],40),sbperc[Company]),powperc[kng]);
  IF emp < No_King THEN Tell_Items(0)
    ELSE IF gametyp = Arcanes_V THEN Tell_Items(Arcanes_V);
  IF emp < No_King THEN BEGIN
    PR2;
{$IFDEF Russian}
WRITE(playfile,
'������⥫�� ����樨 ���� ',gameno:3,' ��魮���   ���   ����   �窨   ��������� ���� ');
    IF regrep THEN WRITELN(playfile,'�����') ELSE WRITELN(playfile,'���');
{$ELSE}
    WRITE(playfile,
'Final Standings Game ',gameno:3,' Alignment   Race   Rank   Points   Tax Base  ');
    IF regrep THEN WRITELN(playfile,'Treasury') ELSE WRITELN(playfile,'Account');
{$ENDIF}
    FOR k:= 0 TO nkings-1 DO krank[k]:= 0;
    lasthip:= -1;
    FOR k:= 0 TO nkings-1 DO BEGIN
      lasthip:= hip; hip:= -1; bestlk:= No_King;
      FOR k2:= 0 TO nkings-1 DO IF krank[k2] = 0 THEN BEGIN
        tkp:= kingpoints[k2]*65536.0+Tax_Base(k2)*256.0+lgold[k2];
        IF tkp > hip THEN BEGIN
          hip:= tkp;
          bestlk:= k2;
         END;
       END;
      IF regrep THEN ts:= lname^[bestlk] ELSE ts:= plname[bestlk];
      WRITE(playfile,ts,'':24-Length(ts),outname[lalign[bestlk]]:10,
        rname[lrace[bestlk]]:7);
      IF hip <> lasthip THEN WRITE(playfile,k+1:6) ELSE WRITE(playfile,'      ');
      WRITE(playfile,kingpoints[bestlk]:9:1,Tax_Base(bestlk):9);
      IF regrep THEN WRITELN(playfile,lgold[bestlk]:11)
        ELSE BEGIN
          IF not Read_SA(bestlk) THEN IF standby[bestlk] <= SB_Int THEN
            acc1:= kacct[bestlk];
          WRITELN(playfile,acc1:11);
         END;
      krank[bestlk]:= k+1;
     END;

    IF team_game THEN BEGIN
      maxteam:= 1;
      FOR team:= 0 TO 16 DO BEGIN
        team_points[team]:= 0;
        team_kings[team]:= 0;
        team_taxes[team]:= 0;
        team_treas[team]:= 0;
       END;
      FOR k:= 0 TO nkings-1 DO IF kteam[k] > 0 THEN BEGIN
        team:= kteam[k] MOD 100;
        maxteam:= Max(team,maxteam);
        team_points[team]:= team_points[team] + kingpoints[k];
        Inc(team_kings[team]);
        team_taxes[team]:= team_taxes[team] + Tax_Base(k);
        team_treas[team]:= team_treas[team] + lgold[k];
       END;
      FOR k:= 0 TO nkings-1 DO IF kteam[k] > 0 THEN
        kingpoints[k]:= team_points[kteam[k] MOD 100]/team_kings[kteam[k] MOD 100];

      PR1;
      WRITELN(playfile,
        'Team Standings Game ',gameno:3,' Alignments          Rank   Points   Tax Base  Treasury');
      FOR team:= 0 TO 16 DO trank[team]:= 0;
      lasthip:= -1;
      FOR team:= 1 TO maxteam DO BEGIN
        min_al:= Undead; max_al:= Heavenly;
        lasthip:= hip; hip:= -1; best_team:= noleader;
        FOR team2:= 1 TO maxteam DO IF trank[team2] = 0 THEN BEGIN
          tkp:= kingpoints[team2]*256.0+team_taxes[team2];
          IF tkp > hip THEN BEGIN
            hip:= tkp;
            best_team:= team2;
           END;
         END;
        ts:= '';
        FOR k:= 0 TO nkings-1 DO IF kteam[k] MOD 100 = best_team THEN BEGIN
          IF min_al > lalign[k] THEN min_al:= lalign[k];
          IF max_al < lalign[k] THEN max_al:= lalign[k];
          Str(k,tmp);
          ts:= Concat(ts,',',tmp);
          IF ts[1] = ',' THEN Delete(ts,1,1);
         END;
        WRITE(playfile,ts,'':24-Length(ts));
        tmp:= outname[min_al];
        IF min_al <> max_al THEN tmp:= Concat(tmp,' to ',outname[max_al]);
        WRITE(playfile,tmp,'':17-Length(tmp));
        WRITE(playfile,team:6);
        WRITE(playfile,team_points[best_team]:9:1,team_taxes[best_team]:9);
        WRITELN(playfile,team_treas[best_team]:11);
        trank[best_team]:= team;
       END;
     END;

    IF kingpoints[kng] > 0 THEN IF gametyp > Trial_V THEN BEGIN
      PR1;
      prcred:= Trunc(totfees*prizeperc*kingpoints[kng]*0.01*(0.5*(1+ord((gamevers<=3) and (gametyp <> Valhalla_V)))));
{$IFDEF Russian}
      IF prcred > 0 THEN WRITELN(playfile,'�먣��� ',(prcred/100.0):6:2,' �㤥� ��ॢ���� �� ��� ���!');
{$ELSE}
      IF prcred > 0 THEN WRITELN(playfile,'A prize credit of ',(prcred/100.0):6:2,' will be applied to your account!');
{$ENDIF}
      IF main_rep THEN IF kacct[kng] <> 0 THEN BEGIN
        GetDate(y,m,d,dw);
        Str(m,ts);
        tmp:= Concat('C:\tp\akf\CREDIT.',ts);
        Assign(miscfile,tmp);
        Start_App(miscfile);
        WRITELN(miscfile,(prcred/100.0):7:2,' credited to account ',kacct[kng], ' in Game ',gameno);
        AClose(miscfile);
       END;
      prize[kng]:= prcred;
      IF kingpoints[kng]*(1+ord((gamevers >=4) or ((Company = ArkROyal) and (gameno = 400)))) >= 15.0 THEN BEGIN
        WRITELN(playfile);
{$IFDEF Russian}
        WRITELN(playfile,'   ��� ��� �� � �ᯥ宬 �����稫� ��� ����, �� 㤮�⮥�� ��� ���� ���ᥭ�� � ᯨ᮪');
        WRITELN(playfile,'"�� ������" ���� "�ਪ��祭�� ��஫��"!  �� �।��⠢�� ��� ���� � �� ');
        WRITELN(playfile,' ᫥���饩 ��� � � �६�, � ���஥ �� ��������.  �� ⠪�� ���㤭�砥� �');
        WRITELN(playfile,'⠪��� ��ୠ����, ��� Flagship''s "Honor Roll" � Paper Mayhem''s');
        WRITELN(playfile,'"PBM Activity Corner".  �᫨ �� ��室�� ����� ���� �������ਨ �⭮�⥫쭮');
        WRITELN(playfile,'��襩 ������ (��� ���� ᤥ���� ��⥫����㠫쭮� ����砭��), �� � 㤮�����⢨�� �����㥬 ���.');
{$ELSE}
        WRITELN(playfile,'   Because of your good finish in this game, you have qualified to enter an');
        WRITELN(playfile,'"all-star" game of Adventurer-Kings!  We will place you in the next');
        WRITELN(playfile,'available game at any time you wish to request one.  Also, we support');
        WRITELN(playfile,'magazine columns such as Flagship''s "Honor Roll" and Paper Mayhem''s');
        WRITELN(playfile,'"PBM Activity Corner".  If you''d like to make a perceptive comment on');
        WRITELN(playfile,'your victory (or even a smart-alecky remark), we''d like to quote you.');
{$ENDIF}
       END;
      IF ((k_indivpoints[kng] >= 20.0) or (krank[kng] = 1)) THEN
          IF gametyp <> Valhalla_V THEN BEGIN
        WRITELN(playfile);
{$IFDEF Russian}
        WRITELN(playfile,'  ',lname^[kng],' ⠪�� �ਣ��襭 ������ ᢮� ���� � ��������!  �� ����� ������� ������ ');
        WRITELN(playfile,'��ࠣ�� � 20-200 ᫮�, � ���஬ �� �����, ��� ��� ���ᮭ�� �룫廊� �');
        WRITELN(playfile,'�� �� �㤥� �������, ����� ����� � ���饩 ���.  �� ����� ������� ᮢ���, ��� ���,');
        WRITELN(playfile,
        '墠�⮢�⢮� ���, � ���ன �� �먣ࠫ�, ����� ���ᮭ��� � ⮬� ��������.  �� ⠪�� �������� 㧭���,');
        WRITELN(playfile,'����� �� ���� �����᪨� �।��⮢ (⮫쪮 ����) �� ������ � ᮡ��.  ��');
        WRITELN(playfile,'������ ������� �����⨥ �� ���. �᫨ �� ������ ������� � ��������!');
{$ELSE}
        WRITELN(playfile,'  ',lname^[kng],' is also invited to join Valhalla!  You can write an introductory');
        WRITELN(playfile,'paragraph of 20-200 words which can describe what your character looks like and');
        WRITELN(playfile,'will say when he appears in a future game.  You can include advice, your name,');
        WRITELN(playfile,'bragging, which game you won, character history and so on.  We''ll also need to');
        WRITELN(playfile,'know which one (1) of your magic treasures you will bring along with you.  We');
        WRITELN(playfile,'need to hear from you if you want to join Valhalla!');
{$ENDIF}
        IF main_rep THEN Induct_Val(kng);
       END;
     END;
   END;
  IF not catchup THEN BEGIN
    IF emp = No_King THEN BEGIN
      dec_perc:= 5;
      IF Company <> Sargona THEN dec_gt:= 24
        ELSE BEGIN
          IF gamevers = 4 THEN dec_gt:= 44
            ELSE dec_gt:= 34;
          dec_perc:= 3;
         END;
      reqperc:= 55 - (dec_perc*ord((gdyear >= 1995) or (gdmonth >= 5))*Max(0,gameturn-dec_gt));
      IF reqperc < 55 THEN WRITELN(playfile,'  Note: It requires only ',reqperc,
        '% of world taxbase to become Emperor next turn.   ');
     END;
    IF vote_perc > 0 THEN BEGIN
      PR1;
{$IFDEF Russian}
      WRITELN(playfile,'  ����砭��: ��஫�, �������騥 ',vote_perc,'% ��஢�� ��������� ����, �ॡ����� �롮��.   ');
{$ELSE}
      WRITELN(playfile,'  Note: Kings owning ',vote_perc,'% of the world''s tax base called for an election.   ');
{$ENDIF}
     END;
    IF req_vote = Vote_Turn THEN BEGIN
      IF alperc[alvote] >= 55 THEN BEGIN
        IF ((gamevers >= 4) or ((Company = ArkROyal) and (gameno = 400))) THEN IF alvote <> Mechanical THEN
          IF Company = Roland THEN WRITELN(playfile,'  L''alignement ',outname[alvote],' contr"le actuellement ',
                    alperc[alvote],'% du total des votes.')
{$IFDEF Russian}
ELSE WRITELN(playfile,'',outname[alvote],' ��魮��� �ࠢ��� ',
                    alperc[alvote],'% ����ᮢ ���.');
{$ELSE}
            ELSE WRITELN(playfile,'  The ',outname[alvote],' alignment controls ',
                    alperc[alvote],'% of the world''s votes.');
{$ENDIF}
       END;
      IF Company = Roland THEN
          WRITELN(playfile,'  En cons_quence, une _lection pour le titre d''Empereur du Monde aura lieu ce tour.')
{$IFDEF Russian}
        ELSE WRITELN(playfile,'  ���⮬� ����ᮢ���� �� �ᥬ�୮�� ������� �㤥� �஢������� �� �⮬ 室�.');
{$ELSE}
        ELSE WRITELN(playfile,'  Consquently, a vote for World Emperor will be held this turn.');
{$ENDIF}
     END;
   END;
  IF ((gamevers >= 4) or ((Company = ArkROyal) and (gameno = 400))) THEN IF not catchup THEN BEGIN
    PR1;
    kalign:= lalign[kng];
    IF Company = Roland THEN BEGIN
        WRITELN(playfile,'  L''alignement ',outname[kalign],' contr"le actuellement ',
          alperc[kalign],'% du total des votes');
        WRITELN(playfile,'(imposable + (5 x points pour charges/tr_sors)).');
       END
      ELSE BEGIN
{$IFDEF Russian}
        WRITELN(playfile,'',outname[kalign],' ��魮��� ᥩ�� �ࠢ��� ',
          alperc[kalign],'% ����ᮢ ���');
        WRITELN(playfile,'(��������� ���� + (5 X �窨 �� ���������/᮪஢��)).     ');
{$ELSE}
        WRITELN(playfile,'  The ',outname[kalign],' alignment now controls ',
          alperc[kalign],'% of the world''s votes');
        WRITELN(playfile,'(taxbase + (5 X office/treasure points)).     ');
{$ENDIF}
       END;
{$IFDEF More_Entry}
    IF gameturn = 0 THEN BEGIN
      PR1;
{$IFDEF Russian}
WRITELN(playfile,'   � ��஫�',outname[kalign],' , ���� ��襩 ��魮�� ��������� ��� ������, �� ');
      WRITELN(playfile,'� ���쭨� ��࠭�� ���� ��㣨� ��஫�, ����� ࠧ������ ��� �ࠢ������ ',outname[kalign]);
      WRITELN(playfile,'������ �� �ࠢ�����.   ',outname[kalign],' ��� ��� ��㧥� ',outname[kalign],'�� 㡥������:');
{$ELSE}
      WRITELN(playfile,'   O ',outname[kalign],' King, the Gods of thy alignment would have you know that');
      WRITELN(playfile,'there are other Kings in faraway lands who share your righteously ',outname[kalign]);
      WRITELN(playfile,'views on governance.  Seek ye these friends of ',outname[kalign],' persuasion:');
{$ENDIF}
      PR1;
      FOR k:= 0 TO nkings-1 DO IF k <> kng THEN IF lalign[k] = kalign THEN BEGIN
        KStr(k,ts);
        WRITELN(playfile,ts,' (#',k,')');
       END;
     END;
{$ENDIF}
   END;
 END;
{$ENDIF}
PROCEDURE Desc_Adventure(kng: integer; pex: mapbyte; fdis: fbool);
VAR zero,none: boolean;
    px,py: integer;

PROCEDURE It;
VAR an,fn,fn2,ln: integer;
    l1: boolean;
    s: Str40;
    ps,as,hs: Str30;

PROCEDURE Check_None;
BEGIN
  IF last_line = 0 THEN IF last_feat THEN UL;
  IF none THEN BEGIN
      Get_PN(px,py,ps);
      s:= pname^[px,py];
      PMod_PName(s,px,py,kng);
      IF Length(s) > 14 THEN Delete(s,15,99);
      WRITE(playfile,s,'':15-Length(s),' ',ps,'  ',pex[px,py]:3,'  ');
     END
    ELSE WRITE(playfile,'':27);
 END;

BEGIN
  IF provpres[px,py] and 16 = 16 THEN FOR fn:= 0 TO nfeatures-1 DO
    IF fx[fn] = px THEN IF fy[fn] = py THEN IF fdis[fn] > 0 THEN BEGIN
      last_line:= 0; {0 = thisone}
      last_feat:= true;
      IF fn <> nfeatures-1 THEN FOR fn2:= fn+1 TO nfeatures-1 DO
        IF fx[fn2] = px THEN IF fy[fn2] = py THEN IF fdis[fn2] > 0 THEN
          last_feat:= false;
      IF fstate[fn] <> Dead THEN
        IF ((emp = No_King) and ((trowner[fn] <> fn+256) or (fn and 1 = 0))) THEN
            last_line:= 1 {unk riches}
          ELSE last_line:= 2;
      Check_None;
      tmp:= ftname[ftype[fn]];
      IF Length(tmp) > 14 THEN IF Pos(' ',tmp) > 0 THEN BEGIN
        Delete(tmp,4,Pos(' ',tmp)-4);
        Insert('.',tmp,4);
       END;
      WRITE(playfile,tmp,'':15-Length(tmp));
      WRITE(playfile,fn:3,'  ');
      IF fstate[fn] <> Dead THEN BEGIN
          tmp:= mtname[fmonst[fn]];
{$IFDEF Russian}
          IF Pos('��ॡ��稪 ',tmp) = 1 THEN Delete(tmp,1,9)
            ELSE IF Pos('������᪨� ',tmp) = 1 THEN Delete(tmp,1,6)
            ELSE IF Pos('������� ',tmp) = 1 THEN Delete(tmp,1,6)
            ELSE IF Pos('��娩��',tmp) = 1 THEN Delete(tmp,14,99);
          WRITE(playfile,tmp,'':16-Length(tmp));
         END
        ELSE WRITE(playfile,'ࠧ�ࠡ��� � ���饭  ');
{$ELSE}
          IF Pos('Renegade ',tmp) = 1 THEN Delete(tmp,1,9)
            ELSE IF Pos('Giant ',tmp) = 1 THEN Delete(tmp,1,6)
            ELSE IF Pos('Great ',tmp) = 1 THEN Delete(tmp,1,6)
            ELSE IF Pos('Elemen',tmp) = 1 THEN Delete(tmp,14,99);
          WRITE(playfile,tmp,'':16-Length(tmp));
         END
        ELSE WRITE(playfile,'sacked &looted  ');
{$ENDIF}
      Set_Event(fn,false);
      CASE fdisc^[playking,fn] OF
        1: WRITE(playfile,'    ?');
        2: BEGIN
          tmp:= mfname[fmagfeat];
          IF fn and 1 = 1 THEN Delete(tmp,Pos('/',tmp),99)
            ELSE Delete(tmp,1,Pos('/',tmp)+1);
          WRITE(playfile,tmp);
         END;
        3: Set_Event(fn,true);
       END;
      WRITELN(playfile);
      CASE last_line OF
        0: IF last_feat THEN NUL;
        1: BEGIN
          IF last_feat THEN UL;
{$IFDEF Russian}
WRITELN(playfile,'':27,'/��࠭�� �������⭮� ������⢮            ');
{$ELSE}
          WRITELN(playfile,'':27,'/Guarding unknown riches            ');
{$ENDIF}
          IF last_feat THEN NUL;
         END;
        2: List_Treas(fn+256,true);
       END;
{$IFDEF More_Entry}
      IF gameturn = 0 THEN BEGIN
        Elite_On;
      WRITE('Eo');
        Imp_Code(2900+ord(fmonst[fn]));
        Imp_Code(_LMDesc);
      WRITE(',');
        Elite_Off;
        PR2;
       END;
{$ENDIF}
      none:= false;
     END;
 END;

BEGIN
  PR2;
{$IFDEF Russian}
Expand_Write('�����������',kng);
  PR1;
  WRITELN(playfile,
    '  � ���⫥�訩, �ਪ��祭�� ���� ��� � ���� ��⭨��� � ������ 㣮���');
  WRITELN(playfile,
    '������� ��!  ����� ������� ����� � ᢮�� ������ ��������� ������� ���� �');
  WRITELN(playfile,
    '���ਧ����� ���⭮� ��ᥫ���� �����.  ��� �� ������:                      ');
  PR1;
  UL;
  WRITELN(playfile,'�஢����             %��᫥� ���⮯ਬ��⥫쭮�� � �#     ������         �ᮡ�������');
{$ELSE}
  Expand_Write('ADVENTURE',kng);
  PR1;
  WRITELN(playfile,
    '  O Luminous One, adventure awaits thee and thy companions at every corner of');
  WRITELN(playfile,
    'the globe!  Fearsome monsters lurk in their cavernous hidden lairs by day and');
  WRITELN(playfile,
    'terrorize the populace by night.  Here are these lairs:                      ');
  PR1;
  UL;
  WRITELN(playfile,'Province             %Exp  Features and F#     Monster         Special');
{$ENDIF}
  NUL;
  Use_NewVal(true,true);
  FOR px:= left TO right DO FOR py:= top TO bottom DO BEGIN
    none:= true;
    It;
   END;
  Use_NewVal(false,true);
 END;

FUNCTION Disk_Read(ldr,gt: integer): boolean;
VAR s: str20;
    woe: integer;
BEGIN
  _prevact:= -32000;
  Get_LFN(ldr,gt,s);
  WRITE(' DR',s);
  Assign(intfile,s);
  Disk_Read:= true;
  Reset(intfile);
  woe:= IOResult;
  IF woe <> 0 THEN BEGIN
    Disk_Read:= false;
    IF woe <> 2 THEN BEGIN WRITELN(s,' Dos error ',woe); REadln; END;
   END;
 END;

PROCEDURE Disk_Int(ldr,gt: integer; VAR f: integfile);
VAR s: str20;
    woe: integer;
BEGIN
  Get_LFN(ldr,gt,s);
  WRITE(' DI',s);
  Assign(f,s);
  Reset(f);
  woe:= IOResult;
  WRITELN(woe);
  IF woe = 2 THEN
      BEGIN Rewrite(f); woe:= IOResult; WRITE('/',woe); IF woe <> 0 THEN READLN; END
    ELSE IF woe <> 0 THEN
      BEGIN WRITELN(s,' Dos error ',woe); READLN; END
    ELSE BEGIN
      IF FileSize(f) > 0 THEN Seek(f,FileSize(f));
      woe:= IOResult; WRITE(':',woe); IF woe <> 0 THEN READLN;
     END;
  last_intldr:= ldr;
 END;

PROCEDURE Disk_Play(ldr,gt: integer);
VAR s: str20;
    woe: integer;
BEGIN
  playking:= ldr;
  Get_LFN(ldr,gt,s);
  WRITE(' DP',s);
  Assign(playfile,s);
  Append(playfile);
  woe:= IOResult;
  WRITELN(woe);
  IF woe = 2 THEN
      BEGIN ARewrite(playfile); END
    ELSE IF woe <> 0 THEN
      BEGIN WRITELN(s,' Dos error ',woe); READLN; END;
 END;

PROCEDURE Set_Defend(l2: integer);
VAR ph: integer;
BEGIN
  IF AA_Led(l2) > 0 THEN
    WITH lplan^[l2] DO BEGIN
      planstart:= 0; planend:= 4;
      FOR ph:= 0 TO 4 DO IF ((ph = 0) and (AA_Led(l2) > 0)) THEN
          lactions[ph]:= Defend
        ELSE lactions[ph]:= Wait;
      lobjects[0]:= lx[l2]*XMULT+ly[l2];
     END;
 END;

PROCEDURE Start_Rpt(ldr: lrange);
VAR ph,l2: integer;
    s: Str40;
    y,m,d,dw: word;
BEGIN
    phasewrit[ldr]:= true;
    Str(Adj_Turn,s);
    Disk_Play(ldr,gameturn);
    Str(gameno,tmp);
    IF Company = ArkRoyal THEN IF Mail_Send(ldr) THEN WRITE(playfile,'r4');
{$IFDEF Russian}
    Title_Page(Concat('����������� �������:  ���� ',tmp,', TURN ',s),ldr);
{$ELSE}
    Title_Page(Concat('ADVENTURER-KINGS:  GAME ',tmp,', TURN ',s),ldr);
{$ENDIF}
    IF ((not catchup) and (not kfindo[ldr])) THEN BEGIN
        IF ((standby[ldr] <> SB_Start) and (standby[ldr] <> SB_Waiting)) THEN BEGIN
          PR1;
{$IFDEF Russian}
          WRITELN(playfile,'  �� �ய��⨫� �ࠩ��� �ப 室�. �������� �⤠� ��訬 ����ࠫ�� �ਪ�� ');
          WRITELN(playfile,' ��������. �᫨ �� ����稬 ��� �ਪ��� �����, � ��ࠡ�⠥� �� � ��諥� ��� ');
          WRITELN(playfile,' १����� 室�. �᫨ �� �ய���� 2 室�, �������� �᪫��� ��� �� ����.');
{$ELSE}
          WRITELN(playfile,'  You missed the turn deadline. The computer ordered Defend actions for your');
          WRITELN(playfile,'generals. If we receive a late move, we will process it and send you the turn');
          WRITELN(playfile,'results. If you miss 2 turns, the computer will drop you from the game.');
{$ENDIF}
         END;
        FOR l2:= 0 TO nleaders-1 DO IF LKing(l2) = ldr THEN Set_Defend(l2);
        CASE Company OF
          ArkRoyal, Roma: PR1;
          ELSE Pr_Lines(3);
         END;
       END
      ELSE BEGIN
        IF Company = Standard THEN BEGIN
          GetDate(y,m,d,dw);
{$IFDEF Russian}
          WRITE(playfile,'��ࠡ�⠫ ',d,'-',m,'-',y);
{$ELSE}
          WRITE(playfile,'Processed ',d,'-',m,'-',y);
{$ENDIF}
         END;
        PR_Lines(7-2*ord((Company = ArkRoyal) or (Company=Roma)));
       END;
    IF Get_Cust(ldr,player,false) THEN BEGIN
      IO_Check('GC');
      Write_Addr(ldr,playfile,true);
      IO_Check('WA');
     END;
    IO_Check('NGC');
    AClose(playfile);
    IO_Check('Start Close');
 END;

PROCEDURE Read_Story(ldr,sk: integer);
label 10;
VAR n,i,t: integer;
BEGIN
  WRITE('RS');
  IF Disk_Read(ldr,-1) THEN BEGIN
      IF sk > 0 THEN FOR i:= 1 TO 2000*sk +(tdex-2001) DO Read(intfile,t);
      rdex:= 1; tdex:= 1;
      WHILE ((rdex < 2189) and (not EOF(intfile))) DO BEGIN
        READ(intfile,n);
        IO_Check('Int Read');
        story^[rdex]:= n;
        Inc(rdex);
       END;
      IF rdex > 2001 THEN rdex:= 2001
        ELSE IF eof(intfile) THEN skips:= -2;
      Close(intfile);
      IO_Check('Read Close');
      IF rdex = 1 THEN GOTO 10;
     END
    ELSE BEGIN
10:   story^[rdex]:= _LNoNews;
      Inc(rdex);
     END;
  WRITE('RSe');
 END;

PROCEDURE Check_Pigeons(ldr: integer);
VAR frochar,tochar: integer;
    writ_on: boolean;
BEGIN
  IF ((not readletter) or (gotmsg[ldr] and L_GotM = L_GotM)) THEN BEGIN
    Get_FN('KM',gameturn,-1,tmp);
    Assign(miscfile,tmp);
    Reset(miscfile);
    readletter:= true;
    IF IOResult = 0 THEN BEGIN
      REPEAT
        READLN(miscfile,tmp);
        IF tmp = 'M>>' THEN BEGIN
          writ_on:= false;
          READLN(miscfile,frochar,tochar);
          IF ((tochar = 1000) or (tochar = -1)) THEN BEGIN
              FOR i:= 0 TO nkings-1 DO gotmsg[i]:= gotmsg[i] or L_GotM;
              IF ldr < nkings THEN tochar:= ldr;
             END
            ELSE gotmsg[tochar]:= gotmsg[tochar] or L_GotM;
          IF tochar = ldr THEN BEGIN
      WRITE('Pi');
            Imp_Code(ldr); Imp_Code(frochar+1280); Imp_Code(_LPigeon);
      WRITE(',');
            writ_on:= true;
            READLN(miscfile,tmp);
           END;
         END;
        IF writ_on THEN WRITELN(playfile,tmp);
      UNTIL ((IOResult <> 0) or (eof(miscfile)));
      AClose(miscfile);
     END;
   END;
 END;

PROCEDURE Gab(ldr: integer);
VAR n: integer;
BEGIN
  WHILE tdex < rdex DO BEGIN
    n:= story^[tdex];
    Inc(tdex);
    IF n = _LThEnd THEN BEGIN
      IF ldr = viskng THEN IF not catchup THEN BEGIN
      WRITE('vh');
        Imp_Code(ldr);
        Imp_Code(_LValHal);
       END;
      Check_Pigeons(ldr);
     END;
    Imp_Code(n);
      WRITE(',');
   END;
 END;

PROCEDURE Tell_Story(ldr,kng: integer);
BEGIN
  _attl:= noleader; _defl:= noleader;
  RandSeed:= crs^[ldr];
  WRITE('TS');
  skips:= 0;
  REPEAT
    Read_Story(ldr,skips); repldr:= ldr;
    Gab(ldr); repldr:= noleader;
    Inc(skips);
  UNTIL skips < 0;
  WRITE('TSe');
 END;

PROCEDURE Write_Letter(ldr,kng: integer; VAR non: boolean);
VAR n: integer;
    ls: Str30;
BEGIN
  IF Disk_Read(ldr,-1) THEN BEGIN
    Close(intfile);
    IF non THEN BEGIN
      PR1;
{$IFDEF Russian}
      WRITELN(playfile,
        '  � ��஫� ��஫��, ��� ��ந ᮢ��訫� �����⢨� ����� ������� �� �');
      WRITELN(playfile,
        '���᪠� �ਪ��祭�� � ����������.  � ����ᮢ��⭮ �࠭�� ��');
      WRITELN(playfile,
        '����ᯮ������, � ⥯��� � �।�⠢��� �� ���:');
{$ELSE}
      WRITELN(playfile,
        '  O King of Kings, thy heroes have travelled around the globe in');
      WRITELN(playfile,
        'search of adventure and conquest.  I have faithfully kept their');
      WRITELN(playfile,
        'correspondence, and now I present it to thee:');
{$ENDIF}
     END;
    ls:= ''; non:= false;
    IF ((Company <> Roland) and (ldr = valhero)) THEN author:= ldr
      ELSE IF ((lstate[ldr] = Dead) or (Company = Roland) or (Company = Italy) or
        (Aud_Rand(ldr,kng) + 4 < (bornx[ldr]+lx[ldr]*4+ly[ldr]*2) and 7)) THEN
{$IFDEF Russian}
        ls:= Concat(squires[ldr MOD 10],', ��㦥���� ')
{$ELSE}
        ls:= Concat(squires[ldr MOD 10],', Squire to ')
{$ENDIF}
      ELSE author:= ldr;
    PR2;
  {  ItalicOn;}
{$IFDEF Russian}
     WRITELN(playfile,
      '��: ',ls,lname^[ldr]);
    WRITELN(playfile,
      '�: ',lname^[kng]);
    PR1;
    WRITELN(playfile,
      '  ���� ������⥫�, ');
{$ELSE}
    WRITELN(playfile,
      'From: ',ls,lname^[ldr]);
    WRITELN(playfile,
      'To: ',lname^[kng]);
    PR1;
    WRITELN(playfile,
      '  Honored Sovereign, ');
    PR1;
{$ENDIF}
    Tell_Story(ldr,kng);
    Check_Pigeons(ldr);
    PR1;
{$IFDEF Russian}
    WRITELN(playfile,'  ��� ������ �㣠,   ',ls,lname^[ldr]);
{$ELSE}
    WRITELN(playfile,'  Thy humble servant,   ',ls,lname^[ldr]);
{$ENDIF}
  {  ItalicOff;}
    author:= noleader;
   END;
 END;

PROCEDURE Letter_Reports(kng: integer);
VAR none: boolean;
    lrt,ldr: integer;
BEGIN
  Disk_Play(kng,gameturn);
  PR2;
{$IFDEF Russian}
  Expand_Write('���������� �����',kng);
{$ELSE}
  Expand_Write('LETTER REPORTS',kng);
{$ENDIF}
  none:= true;
  FOR lrt:= 0 TO gameturn DO FOR ldr:= 0 TO nleaders-1 DO
    IF lrecturn^[ldr] = lrt THEN IF Either_King(ldr,kng,false) THEN
      IF ldr <> kng THEN Write_Letter(ldr,kng,none);
  IF none THEN BEGIN
    PR1;
{$IFDEF Russian}
    WRITELN(playfile,'�� ⥪�騩 ������ ��ᥬ �� ����-���� ���.');
{$ELSE}
    WRITELN(playfile,'There are no letters from anyone at this time.');
{$ENDIF}
   END;
  Elite_Off;
  AClose(playfile);
  IO_Check('Tell Close');
 END;

PROCEDURE Basic_Report(kng: integer);
BEGIN
  Disk_Play(kng,gameturn);
  phasewrit[kng]:= true;
  Elite_On;
  Imp_Code(_SQuote);
  PR2;
{$IFDEF Russian}
  Expand_Write('����� � ���������    ',kng);
  PR1;
  WRITELN(playfile,
    '����� ��᪠�뢠���� � ⮬, �� �ந��諮 � ��訬 ������⢮� �� ��� 室:');
{$ELSE}
  Expand_Write('ACTION REPORT    ',kng);
  PR1;
  WRITELN(playfile,
    'Here''s what happened to Your Majesty this turn:');
{$ENDIF}
  PR1;
  Tell_Story(kng,kng);
  AClose(playfile);

  Check_NSpabs(valhero,true);
  IO_Check('Bas Rep Close');
 END;

PROCEDURE Birth_Title(kng: integer);
{$IFDEF Russian}
BEGIN  Title_Page('����� ���� ������� ����������� �������',kng); END;

PROCEDURE Desc_Summary(ldr: integer);
BEGIN
    IF Get_Cust(ldr,player,false) THEN
      WRITELN(playfile,'��� ��� ',lname^[ldr],' (',player.name,', King #',ldr,') due ',gdmonth,'/',gdday,'/',gdyear);
    WRITELN(playfile,'   ��� ��⪮� ���������� ���� ����⢨�.  ���砫� ���⠩� ���� �� 室 ');
    WRITELN(playfile,
    '�� ��᪥�.  �᫨ ��᪥� ���� �⠥���, �令��� � ����-����஬, �⮡� ������� ���쬥��� ����  �� 室.');
    WRITELN(playfile,'����� �� ���뫠�� ���� ��᪥��, �ᯮ���� ���� ":" ��� ࠯��⪨ १�ࢭ�� �����.');
{$ELSE}
BEGIN  Title_Page('THE ADVENTURER-KINGS BIRTHRIGHT REPORT',kng); END;

PROCEDURE Desc_Summary(ldr: integer);
BEGIN
    IF Get_Cust(ldr,player,false) THEN
      WRITELN(playfile,'Summary for ',lname^[ldr],' (',player.name,', King #',ldr,') due ',gdmonth,'/',gdday,'/',gdyear);
    WRITELN(playfile,'   This is a summary of your game position.  Read the turn report on the disk');
    WRITELN(playfile,'first.  If your disk goes bad, call the moderator for a written turn report.');
{$ENDIF}
    WRITELN(playfile,'When sending your disk in, use the ":" option to print a backup printout.');
    WRITELN(playfile);
    IF ((Company = ArkRoyal) or (kpmode[ldr] > 1)) THEN BEGIN
      PR_Lines(6);
      IF Get_Cust(ldr,player,false) THEN
        Write_Addr(ldr,playfile,true);
     END;
 END;

PROCEDURE Say_Menu;
VAR sayno: integer;
BEGIN
  _ldr1:= IRand and 31; _attl:= _ldr1; _feat1:= 256 + _ldr1;
  _treas:= treasure(IRand and 63); _prov:= 13000; _px:= 0; _py:= 0;
  _prov2:= 13001;
  _px2:= 0; _py2:= 1; _adex:= IRand and 63; lastat[_adex]:= atype[_adex];
  _feat2:= 256 + IRand and 63; _spell:= Charm;
  _abil:=  ability(IRand MOD 15); _terrain:= Mtns; _atype:= atype[_adex];
  _dir:= D6; _qual:= aqual[_adex]; _race:= arace[_adex]; _discov:= discovery(IRand and 63);
  _qprov:= 0; _qchar:= 0; _qtrdex:= 0; _qplotno:= reply(3); _qchar:= 0;
  _qterr:= Mtns; _qsubplot:= 0; _align:= Good; _temper:= Brave;
  _mtype:= Mermaid; _magfeat:= Crysball; _office:= Treasurer;
  Assign(playfile,'CON');
  ARewrite(playfile);
  playkg:= 0; playking:= 0; phasewrit[0]:= true; kingwrit[0]:= false;
  stat_on:= false; eot_on:= true; say_trial:= true; extext:= false;
  REPEAT
    _defl:= IRand and 31; _ldr2:= _defl;
{$IFDEF Russian}
   PR2; WRITE('������ ����� 䠩��-�஧� ��� ���஢���� ? '); Readln(sayno);
{$ELSE}
    PR2; WRITE('Which prose number to test? '); Readln(sayno);
{$ENDIF}
    author:= noleader;
    IF sayno >= 0 THEN Imp_Code(sayno);
  UNTIL sayno < 0;
  AClose(playfile); say_trial:= false;
 END;

end.

{$IFDEF Russian}
          s:= pname^[px,py]; IF Pos('',s) = 1 THEN Delete(s,1,4);
{$ELSE}
          s:= pname^[px,py]; IF Pos('the',s) = 1 THEN Delete(s,1,4);
{$ENDIF}

superfluous
80+lines
goes across BEGIN
