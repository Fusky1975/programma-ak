[11.0]  BEGINNING PLAY

  You, the player, can choose your King's race, alignment, temper and four
ability levels.  Race and alignment can generally be chosen according to
personal tastes, because the powers of the different races and alignments are
fairly well balanced.
  Ability levels may require some more thought. It really does help to have
some good martial abilities to ensure that you can expand your kingdom
quickly.
  The most obvious way to do this is to choose Tactical ability.  Melee, Archery
and magical abilities can help you win duels with the opposing commander at a
battle, which helps your chances of victory. These abilities also help in
Searching out features. A pet strategy of some players is to pick two March
skill levels, which enables infantry to attack a second province after they
have conquered one province.
  Another oft-ignored strategy is to take some Naval ability, which will help
you master the vast oceans of the world.  Druidic ability will help you lead
armies of races other than your own. About half the world is Human, so if you
pick a race other than Human, you should probably take one Druidic level.
For Human Kings, the Druid skill is still very useful, but can be considered
optional.
  Don't forget that there are 7 Imperial Offices other than World Emperor.  A
good idea is to concentrate on one other office other than World Emperor, and
to do whatever you can for the other six offices until it's clear that you've
slipped too far behind.
  Your temper should correspond to the abilities you've selected.  Cautious and
Cowardly are good neck-saving tempers for Kings with little melee combat
ability.  Brave and Berserk are good for powerful warriors.  But remember,
your starting heroes will probably be of similar temper.
  Included with these rules is a set-up request form. Please fill out this
sheet and send it to us. We will try to set you up in a game as soon as
we can.  If there is a delay we will contact you with an estimate of when the
next game of the length and type you requested will begin.  When the game
begins, we will send you a map and a set-up report which completely describes
your Kingdom, as well as a general description of surrounding areas.
  One way to play the game is through the mail.  If you own a computer,
then moves can be sent back and forth between you and the
Game Master with a disk mailer.  If you plan to play by disk, mail it in
with your set-up request. If you play by disk in this manner we can offer you
"Saga", a program which displays your turn results along with a colourful map
of the world you've explored, and makes filling out your turn sheet a piece of
cake.  If you've ever been frustrated by PBM games that choke on your orders
because of some obscure rules violation or a typo, you'll love this program,
because it screens out just these kinds of errors.
  Players who have a modem and want to use Electronic Mail to play "Adventurer
Kings" can play by CompuServe, or any service connected to the InterNet.
  You can select the moves-turnaround time you wish to play with.  The most
common turnaround time is 15 days.  You can choose a game which allows
diplomacy or one which doesn't.  Most players prefer games which allow
diplomacy between players.  In these games,  players can call and write each
other outside the game.  In non-diplomacy games, you can only write to another
player by sending a message to the Game Master to forward to the other player.
You can know only the name of the King controlled by the player, not the
player himself.  Non-diplomacy games save on your phone bill and eliminate
a lot of diplomatic footwork for those who would just as soon do without it.
  If you lose your home province and you have less than 6 armies, you can
continue to play for half price.


[11.1]  BEGINNER'S TIPS

  When engaging in a campaign of conquest, remember that one additional move-
point is used up when conquering an enemy province (rule  [6.2]). An army with
a speed of 2 will thus be able to conquer only one province in a game-turn; a
cavalry force, or an army led by a leader with a March ability of 2 or higher,
can try to conquer two provinces.  Navies must use up this movement point only
when they fight a battle in the province. If you attack on phase 4 or earlier,
your armies can fight more than 1 battle.
  A "beginner's tip" showing an example combat situation may do some good.
Let's say you start with 2 Human Legion and 1 Heavy Cavalry, and you're
thinking of attacking a Prosperous Forest province defended by Elven bowmen.
  Usually, you should recruit 4 units with your 10 gold, giving you about 4
Average Legion and 3 Average HC.  Now let's work out what your odds are if you
attack that Elven province, using the "Summary of factors affecting army
strength" on the Army Type Table.
  First, the opposition.  Since it's a prosperous (average) province, it will
probably have 2 defending Elven Bow units.  Each Bow unit has a basic strength
of 2, +1 because Forest is home terrain for Elves, +1 because Forest is home
terrain for Bow, and +1 more because Elves get +1 as Bowmen.  Total modified
strength per unit is thus 5.  Multiply this by 2 because all units start as
Average quality, giving 10 defense points.  Then multiply by 1.25 for defense,
1.25 for exploration, and you wind up with 16 points per unit, for a total
strength of 32 (this won't seem so complicated, once you get used to it.)
  Now let's say you invade with all your units.  Your first line in the battle
will be 2 Human Legions, total strength = 16 (Legion strength = 3; +1 for
Humans fighting as Legion; x 2 for Average quality; x 2 units.)  Your second
line of 2 Legions will have the same strength; their strength will not be
penalized 50% because they will be able to outflank the enemy (as explained in
section 7.6 of the addendum sheet.)
  The next 2 cavalry will be penalized 50% however.  Their total strength is
4 (HC basic strength = 4; x2 for Average quality; halved for adverse terrain
of Forest; x 50% penalty; x 2 units.)  The last cavalry unit will contribute
1 strength.
  So the total attacking strength will be (16 +16 +4 + 1) = 37, against 32
defense.  That's about 1.15 to 1 odds, which gives you about a 55%-60% chance
of victory.  That's not so good!  You want to look for odds closer to 2:1.
Check your other skills to see if you can improve your odds: some Tactical
skill will make the odds more acceptable, or some spell(s) may help.  If your
leader is designed for personal combat, or you have the Neutral Order of
Duellists ability, consider challenging the defending hero to a duel.  You
might also consider sending someone ahead to explore the province, especially
Plains.  Lastly, consider taking on a weaker province first.  That may gain
you some quick tax points to build up your army, and your units may gain
crucial quality levels while beating up on weaker units.
  At the start of the game, aim towards taking as many provinces as possible
on each and every turn. You should try for at least two provinces per turn,
three or four if you can manage it. You should recruit some armies on the very
first turn to help you accomplish this.  If you have a skill of less than 2 in
March ability, you can divide your forces into a cavalry army and an infantry
army, using the infantry army to conquer one province while the cavalry horde
tries to conquer two successive provinces.
  A King who has a fleet should also try to take 1-3 sea provinces.  You can
order a fleet to move into an unknown area, which is sometimes a good gambit.
  When considering an invasion, weigh all the conditions which argue for and
against success in battle.  All of the modifiers to army strength are given
with the Army Table.  Also, remember that how many armies you have doesn't
matter much in mountainous terrain because it may be that the battle will be
fought in a narrow pass, allowing a frontage of only one or two armies.
  After you conquer a province controlled by a neutral hero, consider
hiring the hero in the same game-turn. It may be wise to wait a phase before
hiring him, in case you need two battles to conquer the province.
  When searching features, remember that using the Talk tactic can lead to
considerable success.  Some "monsters" may be willing to let you have their
treasure for a simple favour,  and even a vicious monster will hesitate to
attack a Hero, so your chances of survival are quite good.  Still, don't make
risky attacks against monsters on early game-turns, and try to have a good
supply of spare characters.  When you make up an encounter plan which starts
with a negotiation tactic, place a Flee and/or combat tactic after it, in case
the negotiations fail.
  Try for every Imperial Office.  At the start of the game, think about which
character will be your primary candidate for each office, and which offices
will receive first priority.  Towards the middle or end of the game, try to
find out which characters are ahead of you for which offices and neutralise
those characters.  The winner of the game will probably be the King who
explores the most avenues for advancement and takes advantage of every
opportunity. Luck plays a large part in the game, so players will have to take
many calculated risks to make the law of averages work for them.
  If you are invaded and lose your Kingdom, it's not necessarily the end.  You
can fire your more expensive heroes, then travel around the world looking for
mercenaries and battlefields where you can raise skeletal armies.  Some
features have magic items which will help you, or incredible amounts of gold
to finance a comeback.  Some Kings may help you in exchange for some training
or a magic item, while others may have gaps in their defences which you can
exploit by raising mercenaries and skeletal armies in the middle of their
Kingdom!


[11.2]  EXAMPLES OF MOVES FOR ADVENTURER-KINGS
  
  Here's an  example of  a "moves  sheet" which  you can  use to give
  orders to one of your characters:

              Moves:
Character ID  Phase 1     Phase 2     Phase 3     Phase 4     Phase 5

1_________   (__)_______ (__)_______ (__)_______ (__)_______ (__)______
(Kyron______)(__________)(__________)(__________)(__________)(_________)
 Enctr Plans: __________  __________  __________  __________  _________
 Special Plan:__________
  
     The first  line is  used to  fill in  the  order,  for  example,
  "(HI)re_88___". The second line is for anything else that is needed
  to explain  the order (for example, how much are you going to offer
  character 88  to join  you?)  The third line is for more notes, and
  for the plans for Encounter and Search actions.
  
  The "Special  Plan" line is for encounters with random monsters and
  duels at  battles, and  will be in effect for the entire turn. Here
  are examples of how to write moves for each order:

   [3.1]       [3.2]       [3.3]       [3.4]       [3.5]       [3.6]
   Move        Explore     Search      Recruit     Hire        Disband

(MO) NE 304 (EX) 304    (SE) 33     (RE) for 22 (HI) 88     (DI) 33,44,.
( Burgundy )( Burgundy )( Dungeon  )(LE,LE,HC  )( Lancelot )( 112,113  )
                          FI,ME                  for 3 gold            .

  [3.7]       [3.8]       [3.9]       [3.10]      [3.11]      [3.12]
  Fire        Leave       Pick Up     Cast Spell  Use Item    Encounter

(FI) 88     (LE) 8,9 to (PI) 33,34  (CA)-BL     (US) 19     (EN) 88    .
( Lancelot )( Garrison )(          )(on 304    )(Magic Wand)( Lancelot )
                                                  on 88       TA,FL    .

  [3.13]      [3.14]      [3.15]      [3.16]      [3.17]      [3.18]
  Practice    Spy         Defend      Pursue      Trail       Give

(PR) TA     (SP) 304    (DE) 304    (PU) 88     (TR) 88     (GI) 19    .
(          )( Burgundy )( Burgundy )(Lancelot  )( Lancelot )( to 88    )
                                      CA-FI,ME                         .


  You don't really have to include the names of provinces and characters in
orders, since the computer operator will just type in the number.  But it may
be a useful note for you and sometimes serves as a double-check.

  If you run out of space when writing an order, put an asterisk (*) and
continue the order on the bottom of the moves sheet.

[11.3]  EXAMPLES OF COMBAT PLANS

  FI,FL (Meaning: Fire arrows, and if this doesn't win it, attempt to flee.)

  ST,CA-FI,ME,SC   (Attempt to steal from the monster.  Then cast a fireball
spell and charge into melee. If you win, Scout the feature.)

  CA-IN,ST,FL,ME   (Cast Invisibility and attempt to Steal; if caught, attempt
flight, and Melee if necessary. Remember: only CA-IN can come before Steal.)

  CA-PS,CA-FI,ME,ME,FL,CA-CH,ME   (Cast Psychic Blast and Fireball. Then melee
for two rounds,  and if it still lives, attempt flight.  If this fails,
attempt to charm the opponent, and if that fails then resume melee. Note that
this plan assumes skills of 1 in Elemental Magic and 2 in Psychic Magic.

  SA-"Greetings, Supreme One!",TA,SC,ME  (Talk to the monster and see if it
wants to deal. If possible, Scout the feature to see if something special can
be found.  If the monster attacks, proceed to Melee.)


(assumes that  Magic Item #55 is a sword, while #31 casts a Fireball spell):

  US-31,US-31,US-31,US-31,US-31,US-31,US-31,US-31,US-31,US-31,US-31,US-55,ME
(Use the  Wand of  Fire until it runs out of charges, then switch to the sword
and Melee.)

[11.4]  WHEN WRITING MOVES, PLEASE...

  -Don't Leave,  Disband or Pick Up a unit you hired in the same game-turn.
When using these orders, at all times you MUST give army numbers and not army
types. The only exception is the "PickUp/Disband/Leave All" command.

  -When using the "Move" order to attack a province, don't write your duelling
plans under the "Move" order. Write them in  the "Special Plan" line, which
covers the entire game-turn.

  -In an encounter plan, some tactics are not allowed together (see sections
[5.4] and [5.5].)  Example:  TA-lk, FU-lfil and ST-eal are not allowed in a
Special Encounter Plan.  There is no call for them in duels at battles, and
if a wandering monster wants to talk with you, he will do so.

  -When you Hire, Charm or Resurrect a new Hero, you can't give him orders the
same phase you hired them. Give him orders starting with the next phase.

  -In many orders, including as Spy and Explore, the character must be located
in the province that is the objective of the order.

  -Please remember to type the direction when giving a Move order (ie. "(MO)ve
NE" or "(MO)ve NE 1801"). You should include the  name or number of at least
the last province you move to, so we can check our moves entry.  The six
directions are  NE, E,  SE, SW,  W and  NW.

