Adventurer-Kings Rules, Version 1.2  Copyright 1995, Ark Royal Games

[1.0]  INTRODUCTION.................. [6.0]  ARMIES...........................
[1.1]  Game Components............... [6.1]  Types of Armies..................
[1.2]  Kingdoms...................... [6.2]  Movement and Transport...........
[1.3]  Character Actions.............
[1.4]  Turn Results.................. [7.0]  BATTLES..........................
[1.5]  Victory....................... [7.1]  Supreme Commanders...............
                                      [7.2]  Battle Lines.....................
                                      [7.3]  Pursuit..........................
[2.0]  CHARACTERS.................... [7.4]  Retreat..........................
[2.1]  Kings......................... [7.5]  Aftermath of Battles.............
[2.2]  Heroes........................ [7.6]  Contested Provinces..............
                                      [7.7]  Conquest.........................
[3.0]  ACTIONS....................... [7.8]  Multiple Contingents.............
[3.1]  Move (Abbreviated "MO").......
[3.2]  Explore (EX).................. [8.0]  DIPLOMACY........................
[3.3]  Search feature (SE)........... [8.1]  Relations........................
[3.4]  Recruit army(s) (RE).......... [8.2]  Treating.........................
[3.5]  Hire Hero (HI)................ [8.3]  Breaking Treaties................
[3.6]  Disband army(s) (DI).......... [8.4]  Scientific Treaties..............
[3.7]  Fire Hero (FI)................
[3.8]  Leave Army(s) (LE)............ [9.0]  FINANCES.........................
[3.9]  Pick Up Army(s) (PI).......... [9.1]  Revenue..........................
[3.10]  Cast Spell (CA).............. [9.2]  Expenses.........................
[3.11]  Use Magic Item (US)..........
[3.12]  Encounter Character (EN)..... [10.0] VICTORY..........................
[3.13]  Practice Ability (PR)........ [10.1] Imperial Offices.................
[3.14]  Spy Province (SP)............ [10.2] The World Emperor................
[3.15]  Defend (DE).................. [10.3] Valhalla.........................
[3.16]  Pursue (PU)..................
[3.17]  Trail (TR)................... [11.0] BEGINNING PLAY...................
[3.18]  Give (GI).................... [11.1] Beginners Tips...................
                                      [11.2] Example Moves....................
[4.0]  ABILITIES..................... [11.3] Example Combat Plans.............
[4.1]  Martial Abilities............. [11.4] Turnsheet Hints..................
[4.2]  Magical abilities.............
[4.3]  Special Abilities............. [12.0] AK VARIANTS......................
                                      [12.1] Super AK.........................
[5.0]  ENCOUNTERS                     [12.2] European AK......................
[5.1]  Magic Spells/Items (CA-XX,US-#)[12.3] Other Variants...................
[5.2]  Fire Arrow (FI)...............
[5.3]  Melee (ME).................... [13.0] DESIGN CREDITS...................
[5.4]  Negotiate (TA-lk,SA-y,FU-lfill)
[5.5]  Steal (ST)....................
[5.6]  Flee (FL).....................
[5.7]  Give (GI).....................
[5.8]  Scout (SC)....................
[5.9]  Victory and Death.............
[5.10] Special Encounter Plan........

[1.0]  INTRODUCTION
  "Adventurer-Kings" is a game set in a medieval world filled with magic,
treasure, monsters and armies.  There are 8 to 12 players in each game.  A
player controls one King, his armies and treasures, and any Heroes which he
hires to serve him.  Each turn, a player sends in a set of moves for his
"Adventurer King" (or Queen, for that matter) and his Heroes.  These moves
cover the King's activities for one year in the medieval world.

[1.1]  Game Components
  The map has a total of 162 provinces.  Some of the land provinces are
initially controlled by player Kings, and the remaining land provinces are
defended by 1-4 armies and (usually) a Hero.  These non-player-controlled
Heroes do not attack you or go on adventure.  Each player starts out with
the ownership of one province.  No King will start closer than three
provinces away from another.  Each province has a terrain type, native race,
army type and tax base.  As you explore the world, more sections of the map
become known to you.
  Terrain types are plains, deserts, forests, jungle, mountains, and seas.
About half of the provinces are seas.  Many of the provinces contain
additional features, such as a dungeon, dragon lair, abandoned castle,
pyramid, wizard's tower and so on.  They are usually defended by a monster
which guards a treasure.
  Native races can be human, elven, dwarven, orcish, eagles, dragons or
whales.  Humans are by far the most common race.  Each province may have one
or two of the army types.listed in the Army Type Table.  The taxation value
of a province can range from 0 to 10.
  When you come adjacent to a province, it will usually be described as Rich
(7-10 tax), Prosperous (3-6 tax) or Poor (0-2 tax).  If a province's wealth is
not described, then for most terrains you can assume that it's Prosperous (but
for Sea or Desert, assume Poor.)  On average, a Rich province will be defended
by 3 armies, Prosperous by 2 armies, Poor by 1 army (although sea provinces
which are occupied by no races will still be undefended.)

[1.2]  Kingdoms
  Each player starts out with a King, a few subordinate Heroes, one province,
some armies and a treasury of 10 gold.  The province, Heroes and army are
assigned to the player by the computer, but the player can select four skill
levels for his King from the 15 available abilities.

[1.3]  Character Actions
  There are five action phases in each gameturn, corresponding to Spring,
Early Summer, Late Summer, Fall and Early Winter.  A player may give one order
to his King and each of his Heroes per phase.  He may choose from among the
following actions:

  Move:  The character may Move to an adjacent province, which may result in
a battle.
  Explore:  The character may Explore a province, and may find a feature such
as a dungeon.
  Search feature:  When a character searches a feature, he encounters the
monster there.  The character can try to steal some treasure, talk to the
monster, or attack it.
  Recruit army or Hire Hero:  Each province on the map has army types to
Recruit.  Some have Heroes for Hire.
  Disband army/Fire Hero: Releases the army or Hero from service, to wander
and adventure on their own.
  Leave army(s):  The specified army(s) are left in the province or to another
character.
  Pick up army(s):  Pick up army unit(s), which will then travel with the
character.
  Cast spell:  The character Casts a spell he knows.
  Use Magic Item:  A character casts a spell from a magic item.
  Encounter character:  The character Encounters another character, which may
involve combat or talking.
  Spy:  The character Spies on the province he is in, learning of events,
forces and characters in that province.
  Trail:  The character follows and spies on a character, gaining information
on the character and his actions.
  Practice: The character attempts to raise his skill level in an ability by
Practicing it.
  Defend:  A general ordered to Defend can react to enemy moves into adjacent
provinces for the entire turn.
  Pursue:  The character Pursues another character.  When he catches up, there
can be an Encounter or a battle.
  Give:  The character Gives a magic item to another character.
  Treat or Break Treaty:  Kings may establish (or break ) treaties of
neutrality or alliance.
  Call for Vote: A vote for World Emperor can be held.

[1.4]  Turn Results
  The turn results are informative, comprehensive and written in descriptive
prose with supporting charts and tables.  Here's what you receive each turn:

  Action Report:  The deeds of your "Adventurer King", recounted in exciting
prose.
  Letter Reports:  All Heroes in your employ write to you of their adventures.
  State of the Kingdom Report:  Tables for provinces, characters, armies and
finances.
  Map:  A map is drawn showing all known provinces.
  Adventure Report:  All dungeons and features known to you are listed, as
well as their guardian monsters, the treasure believed to be there, and the
characters who may be hired to serve the Kingdom.
  General Intelligence Report:  Every activity of all other players is
checked to see if your King would find out about it.  For example, you are
informed when a province adjacent to your Kingdom changes hands.  You may
also be informed of the activities of other King's characters when they
operate in your Kingdom.

[1.5]  Victory
  Long ago, the world was reigned over by a great Emperor who enforced
justice and maintained world peace.  But the Empire was torn apart by the
petty disputes of small-minded nobles, and the world plunged into a dark age
of barbarism.  After centuries of warfare, strong kings who dream of a second
Empire have begun to emerge in different parts of the world.  You are such a
King.  Your goal is to reunite the Empire under your rule, and to maintain
the Empire by awarding high office to those men who have demonstrated the
most merit for such an honor, regardless of their creed.
  There are a total of 8 major Imperial Offices, each of which will be
awarded at the end of the game to the character who has piled up the most
Merit Points for the office.  The highest office is World Emperor, awarded to
the player who has the largest tax base support at the end of the game.  Each
office comes with a percentage prize share.  The standing of the player in the
game is decided by the prize share of the Imperial Offices he controls.


[2.0]  CHARACTERS

  Adventurer-Kings is centered on characters.  Each character has skill in at
least one ability.  Skill in an ability is rated from level 1 to level 9.
Secret special spells and abilities are attainable at high levels of ability
(skill level 5+ ).
  Some special abilities are fairly minor, others are average, and others
are potentially quite powerful.  The usual percentages increases for an
ability may or may not continue, and sometimes they'll only be given when you
reach certain levels.  Some advanced abilities will allow you to override a
rules restriction in some minor way, so if you get a report of another player
soing something that normally isn't allowed, that could be the reason why.
Also if a special ability gained by someone else seems too strong, it may be
because there are limitations that only the other player knows about.  The
special abilities can also vary from game to game.

Characters can raise their skill by practicing, or by performing actions
related to those abilities (see the Experience Table for more details.)  Each
character also has an aptitude for each ability which determines how hard he
has to work in order to rise in that ability.  If a character practices an
ability, his chances of success are lessened if he is trying to attain a
level beyond his natural aptitude.
  Characters also have a race (Human, Elven, Dwarven, Orcish), an Alignment
(Divine, Good, Druidic, Neutral, Pagan, Evil, Undead) and a Temper (Cowardly,
Cautious, Brave or Berserk).  Temper affects the character's conduct in
personal combat.  Characters get along better with other characters of their
own race, and each race usually favors one army type and terrain (for example,
Elven armies fight better as bowmen and in forests.)
  Each alignment has its own special benefits, shown in the Alignment Table.
Alignment also affects victory conditions (if you can't win, it will improve
your standing in the game if a King of a similar alignment wins.)  Lastly,
alignment affects hiring.  Neutral characters have an advantage because a
King can rarely hire a character with an alignment more than two steps
removed from his own alignment.  Undead and Divine Kings, while powerful, are
disadvantaged as only about 40% of heroes will serve these alignments.
To explain the essential beliefs of the seven alignments:

Divine:   The holy union of gods and mortals
Good:     Spirituality and benevolence towards subjects
Druidic:  Harmony between all life forms
Neutral:  Freedom to do as one pleases
Pagan:    Belief in magic and sacrifice to pagan gods
Evil:     Gaining power and sadistically causing pain
Undead:   Anti-holy crusade for world mastery

  Characters may move freely on land or sea, and can move through enemy or
neutral provinces without fear of capture if unencumbered by armies (the code
of honor of this game-world forbids such capture.)  They may carry any number
of magic items.  Armies can move only if they are with characters.  If a
character is given an order to move, and the move would be illegal for any of
the armies led by him, the move is not allowed.  There are two kinds of
characters:  Kings and Heroes.

[2.1]  Kings
  The 10 or so lowest-numbered characters in the game are Kings.  No more than
one King of Divine or Undead alignment is permitted per game. At the start of
the game, the player assigns the King's name, race, temper, alignment and four
ability levels.  The King can have four abilities start at level 1, or 2
abilities at level two, and so on, but can't assign more than 2 points to any
ability. If a player picks Naval ability for his king, the King will be given
the Fleet army-type and placed in a province next to the ocean.  When a player
picks a race, he is guaranteed to get the preferred army type of that race,
listed with the Army Type Table. Orcish Kings will always be given Warg Riders
as their second army type, unless they have selected Naval ability.
  Kings also automatically get a +1 modifier to their skill in Melee, Archery
and Sage, which reflects their royal training and education.  A Divine King
receives a +1 modifier to his White Magic skill, and starts with zero aptitude
in Necromancy skill.  An Undead King receives a +1 modifier to his
Necromancy skill, and starts with an zero aptitude in White Magic skill. The
starting aptitude of a King is always 2 higher than his initial skill, to a
maximum of 5. Undead and Divine Kings cannot start with any ability in a skill
in which they have zero aptitude.
  When two Kingdoms become adjacent, the Kings are given each other's phone
numbers and addresses.  Exception:  some games are designated no-diplomacy
games and players may not contact each other outside of the game.  If a King
does not have another King's phone number, he can still send a written
message to another King through the referee, who will forward it to the
other player.  He may not include his real name, address or phone number in
this message.  If you become adjacent to a Divine or Undead King, you will be
told of the King's alignment in your Diplomacy report.

[2.2]  Heroes
  Heroes start with an average of 2-3 ability levels.  Kingdoms start with one
hero of the same alignment as the king, and one hero of an adjacent alignment,
except that a Divine king starts with heroes of Good alignment and an Undead
King starts with heroes of the Undead and Evil alignment.  Unemployed Heroes
wander from one province to another, sometimes staying in the same province
for a turn or more, until they are hired.  They move at the end of a game
turn, so if you are told the location of a Hero, you know he will stay there
until the end of the turn.  A King is notified when a Hero enters a province
he owns, or may encounter him in other provinces of the world.


[3.0]  ACTIONS

  Each character is allowed 5 actions per gameturn.  If a player misses a
turn, the computer generates Defend actions for his characters.  Late turns
will be accepted, but any moves that conflict with other players, and even
attacks on non-player provinces adjacent to other player Kingdoms, will be
disallowed.
  The computer first does every character's first action, then it resolves
every character's second action, and so on.  The characters with the highest
total ability levels (including all increases for magic items and sage
discoveries) generally go first, with March ability counted three times.  One
exception is that when a character is ordered to Defend, he will always go
last.  Another exception occurs when two characters (A & B) are in the same
province, and character B wants to do something non-aggressive for or with
character A (such as Recruit, Leave or Pick Up armies, casting favorable
spells, friendly Encounters and Giving magic items.)  In this situation,
character A will wait for character B.  Also, when character A is coming
into a province where character B has plans to do something for character A,
even if character B has higher initiative, he will wait for the character A
before performing the action.  The characters must be of the same kingdom.
  Another exception is when a character Pursues another character, and they
are in the same province, the Pursuing character will go right after the
Pursued character.
   If two characters are tied after all this, the lower-numbered character
goes first.

The following actions are now explained in detail:

[3.1]  Move (Abbreviated "MO")
  The character Moves to an adjacent province.  You cannot Move to a
non-adjacent province.  If the character has an army with him and the province
is occupied by a enemy army, combat occurs. Moving into a province also counts
as a partial exploration of the province, with half the effect of an Explore
order. If a character Moves into a province for the first time, all unexplored
adjacent provinces are described in general terms (terrain, race and ruler).
This description counts as a 1% exploration.  Unconquered non-player land
provinces will usually be defended by 1 or 2 armies.  Non-player sea provinces
are undefended unless inhabited by whales or mermen.  When an army leader
Moves into an enemy province, any enemy armies in that province who had been
ordered to move away and haven't yet moved out of the province, stay for the
battle instead, unless they are sent to an adjacent province by a general who
has Defend orders.
  If a character is ordered to move to a hex number, but is not adjacent
to it, he will move towwards it (through friendly hexes, if possible.)
The movement order will override orders in a subsequent phase only if the
character is practicing in that phase.
  The character will stop chasing the province if he can't find
a legal way to move closer to it in one phase.
  If there are two possible provinces that are both closer to the target
province, the following priorities are used:

  1) Owned or Allied-player hex;
  2) Enemy-player hex;
  3) Hero-owned hex;
  4) Neutral-player hex.


[3.2]  Explore (EX)
  The character may Explore the province he is in, which allows a chance of
finding a feature such as a dungeon or pyramid.  There can sometimes be more
than 1 feature in a province.  The character is told the name of the feature,
the treasure that legend says lies within, and the monster guarding the
treasure.  The Basic Exploration Number for each terrain type is listed in
the Terrain Table.  An exploration will result in (Basic Exploration Number x
(Skill in Explorer Ability + 1))% of the province.  A character must Explore
100% of the province to make sure that everything in the province has been
found.  Exploration also may uncover battlefields, in which case you will be
informed which soldiers have fallen in the province.  You can explore a
province even if its been 100% explored, with the object of learning whether
there are destroyed armies in the province.  This is useful for the Skeletal
Armies spell.  Exploration does not reveal information on armies or leaders
in the province.
  Sometimes you get rumours of previously unheard-of features in your turn
reports.  About half of these rumours are true, but the rest are false in some
respect:  the treasure may not actually be there, and/or the feature may be in
a different province (although its usually at least next to the rumoured
province.)
  Monsters are described when they are first discovered, as follows:

  Weak:            7-12 hit points
  - :             13-19 hit points
  Large/Strong    20-29 hit points
  Powerful:       30-44 hit points
  Very Powerful:  45+ hit points

  If a monster has an exceptional ability, such as a Melee ability of 2 or
higher, it is described as the next highest level than its hit points would
ordinarily justify.  Monsters can have abilities not described in your turn
report.  For example, swordsmen can also have some minor magic. You can expect
many intelligent or magical monsters to have magic too.

[3.3]  Search feature (SE)
  A character may Search any feature that has been discovered by his kingdom,
or that he hears about from another King.  When a character Searches a
feature, he must face the guardian monster first.  He specifies an Encounter
Plan.  If he defeats the monster, the treasure in the feature is his.

  Searching a feature can also trigger a special event:  for example, a
character may scout a magic pool, drink its waters and be blessed with
increased ability, or perhaps be cursed (though this is less likely).  See
Scout encounter tactic [5.8].  You can Search a feature to Scout it even
after the monster has been killed.
  A character may Search a feature in a province he does not own, or a feature
they have not discovered yet, if they know the location and feature number.
Characters must Search features as individuals; it is a point of honor to
defeat a monster in single combat.  Armies may not Search features, although a
character may Search a feature while leading an army.

[3.4]  Recruit army(s) (RE)
  With each Recruit order, a character must specify the army types he will
Recruit and the character who will lead the armies.  Any character in the
province may lead the armies, or they can be placed under the garrison
commander.  Each province has 1 or 2 army types that can be recruited from
the populace.  Garrison units may also be recruited, and a character may
recruit mercenaries if any are located in the province.  You can Recruit
armies from the populace only if you own the province, but mercenaries can be
Recruited in any province by any character, even a King who owns no
provinces.  If a character recruits an army type in a province, and there is
an Average or higher quality mercenary army of that type in the province, then
the mercenaries are hired.  Otherwise an army is levied from among the
populace, and will be of the same race as the province's population.
  Normally, only one army of each type may be recruited per province per
turn.  There are two exceptions.  First, in a King's home province two of
each type can be recruited per turn.  Second, Garrison units may be recruited
in any province populated by humanoids, up to a limit of two per gameturn.
Within these limits, one order can be used to Recruit any number of armies.
  If you can't recruit an army type in a province because the natives
don't have that type, you can still recruit it IF the recruiting leader, or
the leader you are recruiting for, has an army of that type under his command.
The army will start out at the normal quality, but will cost DOUBLE to recruit
(because the required armament for that type is rare in that province and you
have to pay more for it, or pay to "have it shipped in.")  You still only
recruit the same number of armies: if there is only 1 army type in the
province, you can recruit only 1 army.  If there are 2 types, you can recruit
2 armies of any type that your leader commands.  Another example: in your home
province, you could recruit 4 armies of one native army-type, and the second
two armies would be double-cost (but still Average quality.) You can only
recruit types that make sense for the province's race (for example, you can't
recruit Dragons in a Human province or vice versa.)  You CAN recruit any
humanoid army type in any humanoid province (humanoids being men, elves, orcs
and dwarves.)  A recruited army will always be of the provincial race, not the
race of the armies led by the recruiting character.
  An army is paid when it is hired (the sign-up bonus), and the King must pay
the same cost to maintain it at the end of a turn.  You can never Recruit
armies belonging to another kingdom or defending a non-player province.
  A character is allowed to recruit an army in a province belonging to his
ally.  The recruiter pays 1 gold to his ally for each recruited
army.  In this way, a vanquished king can hope to get on his feet
again.
  When you recruit units in an ally's territory, the computer always makes
sure that in any given phase, the owner of the territory has the right to
recruit there before you do.  Also, if you are recruiting in your former home
province which is now your ally's province, you can recruit 4 units, and they
will start as Average units.
  In order for you to Recruit in your ally's territory, he MUST issue a
"Treat" order with you (even though you may already be allied.)

[3.5]  Hire Hero (HI)
  Any character can attempt to Hire a Hero in the same province.  The
character offers a payment of 1-4 gold to the Hero.  If the pay required by
the Hero is equal to or less than the offer, the Hero will enter the service
of the Kingdom at the pay required by the Hero (which may be less than the
offer.)  The Hero is paid when he signs up and at the end of each gameturn.
  The pay required by a Hero varies from King to King depending on how much
liking he has for your Kingdom, and is unrelated to the ability of the Hero.
It helps if the Hero has the same temper, same race and similar alignment.  A
King can rarely Hire Heroes with an alignment more than two steps removed from
his own alignment (for example, a Good King can't usually Hire a Pagan Hero.)
You may give a hired Hero orders starting with the action phase after the
phase in which he is hired.  You can't Hire a Hero who rules his own province.

[3.6]  Disband army(s) (DI)
  Releases the army(s) into mercenary status.  A King may Disband any army at
any time.  A character can Disband an army only if he is in the same province.
The disbanded army(s) will wander around as unemployed mercenaries until hired
by another character.  To disband all armies led by the character, write
"(DI)sband All".   If there are mecernary armies in a province when a general
passes through it, they may follow that general instead of staying behind.

[3.7]  Fire Hero (FI)
  Releases the Hero into private life.  A King may Fire a Hero at any time.  A
character can Fire a Hero only if he is in the same province.  The Hero will
wander around until hired by another King.

[3.8]  Leave Army(s) (LE)
  The specified army(s) stay in the province instead of accompanying the
character.  If you Leave an army in an ally's province, the army then belongs
to the ally.  To leave all armies led, write "(LE)ave  All".  You may leave
your armies to garrison the province, or give them to another leader, if the
leader is in the province at the time the leave order is executed.
  Also, let's say one of your characters and one of your armies are in the
same province, but the character does not lead that army.  That character is
still allowed to "Leave" the army to another character, or the garrison
commander.  Therefore, the "Leave Armies" order becomes an all-purpose
"Transfer Armies" command.
  When you use the "Leave" as this transfer command, if you "Leave All", it
will still only leave units that you directly lead, not units under other
commanders or the garrison command.


[3.9]  Pick Up Army(s) (PI)
  Picks up the specified army(s), which will then follow the character around.
You can Pick Up an army led by a co-located character.  You can't use the Pick
Up order to pick up a unit for another character.  You can't use the
"Pick Up" order on an army in the same turn that the army is recruited.
(exception is Pick Up All).   To Pick Up all UNLED armies (with Garrison
Commander) in the province, write "(PI)ck Up All".

[3.10]  Cast Spell (CA)
  The character can attempt to Cast a spell in a Magical ability that he has
some skill in.  The spell must be an Action Spell, not a personal-combat
spell.  The chance of success is 15% plus 15% per level.  Be careful that you
don't use the Cast Spell command to use a magic item.

[3.11]  Use Magic Item (US)
  The character Uses a Magic Item to cast a spell, specifying the ID number
of the magic item.  A spell cast from a magic item is automatically
successful.

[3.12]  Encounter Character (EN)
  The character attempts to Encounter another character in the same province,
to talk to him, steal from him or engage in personal combat.
  If a character wants to Encounter another character with combat in mind,
there are some limitations.  Heroes who don't lead armies can always be
Encountered by other Heroes, but evade encounters from Kings 50% of the time.
Kings only accept a non-peaceful encounter if both King and challenger attempt
to Encounter each other in the same province in the same phase.  Heroes who
lead armies also do not accept encounters.
  If the encounter plan has no combat tactics or personal combat spells
(including Charm), these restrictions do not apply.  If the Steal tactic is
used in such a restricted encounter, the chance of success is halved.

[3.13]  Practice Ability (PR)
  If 2 or more characters are in the same province and all characters
Practice the same ability in a phase, and one character has a higher skill in
the ability (unmodified by magic items he possesses), the character(s) with
the lower skill in the ability will rise in skill 1 level (provided he has
sufficient aptitude, explained below.) If the characters have the same skill
level, there is a 10% chance of rising 1 level for each character.  A
character who Practices alone has a 5% chance of rising 1 level.
  When a character Practices an ability with another character, and one
character has higher skill because he possesses a magic item that raises his
skill level, that magic item does not count and both characters have only a
10% chance of improving.
  A character's chance of rising 1 level is halved for each level beyond his
natural aptitude.  For example, if a character has a natural aptitude of 1,
he has no trouble attaining level 1 in an ability, but has only a 50% chance
of attaining level 2, a 25% chance of attaining level 3, and a 12.5% chance
of attaining level 4.  This applies even when the character is learning from
a character with a higher level.  The chance to increase by experience is
affected by aptitude in the same way.
  Aptitude may increase if a character is due to rise in level, (either from
practicing or experience), but can't because of low aptitude.  The chance of
an aptitude increase depends on the current skill level:

0:     0%           5:    80%
1:    10%           6:    60%
2:    25%           7:    40%
3:    50%           8:    20%
4:   100%

[3.14]  Spy Province (SP)
  A character Spying on a province will report on its owner, owners of
adjacent provinces, taxation of the province, army types recruitable there,
and whether the province is the capital province of the Kingdom.  When a
character spies on a province in a phase, he will have a chance of knowing
about any events that occur in the province in that phase.  These events will
be described in the General Intelligence Report, which is separate from the
character's spy report.  There is also a chance of finding out what Sage
Discoveries the spied-on Kingdom has, and obtaining them for the use of your
Kingdom.  Sage ability also has something to do with spying out inventions.
If a spy sees an invention, some Sage ability will help him figure out
how to get it for your kingdom.  Sage level 1 will be more than enough to
understand all common inventions, but higher ability may be needed for
inventions of obscure design.  The chance for discovering an invention by
spying is limited to twice the chance of discovery by Sages.

  Once per gameturn, a spy will also report on the military forces and
characters in the province.  If a character spies on a province, moves to an
adjacent province and spies there, the King will get this military report for
both provinces.
  Spies always give accurate reports of the events occuring in a province,
but military reports, taxation values and army types are subject to a margin
of error which decreases with increasing skill in Spy ability.  A character
may only Spy on a province he is actually in.

[3.15]  Defend (DE)
  A general ordered to Defend will be able to react to enemy invasions of
adjacent provinces for the rest of the turn.  For example, if you order a
general to Defend as his first action, and an enemy general invades an
adjacent province as his fifth action, your general will move his army to
that province and his troops will fight with the defenders in the battle.
This movement does use up movement points, and if an army uses up its
movement points it can no longer react to an invasion.
  Your Defending general will act fairly intelligently.  For example, if an
enemy sends armies into a Defended province and two adjacent provinces, the
Defending general will go to the aid of one adjacent province with a part of
his forces if he is strong enough; if not, he will stay to defend the
province.  If he wins a battle, he will Pursue the general who invaded an
adjacent province.  Note that in order to move to one province to defend it,
then move back across to the other adjacent province, he would have to move
three times, in which case he would have to have armies with a speed of at
least 3, or good  March ability.
  A general will not react to the invasion if his army can't move there
because the terrain does not allow it.  For example, a general in a land
province who leads 1 Fleet and 3 Bowmen doesn't have enough transport to move
into a Sea province if it is invaded, and can't move to a land province
because a Fleet may not move directly from one land province to another.
  You can order your general to Defend an area of 7 provinces, centered on
any province up to two provinces away.  However, he will only react to an
invasion of a province if that province is adjacent to both the province the
general is currently in and the province he was assigned to Defend.  Note
that you can use this rule to limit the provinces you want to Defend.
  A general with Defend orders may use the rest of his actions to practice,
explore, etc.  If he receives a Move, Pursue or Trail order, the Defend order
is cancelled.   A character's Defend order is cancelled if he loses a battle,
to prevent further needless defeats.
  A "Defend" order will include defending your ally's territories, but only if
you are Enemies with the player who attacks your ally.

[3.16]  Pursue (PU)
  A character can be ordered to chase after another character for the rest of
the turn.  For example, if you order a character to Pursue as his first
action, he will keep moving from province to province until he arrives in the
province occupied by the targeted character.  You can specify other actions
on phases 2 through 5 which will be attempted if the pursuit is resolved
before the end of the gameturn.  All rules listed under the Encounter action
apply to Pursuit encounters.
  If both characters lead armies, the pursuing character will attempt to run
him down and defeat him in battle.  If the Pursuing character does not lead
any armies, then an encounter plan must be specified which will be executed
if they meet.  If the scent is cold, this may take time, so it is best if you
move the character to where the targeted character was last known to be.
  If the Pursuing character leads an army and the pursued character doesn't,
or visa versa, the Pursue order is ignored.  If you Pursue or Trail  character
who belongs to your Kingdom, and both characters start in the same hex, the
Pursuing character will perform the action after the man he's chasing.
  And...

  "Characters On Patrol" (Police Academy 7?!):  This is like the Defend
order, except whenever the character hears of an intruding character, he
chases him down.
  Write this order by having the character "Pursue" his own character
number.  This means the character will track down any detected Enemy character
who enters a hex next to the character.  The evasive skills of Thieves and
Spies still operate normally.
  The "Patrol" order works differently in some important respects from the
Defend order, while in other respects they are quite similar:

  a) Only leaders not leading armies may Patrol, and they chase only
characters not leading armies.
  b) They patrol the current hex they are in and all adjacent hexes.
  c) They only intercept enemy characters.
  d) The Patrol stays active until the next Move, Trail or Pursue order; other
orders after the Patrol order are used if there is no current threat to be
intercepted by the Patrol.
  e) A Patrol may be unable to detect an enemy character if he is using his
Spy or Thief ability that gameturn.
  f) A Patrol will only intercept in owned or Allied territory.
  g) A Patrol will only attempt to pursue intruders whose best skill in
Archery, Melee or Magic is equal to or less than the Patrol's best such skill.
  h) If there are more than one such intruders, the most threatening one is
intercepted, by "highest skill" as defined in point (7).
  i) The "Spy Table" is still used: When intercepting a character in an
adjacent hex, if the Patrol has no Spy skill, there is a 50% chance that the
character will wander into a random hex rather than intercept the intruder.

[3.17]  Trail (TR)
  The character follows and spies on a character, gaining information on the
character's Actions, race, temper, alignment, treasures owned and armies led.
  If the character is a King, some information may be gained concerning the
finances, alliances, enemies and controlled provinces of the Kingdom.  Like
the Pursue order, the Trail order ends when the character finds and has spied
on the character for one phase.  Further Trail orders would be needed to
maintain the spying.  A character leading an army may not be ordered to
Trail.

[3.18]  Give (GI)
  A character may Give a magic item to another character.  List the ID number
of the magic item and a co-located character who will receive it.  The
characters may belong to different kingdoms.  If so, you may specify that the
gift will be made only if the recipient Gives you a specified magic item in
the same phase.
  You can give limited amounts of gold to other Kings.  Only a King may use
this "Give Gold" order.  The King does it by using the Give command together
with a specified amount of gold, giving it to another player's character (King
or Hero) located in the same province.  A King may give out in a gameturn no
more than 10% of the size of his treasury at the start of the gameturn
(although he may always give out at least 10 gold if he has it in his
treasury.)  Be careful that you don't "Give" an amount of gold that equals a
magic item I.D. number carried by the King.

[4.0]  ABILITIES

  Characters have abilities which can help their chances of success in
attempting actions.  You don't necessarily need skill in an ability in order
to attempt an action related to that ability.  For example, you can attempt
to steal even if you have no Thief ability.  The two exceptions are using
archery and casting spells, which require the Archery ability and Magical
abilities respectively.  Abilities of characters are as follows:

[4.1]  Martial Abilities
  Martial abilities aid a character in moving armies, fighting battles and
fighting in personal combat.  There are 5 Martial abilities:

[4.11]  Tactical (abbreviated "TA")
  Tactical ability increases strength of the land and air armies led by the
character by 20% per skill level. If the character is at level 1, the
strength of his troops would increase by 20%.

[4.12]  March (MA)
  The March ability allows a character to move a land army further than the
number of provinces given in the Army Table.  Also, when invading an enemy
province, the character with Forced March ability has a better chance of
uniting with another character invading the same province for the battle
against the defenders.  The March Table gives further details on these
benefits.  March ability applies to units moving from one land province to
another.

[4.13]  Naval (NA)
  Increases the strength of the fleets led by the character by 20% per level
and the speed of naval movement by 1 province per level in a manner similar
to March ability.  Also, when invading a province, the character has a better
chance of joining with another character who is invading the province for the
battle with the defenders.  Naval ability applies to moves to or from a Sea
province.

[4.14]  Archery (AR)
  This ability allows a number of free attacks equal to the level of the
archer.  For example, a character with an Archery skill of 2 gets 2 free
attacks.  The base chance to hit is 30%, plus 10% per Archery level, and the
damage is 1-6 hit points. Monsters sometimes get free attacks because of
archery or other missile weapons.

[4.15]  Melee (ME)
  In melee combat, this ability increases the character's chance to hit and
decreases the opponent's chance to hit by 10% per difference in level, and
increases or decreases the damage by 1 hit point per difference in level.
Example:  if your skill in Melee is 3 and your opponent's skill is 2, you
have a 60% chance to hit and +1 damage, and he has a 40% chance to hit and -1
damage.

[4.2]  Magical abilities
  Every Magical ability has five basic spells.  A character with a skill of
one or higher in a Magical ability knows those spells.  A character may use a
Magical ability to cast one Action spell per gameturn (at level 3, this
increases to two Action spells, and at level 4, three Action spells).  A
character with skill in two or more Magical abilities may use each ability to
cast spell(s) in a gameturn.  A character may use a Magical ability to cast
one Combat spell per encounter (at level 2 this increases to two Combat
spells).  The same Combat spell cannot be cast more than once in an encounter.
  The spellcasting limits for Action and Combat spells are separate.
  A character may cast a spell in a Magical ability only if he has a skill
level of 1 or higher in that ability.  The chance that an action spell will
succeed is 15% plus 15% per level. Combat spells have a 30% + 15% per level
chance of success.  If the spell fails, nothing happens.
  Combat spells work exactly as described, with no other major effects.  For
example, the Psychic Blast spell does not increase your chance to hit in
melee, nor does it allow you to flee the combat.
  A Pagan kingdom, whose leaders possess minds which are especially sensitive
to magical forces, is aided by an Order of Magicians.  All Pagan characters
controlled by the King have a +10% modifier to their spellcasting attempts,
except for White Magic spells.

[4.21]  White Magic (WH)
  The player may cast these White Magic spells:

1.  Resurrect character (Abbreviated "RE") (Action spell): A spellcaster in
the same province as a deceased character may attempt to bring the character
back to life.  If the spell is successful, the character returns to life with
all of his former abilities, but not his former possessions, and becomes
employed by the King who resurrected him.  A character may be resurrected at
any time after his death.  When a Divine king resurrects a hero, his alignment
becomes Good, thus enabling the King to gain a character at reduced pay.  A
Divine King can cast resurrection on one of his own living heroes to turn
him into a Good character.  Undead characters can be resurrected if they die,
in which case they become the same alignment as whoever resurrected them
(except for an Undead King.)
  After your King dies, you can cast a Resurrection spell on your Royal Heir
and get your old King back (you're actually casting the spell on the bones
carried around by the Heir.)  If another player casts a Resurrection spell on
your Royal Heir, you still get your old King back.  But as soon as you assign
your Heir his new skill levels, or improve any of his abilities by practice or
experience, you lose the resurrection option.  If the Heir dies, his abilities
don't replace the abilities of the dead King for the purposes of this rule.

2.  Part Sea (PA) (Action spell): A sea province is transformed into a plains
province for the rest of the turn.  Fleets or Whales may not enter or leave
but land units including Mermen may.  Only the province the caster is in, or
an adjacent province, can be affected.
  Land units may only enter the Parted Sea from an adjacent land province or
Parted Sea.  They may leave the Parted Sea only to an adjacent land province
or Parted Sea.  A land unit which entered a Parted Sea in a previous gameturn
will find that the Parted Sea must be re-parted in order for the unit to move.
  "Part Sea" cancels the effects of "Flood", and vice versa.

3.  Bless Province (BL) (Action Spell): The tax base of any one province is
increased by 60% for one turn.  Multiple Bless spells have no cumulative
effect.
  A Bless spell can remove buried skeletons permanently (the chance
is (White-skill x 10%) + 10%.)
  Armies "Paroled into population" in a battle are not eligible to
become skeletons.


4.  Holy Symbol (HO) (Personal Combat spell): The Holy Symbol invokes Divine
protection. It reduces an opponent's chance to hit in archery or melee by 10%
per skill level.  For example, at skill level 1 an opponent with a 50% chance
to hit will have his chance reduced by 5% (50% x 10% = 5%).
  When used against an undead character or monster such as a vampire or ghost,
or an anti-holy monster such as a Demon, the spell reduces its chance to hit
by 20% per skill level and inflicts 1-4 damage points per skill level.

5.  Spiritwrack (SP) (Personal Combat spell): The caster utters holy words
which cause the spirit and body of his opponent to undergo weakening
convulsions.  The victim can't cast spells or use archery, and the damage he
does in melee is reduced by 1/2 hit point per level of ability of the caster,
rounded up or down randomly.  The spell does not work against undead monsters
or characters, or mechanical monsters because they have no spirit, and its
effects are halved against monsters with animal intelligence.

[4.22]  Psychic Magic (PS)
  Allows the use of spells having to do with powers of the mind:

1.  Charm (CH) (Action spell OR Personal Combat spell):  When cast on a Hero
in the same province who leads no armies, allows the caster to hire the Hero
at no cost (however, maintenance costs must still be paid.)  Otherwise, it
allows the caster to befriend his opponent and escape from combat unharmed.
  When cast by an Undead character, the Charm spell is a Necromatic spell (not
a Psychic spell.)  When an Undead King (not a hero) Charms a hero (as an
action spell only), he also turns Undead.  An Undead King may Charm his own
heroes in an attempt to turn them to undead.  Heroes with advanced skills are
more resistant to being turned undead (although the cast chance itself is not
lessened.)  For these heroes, corruption occurs gradually: alignment will
change by 1-3 steps per spellcast.

2.  Oratory (OR) (Action Spell): The caster may cast the spell on himself or a
co-located character.  All armies that travel with him are heartened by the
oratory and have their quality increased by one level for the rest of the
turn.  Green armies become Average, Average armies become Veteran, and so on.
Casting this spell more than once does not produce a cumulative effect.

3.  Clairvoyance (CL) (Action Spell): The spell is cast on a character in any
province in the world.  Everything that happens to that character for the
rest of that turn becomes known to the caster.  A character can only cast one
Clairvoyance spell per gameturn.  A subsequent Clairvoyance spell will nullify
the one currently in effect.

4.  Psychic Blast (PS) (Personal Combat spell): The spellcaster projects a
blast of mental energy which stuns the enemy and allows the caster 2-5 free
attack rounds.

5.  Telekinetic Storm (TE) (Personal Combat spell): The caster creates a
telekinetic storm centered close to the victim which seizes small objects and
whirls them in all directions at great speed.  The spell does 4-16 hit points
to the monster, and some objects will also strike the caster.  If he is at
melee range, he takes 4-16 hit points; at bow range, 2-8 hit points; and at
spell range, 1-4 hit points.  This spell does not work against underwater
monsters.

[4.23]  Illusory Magic (IL)
  Allows the spellcaster to become invisible or change the appearance of
terrain or his armies.

1.  Illusory Terrain (IL) (Action spell): The spellcaster causes the province
he is in (or an adjacent province) to appear to be of a different type of
terrain.   You can select the terrain the illusion will mimic.  The illusion
has a 15% chance of dissipating per gameturn.  The spell only affects someone
viewing the province from an adjacent province.  Someone who enters it will
detect the illusion, but it will still affect armies somewhat:  the strength
of armies will be halfway between their strengths for the real terrain and the
illusory terrain.

2.  Phantasmal Armies (PH) (Action spell): This spell causes armies of
illusory soldiers to travel with the spellcaster (or co-located character)
for the rest of the turn, which increases the strength of the armies he
directly leads at a battle by 15% per level of the spellcaster.  Casting
more than one Phantasmal Armies spell does not have a cumulative effect.

3.  Hide Feature (HI) (Action spell): A specified feature in the province
occupied by the character becomes invisible to any explorer, although a King
who already knows the feature is there will not be fooled by the illusion,
nor will the Heroes in his employ be fooled.  The illusion has a 10% chance
of dissipating per turn.
  If a monster is currently raiding one of your provinces, then casting this
spell on his feature will stop him for as long as the spell lasts.

4.  Invisibility (IN) (Personal Combat spell): The spellcaster becomes twice
as hard to hit by archery or melee attacks for the duration of the combat.
If you cast an Invisibility spell in your encounter plan before you steal,
it's worth a +15% modifier to the stealing attempt.
  The Invisibility spell also allows a +30% chance to Flee an encounter.


5.  Mirror-Image Phantasm (MI) (Personal Combat spell): The caster creates a
mirror-image illusion of his opponent and sends the phantasm into combat.  To
his opponent, the phantasm is real and initially has exactly the same
characteristics as when the spell was cast.  The two mirror images then fight
it out, while the caster must concentrate on his illusion, performing no
other actions.  If another Mirror-Image spell is cast while the illusion is
fighting, both illusions will dissipate.
  Before each combat round, there is a chance that the victim will disbelieve
the illusion, in which case the illusion loses its power.  The chance of
disbelief for each type of intelligence level is listed below.  15% per level
of the spellcaster is subtracted from the listed chance.

Divine or Superhuman 120%
High Human 100%
Medium Human 80%
Low
Human 60%
Animal 40%
Mechanical 20%

  If the mirror image loses, the caster must continue the fight at the
current combat range.  If it wins, the real monster is mentally slain and
falls to the ground.  The illusion then turns on its master, who is in such a
deeply involved trance-state that his own sense of reality is distorted.  The
illusion must be disbelieved (at a bonus of 25% above Medium intelligence) or
slain.  If the illusion wins, it fades out, and the real monster revives and
slays the fallen illusionist.  If the illusion loses, the caster
automatically finishes off the mentally-slain monster and claims the
treasure.

[4.24]  Elemental Magic (EL)
  Allows casting of spells which draw on the four elements of fire, air,
water and earth:

1.  Flood Province (FL) (Action spell): This can only be cast on a co-located
or adjacent non-mountain land province.  It immobilizes all land armies in it
for the rest of the turn.   No land armies may enter the province.  Naval and
air movement and transport is unaffected.

2.  Tornadoes (TO) (Action spell): When cast against an enemy province which
the caster is in or adjacent to, each army there has a 10% chance per level
of being sucked up and scattered to the four winds.

3.  Earthquake (EA) (Action spell): Wipes out the tax base of an enemy land
province adjacent to or co-located with the spellcaster for the current
gameturn.

4.  Fireball (FI) (Personal Combat spell): When used in personal combat, does
1-8 hit points of damage, plus 1 hit point per level.  The spell does not
work against underwater monsters.

5.  Ice Suspension (IC) (Personal Combat spell): The caster may suspend the
victim in a magical shell of ice, or at least slow it down for a few rounds.
The caster may suspend a monster which has up to 4 remaining hit points per
level of the caster in Elemental Magic.
  If the spell successfully suspends the victim, the caster will gain
whatever magic items are not being carried by the victim, and may choose
between fleeing (with automatic success) or waiting for the ice to melt
enough for the victim to start breaking out, in which case the caster will
gain 3 free attack rounds (starting at whatever range is best for his next
combat tactic.)
  If the spell is not completely successful, the caster will gain 1-3 free
attack rounds, depending on the percentage of the monster encased in ice.
For example, if the victim has 16 remaining hit points and the caster has a
skill of 1 in Elemental Magic, he gets 1 free attack (4/16 hit points,
multiply by 3 maximum attack rounds and round up, and you get 1 round.)
  Of course, this spell does not work against ghosts, demons and similar
creatures which exist only partly in the material world. Also, it works
differently against flying monsters. If the spell is cast on a flying
creature, it will do 5-10 hit points of damage when the creature crashes into
the ground, and gains the caster 1-3 free attack rounds.

[4.25]  Necromancy (NE)
  Allows casting of the following Black Magic spells:

1.  Skeletal Army (SK) (Action spell): If the character is in a province where
a battle was previously fought and some armies were destroyed, he may recruit
a horde of skeletons who rise from their graves and pick up the weapons they
perished with on the battlefield.  One army per level of ability can be
raised, provided that enough armies have perished on the battlefield on
previous turns.  There is no recruiting cost, but maintenance costs must be
paid at the end of the turn.  The caster has no control over which army type
will answer his call.  There is a limit of 350 armies allowed in the game
(both dead and alive) so after the first few turns, about 10% of the
previously destroyed armies will rot away each turn.  The oldest destroyed
armies will rot away when the 350 army limit is exceeded.
  The Skeletal Army is identical in all respects to whatever army was
defeated on the battlefield, and has all of its movement points.  Skeletal
armies controlled by an Undead Kingdom have a 100% chance of fanaticism.  An
Undead King also starts the game with one of his armies being Skeletal.  A
Skeletal Army can be raised in an enemy-controlled province, which will
provoke a fight with whatever forces are defending the province.  If a
character tries to leave the Skeletal Armies or transfer them to another
character, other than an Undead character, they will dig their own graves
and go to sleep once again.  When a Skeletal army dies (but not a non-skeletal
army), it is reduced in quality by one level.

2.  Kill Enemy (KI) (Action spell OR Personal Combat spell): In order to cast
this spell, the necromancer and his victim must be in the same province.  The
spell may not be cast on a monster guarding a feature except as a Personal
Combat spell. The caster makes a figurine of the opponent he wishes dead,
then "kills" the figurine by a method such as sticking pins in it. If the
spell is successful, the victim is killed in the same way the figurine was
destroyed.  If the spell is unsuccessful, the intended victim will attack the
caster with a Berserk temper, tracking him down that very phase if
necessary.
  This spell does not work against undead monsters or characters, ghosts,
demons and similar creatures which exist only partly in the material world.
Also, it has half the normal chance of working in an encounter in a feature or
against a Hero who leads an army because there is so much guesswork in making
the figurine.  A necromancer can't use it to defend himself in an encounter
because of the time needed to prepare the figurine.  Kings are invulnerable to
this spell.

3.  Plague (PL) (Action spell): The caster names a province to be afflicted.
it must be the same province the caster is in or an adjacent province.  If
successful, each army in the province has a 10% chance of being destroyed,
plus 10% per level of the spellcaster.  If a unit survives a plague, it's
immunized from dying in future plagues (it may instead drop a level in
quality.)  Only the four humanoid races are affected.  Be careful!  The next
phase, there is a 15% chance per adjacent province that the plague will
spread, and it can spread further each phase after that.  Casting more than
one Plague spell does not have a cumulative effect.

4.  Hand of Death (HA) (Personal Combat spell): The caster makes squeezing
motions with his hand, which magically causes his opponent to feel his heart
(or other organ of the caster's choice) being squeezed to a pulp.  The caster
may not cast spells or attack while using this spell, and defends in melee at
his Necromancy skill level, not his skill in melee.  Each attack by the
caster does approximately 1 damage point plus 1/2 damage point per level of
ability.  The victim can't cast spells or use archery, and his chance to hit
in melee is halved. When the caster is hit in melee, his concentration is
broken and the spell ends.  The spell has no effect against undead characters
or monsters, or mechanical or anti-holy monsters.

5.  Control Undead (CO) (Personal Combat spell):  The caster may control any
undead monster or character with this spell for enough time to drive a stake
through its heart (or otherwise incapacitate it.)  Unfortunately, the
consequence of failure of this spell is the instilling of a maniacal rage in
the intended victim, which has the effect of increasing its hit points by
50-100%.

[4.3]  Special Abilities

[4.31]  Sage (SA)
  The Sage is a historian, scientist, and engineer. The Sage ability allows
discovery of new devices.  When a Practice Sage Ability action is performed,
there is a 5% chance per level of inventing or discovering a useful device.
You might discover the compass, which will help your Explorer ability, or
create a mighty war engine to help you in battles.  Some devices aren't
really scientifically possible, but are included just for fun.  If a level-4
Sage practices Sage continuously, he will make a discovery an average of once
a year.

[4.32]  Druid (DR)
  Druids specialize in attaining harmony with all other natural life forms.
With each level, Druids gain the ability to lead armies of races other than
their own, as listed in to the Druid Table.
  If a character attempts to lead an army when he has insufficient Druidic
ability, the quality of the army suffers a decrease equal to his shortfall in
Druidic ability.  For example, if a character with no Druidic ability
attempts to lead an army of Whales, which requires a Druidic skill of 2, the
quality of the army is reduced by two levels (from Average down to Depleted,
or from Veteran down to Green, etc.).
  If a unit is under the garrison commander of a province, and is of a
different race than the King, then the King's druidic ability is used when
figuring the unit's modified quality.
  With regard to the Talk tactic in encounters, some monsters can only be
conversed with by Druids.  Monsters with at least human intelligence and a
humanoid voicebox, and also dragons, can be Talked to by anyone.  Druids gain
additional Talking abilities at each level according to the Druid Table.

[4.33]  Spy (SP)
  The spy is capable of compiling reports on the strength and disposition of
enemy forces and characters, and spying out the inventions used by other
Kingdoms.  On gameturns when a character at some point performs a Spy or
Trail action, the character has a reduced chance of being noticed by other
Kingdoms throughout that entire gameturn.  The Spy ability gives you greater
success when performing the Spy action, and if a character has a Spy ability
of at least one, he may contribute something to your General Intelligence
report even if you don't order him to spy.
  The Spy ability also determines the chance of success when Trailing or
Pursuing another character.  See the Spy Table for more details.

[4.34]  Explorer (EX)
  Increases the amount of province explored in one Exploration action by the
Basic Exploration Number per level.  Basic Exploration percentages are shown
in the Terrain Table.

[4.35]  Thief (TH)
  Increases chance of success when stealing by 15% per level.  Also, a Thief
has the Spy's ability to escape notice when he attempts thievery in a
gameturn.

[5.0]  ENCOUNTERS

  Encounters can occur between characters and monsters as a result of the
Search action, between characters in an Encounter action, or at a battle as a
duel between the two commanders.  An encounter can never involve more than
two characters.
  Both characters have an Encounter Plan.  In general, a character can
attempt to steal, negotiate, or attack his opponent.  An Encounter plan
basically is a listing of tactics that you want to use in the Encounter,
listed in your order of preference.  Whenever a character goes into an
encounter without a plan, or runs out of tactics, the computer will generate
them.  In personal combat, two combatants alternately attack each other in
combat rounds, inflicting damage points with each attack, until one combatant
is killed because the damage points he sustains equals or exceeds his hit
points.  The victor can then loot the vanquished foe for his treasure.
  Whenever aggressive tactics follow negotiation tactics in an encounter plan,
this is interpreted to mean that those aggressive tactics will be used only
if the negotiation tactics fail.
  The character with the greater skill level relevant to the tactic he is
using generally goes first in the combat round.  For example, a Psychic
magician with a skill level of 3 casts his spell before a level-2 archer
fires his arrow.  If the skill is the same, the characters go in random
order.
  There are three ranges in combat:  Spell range, Bow range and Melee range.
Spell range is the greatest distance, and only spells can be used.  At Bow
range, Spell or Fire attacks can be made.  At Melee range, only Spell or
Melee attacks may be made. Encounters normally start at Spell range.
Two exceptions to the combat initiative rule should be mentioned:  At Spell
range, Spell attacks come before closing to Bow range, and at at Melee
range, Melee attacks always go first.
  In combat, all characters have 10 hit points.  Monsters may have anywhere
from 7 to 50 hit points.
  Neutral Kingdoms are aided by an Order of Duelists.  All Neutral characters
controlled by the Kingdom are experts at dueling other characters, and fight
with a +1 modifier to their Melee and Archery abilities.  This also applies
to encounters with humanoid monsters, such as renegade swordsmen in a feature,
and also in random encounters.
  The following rules sections list the combat tactics available.

[5.1]  Cast Spell, Use Magic Item  (CA-XX, US-#)
  A spell can be cast at any range.  Any given combat spell can only be cast
once in a combat.
  Some spells protect a character in personal combat from being hit.  When
more than one such spell is cast on a character, the effects are multiplied.
For example, if a spell reduces an opponent's chance to hit by 50%, and
another spell reduces his chance to hit by 50% again, the opponent's chance
to hit is 25% of what it would normally be (50% x 50% = 25%).
  Some spells stun or delay an opponent for a few rounds.  If the opponent is
delayed long enough for the caster to move out of spell range, the Flee
tactic will work automatically.  These types of spells do not assist in
Stealing.
  In combat, whenever a character attempting to cast a spell takes damage or
is stunned, the spell is checked for disruption. If it is disrupted, the
caster loses a turn.  For example, 3 hit points will disrupt your spell 50%
of the time, while a missed swing will disrupt you 30% of the time because
you may lose your spell-concentration while evading the blow.
  Some magic items can cast spells in combat. The effects are similar to the
spells themselves.  A spell cast from a magic item is automatically
successful.
  If a character has two magic weapons, he can use the "Use Magic Item" order
to specify which weapon he will use.  This does not use up a round.

[5.2]  Fire Arrow (FI)
  You can have a number of free attacks equal to the level of archery skill.
For example, a character with an Archery skill of 2 gets 2 free attacks.  The
base chance to hit is 30%, plus 10% per Archery level, and the damage is 1-6
hit points.
  If two characters with archery skill fight each other, they will both get
about double their usual number of free attacks. However, there is some
random chance involved, and the superior archer may actually be unable to
fire off any attacks before melee combat begins!  Monsters may get free
attacks because of archery skill or other long-range weapons.
  If a character is ordered to Fire attack at Spell range, he closes to Bow
range, which uses up his round, and Fires the next round.  If he is ordered to
Fire at Melee range, he uses the next tactic instead.

[5.3]  Melee (ME)
  You can enter melee even if you have no skill in melee combat.  When you
order melee, your character will close to Melee Range and swing away at his
opponent.  A character has a base chance to hit of 50%, and does 1-6 damage
points per swing.
  If a character is ordered to Melee attack at Spell range or Bow range, he
closes to the next closest range, which uses up his round.  He will Melee
after he closes to Melee Range.
  A character's Temper affects melee according to the Temper Table, shown on
the Quick Reference Card.

[5.4]  Negotiations (TA-lk, SA-y, FU-lfill)
  When Talking to a monster defending a feature, it will either attack you,
ignore you or propose some agreement (such as a quest which will be rewarded
by the gift of a magic item).  When Talking to an unemployed character, you
gain an estimate of the character's Alignment and Temper and find out what it
would cost to hire him.
   If a character of Druidic alignment succeeds in talking to a monster, it
may be more willing to assist him than a non-Druidic character.
  A character may Say whatever words you specify, up to a limit of 160
characters.  This action consumes no time in combat.  The character's next
tactic is done in the same combat round as the Say tactic.  You can use the
Say tactic to enhance the turn results.  For example, if you're about to cast
a Fireball spell on an Ice Devil, you could Say "Here's a hot-dog for you,
icicle-beak!"  You can't say your phone number or any other contact
information in a Say tactic.
  When a monster proposes some agreement, you may Fulfill it after you have
met its terms.  Usually the monster will reward you with gold or treasure.
The monster may not always live up to its end of the bargain, especially if
it's an evil monster and/or there is a great difference in alignment between
monster and character.
Some of you will run across riddling monsters in your adventures searching
features.  Helpful hint:  When you return to their lair to answer the riddle,
you can take as many guesses as you like in your "SA-y" tactic.

You may not use both the Talk and Fulfill tactics in the same encounter plan.

[5.5]  Steal (ST)
  The character attempts to Steal some treasure from his opponent.  He will
either succeed and get away with some gold or magic item(s), or the monster
will attack him.  The base chance of success is 15%, plus 15% per level of
the thief.  If the thief is going after a King or a Hero who leads an army,
the chance of success is halved.  If you go after a king, you may be able to
bag a certain percentage of his treasury (try it to find out how much).
  If a thief fails in an attempt to steal, he wont necessarily get caught
(the chance to avoid capture rises with each level of thief).  If the thief
fails and is caught, there are three possible results.  If the thief is a Hero
who tried to steal from a King or another Hero who leads an army, he is
executed.  If the thief is a King who tried to steal from another King, he
loses half the gold in his treasury as a ransom.  If the King has no gold, he
is executed. If the thief is a character who tried to steal from a monster or
a Hero who does not lead an army, personal combat ensues, at a randomly
determined range.  Steal, Talk and Fulfill are mutually exclusive and only one
of these tactics may appear in any encounter plan.
  Even if the thief is successful, the monster involved has a chance of hiding
a magic item (e.g. sleeping on it).  A creature of average intelligence would
have about a 10% chance of hiding a magic item per stealing attempt, whereas a
smarter monster would have a 25-50% chance.

[5.6]  Flee (FL)
  The character can say that he will Flee rather than undergo combat.  His
chance of fleeing from fast monsters is 20%. Fleeing from medium-speed
monsters or other characters is a 50-50 proposition, and slow monsters can be
escaped from 80% of the time.  A character with a weak Temper may flee
without being ordered to flee, regardless of his tactical plan.  Cowardly and
Cautious characters other than the King may even refuse your command to
encounter a character or monster, depending on how strong the opponent is.
See the Temper Table for more details.

[5.7]  Give (GI)
  In an encounter plan, you may GI-ve any number of items to whomever
you encounter.  This supplements the "GI-ve" Action, and allows you to give
more than one item in a phase, but does not allow you to trade one item for
another.  NEVER use the Give tactic in place of Fulfill, nor can you use
it to give gold away.

[5.8] Scout (SC)
  When searching a feature, a character can use the "Scout" tactic to explore
the feature looking for any special function or event.  These "Specials" can
be of a beneficial or detrimental nature.  A Scouting character may also gain
information on what treasure is in the feature.
It makes no difference where you put the Scout tactic in your encounter plan.
The Scout tactic has no effect on the success of your other tactics, and the
computer will simply do your Scout tactic after all other encounter tactics
are completed.
When the Scout tactic is part of an encounter plan which calls for Talking,
Fulfilling or Attacking, or if there is no monster there, an attempt will be
made to discover any special function or event (usually after concluding any
dealings with the monster, whose permission may be needed to Scout around.)
If you use some other type of tactical plan, you may be told that the Special
is there, but not find out what it does.  For example, if you Steal and Scout,
there is a 33% chance of not finding out.  If you Flee and Scout, this chance
is 67%.
  Suggestion: if you've attacked and looted some features already, try
Scouting them to see what special function you might get.  And, a final note
of caution:  These special functions may be usable only once per phase or
year, and may act differently depending on the searching character's alignment
or other characteristics.

[5.9]  Victory and Death
  If a character survives combat, he regains all hit points immediately.
Magic items are sometimes gained from a vanquished foe as a result of combat.
 They perform a wide variety of functions. Usually they cast a spell or
enhance an ability.  The magic items that cast spells are invoked by a "Use
Magic Item" order, and they have a limited number of charges; after the
charges are used up, the magic item disintegrates.  Magic items which don't
cast spells operate automatically and need not be invoked by a command.
  When a character dies, any magical treasures he used in the combat go to
the victor.  Magical treasures not usable in combat are assumed to be in
safekeeping and are willed out to his heir.  If the deceased character is a
King, his eldest son takes over for him in the province where the King died.
His son will start with four ability levels chosen by the player, three of
which must be within the skill of the former King.  No more than two of these
four levels can be applied to any ability.  A new temper and/or gender may be
selected, but not a new alignment.
  On the printed color map, if a feature has been sacked, it will appear grey.


[5.10]  Special Encounter Plan
  In addition to character actions, players may specify a Special Encounter
Plan for each character.  This plan has two purposes, depending on whether a
character leads an army or not.  If the character does not lead an army, the
plan will be used at all Encounters which are initiated by another character,
or in random encounters.
 At a battle, the Special Encounter Plans of the two supreme commanders
determines whether there will be a duel between them.  The Talk, Fulfill and
Steal tactics are not allowed in a special encounter plan.
  If either supreme commander at a battle has a Special Encounter Plan with
an aggressive action in it, and no "Flee" action, then that commander will
challenge the other commander to a duel.  If you want to refuse a challenge to
a duel by an enemy commander, the FIRST tactic in the Special Encounter Plan
must be a Flee.  If it's any other place in the plan, the computer will assume
you want to fight it out before fleeing.  However, if you have a Flee tactic
anywhere in your Special Encounter Plan, you won't challenge for a duel.  The
Flee tactic always works in a battle encounter, but if it is used, the troops
are disgusted by their commander's cowardice and are reduced in strength by
25% (using a Charm spell to escape has the same effect.)  Otherwise, one of
the commanders will be slain in the encounter.  His troops are disheartened
and their strength is reduced by 25%.

  With the Move, Explore, Search, Trail and Pursue actions, there is a chance
of a random monster encounter.  The percentage chance of a random encounter
is listed in the Terrain Table.  The character will use the Special Encounter
Plan to defend himself.
  Your characters are twice as safe if they are traveling through an friendly
kingdom.  If a character starts a phase in a province with any character who
leads an army, and Moves, Pursues or Trails to the same province as this
character, he is assumed to be travelling with the army and will not have
random encounters.


[6.0]  ARMIES

[6.1]  Types of Armies
  Each land province has 1 or 2 army types, and a King can recruit only these
allowed types and Garrison units in that province.  Garrisons cost 1 gold.
Other infantry costs 2 gold, and most other types cost 3 gold.  See the Army
Type Table for exact unit costs.
  An army has a quality level of Depleted, Green, Average, Veteran, Crack or
Elite.  A newly recruited army starts out as Green, except in the home
province where they begin as Average armies.  Green and Depleted armies
always improve to the next level at the end of a turn.  At the start of the
game, all armies are Average.
  When an army leader Practices Tactics, he is taking his armies on
training maneuvers.  Those armies may have a chance to rise in quality:

Depleted => Green:  100%
Green => Average:    25%
Average => Veteran:   5%
Veteran => Crack:     1%
Crack => Elite:       0.2%

  In order for an army to rise to a higher quality, an existing army of that
quality must be there to train and inspire it.  For example, if a leader has
mostly Average armies under his command, there has to be at least 1 Veteran
army there if the Average armies are to have any chance of rising in quality.
The Veteran army need not be of the same type as the Average armies.
  If two leaders Practice Tactics together, their armies are pooled into the
same training maneuvers.

[6.2]  Movement and Transport
  Armies can't move without characters, but may be left in a province to
defend it.  An army's speed determines how far it can move in a gameturn.
For example, an army with a speed of 3 can move 3 provinces in one gameturn.
If any army moves into a province occupied by another enemy army, there is a
battle.  The army must use up an extra movement point after conquering an
enemy land province or fighting a naval engagement.  If an army BEGINS a
phase in an enemy province and can still move, it uses a movement point to
force a battle.  The increased army-movement allowed by the March and Naval
abilities is always calculated at the moment an army moves.
  Land armies can move only on land, unless they are carried by fleets.
However, they can be left at sea since it is assumed that each sea has some
islands.  They will defend the sea province, even against invading navies.
  Whales and fleets can enter and exit land provinces, but can't move directly
from one land province to another.  A fleet can transport two infantry armies
(including Trolls and Werebeasts), or one mounted army.  Camels and Elephants
are considered mounted units for transport purposes.
  Mermen move like fleets, except they MAY enter and leave a Parted Sea.
They can't transport other units, but may be transported by air units.
  Ents may never be transported, and can enter a Sea province only if it has
a "Part Sea" spell cast on it.
  Air wings (Dragons and Eagles) can move by land or sea and can end a turn
at sea.  They can transport 1 infantry army apiece.
  Armies can't use overland movement and be transported (by sea or air) on
the same gameturn.


[7.0]  BATTLES

  When a character leading armies moves into a province occupied by an enemy
army, there is a battle.  In battles, fleets can be used on land (they
disembark their marines for the battle) and armies can fight at sea.  Sea
battles are basically a series of boarding actions and therefore are somewhat
similar to land battles.  Battles are fought at the end of the phase, after
all characers have taken their actions.

[7.1]  Supreme Commanders
  The two supreme commanders at the battles are the characters with the
largest troop contingents, the tiebreaker being the best Tactical ability.
If a character who leads no armies is present in a province where a battle
occurs, he will appear at the battle to take over in case the supreme
commander dies (but nwill not have to fight a duel).  He will not appear if
there is no supreme commander already at the battle for his side.
If the defending armies aren't led by a character, they are led by the
"provincial garrison commander", who has no abilities and is present for that
battle only.
  Before the battle, the two supreme commanders may fight a duel.  The armies
which were led by the loser of the duel will become demoralized and will be
reduced in strength by 25%.  More details concerning duels are given in the
Special Encounter Plan rules [5.10].

[7.2]  Battle Lines
  When a battle occurs, the armies of the two forces are lined up against
each other.  The line may be shortened by mountainous or wooded terrain on
the flanks of the defender, so that the defending force only has to defend a
small line (see the Terrain Table).  The length of the line is limited to the
line length of the smallest force.  The two opposing forces place their best
armies in the front of the line.  The weaker armies usually line up behind the
front line, and contribute 50% of their strength to the battle. If there are
enough armies for a third line, they are only 25% of their normal strength,
and so on.  If a battle line is shorter than the terrain allows, the flanking
second-line units of a force which is superior in numbers may outflank the
enemy force.  If they do that, they count as 100% strength instead of 50%.
  Non-humanoid units (Eagles, Dragons, Whales and Mermen) can attack from
above or below and contribute 100% of their strength to the battle.  If
there is an enemy unit behind the front lines for the non-human unit to
attack instead of a unit on the front line, it will attack the rear unit
instead (the non-human unit and the rearward unit will both be at 100%
strength in this case.)  However, if the non-human unit has low strength
because its leader has insufficient Druidic ability, it will be held back and
will throw its low strength into the attack on the front-line unit.
  The reasoning for this rule is that the swooping attacks of air units and
the underwater attacks of Whales and Mermen at sea would naturally carry them
past the front lines, especially if the enemy is fighting in close-order
formation. So a second-line unit should always be at 100% strength if an air
unit is overflying or a sea unit is attacking underwater the unit ahead of it
in the front line.
  All non-humanoid units (air units, whales and mermen) become less effective
when more than one is used in a column, or more than one is attacking a single
enemy unit.  A second non-humanoid unit attacking an enemy unit is at 1/2
strength, a third is at 1/4 strength, etc.  Non-humanoid air units, non-
humanoid sea units and humanoid units are considered three separate groups
when halving strength in this way.
  Generals are sometimes able to take account of elephant performance and
the "nemesis" effect when lining up their units.  The chance of being able to
make a switch in any column is (Tactical-Ability / Line-Length).  Switches
can only be made within the same column, and the defender always gets the
last chance to switch.  The switch will only be made if the army strength of
the current front-line unit is less than the strength of a rearward unit,
after adjustments are made for all nemesis effects.

  There are several factors that modify or affect the strength of units in
battle.  These are detailed beneath the Army Type Table.  For Druidic
Kingdoms, if a monster in a province where a battle is being fought is closer
in alignment to Druidic than the player he is fighting, it may come to help
the Druidic cause.  A very powerful monster in a 1-column battle in mountains
may even have a better effect than the fanaticism sometimes given to armies of
Good alignment.

  There is then a number of contests equal to the length of the battle line.
The strengths of the combatants are totalled up and compared.  A 4:1 ratio is
needed to assure victory, while a 1:1 ratio gives a 50% chance of winning.
The side that does best in these contests wins the battle.  The computer
decides which armies were eliminated in the battle by comparing the strengths
of the armies fighting in the contest.  Fleets fighting on land provinces
would generally be reduced to Depleted status instead of being eliminated.

[7.3]  Pursuit
  After the battle, the faster units in the victorious army can pursue and
possibly destroy some of the losing armies.  In this pursuit, army speed is
the most important factor in catching the defenders or evading the pursuers.
Retreating units fight with the 25% bonus given to defenders, but suffer a
-1 quality penalty due to their demoralized state.
  Generally speaking, about 25% of the victorious infantry and 75% of the
cavalry will attempt to pursue the retreating armies.  Especially fast units
such as light cavalry and air wings can attempt more than one pursuit.  If
a retreating army is unable to fight the pursuing unit to a standstill in
a one-on-one battle, it is destroyed.

[7.4]  Retreat
  If the defeated army has little hope of winning a second battle, it will
retreat into an adjacent friendly province.  If retreat is impossible, Green
and Depleted units will be disbanded into the population, while Average and
better units may disband into mercenaries, usually marching a few provinces
away from their attackers at the end of the turn.  You can not hire them that
gameturn.
  If the attacker destroyed all defenders or forced them to retreat, the
province becomes part of the attacker's Kingdom and it will pay taxes to its
new King each turn.  If the attacker was forced to retreat, his armies must
retreat into the same province they invaded from, or a province adjacent to
the province they invaded from.  Retreats are conducted separately for each
character who leads a contingent at a battle.  This is important if the only
retreat route is to the sea, and one leader has all the Fleets.  If you kill
an enemy general in a duel, the troops will usually carry his body with them
in their retreat.  That would be the reason why you don't see his grave in the
province of his death.

[7.5]  Aftermath of Battle
  Armies of the winning force that did well in the battle may have their
quality increased by 1 level, although most troops will never become Crack
and very few will ever become Elite.  Some armies in the losing force will
probably have their quality level decreased by 1 level, although a defeated
force that does not retreat can either improve or decrease in quality.  The
chance of rising or falling in quality decreases as armies gain in quality.
  A unit has less than the normal chance to improve in quality if it is
inadequately led.  If it fought as a Green or Depleted unit because of
insufficient Druidic ability, it has 60% and 20% (respectively) of the normal
chance to improve.

  Factors in a decision whether to give up the fight for the province, or
stay to defend, are as follows:

  -The province is the capital of the losing Hero or King;
  -The existence of an open path of retreat;
  -The wealth of the province;
  -The attacker's ability to force another battle in the ensuing phase;
  -Attackers tend to retreat more readily than defenders.

[7.6]  Contested Provinces
  If an attacker invades a province but fails to destroy the defenders or
make them retreat, the province still belongs to the defender, and is called
a "contested" province.  If the attackers still have at least 1 movement
point for each army, they will be used to force another battle in the next
phase.  If not, both armies will encamp and wait for spring of the next
gameturn.
  If you start a gameturn in a contested province and don't move out, your
armies will use up a movement point to fight a battle at the end of phase 1.
The defending Kingdom can't force a battle in a contested province even if
all its armies can move, nor is a battle caused by reinforcements sent to the
defenders.  If the province is conquered, the attacker uses another movement
point.
  The leader who invaded the contested province will execute his orders in
the next phase, except that it's illegal to move from a contested province to
an adjacent enemy province.  You can, however, move from a province owned by a
neutral player-King to an enemy province.
  Let's take the example of an all-infantry army led by a Hero with March
skill of 2.  It moves into a province (using 1 movement point) and wins the
first battle, destroying half of the defending armies in the pursuit.  But
the defenders decide they still have a chance.  They stay, and in the next
phase, the attackers use up a movement point to force another battle.  They
wipe out the defenders, use up another movement point to occupy the province,
and are left with 0 movement points.  They can move no further.
  If your Move into a province uses up your last movement point, one battle
is still fought that phase.

[7.7]  Conquest
  Conquering an enemy province slows an army down, counting as 1 province
entered for purposes of movement.  For example, let's say an army with a
speed of 3 enters an enemy province.  That army has used up 2/3 of its
movement.  It can enter one more province that turn, even if it is an enemy
province, because the -1 movement deduction is applied after the move is made
(an army may wind up with negative movement points only as a result of this
rule).  A move into a sea province uses up an extra movement point only if
there is a battle in the province.
  If you conquer a Hero's province, he will probably be more expensive to
hire or even non-hireable.  Only if the Hero is fairly compatible with your
King, will he be likely to forget his defeat and offer his services at a
low cost.

[7.8]  Multiple Contingents
  If two characters who are controlled by the same King (or, two characters
employed by different Kings who are allied with each other) attack the same
province in the same action phase, they may fight together in the same
battle.  If they moved from the same province in making the attack, the
chances of uniting for the battle are very good, but if they attacked the
province from opposite directions they probably will fight the defenders in
separate battles.


[8.0]  DIPLOMACY

  There are three possible relations between Kings:  Allied, Neutral or
Enemy.  All relations between Kings are Neutral on turn 1.  All provinces not
controlled by players are Enemies.  At the end of any gameturn, you may
"Treat" or "Break Treaty" with other players.

[8.1]  Relations
  When two nations are Enemies, they may attack each other freely.  If two
Kings have Neutral relations, their armies do not attack when ordered to move
into the other King's province; instead, they remain where they are (this
rule is especially useful when two countries plan to take the same non-player
province in a turn).  When two Kings are Allied, their forces and their
Heroes' forces won't attack each other when in the same province and will try
to add their strengths when in combat against a non-allied army.  A province
conquered by an Allied force belongs to the King with the larger army after
the battle.
  Some interesting cases arise when King X is allied to Kings Y and Z, who are
Enemies.  For example, either ally can march through the territory of King X
to attack the other ally.  Also, When King X leads forces present at the end
of a phase in a province owned by King Y which has been invaded by King Z, his
forces fight with King Y.  Or, if Kings X and Z have Neutral relations, King X
will fight with King Y.  In none of these cases can King X ever assist in an
attack.


[8.2]  Treating
  A "Treat" order raises Enemy relations to Neutral, or Neutral relations to
Allied, but only if both Kings "Treat" with each other on the same turn.  The
treaty lasts until broken.
  When a Druidic kingdom Treats with another kingdom with which it has Neutral
relations, the diplomats of the other kingdom will be swayed by the Druidic
art of persuasion and doctrine of harmony.  A treaty will be signed even
without a reciprocal Treat order by the other King, unless the other King
issues a Break Treaty order on the same gameturn.
  Druidics also ally more quickly.  IF both a Druidic king and another king
ally with each other, they become Allies before the turn begins, even if they
were former enemies.

[8.3]  Breaking Treaties
  A "Break Treaty" order reduces the level of alliance one step (this gives
an Ally a turn to reposition forces before war begins).  When two Allies
become Neutral and one player has some armies in the territory of the other,
there is no combat.  The armies may move to an adjacent Allied or Enemy
province, otherwise they have little choice but to remain stranded where they
are.  If relations then become Enemy, there will be a battle unless one King
moves his forces out of the province.  If two Allies "Break Treaty" with each
other on the same turn, they become Enemies.
  An Evil or Undead King breaks a treaty at the beginning of a turn, not the
end. Consequently, he may break a treaty with a Kingdom he has neutral
relations with, and immediately invade it.

[8.4]  Scientific Treaties
  To exchange Sage discoveries, players need to have become Allies on a
previous gameturn.  From then on, a mutual "Treat" order is interpreted as a
scientific exchange.  The only requirement is that at the end of the turn, the
2 Kingdoms are adjacent, or else a character from one Kingdom must be inside
the other Kingdom.  The two nations will exchange 1 secret for each mutual
Treat order.  Generally speaking, the secrets exchanged are the most military-
oriented ones.  The exchange takes place after finances are computed.  The
discoveries listed in your turn report will be shown in the order of their
priority for scientific exchanges.  If only one of the Kingdoms has a secret
unknown to the other, one secret will still be given away.


[9.0]  FINANCES

  Each King starts with a treasury of 10 gold.  This money can be used to
hire armies or Heroes.  At the end of a gameturn, revenue is collected, then
armies and Heroes are maintained.

[9.1]  Revenue
  Gold is earned in two ways: taxation and adventure.  Each province has a
taxation value.  If a King controls a province at the end of the turn, the
taxes are added to his treasury.  A King may also gain gold by thiever or
by defeating a monster in its lair and taking its treasure.

[9.2]  Expenses
  Heroes and armies are paid when they are hired and at the end of each
gameturn.  Heroes get paid first, then armies.  An unpaid army may be reduced
in quality and may desert.  If a Hero goes unpaid in a turn, there is a
possibility of desertion, but some Heroes are so loyal that they will never
willingly desert their liege lord.
  A King may also lose gold in adventure.  An unfriendly character may steal
from the King, or a monster may venture from its lair and devastate a
province, thus reducing taxes for that gameturn.  Monsters tend to grow
bolder and devastate the province more often unless they are effectively
attacked.


[10.0]  VICTORY

[10.1]  Imperial Offices
  There are a total of 8 Imperial Offices, each of which will be awarded at
the end of the game to the character who has piled up the most Merit Points
for the office.  Ties are broken first by amount of gold in the treasury, then
by size of tax base.  Each office comes with a percentage prize share.  The
standing of the player in the game is decided by the prize share of the
Imperial Offices he controls.  A prize fund is maintained equal to 10% of the
turn fees paid by the players.  When the game ends, a player gets a
percentage of the prizes awarded proportional to the total prize shares of
his Offices.  For more details, see the Imperial Office Table.
  During the game, each player is informed of his standing in the race for
each office, stated as a percentage of points accumulated relative to the
leading competitor for that office.  When you gain an Office, a special
ability may be given to you for as long as you hold it.  There are also
additional "Titles" that may be gained, with special abilities, but they do
not give you any percentage prize share at the end of the game.  A Hero may
hold office.  A character may hold more than one office. If a character dies
(King or Hero), he loses 25% of his accumulated Office points.

[10.2]  The World Emperor
  The eventual World Emperor is the player who has the largest tax base
support at the end of the game. The following is a description of the sequence
needed to end the game.

  At the end of any turn, when Kings owning more than 55% of the total World tax
base call for an election,  a "Vote for World Emperor" is held on the
following turn. In the next turn each King can vote for their choice of the
World Emperor.  The eventual World Emperor does not necessarily have to be
the player who has the largest tax base at the end of the game.   Each King
who votes gets votes equal to his tax base at the end of the turn.  If one
King receives more than 50% of the votes, he/she becomes the Emperor, and
receives the 20 Prize percentage points for the Imperial Office of World
Emperor.  If one player does not receive a number of votes that exceeds half
the total world tax base, the game continues, and another election may be
called at any time.  Because a vote for World Emperor occurs after an election
is called, there can never be a vote held two turns in a row.

  Each King retains possession of his lands, but the elected World Emperor has
overall dominion over the entire world.  The alignment of the newly elected
Emperor determines the points for each player on their comparative alignment
to the new Emperor.  The Alignment Table gives a percentage reduction for each
step you are removed from the Emperor's alignment.  For example a Pagan King
would lose 45% of his points if a Good King was elected World Emperor.  The
greatest "Adventurer-King" in the world and the winner of the game (not
necessarily the World Emperor) is the player with the greatest adjusted prize
share.

 [10.3]  Valhalla
  If a character does exceptionally well in a game, he may be admitted into
Valhalla.  In Norse legends, Valhalla is the Great Hall of Odin, which only
the bravest of the brave may enter.  To enter Valhalla, a character must
either be the winning King, or contribute 20 victory points toward the
standings of his Kingdom, after points are reduced for alignment differences.
Only one character may enter Valhalla from any one Kingdom.
  When you enter Valhalla, you will join such legendary figures as King
Arthur.  These legendary figures, and characters who have won their way into
Valhalla by their performance in a previous game, often visit the game-worlds
of Adventurer-Kings!  Each alignment from Good to Evil will be visited once
in each five-turn period (if there are more than one players to be visited in
an alignment, the choice will be made randomly.)  They appear by the side of
your King.  When you get a visitor from Valhalla, you may plot his Actions for
that turn.  In turns 1-2, your visitor will perform 1 Action; this increases
by 1 Action every 2 turns.
  Undead and Divine Kings may enter Valhalla for Good or Evil, but do not
receive visits from Valhalla.
  If you go to Valhalla, you can take your magic items with you.  You may also
write up a description of what your character will say when he visits a King,
including the character's history, friendly advice, bragging, etc.

[10.4]  Time Limit
  There will be a time limit for all AK games (the people of the world
gradually put more pressure on the kings to resolve the political
situation).  On turn 25, you need 50% of the world's taxbase to become world
emperor, call an election, or win a vote; this decreases by 5% each turn,
so that by turn 30 you need only 25% of the world's taxbase.  When your
turnsheet says that the moves are due May 1 or later, you'll know this rule
is in effect for your game.
  In Super-AK games, if an alignment controls the needed percentage of votes,
a vote for World Emperor is automatically called for.


[11.0]  BEGINNING PLAY

  You, the player, can choose your King's race, alignment, temper and four
ability levels.  Race and alignment can generally be chosen according to
personal tastes, because the powers of the different races and alignments are
fairly well balanced.
  Ability levels may require some more thought. It really does help to have
some good martial abilities to ensure that you can expand your kingdom
quickly.
  The most obvious way to do this is to choose Tactical ability.  Melee, Archery
and magical abilities can help you win duels with the opposing commander at a
battle, which helps your chances of victory. These abilities also help in
Searching out features. A pet strategy of some players is to pick two March
skill levels, which enables infantry to attack a second province after they
have conquered one province.
  Another oft-ignored strategy is to take some Naval ability, which will help
you master the vast oceans of the world.  Druidic ability will help you lead
armies of races other than your own. About half the world is Human, so if you
pick a race other than Human, you should probably take one Druidic level.
For Human Kings, the Druid skill is still very useful, but can be considered
optional.
  Don't forget that there are 7 Imperial Offices other than World Emperor.  A
good idea is to concentrate on one other office other than World Emperor, and
to do whatever you can for the other six offices until it's clear that you've
slipped too far behind.
  Your temper should correspond to the abilities you've selected.  Cautious and
Cowardly are good neck-saving tempers for Kings with little melee combat
ability.  Brave and Berserk are good for powerful warriors.  But remember,
your starting heroes will probably be of similar temper.
  Included with these rules is a set-up request form. Please fill out this
sheet and send it to us. We will try to set you up in a game as soon as
we can.  If there is a delay we will contact you with an estimate of when the
next game of the length and type you requested will begin.  When the game
begins, we will send you a map and a set-up report which completely describes
your Kingdom, as well as a general description of surrounding areas.
  One way to play the game is through the mail.  If you own a computer,
then moves can be sent back and forth between you and the
Game Master with a disk mailer.  If you plan to play by disk, mail it in
with your set-up request. If you play by disk in this manner we can offer you
"Saga", a program which displays your turn results along with a colourful map
of the world you've explored, and makes filling out your turn sheet a piece of
cake.  If you've ever been frustrated by PBM games that choke on your orders
because of some obscure rules violation or a typo, you'll love this program,
because it screens out just these kinds of errors.
  Players who have a modem and want to use Electronic Mail to play "Adventurer
Kings" can play by CompuServe, or any service connected to the InterNet.
  You can select the moves-turnaround time you wish to play with.  The most
common turnaround time is 15 days.  You can choose a game which allows
diplomacy or one which doesn't.  Most players prefer games which allow
diplomacy between players.  In these games,  players can call and write each
other outside the game.  In non-diplomacy games, you can only write to another
player by sending a message to the Game Master to forward to the other player.
You can know only the name of the King controlled by the player, not the
player himself.  Non-diplomacy games save on your phone bill and eliminate
a lot of diplomatic footwork for those who would just as soon do without it.
  If you lose your home province and you have less than 6 armies, you can
continue to play for half price.


[11.1]  BEGINNER'S TIPS

  When engaging in a campaign of conquest, remember that one additional move-
point is used up when conquering an enemy province (rule  [6.2]). An army with
a speed of 2 will thus be able to conquer only one province in a game-turn; a
cavalry force, or an army led by a leader with a March ability of 2 or higher,
can try to conquer two provinces.  Navies must use up this movement point only
when they fight a battle in the province. If you attack on phase 4 or earlier,
your armies can fight more than 1 battle.
  A "beginner's tip" showing an example combat situation may do some good.
Let's say you start with 2 Human Legion and 1 Heavy Cavalry, and you're
thinking of attacking a Prosperous Forest province defended by Elven bowmen.
  Usually, you should recruit 4 units with your 10 gold, giving you about 4
Average Legion and 3 Average HC.  Now let's work out what your odds are if you
attack that Elven province, using the "Summary of factors affecting army
strength" on the Army Type Table.
  First, the opposition.  Since it's a prosperous (average) province, it will
probably have 2 defending Elven Bow units.  Each Bow unit has a basic strength
of 2, +1 because Forest is home terrain for Elves, +1 because Forest is home
terrain for Bow, and +1 more because Elves get +1 as Bowmen.  Total modified
strength per unit is thus 5.  Multiply this by 2 because all units start as
Average quality, giving 10 defense points.  Then multiply by 1.25 for defense,
1.25 for exploration, and you wind up with 16 points per unit, for a total
strength of 32 (this won't seem so complicated, once you get used to it.)
  Now let's say you invade with all your units.  Your first line in the battle
will be 2 Human Legions, total strength = 16 (Legion strength = 3; +1 for
Humans fighting as Legion; x 2 for Average quality; x 2 units.)  Your second
line of 2 Legions will have the same strength; their strength will not be
penalized 50% because they will be able to outflank the enemy (as explained in
section 7.6 of the addendum sheet.)
  The next 2 cavalry will be penalized 50% however.  Their total strength is
4 (HC basic strength = 4; x2 for Average quality; halved for adverse terrain
of Forest; x 50% penalty; x 2 units.)  The last cavalry unit will contribute
1 strength.
  So the total attacking strength will be (16 +16 +4 + 1) = 37, against 32
defense.  That's about 1.15 to 1 odds, which gives you about a 55%-60% chance
of victory.  That's not so good!  You want to look for odds closer to 2:1.
Check your other skills to see if you can improve your odds: some Tactical
skill will make the odds more acceptable, or some spell(s) may help.  If your
leader is designed for personal combat, or you have the Neutral Order of
Duellists ability, consider challenging the defending hero to a duel.  You
might also consider sending someone ahead to explore the province, especially
Plains.  Lastly, consider taking on a weaker province first.  That may gain
you some quick tax points to build up your army, and your units may gain
crucial quality levels while beating up on weaker units.
  At the start of the game, aim towards taking as many provinces as possible
on each and every turn. You should try for at least two provinces per turn,
three or four if you can manage it. You should recruit some armies on the very
first turn to help you accomplish this.  If you have a skill of less than 2 in
March ability, you can divide your forces into a cavalry army and an infantry
army, using the infantry army to conquer one province while the cavalry horde
tries to conquer two successive provinces.
  A King who has a fleet should also try to take 1-3 sea provinces.  You can
order a fleet to move into an unknown area, which is sometimes a good gambit.
  When considering an invasion, weigh all the conditions which argue for and
against success in battle.  All of the modifiers to army strength are given
with the Army Table.  Also, remember that how many armies you have doesn't
matter much in mountainous terrain because it may be that the battle will be
fought in a narrow pass, allowing a frontage of only one or two armies.
  After you conquer a province controlled by a neutral hero, consider
hiring the hero in the same game-turn. It may be wise to wait a phase before
hiring him, in case you need two battles to conquer the province.
  When searching features, remember that using the Talk tactic can lead to
considerable success.  Some "monsters" may be willing to let you have their
treasure for a simple favour,  and even a vicious monster will hesitate to
attack a Hero, so your chances of survival are quite good.  Still, don't make
risky attacks against monsters on early game-turns, and try to have a good
supply of spare characters.  When you make up an encounter plan which starts
with a negotiation tactic, place a Flee and/or combat tactic after it, in case
the negotiations fail.
  Try for every Imperial Office.  At the start of the game, think about which
character will be your primary candidate for each office, and which offices
will receive first priority.  Towards the middle or end of the game, try to
find out which characters are ahead of you for which offices and neutralise
those characters.  The winner of the game will probably be the King who
explores the most avenues for advancement and takes advantage of every
opportunity. Luck plays a large part in the game, so players will have to take
many calculated risks to make the law of averages work for them.
  If you are invaded and lose your Kingdom, it's not necessarily the end.  You
can fire your more expensive heroes, then travel around the world looking for
mercenaries and battlefields where you can raise skeletal armies.  Some
features have magic items which will help you, or incredible amounts of gold
to finance a comeback.  Some Kings may help you in exchange for some training
or a magic item, while others may have gaps in their defences which you can
exploit by raising mercenaries and skeletal armies in the middle of their
Kingdom!


[11.2]  EXAMPLES OF MOVES FOR ADVENTURER-KINGS
  
  Here's an  example of  a "moves  sheet" which  you can  use to give
  orders to one of your characters:

              Moves:
Character ID  Phase 1     Phase 2     Phase 3     Phase 4     Phase 5

1_________   (__)_______ (__)_______ (__)_______ (__)_______ (__)______
(Kyron______)(__________)(__________)(__________)(__________)(_________)
 Enctr Plans: __________  __________  __________  __________  _________
 Special Plan:__________
  
     The first  line is  used to  fill in  the  order,  for  example,
  "(HI)re_88___". The second line is for anything else that is needed
  to explain  the order (for example, how much are you going to offer
  character 88  to join  you?)  The third line is for more notes, and
  for the plans for Encounter and Search actions.
  
  The "Special  Plan" line is for encounters with random monsters and
  duels at  battles, and  will be in effect for the entire turn. Here
  are examples of how to write moves for each order:

   [3.1]       [3.2]       [3.3]       [3.4]       [3.5]       [3.6]
   Move        Explore     Search      Recruit     Hire        Disband

(MO) NE 304 (EX) 304    (SE) 33     (RE) for 22 (HI) 88     (DI) 33,44,.
( Burgundy )( Burgundy )( Dungeon  )(LE,LE,HC  )( Lancelot )( 112,113  )
                          FI,ME                  for 3 gold            .

  [3.7]       [3.8]       [3.9]       [3.10]      [3.11]      [3.12]
  Fire        Leave       Pick Up     Cast Spell  Use Item    Encounter

(FI) 88     (LE) 8,9 to (PI) 33,34  (CA)-BL     (US) 19     (EN) 88    .
( Lancelot )( Garrison )(          )(on 304    )(Magic Wand)( Lancelot )
                                                  on 88       TA,FL    .

  [3.13]      [3.14]      [3.15]      [3.16]      [3.17]      [3.18]
  Practice    Spy         Defend      Pursue      Trail       Give

(PR) TA     (SP) 304    (DE) 304    (PU) 88     (TR) 88     (GI) 19    .
(          )( Burgundy )( Burgundy )(Lancelot  )( Lancelot )( to 88    )
                                      CA-FI,ME                         .


  You don't really have to include the names of provinces and characters in
orders, since the computer operator will just type in the number.  But it may
be a useful note for you and sometimes serves as a double-check.

  If you run out of space when writing an order, put an asterisk (*) and
continue the order on the bottom of the moves sheet.

[11.3]  EXAMPLES OF COMBAT PLANS

  FI,FL (Meaning: Fire arrows, and if this doesn't win it, attempt to flee.)

  ST,CA-FI,ME,SC   (Attempt to steal from the monster.  Then cast a fireball
spell and charge into melee. If you win, Scout the feature.)

  CA-IN,ST,FL,ME   (Cast Invisibility and attempt to Steal; if caught, attempt
flight, and Melee if necessary. Remember: only CA-IN can come before Steal.)

  CA-PS,CA-FI,ME,ME,FL,CA-CH,ME   (Cast Psychic Blast and Fireball. Then melee
for two rounds,  and if it still lives, attempt flight.  If this fails,
attempt to charm the opponent, and if that fails then resume melee. Note that
this plan assumes skills of 1 in Elemental Magic and 2 in Psychic Magic.

  SA-"Greetings, Supreme One!",TA,SC,ME  (Talk to the monster and see if it
wants to deal. If possible, Scout the feature to see if something special can
be found.  If the monster attacks, proceed to Melee.)


(assumes that  Magic Item #55 is a sword, while #31 casts a Fireball spell):

  US-31,US-31,US-31,US-31,US-31,US-31,US-31,US-31,US-31,US-31,US-31,US-55,ME
(Use the  Wand of  Fire until it runs out of charges, then switch to the sword
and Melee.)

[11.4]  WHEN WRITING MOVES, PLEASE...

  -Don't Leave,  Disband or Pick Up a unit you hired in the same game-turn.
When using these orders, at all times you MUST give army numbers and not army
types. The only exception is the "PickUp/Disband/Leave All" command.

  -When using the "Move" order to attack a province, don't write your duelling
plans under the "Move" order. Write them in  the "Special Plan" line, which
covers the entire game-turn.

  -In an encounter plan, some tactics are not allowed together (see sections
[5.4] and [5.5].)  Example:  TA-lk, FU-lfil and ST-eal are not allowed in a
Special Encounter Plan.  There is no call for them in duels at battles, and
if a wandering monster wants to talk with you, he will do so.

  -When you Hire, Charm or Resurrect a new Hero, you can't give him orders the
same phase you hired them. Give him orders starting with the next phase.

  -In many orders, including as Spy and Explore, the character must be located
in the province that is the objective of the order.

  -Please remember to type the direction when giving a Move order (ie. "(MO)ve
NE" or "(MO)ve NE 1801"). You should include the  name or number of at least
the last province you move to, so we can check our moves entry.  The six
directions are  NE, E,  SE, SW,  W and  NW.


[12.0]  ADVENTURER KINGS VARIANTS

[12.1]  SUPER-AK VARIANT

Here are the basic rule changes for the 20-32 player "Super-AK" variant.
(These changes will not apply to the normal game verson.)

1.  There will be about 28 players per game, 4 from each alignment.  Players
will need to pick an alternate alignment if the one they want is already
filled.  (You can even send two alternate setup requests, depending on what
alignment you get.)  The map will be 30x15 provinces, up from the current
18x9.  There will be about 1000 armies, 250 leaders and 250 features.  The
features will sometimes attract another monster after its current occupant
has been slain.

2.  In addition to the Imperial Offices, there are about 35 new "Royal Titles"
such as "Lord of the Were-Beasts" and "Ranger of the Plains".  Rather than
reveal all of the specific titles, here are the major groupings:

- 7  Titles for the leader of each alignment
- 11 Titles for being the primary leader of each racial type
- 6  Titles for protecting homelands of each terrain type
- About 5 Titles related to military achievements
- About 5 Titles related to personal combat
- About 4 miscellaneous Titles

Each Title would be worth 1-5 victory points.  the way each Title is gained is
up to you to discover.  When elections are held, or in determining whether the
55% mark has been reached, you get added votes for Offices, Titles and Magic
Items.  Each victory point counts the same as five tax points towards reaching
the needed percentage (your votes are not lessened if there's any difference
in alignment between you and the leader of the race for World Emperor.)
  When you gain an Office or Title, a special ability may be given to you as
long as you hold it.
  Each Title has 1-3 ways to aquire points for it.  There's a certain minimum
number of points to qualify you for each Title.
  When you reach that minimum, and your character has at least half the points
of the leader for that Title, the Title will be mentioned in your Imperial
Office Report.  Each Office and Title now comes with a certain power which is
given to you when you are number one in the race for it.

3.  When an alignment has conquered 55% of the world, a vote is automatically
held the next turn.  They can then elect one of their own if they want to, or
continue to fight it out.

4.  For Scientific Treating (exchanging Sage Discoveries), you have a lesser
chance of exchanging with a King of a different alignment (subtract 40% per
step of alignment difference.)

5.  At the start of the game, players will be told which Kings are also of
their alignment, but not where they are or who plays the position.  You can
get a team together to play the same alignment if you want, but your positions
may be a little more scattered to make up for the advantage of knowing each
other before the game begins.  In any case, no two Kings of the same alignment
will start adjacent to each other, and the alignments will be balanced on each
continental land mass.

6.  Maps can be exchanged between members of the same alignment, if the two
Kingdoms have encountered each other (that is, if their Kingdoms become
adjacent, or if a character does a peaceful 'ENcounter" with a character of
the other Kingdom.

[12.2]  "EUROPEAN" VARIANT

The "European" variant is a normal AK game, based on a map of Europe in the
middle Ages.  A player starts with the knowledge of the provinces surrounding
his Kingdom, up to 3 provinces distant from his home province.  Each player
know the address and phone number of adjacent players at the start of the
game.

1.  To reflect the improvement in Light Cavalry over the Greco-Roman era
light cavalry (which serves as the model for light cavalry in Adventurer
Kings), all Light Cavalry are increased in strength to 3, and cost of 3.

2.  Each Kingdom will get a special bonus to one or more abilities, reflecting
their historical strength.
  The following positions will be avilable (if two players want the same
position, the decision will be by random die-roll, so you should list the
positions you want in order of priority):

Caliphate of Cordoba (Spain).
Normandy (France)
England
Germany
Holy Roman Empire (Papal States)
Kievan Russia
Kingdom of Magyars (Hungary)
Byzantine Empire
Khanate of the Golden Horde (Mongols)
The Northern Seljuk Turks (Ukriane)
Caliphate of Baghdad


[12.3]  "EARTH" VARIANT
   This is a new Super-AK variant, played on a map of Earth in the
prehistoric Ice Age, where 20 would-be emperors are drawn from different
historical periods to square off against each other.  You rule such an
Empire in its initial stages, about to embark on a campaign to unify
your region, then conquer the known world!
  Special Rules:

1.  The Light Cavalry for the Earth game is modeled on the bow-armed cavalry
of the Turks and Mongols in the 11th to 14th centuries.  They were better
armed and trained than the Greco-Roman LC that is used in regular games of
AK.  Their strength and pay is 3, not 2, and they have no adverse terrain.

2.  There are some sea areas with islands in them.  Islands are shown on
the map as land hexes with a blue fringe on each side.  These provinces are
considered to have two terrain types (one Sea, while the other type is
some other terrain.)  If an army is fighting in an island, it will normally
fight at its Sea strength, but if that is adverse terrain, it will fight at
its land strength.  Supreme commanders use their naval ability, not tactical
ability, in islands.
  Earthquakes are legal on islands.  For all other purposes, islands are just
like sea.  Movement through is by sea, and if there is no battle when you
conquer an island, no extra movement points are expended.

3.  When your map shows a blue zone between two non-island land hexes, there
is sea between them, so that you can move naval forces between them, but
not land forces, unless by transport.  If the blue zone continues along two
hexsides, you can sail from that land hex to the next land hex along the
blue zone, but that's the only way you could move between land hexes.
Only version 22 of IBM Saga will show the blue zones, so if you don't
have it and can't get it, you need to receive printed maps by mail.
A Part Sea spell on either side of a blue zone will enable crossing it
overland, and prohibit entry from another land hex by sea units.
  On the map printouts, these blue zones along hexsides may sometimes
appear to be partly blue, and partly connected by land.  In this case,
you should still assume that the entire hexside is impassable to land units.

4.  There are places on the map where you can move ships from one ocean, through
an isthmus such as Panama, and then to the other ocean.  Canals are always
assumed to exist to allow this to happen, or else you can just look at your
Fleets as being Viking longships, which can be portaged overland somewhat.

5.  The map wraps around on left and right edges, but is prohibited "Ice Cap"
terrain at the top and bottom.

6.  Each country gets a bonus in one or more historical abilities.  The bonus
applies to both ability and aptitude, with a maximum starting skill of 4
(for you and your starting heroes only.)  You also may have some starting
Sage Discoveries and perhaps other benefits, although the Elder Gods may
not give you each and every Discovery that your Empire historically possessed.

7.  Each player starts with the phone number and address of nearby kings.

8.  An element of mystery is added by randomly placing the "lost continent
of Atlantis" in one of the ocean areas.  One, maybe two players starts there,
with little or no prior contact with the outside world.

9.  Some empires start 2 provinces away from each other, by design.

10. You may change one of your king's starting abilities, after looking at the
abilities you start with.  If you realize your race is wrong for the terrain
around you, that can be changed also.  If the GM had to change your alignment
to balance the game, you may change one additional ability.

11. Give 3 positions that you want to play, in order of preference.
If you ask for a first preference for your starting position and don't
get it, you may change one of your king's starting abilities.  Also, please
state one alternate alignment in case the one you pick is too packed  In
each area (Asia, Europe-Africa, the Americas), I will try to balance the
alignments fairly evenly.

  Persia                Rome                    the Norse Explorers
  India                 the Rus Vikings         the Hudson Bay Company
  China                                         the Indians
  the Huns              Carthage                the Eskimos
  the Mongols           Egypt                   
  the Manchus/Siberia   the Zulus               the Amazon Queen
                                                the Aztecs
  Polynesia/Australia   Atlantis                the Incas
  Japanese Shogunate
  Dutch East India Co.


[12.4]  OTHER VARIANTS

Other variants are offered irregularly:  Limited-Diplomacy (Anonymous) games,
All-Beginner games, Bash the GM games, King of King games, All Electronic-Mail
games, Team games, 3-week games.


Design Credits:

Game Design and Development:  David Snell
Playtesting:  Rich Eisenman, David Hunt, Bill Livesay, Bill Paxton, and others
Artwork:      Danny Willis


[6.3]  ARMY TYPE TABLE

                Army         Home      Adverse
Army Type       Str Spd Pay  Terrain   Terrain            Nemesis
Garrison     GA 3/1  1   1   None      None               None
Bowmen       BO  2   2   2   For,Jung  None               None
Axemen       AX  2   2   2   For,Mtns  None               None
Phalanx      PH  3   2   2   Plains    For,Jung,Sea       Legion
Legion       LE  3   2   2   None      Sea                Hvy Cavalry
Lt Cavalry   LC  2   4   2   Plns,Des  None               Chariot,Beasts
Hvy Cavalry  HC  4   3   3   Plains    For,Jung,Mtns,Sea  Chariot,Beasts
Chariots     CH  3   3   3   Plns,Des  For,Jung,Mtns,Sea  Beasts
Elephants    EL  V   2   3   Jung      For,Mtns,Sea       None
Camel Corps  CC  2   3   3   Desert    For,Jung,Sea       None
Warg Riders  WR  3   3   3   Forest    Sea                Eagles
Dragon Wing  DR  6   5   4   None      None               Bowmen
Eagle Wing   EA  4   5   3   Mtns      For,Jung           Bowmen
Whales       WH  5   4   3   Sea       All other terrain  Mermen
Fleet        FL  3   2   3   Sea       All other terrain  None
Mermen       ME  2   3   2   Sea,Jung  Desert,Mtns        Bowmen
Ents         EN  6   1   3   For,Jung  Sea,Desert         Axemen,Dragons
Trolls       TR  5   2   3   Mtns      Sea                Axemen
Werebeasts   WE  3   3   3   For,Mtns  Sea                None


Spd: This speed is the number of Provinces an army can move per gameturn.
Speed also determines the chance of escape from a lost battle.

Str:  Garrison units have a strength of 3 when defending a province, but only
1 when attacking.  Basic strength can be modified by the army's race:

Elves: +1 when fighting as Bowmen, +1 in Forest.
Dwarves: +1 as Axemen, +1 in Mountains.
Orcs: +1 as Phalanx, +1 in Mountains.
Humans: +1 as Legion (no bonus for any terrain.)

If a unit fights in terrain which is listed as home terrain, it gets a +1
modifier to its basic strength.  A unit's strength is halved in adverse
terrain.

A unit's strength is 2/3 normal when fighting against its nemesis, a troop
type which the unit is especially vulnerable against.  A unit is a nemesis
to it's opponent if it's on the front line or it's an air unit flying against
a unit behind the front line. If more than one of your units are eligible to
be a nemesis due to overflight or outflanking, one of them is chosen at
random.


ARMY STRENGTH NOTES:

The actual strength of a unit is the strength multiplied by the quality level
(Depleted = 0, Green = 1, Average = 2, Veteran = 3, Crack = 4, Elite = 5).
There also exists the strength levels of Sub-Depleted, and Super-Elite.
Even though Depleted and Sub-Depleted have a strength multiplier of zero,
units still have a small intrinsic strength.  Super-Elite signifies a strength
multiplier of 6+ as a unit can have several additions to quality above Elite.

When a unit fights a battle in the starting home province of a player-King
who owns the unit, it's quality is increased by 1 level.

If a character commanding at a battle has tactical ability, his units are
increased in strength by 20% per level (see Tactical and Naval abilities.)

The strength of a defending army is multiplied by 1.25.  The side with the
better exploration of the contested province will also have up to a 25%
advantage, if they have explored 100% of the province and the other side has
not explored it.

To explain the events in battle reports, they are basically randomly
determined as the turn is processed.  Each random event can as much as double
the strength of the affected force (but most only multiply it by a factor of
1.5 or less). The first random event affects the whole battle, while
succeeding events affect a column of units in a battle line.

An army fighting for a Divine kingdom has a 50% chance of becoming fanatical,
while an army fighting for a Good kingdom has a 40% chance of becoming
fanatical, thus fighting at the next higher quality level.  An army fighting
for an Evil kingdom has a 25% chance of becoming fanatical.  A Skeletal army
fighting under an Undead character has will always be fanatical.

Elephants are unpredictable in battle and can have a strength of anywhere
between 2 and 5.

"Beasts" are camels, elephants, werebeasts, wargs and dragons.  Horses are
frightened of these animals.

Special rules:
  Camels:  In a desert battle, one camel unit should be present (it sees
double duty as as a supply train.)  If not, all armies have their quality
reduced by 1 level.

  Werebeasts:  Werebeasts are a collection of outcast Werewolves, Werebears,
Were-rats, etc.  When Werebeasts defeat the unit opposing them, there is about
a 40% chance that the unit will gradually turn into a Werebeast itself.  The
change will take place after the gameturn is over.  Only the 4 humanoid races
can be "bitten" and become werebeasts.  Fleets are never affected by
Werebeasts.

  Trolls:  If they die in battle, they can regenerate:  their body parts just
crawl back together, although they are reduced 1 step in quality.  But since
they're perturbed at their commander for getting them killed, they become
mercenaries.

Whales: When fighting in any terrain other than Sea, they have zero strength.
However, if they lose a battle in such terrain, they can retreat into a Sea
hex automatically without fear of being destroyed.


Summary of factors affecting army strength:

Strength of army type, modified by terrain:
  +1 if home terrain for race
  +1 if home terrain for army type
  Halve for adverse terrain
  Illusory Terrain spell: effects of illusory and real terrain are averaged.
Multiply strength by modified unit quality:
  -1 if in desert without camels
  -? if led by leader with insufficient Druidic ability (see Druid Table)
  +1 if in home province
  +1 for fanatical units
  +1 for Oratory spell
  +? for magic items
Multiply result by special factors:
  Defense:           +25%
  Exploration:       +25% (maximum)
  Tactical Ability   +20% per level (or Naval ability in Sea provinces)
  Phantasmal Armies: +15% per level of caster
  Nemesis encounter: -33%
  Random Event:      +/-%
The special factors are multiplied, not added together.  (eg. If you have both
the Defense and Exploration bonuses, your strength is multiplied by
1.25 x 1.25 = 1.625.)


[1.6]  TERRAIN TABLE
                                 Length of    Random
Terrain  Average   Basic        battle line  Encounter
Type     Taxation  Exploration  (in #armies)  Chance
Plain     6           50%          5-10         10%
Desert    2           25%          5-10         15%
Jungle    4           10%           3-6         25%
Forest    5           15%           3-6         20%
Mountain  5           15%           1-3         15%
Sea       1           25%*         5-10          5%

*There is only a small chance of finding a feature in a Sea province.

The chance of encountering monsters applies to Move, Pursue, Trail, Explore
and Search actions.  It does not apply when a character Moves or Pursues with
an army, and is halved when the character is within the boundaries of the
Kingdom.




[3.19] EXPERIENCE TABLE

Action                           Chance to Improve Ability
Move (on land, with armies)      10% Forced March              
Move (by sea, with fleets)       10% Naval
Explore                          10% Explorer
Recruit or Hire                   5% Druid
Pick Up or Leave Army             5% Forced March
Pick Up or Leave Naval units      5% Naval
Cast Action Spell                10% in related Magical Ability.
Spy/Trail/Pursue                 10% Spy
Supreme Commander at battle      15% Tactical or Naval
Lead some units at battle        10% Tactical or Naval
Search/Encounter, Attempted
Tactic:
  TA-lk to opponent              10% Druid
  FI-re arrows                   10% Archery
  ME-lee                         10% Melee
  CA-st combat spell             10% in related Magical Ability
  ST-eal                         15% Thief


[2.3]  ALIGNMENT TABLE

           Reduction/
           Alignment    Magic       Special   Special
Alignment  Difference   Aptitude    Aptitude  Abilities         
Divine        20%       None        None      50% Fanaticism; +1 White Magic
                                              Resurrection to Good Alignment
                                              Pay heroes as if Divine=Good
Good          12%       White       Sage      40% Fanaticism
Druidic       15%       Psychic     Druid     Automatic Treat
Neutral       20%       Illusory    Spy       Order of Duelists
Pagan         15%       Elemental   Explorer  Order of Magicians
Evil          12%       Necromancy  Thief     25% Fanaticism; Automatic Break
Undead        20%       None        None      100% Skeletal Fanaticism
                                              Automatic Break Treaty
                                              Necromantic Charm Spell
                                              +1 Necromancy

Note:  At first glance, the Reduction/Alignment Difference column seems to
favor Good and Evil characters, but counteracting this is the fact that
Neutral characters are, on the average, closer to the other alignments and
can hire characters of any alignment.

Note 2:  Under "Magic Aptitude" and "Special Aptitude" are listed abilities
which characters of the given alignment are especially good at.  Their
starting aptitude is doubled for these abilities, up to level 5.


[2.4]  TEMPER TABLE

Temper    Special Effects    Flight from Combat            Refusal
Berserk   Rage,Intimidation  Never                          Never
Brave     Elan               When odds seem unfavorable     Never
                               and the risk of receiving
                               a death blow seems large
Cautious  Parrying           When the risk of receiving a   1-50%
          Fleeing              death blow seems significant
Cowardly  Begging for mercy  When death possible; may also    50-
          Bluffing             flee after any harmful blow   100%

   Rage:  The Berserker does not really notice a damaging blow, and this
psychological fortitude gives him 1-4 extra hit points.
   Intimidation:  Opponents are cowed and have less chance to hit in melee
(Brave -5%, Cautious -10%, Cowardly -15%.)
   Elan:  The man with Elan is bold in combat and never hesitates to instantly
take advantage of an opening in melee.  He gets a +10% chance to hit.
   Parrying: The Cautious man is expert at parrying, and his opponents have a
-10% chance to hit.
   Fleeing: 10% is added to the chance of success when attempting to Flee.
   Begging for mercy:  In addition to fleeing, a Coward may plead for mercy in
order to escape death.  Begging works best against Good characters and
characters of similar alignment.  On the average, it has a 50-50 chance of
working.
   Bluffing:  In battle duels, the Coward makes excuses 2/3 of the time
("warhorse is sick", etc.), thus avoiding the 25% demoralization.
The coward's "Bluff" ability is only used when the character actually
enters the duel (in other words, when an "FL" is not at the start of his
encounter plan.)  It is used only when the coward has "refused to enter
combat" according to the temper table.


Note:  A cowardly or cautious King will never refuse combat, although they may
well flee from combat after they take damage.


[4.33]  SPY TABLE

 Spy   Chance of        Margin of Error  Chance to Pursue
Level  Escaping Notice  of Spy Reports      or Trail
  0       0%               70%                 50%
  1      50%               55%                100%
  2      75%               40%                150%
  3      88%               28%                200%
  4      95%               15%                250%

Note:  The chance to Pursue or Trail is multiplied by two if the target leads
an army.  The chance to pursue is then divided by the distance (in number of
provinces) between the two characters.
  If the pursued character is of the same Kingdom as the pursuer, then the
chance of success is 100%.


[4.12]  MARCH TABLE
                                  Contingents Unify %
Ability   Extra moves for...     Distance to 2nd force:
 Level    Speed 1-2   Speed 3+       0     1     2
   0         0           0          80    50    20
   1         0           1          90    60    30
   2         1           1         100    70    40
   3         1           2         100    80    50
   4         2           2         100    90    60

Eagles and Dragons are not affected by March ability.

Contingent Unity shows the chance that two leaders invading a province will
join together for the battle, depending on whether they invade from the same
province, adjacent provinces or non-adjacent provinces.


[4.32]  DRUID TABLE

Druid   Gains ability to
Level   lead armies of...                     Can talk to...           
  1     Humans, Elves, Dwarves,               Avians, mammals
          Orcs, Mermen, Werebeasts
  2     Whales, Trolls                        Reptilians, sea creatures
  3     Eagles, Ents                          Insectoid monsters
  4     Dragons                               All monsters


[5.9] MONSTER TABLE

The following table is a partial listing of monsters that you may encounter:

             Average
             Hit      Melee           Missile
Monster      Points   Skill  Damage   Skill  Damage   Speed
Gryphon       25        2      1-6      0      -      Fast
Giant         25        1      1-7      1     1-7     Medium
Gargoyle      15        1      1-6      0      -      Medium
Demon         30        3      1-8      0      -      Fast
Troll         25        1      1-6      0      -      Medium
Spectre       20        1      1-6      0      -      Medium
Elasmosaurus  25        2      1-7      0      -      Fast

[10.1]  IMPERIAL OFFICE TABLE

   The standing of a player is decided by the Imperial Offices he controls.

Title                       Prize %   Merit Points Awarded
World Emperor                 20      Largest tax base at end of game

Esteemed High Chancellor      10      For each level in Explorer, Spy
of the Imperium (who art                and Sage abilities:            +1
the wisest man in the                 For each feature character
Imperium, and thus First                was first to discover:         +2
Advisor to the Emperor)               For each invention character
                                        was first to discover:         +2
                                      For each invention character
                                        obtained by espionage:         +1

Imperial Treasurer            10      Richest treasury at end of game
(who fondleth the
Emperor's gold)

Imperial Grand Marshal        10      For each land battle commanded:
(who commandeth the                   If won battle, then for each
Imperial Grand Army)                    unit in enemy force:           +1
                                      If lost battle, then for each
                                        unit in friendly force:        -1

Imperial Grand Admiral        10      For each sea battle commanded:
(who commandeth the                   If won battle, then for each
Imperial Grand Navy)                    unit in enemy force:           +1
                                      If lost battle, then for each
                                        unit in friendly force:        -1
                                      For each sea province with tax
                                        base of 2 or higher:           +1
                                      For each Naval skill level:      +1

Lord High Defender            10      For each hostile monster slain
of the Imperium                         Total hit points of monster
(who guardeth the Imperium             (Half points for neutralization
against dangerous monsters)             by negotiations)

High Priest Palatine          10      For each Resurrection or Bless
of the Empire                           spell successfully cast:       +1
(who communeth with the               For each level in Druid and
Great Spirit and                        White Magic abilities:         +2
administereth to the
souls of the people)

Arch-Mage Palatine            10      For each level in any magical
of the Empire                           ability (including White):     +1
(who weaveth great                    For each spell-casting magic
spells of magic for                     item possessed:                +1
the benefit of the
Empire)

   The 10 remaining Merit Points are awarded for the owners of the following
magic artifacts:  Excalibur, Bow of the Elven Kings, Axe of the Dwarven
Lords, Scimitar of Orc Mastery, Crown of Dragon Command, Feather of the Great
Eagle, Horn of Neptune, Holy Sword, Invisible Sword, Shadow Sword.  These points
are not modified by an alignment difference with the Emperor.

Note:  The points awarded for Admirals for control of rich sea provinces are
given to each character in the Kingdom.

Note 2:  No points are awarded for the Imperial Defender office for Fulfilling
an agreement.  Often a character's efforts to negotiate with or damage a
monster will persuade it to stop raiding your Kingdom, in which case half
points are awarded.

Note 3:  If you are tied with someone in the lead for an Office, the report will
show you as being ranked #2 if you're losing the tiebreaker (the first
tiebreaker for Offices is gold in treasury, next is size of tax base.)

