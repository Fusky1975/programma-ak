ADDENDA TO ADVENTURER-KINGS, Updated through August 24, 1995

  The following addenda is already included in the rules file,
but not in the printed rulebook.

[2.0]  New Skill-Level Limits
  The skill range is now 1-9.  Secret special spells and
capabilities are attainable at high levels of ability.  The new
capabilities gained are good, but not overly destructive, and can
vary from game to game.  Your turn report will inform you of any
new abilities you receive for achieving level 5+.
  When you pick abilities for a new king, the "double aptitude"
for a king's special alignment-abilities should read  "+2
aptitude, with a maximum of 5."
  Aptitude may increase if a character is due to rise in level,
but can't because of his low aptitude.  The chance of an aptitude
increase depends on the current skill level:

	0:	0%	5:	80%
	1:	10%	6:	60%
	2:	25%	7:	40%
	3:	50%	8:	20%
	4:	100%

   If anyone starting a new game wants to rename the heroes or starting
province that you've been given, that's fine, just make a note on your turn-1
moves sheet.
   It says in section 2.0 that aptitude affects the chance to increase in
skill when practicing.  It should also mention that aptitude affects the
chance to increase skill by experience.

[3.0]  Exceptions to Movement Initiative
  Let's say two characters are in the same hex and character-A
wants to move out, while character-B of the same kingdom wants to
do something for character-A, such as recruit armies for him. 
Character-A will wait for character-B in this situation, even if
he has higher move priority.  This rule will apply not only to
Recruiting, but also for Leaving and Picking Up armies, casting
favorable spells, Encounters, and Giving magic items.
  Also, when a character is coming into a province where a second character
has plans to do something for that character, if the second character has
higher initiative, he will wait for the first character before performing the
action.  The characters must be of the same kingdom.


[3.1]  Movement
   There has been some confusion about moving to non-adjacent provinces.  It
is never legal to do this, the rules only suggest that you can order a
character to move to a non-adjacent province if you think the move might be
made legal by a previous move which may be illegal.  Example:  you want to
conquer a province this turn, and you have two choices; one province is east
of you and the other lies west.
  A character will move towards a hex
number if he is not adjacent to it.
The movement order towards this non-adjacent provice will override
practice orders in subsequent phases.
The character will stop chasing the province if he can't find
a legal way to move closer to it in one phase.
   If there are two possible provinces that are both closer to the target
province, the following priorities are used:

  1) Owned or Allied-player hex;
  2) Enemy-player hex;
  3) Hero-owned hex;
  4) Neutral-player hex.


[3.2]  Exploring Battlefields
   Note: You can explore a province even if it's been 100% explored, with the
object of learning whether there are skeletal armies in the province.

[3.3]  Notes on Searching Features
   You can search a feature you haven't found yet if an allied player gives
you the location and feature number.
   Sometimes you get rumors of previously unheard-of features in your turn
reports.  At present, about half of these rumors are true, but the rest are
false in some respect:  the treasure may not be what's actually there, and/or
the feature may be in a different province (although it's usually at least
next to the rumored province.)
   It's worth mentioning that monsters can have abilities not described in
your turn report.  For example, swordsmen can have some minor magic.  You can
expect many intelligent or magical monsters to also have magic.
   You can Search a feature to scout it even after you've killed the monster.

[3.4]  Recruiting
   As you know, you may recruit an army that isn't the provincial army type
if you lead an army of that type.  You may alse recruit an army for another
leader (but not a garrison commander) if that leader leads an army of that
type.

  A character is allowed to recruit an army in a province belonging to his
ally.  The recruiter pays 1 gold to his ally for each recruited
army.  In this way, a vanquished king can hope to get on his feet
again.
  When you recruit units in an ally's territory, the computer always makes
sure that in any given phase, the owner of the territory has the right to
recruit there before you do.  Also, if you are recruiting in your former home
province which is now your ally's province, you can recruit 4 units, and they
will start as Average units.
  In order for you to Recruit in your ally's territory, he MUST issue a
"Treat" order with you (even though you may already be allied.)


[3.6]  Wandering Mercenaries
  If there are mercenary armies in a hex when a general passes
through it, they may follow that general instead of staying
behind.
  This counteracts the sneaky trick of disbanding armies when
faced with attack, then rehiring them when the opposing general
has passed through the hex.

[3.8]  Transferring units with the Leave command
  Let's say one of your characters and one of your armies are in the
same province, but the character does not lead that army.  That
character is still allowed to "Leave" the army to another
character, or the garrison commander.  Therefore, the "Leave
Armies" order becomes an all-purpose "Transfer Armies" command.
  When you use the "Leave" as this transfer command, if you "Leave All", it
will still only leave units that you directly lead, not units under other
commanders or the garrison command.

[3.9]  Picking Up Armies
   To clarify the rule on Picking Up armies previously recruited on the same
gameturn. You can't do this because you don't know the army number yet, and
the PickUp order doesn't allow you to pick up an army type such as "AX" (if
you want me to rationalize this, it's because the new troops wouldn't feel
comfortable switching leaders in their first year on the job; but really,
it's just because the computer program needs the numbers so it knows exactly
which troops you want Picked Up.)  What you can do is, "Pick Up All"; or
just use the Recruit order to recruit the armies for a designated character
number, after which the armies will automatically move with that character.
   Some players seem to think the "Pick Up" order can pick up units for a
a different character, but that's not so.

[3.14]  Spying Inventions
  The chance for discovering an invention by spying will be
limited to twice the chance of discovery by Sage practicing.
  Sage ability has something to do with spying out inventions.  If a spy
sees an invention, some sage ability will help him figure out how to get
it for your kingdom.  Sage level 1 will be more than enough to understand
all common inventions, but higher ability may be needed for inventions
of obscure design.

[3.15]  Defend
   A character's defend order is cancelled if he loses a battle, to prevent
further needless defeats.
   When giving a "Defend" order, list only one province.  The general will
defend any province that is adjacent to both the named province and the
province the leader is currently located in.
  A Defend order will include
defending your ally's territory, but only if you are Enemies with the
player who attacks your ally.

[3.16]
  "Characters On Patrol" (Police Academy 7?!):  This is like the Defend
order, except whenever the character hears of an intruding character, he
chases him down.
  Write this order by having the character "Pursue" his own character
number.  This means the character will track down any detected Enemy character
who enters a hex next to the character.  The evasive skills of Thieves and
Spies still operate normally.
  The "Patrol" order works differently in some important respects from the
Defend order, while in other respects they are quite similar:

  a) Only leaders not leading armies may Patrol, and they chase only
characters not leading armies.
  b) They patrol the current hex they are in and all adjacent hexes.
  c) They only intercept enemy characters.
  d) The Patrol stays active until the next Move, Trail or Pursue order; other
orders after the Patrol order are used if there is no current threat to be
intercepted by the Patrol.
  e) A Patrol may be unable to detect an enemy character if he is using his
Spy or Thief ability that gameturn.
  f) A Patrol will only intercept in owned or Allied territory.
  g) A Patrol will only attempt to pursue intruders whose best skill in
Archery, Melee or Magic is equal to or less than the Patrol's best such skill.
  h) If there are more than one such intruders, the most threatening one is
intercepted, by "highest skill" as defined in point (7).
  i) The "Spy Table" is still used: When intercepting a character in an
adjacent hex, if the Patrol has no Spy skill, there is a 50% chance that the
character will wander into a random hex rather than intercept the intruder.


[3.18]  Giving Gold
  You can give limited amounts of gold to other kings.  Only a
King may use this "Give Gold" order.  The King does it by using
the "Give" command together with the specified amount of gold,
giving it to another player's character (King or hero) located in
the same province.  A King may give out in a gameturn no more
than 10% of the size of his treasury at the start of the gameturn
(although he may always give out at least 10 gold if he has it in
his treasury.)  Be careful that you don't "Give" an amount of
gold that equals a magic item I.D. number carried by the King.
  Giving gold must be done with the Give ACTION, not with the
"Give" TACTIC used in encounters.

[4.2]  Magical Abilities
   To give an example of spell casting limits, if you have Level-3 Psychic,
you can cast 2 psychic spells in any encounter, whatever number of encounters
you have in a turn.  However, you couldn't cast the same spell twice.  You
can also cast any 2 Psychic "Action Spells", which could be the same spell,
in addition to the combat spells (those are two *separate* limits.)

[4.21.1]  Resurrection
   The resurrection of a King is now easier than is said by the rulebook.  You
can resurrect him as long as the Royal Heir has less than 7 skills total
(unmodified by magic items and sage discoveries.)  Also, if you do something
other than practice, the Royal Heir gets no chance to rise in level by
experience.
   If you use the option to assign abilities to your Royal Heir, you must
still assign 4 levels, thus losing the ability to resurrect the former King.

[4.21.3]  Blessing skeletons
  A Bless spell can remove buried skeletons permanently (the chance
is (White-skill x 10%) + 10%.)
  Armies "Paroled into population" in a battle are no longer be eligible to
become skeletons.

[4.23.1]  Illusory Terrain
   When you cast an "Illusory Terrain", you can select the terrain the
illusion will mimic.

[4.23.4]  Invisibility
  The Invisibility spell is enhanced by allowing a +30% chance to Flee an
encounter.

[4.24.1]  Kill Enemy
   If you cast a Kill Enemy spell as an action, the victim may instead "fall
into a deathly coma and become an imbecilic shadow of his former self" with
no skill levels and no chance of rising in skill.  In this case, a
resurrection spell can restore the skills.

[4.25.1]  Skeletal Armies
  The maximum number of armies in the game is now 350, up from 250.
  When a skeletal army dies (but not a non-skeletal army), it is
reduced in quality by one level.

[4.25.3]  Plague Survival
  If a unit survives a plague, it's immunized from dying in
future plagues (it may instead drop a level in quality.)

[5.0]  Tactical Initiative
  Two exceptions to the combat initiative rule should be
mentioned:  at spell range, spell attacks come before closing to
archery range, and at melee range, melee attacks always go first.

[5.5]  Steal Tactic Explanation
  The base chance given in the rules (15% +15%/level) is modified
in some situations.  If the thief is going after a king or a hero
who leads an army, the success chance is halved.  If you go after
a king, you may be able to bag a certain percentage of his
treasury (try it if you want to find out how much.)  If a thief
fails in an attempt to steal, he won't necessarily get caught
(the chance to avoid capture rises with the level of the thief.)
   Monsters have a chance of hiding a magic item where it can't
be found (e.g. sleeping on it.)  A creature of average intelligence would
have about a 10% chance of hiding it per stealing attempt, whereas a smarter
monster could have a 25-50% chance.

[5.7]  Scouting Tactics
  When you Scout a feature, if you talk to the monster within, it
will normally allow you to examine the feature close enough to
investigate any "Special" function the feature may have.  If you
use some other type of tactical plan, you may be told that the
Special is there, but not find out what it does.  For example, if
you Steal and Scout, there's a 33% chance of not finding out.  If
you Flee and Scout, this chance is 67%.

[5.10]  Battle Duels
   To clarify the rule on duels at battles:  if you want to refuse a challenge
to a duel by an enemy commander, the *first* tactic in the encounter plan
must be a Flee.  If it's any other place in the plan, the computer will
assume you want to fight it out before fleeing.  However, if you have a Flee
order *anywhere* in your encounter plan, you won't challenge for a duel.

[6.2]  Movement and Transport
   Camels and Elephants are considered mounted units for transport purposes
and can only be carried by ships one at a time.
   Flying units are not affected by the March and Naval abilities.

[7.0]  Battles with Neutral Heroes
   If you attack a neutral province, and another player attacks it in the
same phase, or attacks while you are still contesting the province, either
player may be first to battle the defenders. Your chances are proportional
to how many armies you have.

[7.1]  Leaders Appearing at Battles
  If a character who leads no armies is present in a province
where a battle occurs, he will appear at the battle to take over
in case the supreme commander dies (but will not have to fight a
duel).  He will not appear if there is no supreme commander
already at the battle for his side.

[7.2]  Battles Explained
  For Druidic kingdoms, if a monster in a province where a battle
is being fought is closer in alignment to Druidic than to the
player he is fighting, it may come to help the Druidic cause.  A
very powerful monster in a 1-column battle in mountains may even
have a better effect than the fanaticism sometimes given to
armies of Good alignment.
  Also, if a character of Druidic alignment succeeds in Talking
to a monster, it may be more willing to assist him.
   There's a summary of factors affecting army strength on the AK Charts.
The entry "Multiply result by special factors" lists factors which are
multiplied, not added together (e.g. if you have both the Defense and
Exploration bonuses, your strength is multiplied by 1.25 x 1.25 = 1.5625.)
   To explain the events in battle reports, they are basically randomly
determined as the turn is processed.  Each random event can as much as double
the strength of the affected force (but most only multiply it by a factor of
less than 1.5).  The first random event affects the whole battle, while
succeeding events affect one column in the battle line.
  Generals are sometimes able to take account of elephant performance and
the nemesis effect when lining up their units.  The chance of being able to
make a switch in any column is (TacticalAbility / LineLength).  Switches
can only be made within the same column, and the defender always gets the
last chance to switch.  The switch will only be made if the army strength of
the current front-line unit is less than a rearward unit, after adjustments
are made for all nemesis effects.

[7.5]  Aftermath of Battles
   A unit has a maximum chance to improve in quality at a battle if it is
adequately led.  If it's lowered to a Green or Depleted unit because of
insufficient Druidic ability, it has 60% and 20% of the normal chance to
improve in quality.
   If you kill an enemy general in a duel, the troops will usually carry his
body with them in their retreat.  That would be the reason why you don't see
his grave in the province of his death.

[7.6]  Contested Provinces
   The rules say "it's illegal to move from the contested province to an
unfriendly province".  However, an unowned province, or a provinced owned by
an independent hero, is not considered unfriendly for the purposes of this
rule.

[7.6]  Army Outflanking
  If a battle line is shorter than the terrain allows, the
flanking second-line units of a force which is superior in
numbers may outflank the enemy force. If they do that, they count
as 100% strength instead of 50%.

[10.1]  Regular-AK Titles
  A couple of rules for the Super-AK variant are also used in the
regular 8-11 player games.  When you gain an Office, a special
ability may be given to you for as long as you hold it.  Some of
the additional "Titles" are also used, but they don't give you
any added votes.
  If you lose your home province and you have less than 6 armies,
you can continue to play at half price.

[10.2]  Electing an Emperor
   Rules clarification:  The wording of the rulebook is unclear regarding
the election of an emperor.  Section 10.2 should add, "If the players vote
for someone other than the player with the largest tax base, that player
becomes Emperor instead."

[10.4]  Time Limit
  There is a time limit for all AK
games (as the people of the world gradually put more pressure on the kings to
resolve the political situation).  On turn 25, you need 50% of the world's
taxbase to become world emperor or call an election; this decreases by 5% each
turn, so that by turn 30 you need only 25% of the world's taxbase.  When your
turnsheet says that the moves are due May 1 or later, you'll know this rule
is in effect for your game.


[ARMY TYPE TABLE]
  Light Cavalry will have no adverse terrain.  Cross out the
"Jung, Mtns, Sea" entry for them on the Army Type Table.
  For warg riders, make Forests home terrain (those poor orcs, their
phalanxes suck in both Forests and Jungles.)


[TEMPER TABLE]
  The following effects are added to the temper table:

  -Cautious: Add 10% to the chance of success for fleeing.
  -Coward:   "Bluff" ability: In battle duels, the Coward makes excuses 2/3
of the time ("warhorse is sick", etc.), thus avoiding the 25% demoralization.
The coward's "Bluff" ability is only used when the character actually
enters the duel (in other words, when an "FL" is not at the start of his
encounter plan.)  It is used only when the coward has "refused to enter
combat" according to the temper table.


[11.0] SPECIAL ALIGNMENTS

  Divine:  You are a charismatic, magical and holy offspring from
the union of a god and mortal.
  All troops have 50% fanaticism.
  Add 1 to your King's White Magic after selecting skills.
  The heroes you begin with are Good Your aptitude for Necromancy
starts at zero .
  Whenever your King Resurrects a hero, his alignment becomes
Good, thus enabling you to gain a character at reduced pay.
  A Divine King can cast  Resurrection on one of his living
characters to turn him into a Good  character (but can't cast it
on a character he doesn't own.)
  Divine kings pay heroes as if the Divine King is Good.



  Undead:  You are a young Vampire, a former member of the nobility
who had the misfortune to take the wrong turn into a haunted
graveyard.  Now, you lead all Anti-Holy forces in their evil
crusade for world mastery.
  You may Break Treaty just like an Evil King.
  All Skeletal Armies have 100% fanaticism.  These armies are
transferrable when being taken over BY an Undead character, NOT
when transferred from an Undeadling to a character of another
alignment.  Also, one of your starting armies will begin as a
Skeletal army.
  Add 1 to your King's Necromancy after selecting skills.
  The heroes you begin with are Undead and Evil.
  Your aptitude for White Magic starts at zero.
  All spells which have a special effect on Undead monsters have
the same effect on Undead characters (Spiritwrack, Holy Symbol,
Kill Enemy, Hand of Death, Control Undead).
  When cast by an Undead character, the Charm spell is a
Necromantic spell (not a Psychic spell.)  When an Undead King
(not a Hero) Charms a hero (as  an Action spell only), he also
turns Undead.  You MAY Charm your own character.
  Characters with advanced skills are more resistant to being
turned undead (although the cast chance itself is not lessened.) 
For these characters, corruption occurs gradually:  alignment
will change by 1-3 steps per spellcast.
  Undead characters can be resurrected if they die, in which case
they become the same alignment as whoever resurrected them
(except for an  Undead King.)

  The following rules apply to both alignments: 

  They suffer a reduction per alignment-difference of 20% on the
Alignment Table.  Divine is 1 step above Good, Undead is 1 step
below Evil.
  Only about 40% of heroes will serve these alignments. 
  You can't start with an ability if you have aptitude-0 in it.
  No more than one King of each special alignment is permitted
per game.  The player should list an alternate alignment in case
the special alignment is already taken.
  A King of a special alignment may enter Valhalla for Good or
Evil, but does not receive visits from Valhalla.
  To help balance play, if you come adjacent to one, you will be
told the king's alignment in your Diplomacy report.


[12.0] ADVENTURER-KINGS VARIANTS

[12.1] SUPER-AK VARIANT

1. There are about 28 players per game, 4 from each alignment. 
Players will need to pick an alternate alignment in case the one
they want is already filled.  The map will be 30x15 provinces, up
from the current 18x9.  There will be about 1000 armies, 250
leaders and 250 features.  A feature will sometimes attract
another monster after its current occupant has been slain.

2. In addition to the Imperial Offices, there are about 35 new
"Royal Titles" such as "Lord of the Were-Beasts" and "Ranger of
the Plains".  I won't reveal all of the specific titles, but here
are the major groupings:

  7 Titles for the leader of each alignment
  11 Titles for being the primary leader of each racial type
  6 Titles for protecting homelands of each terrain type
  About 5 Titles related to military achievements
  About 5 Titles related to personal combat
  About 4 miscellaneous Titles

  Each Title is worth 1-5 victory points.  The way each Title is
gained is up to you to discover.  When elections are held, or in
determining whether the 55% mark has been reached, you get added
votes for Offices, Titles and magic items.  Each victory point
counts the same as five tax points in a vote (your votes are not
lessened if there's any difference in alignment between you and
the leader for World Emperor.)
  Each Title has 1-3 ways to acquire points for it. There's a
certain minimum  number of points to qualify for each Title. 
When you reach that minimum, and your character has at least half
the points of the leader for that Title, the Title will be
mentioned in your Imperial Office Report.  Each Office and Title
comes with a certain power which is given to you when you are
number one in the race for it.

3. When an alignment has conquered 55% of the world, a vote is
automatically held the next turn.  They can then elect one of
their own if they want to, or continue to fight it out.

4. For Scientific Treating, you have a lesser chance of
exchanging sage discoveries with a King of a different alignment
(subtract 40% per step of alignment difference.)

5. At the start of the game, players will be told which Kings are
of the same alignment, but not where they are or who plays the
position.  You can get a team together to play the same alignment
if you want, but each alignment is scattered around to avoid
ganging-up situations.


[12.2] "EUROPEAN" VARIANT

  This middle-ages "European" game begins around the year 1000
AD.  A player starts with knowledge of the provinces surrounding
his kingdom, up to 3 provinces distant from his home province. 
Each player knows the address and phone number of adjacent
players at the start of the game.
  All Light Cavalry is increased to Strength-3, Cost-3 to reflect
the improvement in light cavalry over the ancient-era light
cavalry which serves as the model for light cavalry in
Adventurer-Kings.  This change is ONLY for the "Europe" variant! 
Each country gets a special bonus to one or more abilities,
reflecting their historical strength.
  The following positions are available (if two players want the
same position, the decision is by random die-roll, so you should
list the positions you want in order of priority):

Cordoba Caliphate (Spain)	Byzantine Empire
Normandy/France	                Caliphate of Baghdad
England	                        The Seljuq Turks
Germany	                        The Mongols
Papal States	                Kievan (South) Russia
Magyar Kingdom (Hungary)	Novgorod (North) Russia


[12.3]  EARTH VARIANT
  Here is the updated description for the Earth Variant:

  This special "Earth" variant of Adventurer-Kings is set in the prehistoric
Ice Age, where 20 would-be emperors have been drawn from different
historical periods to square off against each other.  You rule such an
Empire in its initial stages, about to embark on a campaign to unify
your region, then conquer the known world!
  Special Rules:

  -The Light Cavalry for the Earth game is modeled on the bow-armed cavalry
of the Turks and Mongols in the 11th to 14th centuries.  They were better
armed and trained than the Greco-Roman LC that is used in regular games of
AK. Their strength and pay is 3, not 2, and they have no adverse terrain.
  -There are some sea areas with islands in them.  Islands are shown on
the map as land hexes with a blue fringe on each side.  These provinces are
considered to have two terrain types (one Sea, while the other type is
some other terrain.)  If an army is fighting in an island, it will normally
fight at its Sea strength, but if that is adverse terrain, it will fight at
its land strength.  Supreme commanders use their naval ability, not tactical
ability, in islands.
  -Earthquakes are legal on islands.
  -For all other purposes, islands are just like sea.  Movement through is by
sea, and if there is no battle when you conquer an island, no
extra movement points are expended.
  -When your map shows a blue zone between two non-island land hexes, there
is sea between them, so that you can move naval forces between them, but
not land forces unless by transport.  If the blue zone continues along two
hexsides, you can sail from that land hex to the next land hex along the
blue zone, but that's the only way you could move between land hexes.
Only versions 22+ of IBM Saga will show the blue zones, so if you don't
have it and can't get it, you need to receive printed maps by mail.
A Part Sea spell on either side of a blue zone will enable crossing it
overland, and prohibit entry from another land hex by sea units.
  -There are places on the map where you can move ships from one ocean, into
an isthmus such as Panama, and then to the other ocean.  Canals are always
assumed to exist to allow this to happen, or else you can just look at your
Fleets as being Viking longships, which can be portaged overland somewhat.
  -The map wraps around on left and right edges, but is prohibited "Ice Cap"
terrain at the top and bottom.
  -Each country gets a bonus in one or more historical abilities.  The bonus
applies to both ability and aptitude, with a maximum starting skill of 4
(for you and your starting heroes only.)  You also may have some starting
Sage Discoveries and perhaps other benefits, although the Elder Gods may
not give you each and every Discovery that your Empire historically possessed.
  -Each player starts with the phone number and address of nearby kings.
  -An element of mystery will be added by randomly placing the "lost continent
of Atlantis" in one of the ocean areas.  One, maybe two players starts there,
with little or no prior contact with the outside world.
  -Some empires start 2 provinces away from each other, by design.
  -You may change one of your king's starting abilities, after looking at the
abilities you start with.  If you realize your race is wrong for the terrain
around you, that can be changed also.  If the GM had to change your alignment
to balance the game, you may change one additional ability.
  -For the next Earth Variant, I will probably add Japan and Indonesia, which
are not covered in the current game.  If you would like to be in the 21-day
game, give 3 positions that you want to play, in order of preference.
If you ask for a first preference for your starting position and don't
get it, you may change one of your king's starting abilities.  Also, please
state one alternate alignment in case the one you pick is filled.

  Persia                Rome                    the Norse Explorers
  India                 the Rus Vikings         the Hudson Bay Company
  China                                         the Indians
  the Huns              Carthage                the Eskimos
  the Mongols           Egypt                   
  the Manchus/Siberia   the Zulus               the Amazon Queen
                                                the Aztecs
  Polynesia/Australia   Atlantis                the Incas
  Japan
  Indonesia

  Concerning the "blue zone" hexsides I mentioned above, sometimes they may
only be partly blue, and partly seem to be connected by land.  In this case,
you should still assume that the entire hexside is impassable to land units.


[13.0]  PLAYER RATINGS

   Not that it's very important in the Great Scheme Of Things, but it's fun
and serves to track your improvement as a player.
   The ratings are done much like the U.S. Chess Federation's method.  Each
beginning player is given an "unknown quality" rating.  The ratings are
calculated so that a player who is 400 points higher than an opponent, will
best him nearly 100% of the time.  The main thing that matters in your rating
is how many "Imperial Office Points" you score in a game.  No added bonus is
given for being the highest scorer in the game.
   A certain minimum number of games is needed to achieve high ranking, so
that players who "get lucky" or have weak opponents in a few games, will not
be given premature honors.  The following chart shows the 9 possible levels
you can attain:

                               Minimum Games
  Rating:     Level            Completed
  ----------------------------------------------
  > 1600:     Emperor/Empress      5
  1500-1599:  King/Queen           4
  1400-1499:  Duke/Duchess         3
  1300-1399:  Count/Countess       2
  1201-1299:  Baron/Baroness       1
  1100-1200:  Knight               1
  1000-1099:  Adventurer           2
  900-999:    Squire               3
  800-899:    Stable Hand          4
  700-799:    Lap Dog              5
    < 700:    Vermin               6

   The rating for Account #0 (dropouts) is about 900.  Some good players
drop below 1000 because of bad luck (or maybe they just need to improve their
diplomacy...)  Also, some players use the game more as an adventure than in a
competitive sense, so they may play well according to their own goals, yet not
rack up a lot of points.
   The higher the quality of the players you best, the faster you will rise
in the rankings.  If you best someone who is 400 points lower than you, no
credit is given at all.  Your rating can also rise or fall even when you're
not playing, depending on the computer's ever-changing assessment of the
strength of your opponents.
   If you play 6 games, your worst game will be dropped from your game
history.  Standby games do not generally count either for or against you
(although past standby games may be included in current ratings if the player
brought them up to a 100% strength/pay rate.)  Also, games before AK-35 do
not count, because I don't have the records any more.  If you dropped out of
a game before 1992, the computer didn't remember your name so you you're off
the hook for those ancient failures.  But not in future dropped games!
   "Emperors", "Kings" and "Dukes" will be honored in the "GAME NEWS"
section about every 3 months.  They are automatically invited to the annual
winter "King of Kings" game.  Your rating will also appear on top of your turn
sheet quarterly, and in final gameturns, once the rating system is integrated
into the turn-processing program (if you want to know what it is now, just
ask and I'll look it up.)
   Lastly, once you attain a title of "Count" or above, it is granted for a
lifetime.


