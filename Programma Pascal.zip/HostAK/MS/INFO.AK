THE STORY OF ADVENTURER-KINGS...

  Long ago, the world was reigned over by a great Emperor who enforced justice
and maintained world peace.  But the Empire was torn apart by the petty
disputes of small-minded nobles, and the world plunged into a dark age of
barbarism.  After centuries of warfare, strong kings who dream of a second,
even greater Empire have begun to emerge in different parts of the world.  You
are such a King.  Your goal is to see the Empire reunited, and maintained by
the awarding of high offices to those who have demonstrated the most merit for
such an honor, regardless of their race or creed.


THE GAME OF ADVENTURER KINGS

  Adventurer Kings is an exciting game of imperial conquest, role-playing and
fantastic adventure, set in a medieval world filled with magic, treasure,
monsters and armies.  It can be played on the InterNet, CompuServe or
virtually any electronic mail service, and can also be played by postal mail
or disk-mailer.  It's classed as a "play-by-mail" or "PBM" game, of which
there are presently about 150 titles being run world-wide.
  There are 8 to 30 players in each game. A player controls one King, his
armies and treasures, and any Heroes who he hires to serve him.  Each turn, a
player writes a set of orders (moves) for his "Adventurer King" (or Queen, for
that matter) and his Heroes.  These moves cover the Kingdom's activities for
one year in the medieval world.  The game lasts about 20 to 30 turns.
  Many avenues of play are available.  Will you send forth your armies in an
attempt to become World Emperor?  Will you unsheath your sword and brave the
dangerous, treasure-laden lairs defended by terrible monsters?  Or will you
become renowned for your wisdom, and achieve the post of Esteemed High
Chancellor of the Empire?  All of these are possible in Adventurer Kings.
  Only one thing is certain.  Only a King who is courageous enough to seek out
the adventure that awaits him, yet wise enough to know when and where to
strike, can attain the prizes which call to him: Imperial Offices with which
he can dominate the world, and at the last, a journey to Valhalla at Odin's
behest, to carouse and make merry with the greatest adventurers and mightiest
warriors of all time.


FASCINATING DEPTH, BUT EASY TO LEARN

  The rules are fairly compact in size (the rulebook is about 24 pages), but
the game is still a challenge to master because of the cleverness needed to
outwit your opponents.  It's also a role-playing game, and characters can
develop many different skills and interests:

  -7 character alignments (Divine, Good, Druid, Neutral, Pagan, Evil, Undead)
  -4 character tempers (Cowardly, Cautious, Brave, Berserk)
  -15 different abilities, such as Tactician, Illusionist or Thief
  -8 Imperial Offices to strive for, and a host of lesser Titles to acquire
  -25 magic spells, 60 magical artifacts
  -15 army types and 10 races (Humans, Elves, Dragons, etc.)
  -60 technological discoveries

  To give new players a fair chance, we regularly start "all-beginners" games
of Adventurer-Kings.  These games don't include anyone who has even played a
trial game of Adventurer Kings.  It's better for beginners than joining a
typical game with lots of veteran players, which is a bit like throwing
yourself into a shark pool!  The GM is also available to give advice and
answer any strategy questions you may have.


ROLE-PLAYING CAMARADERIE

  One of the most often quoted benefits of the PBM hobby is the near- endless
network of game-world allies and enemies -- all real-world friends -- that can
be made from around the country and the world. Most players are intelligent,
fun-loving people looking to have a good time with an exciting challenge. 
Interaction with other players can include role-playing fun, exchanging
information and wisecracks, making joint plans with allies, and sly diplomatic
maneuvering.  Just one game of Adventurer-Kings can liven up your email box
with such entertainment for an entire year!
  When you sign up to play Adventurer-Kings, you're automatically included in
the "International PBM Club", which has its own special International
newsletter, International games, and a ratings system for players around the
world.


HIGHLY RATED AND INTERNATIONALLY POPULAR

  Growing for over 5 years now, Adventurer-Kings is the highest-rated, most
popular fantasy/wargame in the market, as confirmed by the subscriber polls of
"Flagship" gaming magazine.  Sweeping the world with fun and excitement, it is
now licensed to Game Masters in the USA, England, France, Holland, Italy
and Australia, and it's still growing!  With Adventurer Kings, you
would truly be playing with a world of gaming friends. You have your choice of
reading your turn reports in English, French, or Italian, and we're taking
steps to translate it into other languages as well.
  Here's a list of current Adventurer-Kings GMs:

  USA: David Snell, Ark Royal Games [71750,1153]
  USA: Debbie & Bob Thomson, Llucky Llama Games [74044,325]
  Holland and Germany: Paul Hartmann, PBM Express [100141,404]
  United Kingdom: Neil Harris, Ventura Games [100601,3053]
  France: Roland Danard, Productions Roland Danard [73653,574]
  Italy: Roberto Flaibani, Strategia e Tattica [>INTERNET:MC3547@mclink.it]
  Australia: Peter Catling, Roma Games [>INTERNET:RomaGames@b022.aone.net.au]


  If you're on the Internet, you should convert an address such as
"71750,1153" to "71750.1153@compuserve.com".  Or, check out our Home Page,
at http://www.mclink.it/com/agonistika.  And if you live in a country currently
without an Adventurer Kings GM, and you think you could provide high-quality
customer service, perhaps you too could become a GameMaster.


WELL-WRITTEN AND GRAPHICAL

  If you play by electronic mail, you get the "Saga" program with its colorful
screen map and easy turn-report viewer.  If you play by postal mail, the turn
reports are laser- printed, with custom-printed color maps.  You'll also
receive a bimonthly newsletter, at no extra charge.
  The printed rules for Adventurer-Kings are well organized and illustrated.
There are 5 to 20 pages of interesting descriptions of battles and other
events in every turn report.  Here are some examples:

  "On the right wing, the 197th Axemen faced the 194th Phalanx.  The 117th
Dragons soared over the 194th Phalanx and attacked without mercy.  In this
engagement, the battle pennon of the 197th Axemen was captured in a surprise
attack.  Some were discouraged, yet a few others redoubled their efforts to
regain their prized trophy.  The 197th Axemen battled with the 194th Phalanx
and fought courageously, but was steadily pushed back..."

  "The wet spring was followed by early summer.  I approached the Tomb with
every intention of overcoming it and whatever guardian lay within.  I
encountered the Vampire.  I drew out my Psychic Flail.  Gesturing with my
arms, I orchestrated supernatural forces of magic, casting a Holy Symbol
spell.  A golden mist in the shape of a cross formed around me.  The spell
caused the Vampire to shriek in agony and inflicted 9 damage points. The
Vampire's spell was disrupted by the event.  Raising my hands high in the air,
I cast a Psychic Blast spell, projecting psychic waves of stunning force
towards the Vampire.  The Vampire stood dazed, stunned out of its mind..."


HOW THE GAME IS PLAYED

  Each new player receives a rulebook that outlines the possible orders that
can be issued.  The rulebook tells you how to request a "game setup", your
starting position in the game.  Whenever the game company gets enough players
to start a new game, the "setup report" will be sent to you, detailing the
characters, armies and provinces you own in the game-world.  Each game-world
generated by the computer is completely unique.
  The setup report will mention a due-date, on which all orders received from
the players are processed together by the GM. The time allowed to write your
orders (the "turnaround time") varies from 1-3 weeks, depending on how fast
you want to play.  Each set of orders you send in is called your "turn", and
the processing of all the players' orders is called the "gameturn".
  The results of your orders are written in a "turn report", outlining what
happened to you, and showing the current status of your Kingdom in informative
charts, and colorful maps of all parts of the world that are known to your
Kingdom.  The turn report also tells you what you've detected of the
activities and plots of your rivals.  A key part of the fun is the suspense as
you try to piece together what the other players are up to (if you want to
find out what's happened outside your own areas, it's a good idea to contact
other players and compare notes.)


VICTORY

  Each game has "victory conditions" which can be achieved in 20-30 turns,
although you can also play "just for fun".  When someone achieves the victory
conditions, the game ends and everyone gets a final turn report, including the
standings for all players.
  There are a total of 8 major Imperial Offices, each of which will be awarded
at the end of the game to the character who has piled up the most Merit Points
for the office.  The highest office is World Emperor, awarded to the player
who has the largest tax base support at the end of the game.


ADVENTUROUS GLORY!

   During your reign, you will be visited by great Heroes from Valhalla such
as Hercules or King Arthur.  And if you succeed in your goals, whatever they
may be, you too will be inducted into Valhalla when the game ends!
  Each player is given a rating, reflecting his skill and success in the game.
As in chess, each beginning player is given an "unknown skill" rating of 1200,
and can go up or down from there.  The ratings are calculated so that a player
who is 400 points higher than an opponent, will best him nearly 100% of the
time.  The number of victory points you score in your games determines your
rating.
  The following chart shows the possible levels you can attain:

  Rating:     Level
  ----------------------------
  > 1600:     Emperor/Empress
  1500-1599:  King/Queen
  1400-1499:  Duke/Duchess
  1300-1399:  Count/Countess
  1201-1299:  Baron/Baroness
  1100-1200:  Knight
  1000-1099:  Adventurer
  900-999:    Squire
  800-899:    Stable Hand
  700-799:    Lap Dog
    < 700:    Vermin


VARIETY AND FLEXIBILITY

  PBM games let you to take part in ambitious scenarios, rich in color and
detail, and populated with numerous players and non-player characters. 
Playing board games at home limits you to your circle of gaming friends.  With
Play-By-Mail, the sky's the limit!
  You can play PBM at your own convenience, filling in the otherwise boring
moments in life.  Over breakfast, in the canteen, travelling by train or ship,
waiting for an appointment - you can always take out the latest turn report
and spend a few moments brooding on your plans to conquer Medieval Europe or
win the crown of a mythical kingdom!  So long as you can send and receive mail
or email, you can play-by-mail.  PBM spans the globe. You can send the GM your
orders by mail, email or fax, and have the turn results sent to you any way
you want.
  Do you own an IBM, Atari-ST, MacIntosh or Amiga computer?  If so, we can
give you "Saga", the best PBM player-assistance program in existence (and,
it's free!)  It displays your turn report in an entertaining way, displays a
colorful map, and it helps to screen out errors in your orders, such as typos
or rules oversights.  You can play by modem, or use it to play by postal mail
via disk-mailer.
  You can try many different types of games:

  -7-day, 14-day and 21-day games
  -All-email games, where no postal players are allowed
  -Limited-diplomacy games, where nobody knows the addresses of other players
  -Team games, where you and a friend can play together.
  -All-beginner games, to give new players an equal chance at victory.
  -All-prepaid games, minimizing the number of players who drop out.
  -Team "National Challenges" (Australia vs. USA, etc.)
  -World Championships, and "Olympic Games" held every 4 years.
  -The "European variant", played on a map of Europe circa 1000 A.D; or the
"Earth Variant", played on a map of the entire world, where each player plays
a famous civilization from history.
  -A "Kill the GMs" game, where a GM (or designated representative) from each
company takes part, and players get bonus points for capturing and holding the
home province of any GM other than their home-country GM.


VALUE AND CUSTOMER SERVICE

  We've always been highly rated for customer service.  And, we're not afraid
to admit that sometimes we make mistakes (as do all PBM companies.)  When that
happens, every effort is made to correct it.  There's no stonewalling or
slip-ups, because the same guy who programmed the game, also moderates it, and
is there to answer the phone.  But however the game truns out for you, your
satisfaction is GUARANTEED.  If, after playing 3 turns of Adventurer- Kings,
you don't agree that it's a great game, we will happily refund every penny
you've sent us.  And if you do find some fault with the game or the GM's
service, we urge you to let us know how to serve you better.
  You can download the rules and programs for Adventurer-Kings for free.  The
optional printed rules package costs $5.00.  Your first setup in a game is
free, and each turn thereafter costs $5.00, giving you hours of enjoyment - a
better value than most hobbies!  You can read the turn reports offline, so
your online charges will be comparatively minimal.  Although the game can last
for up to a year, you're not obliged to keep playing if you want to stop,
though if you constantly start and leave games you might be spoiling the fun
for some of the other players.
  There are also prepaid rates for games of Adventurer-Kings.  The basic rate
is $70.00 (plus $5 for the setup charge), for a game that normally lasts 20 to
30 turns.


INTERNATIONALLY LICENSED TO THE FOLLOWING COMPANIES:

America:      Llucky Llama Games
              80-Q N. Cabrillo Hwy. #226
              Half Moon Bay  CA
              94019-1667

              Ark Royal Games
              14332 126th Ave. NE, Suite B-203
              Kirkland, WA  98034
              Phone: (206)-820-2398

Holland&      The PBM Express
Germany:      Postbus 885
              3300 AW Dordrecht

United        Ventura Games
Kingdom:      P.O. Box 14
              Aldershot, Hants
              GU12 4XN

France:       Productions Roland Danard
              1 square Albert Einstein
              91000 EVRY

Italy:        Strategia e Tattica
              Via Pisacane
              6 - 00152 Roma

Australia:    Roma Games
              P.O. Box 1957
              Toowoomba, QLD    4350

New Zealand:  Circle Games
              P.O. Box 105-320
              Auckland City
              New Zealand

  If your country is not listed, you may still play Adventurer-Kings through
any of the listed Game Masters.


LIST OF AVAILABLE FILES

   The following is a list of files available in the approximate
order that you should download them.  The names are for files on
library 3 of the CompuServe PBMGAMES library, and may be named
differently on other boards:


  Definitely download these:
  --------------------------
   20K INFO.AK        This file (it's included in SAGA.AK, if
                      you want to download that instead.)
   50K RULEZIP.AK     Rules for Adventurer Kings, PkZipped


  If you have an IBM computer (all files archived using PkZip):
  -----------------------------------------------------------
  195K SAGA.AK       Archived IBM program and sample turn report
  200K WNSAGA.AK     Rico Mariani's "Saga for Windows" program.
   80K PRINT.AK      IBM program, prints a map (in color, if you
                     have a color printer)

  Amiga computers:
  -----------------------------------------------------------
  125K SAGAZP.AK     PKZip-Archived Amiga program and samples
    8K SAGADD.AK     An additional module, not needed if you
                     have SAGAZP.AK.

  MacIntosh computers:
  -----------------------------------------------------------
  130K MCSAGA.AK     Stuffit-Archived Mac program and samples

  Atari-ST computers:
  -----------------------------------------------------------
  160K STSAGA.AK     Archived ST program and samples


  For further information:
  ------------------------
   15K TIPS.AK        Beginner's tips
   33K ADDEND.AK      Addendum since January 1991 (all added rules
                      are also contained in rules.ak, so you could
                      skip this one.)

