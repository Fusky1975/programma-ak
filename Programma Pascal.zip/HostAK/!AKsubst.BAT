@echo on
rem AKsubst.BAT 
rem e:
 cd >temp.tmp
 type temp.tmp|what s "">nul
if "%USERPROFILE%" == "" goto NOU1
 set /P WHAT=<temp.tmp
:NOU1
 SUBST K: /D
 SUBST K: %WHAT%
 set WHAT=
 cd TP\PROSE
 cd>temp.tmp
if "%USERPROFILE%" == "" goto NOU2
 set /P WHAT=<temp.tmp
:NOU2
 SUBST T: /D
 SUBST T: %WHAT%
:end
 t:
 cd t:\
 if exist temp.tmp del temp.tmp
 k:
 cd k:\
 if exist temp.tmp del temp.tmp