rem This batch will delete mailjob.bat, cp.bat, dc.bat, hp2.bat,
rem    frontend.scr, backend.scr, gemjob.xts,
rem Assign standbys if anyone's waiting for a standby position.
rem Standbys will be auto-created if a player misses 2 turns.
rem Turn the printer on, hook it up, and feed it paper.
rem Make sure there's enough disk space for all the turn reports.
rem Do "XC.BAT" first, if you haven't already done so.
rem (And perform any other adjustments that may be needed to player positions.)
rem If you need to break out of this batch file, press Control-C.
pause
del do_stuff.bat
del dc.bat
del hp2.bat
del cp.bat
del mailjob.lab
del mi\frontend.scr
del mi\backend.scr
del mi\ak\gemjob.xts
del mi\ak\intjob.xts
REM print /q:32
rem Now put the directories and games to be processed in "do_stuff.bat"
rem Example: "tp\ak g30 gw30 g35 gw36..."
